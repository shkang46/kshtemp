/**
 * Trigger on Market_Insight_Report_Main__c. Delegates all logic to MI_MarketReportTriggerHandler.
 * After insert, the handler starts the asynchronous section-generation chain.
 */
trigger MI_ReportTrigger on Market_Insight_Report_Main__c(after insert) {
  MI_MarketReportTriggerHandler.afterInsert(Trigger.new);
}
