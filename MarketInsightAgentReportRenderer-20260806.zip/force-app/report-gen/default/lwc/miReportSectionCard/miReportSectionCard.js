import { LightningElement, api } from "lwc";

const DOCUMENT_OBJECT = "Market_Insight_Document__c";

// Guard against runaway recursion on malformed nested-list data.
const MAX_LIST_DEPTH = 6;

/**
 * Builds the document's Lightning record-page URL (the same /lightning/r/<object>/<id>/view link the
 * search_all_records action emits), used directly as an anchor href. A static URL rather than
 * NavigationMixin.GenerateUrl, which resolved to an empty "javascript:void(0);" href here.
 *
 * @param {string} recordId The Market_Insight_Document__c record Id
 * @returns {string} The record-page URL, or '' when no Id
 */
function recordPageUrl(recordId) {
  return recordId ? `/lightning/r/${DOCUMENT_OBJECT}/${recordId}/view` : "";
}

/**
 * Renders a single report section. Displays the generated content (a structured JSON block array)
 * when complete, a shimmer skeleton while generating, a dimmed placeholder while queued, and an error
 * notice with a retry button on failure.
 *
 * The content is rendered declaratively by child `c-mi-report-block` components (one per block), so the
 * component's own scoped CSS styles it — no innerHTML and no sanitization. Content__c holds a JSON
 * block array; legacy records may still hold raw HTML, which is detected and rendered through
 * `lightning-formatted-rich-text` as a tolerant fallback.
 */
export default class MiReportSectionCard extends LightningElement {
  _section;
  charts = [];

  // Cited file name -> Market_Insight_Document__c Id. Citations whose name resolves to an Id render
  // as clickable links to the document's Lightning record page; the rest stay as plain text.
  _sourceRecordIdsByName = {};

  /**
   * Map of cited file name -> Market_Insight_Document__c Id, supplied by the parent viewer. Used to
   * build a deterministic Lightning record-page URL for each matching citation.
   */
  @api
  get sourceRecordIdsByName() {
    return this._sourceRecordIdsByName;
  }
  set sourceRecordIdsByName(value) {
    this._sourceRecordIdsByName = value || {};
  }

  /**
   * The section record (Market_Insight_Report_Section__c) to render. A derived
   * `Section_Index_Display` ("N.") is added for the header, and Charts__c JSON is parsed into the
   * `charts` array for the chart renderer.
   */
  @api
  get section() {
    return this._section;
  }
  set section(value) {
    this._section = value
      ? {
          ...value,
          Section_Index_Display: `${(value.Section_Index__c ?? 0) + 1}.`
        }
      : value;
    this.charts = this.parseCharts(value && value.Charts__c);
  }

  /**
   * Safely parses the section's Charts__c JSON into an array of chart specs, each given a stable key
   * for the template iterator. Returns an empty array on missing or malformed JSON, so a bad charts
   * blob never breaks section rendering.
   *
   * @param {string} chartsJson The raw Charts__c value
   * @returns {Array} chart spec objects with an added `key`
   */
  parseCharts(chartsJson) {
    if (!chartsJson) {
      return [];
    }
    try {
      const parsed = JSON.parse(chartsJson);
      if (!Array.isArray(parsed)) {
        return [];
      }
      return parsed.map((spec, index) => ({ ...spec, key: `chart-${index}` }));
    } catch {
      return [];
    }
  }

  get hasCharts() {
    return this.charts.length > 0;
  }

  /**
   * The content blocks to render, parsed from Content__c and given stable keys at every iterated
   * level (blocks, and each block's `first` flag). Returns an empty array on parse failure or when
   * the value is not a JSON block array (see `isLegacyHtml`). Each item is `{ key, block, first }`.
   *
   * @returns {Array<{key:string,block:object,first:boolean}>}
   */
  get blocks() {
    const raw = this._section?.Content__c;
    if (this.isLegacyHtml) {
      return [];
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return [];
    }
    if (!Array.isArray(parsed)) {
      return [];
    }
    return parsed
      .map((block) => this.normalizeBlock(block))
      .filter(Boolean)
      .map((block, index) => ({
        key: `block-${index}`,
        block,
        first: index === 0
      }));
  }

  /**
   * Normalizes a raw block: defaults a heading's level and caps nested-list depth so malformed data
   * can't recurse without bound. Returns null for a non-object block so it is skipped.
   *
   * @param {object} block A raw content block
   * @param {number} [depth] Current nesting depth (for lists)
   * @returns {object|null} The normalized block, or null to skip
   */
  normalizeBlock(block, depth = 0) {
    if (!block || typeof block !== "object") {
      return null;
    }
    if (block.type === "heading") {
      return { ...block, level: block.level === 3 ? 3 : 2 };
    }
    if (block.type === "list" && depth < MAX_LIST_DEPTH) {
      const items = Array.isArray(block.items) ? block.items : [];
      return {
        ...block,
        items: items.map((item) => {
          const nested =
            item && item.list
              ? this.normalizeBlock(item.list, depth + 1)
              : null;
          return nested
            ? { ...item, list: nested }
            : { ...item, list: undefined };
        })
      };
    }
    if (block.type === "list") {
      // Depth cap reached: strip nested lists to terminate recursion.
      const items = Array.isArray(block.items) ? block.items : [];
      return {
        ...block,
        items: items.map((item) => ({ ...item, list: undefined }))
      };
    }
    return block;
  }

  /**
   * True when Content__c holds legacy HTML rather than a JSON block array (pre-migration records).
   * Detected by a leading '<' after trimming — JSON block arrays always start with '['.
   *
   * @returns {boolean}
   */
  get isLegacyHtml() {
    const raw = this._section?.Content__c;
    return typeof raw === "string" && raw.trim().startsWith("<");
  }

  /**
   * The legacy HTML to render through lightning-formatted-rich-text for pre-migration records.
   *
   * @returns {string}
   */
  get legacyHtml() {
    return this.isLegacyHtml ? this._section.Content__c : "";
  }

  /**
   * Map of cited file name -> Lightning record-page URL, derived synchronously from the record-Id
   * map. Passed down to each chart so its 출처 caption can link to the source document.
   *
   * @returns {Object<string,string>}
   */
  get sourceUrlsByName() {
    const urls = {};
    for (const name of Object.keys(this._sourceRecordIdsByName)) {
      urls[name] = recordPageUrl(this._sourceRecordIdsByName[name]);
    }
    return urls;
  }

  /**
   * The section's source citations as footer render items: each comma-separated entry of
   * Sources_Used__c, carrying its record-page URL when the file name matched a document (otherwise
   * `url` is empty and it renders as plain text).
   *
   * @returns {Array<{key:string,name:string,url:string,hasUrl:boolean}>}
   */
  get linkedSources() {
    const raw = this._section?.Sources_Used__c;
    if (!raw) {
      return [];
    }
    return raw
      .split(",")
      .map((part) => part.trim())
      .filter((name) => name)
      .map((name, index) => {
        const url = recordPageUrl(this._sourceRecordIdsByName[name]);
        return { key: `src-${index}`, name, url, hasUrl: !!url };
      });
  }

  get isComplete() {
    return this._section?.Status__c === "Complete";
  }

  /**
   * A Draft section has finished its first-pass content but is awaiting the independent verify pass.
   * Its Content__c already holds a full JSON block array, so we render that draft content (same as
   * Complete) and surface a "검증 중" badge — otherwise a Draft would show an empty card and look stalled.
   */
  get isDraft() {
    return this._section?.Status__c === "Draft";
  }

  /**
   * Whether to render the section's content blocks: both Complete and Draft carry a valid block array.
   */
  get showsContent() {
    return this.isComplete || this.isDraft;
  }

  get isGenerating() {
    return this._section?.Status__c === "Generating";
  }

  get isPending() {
    return this._section?.Status__c === "Pending";
  }

  get isError() {
    return this._section?.Status__c === "Error";
  }

  get hasSources() {
    return !!this._section?.Sources_Used__c;
  }

  /**
   * Notifies the parent that this section should be retried.
   */
  handleRetry() {
    this.dispatchEvent(new CustomEvent("retry"));
  }
}
