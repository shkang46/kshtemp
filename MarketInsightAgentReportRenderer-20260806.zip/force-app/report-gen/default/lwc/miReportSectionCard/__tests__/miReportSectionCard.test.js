import { createElement } from "lwc";
import MiReportSectionCard from "c/miReportSectionCard";

function createComponent(section) {
  const element = createElement("c-mi-report-section-card", {
    is: MiReportSectionCard
  });
  element.section = section;
  document.body.appendChild(element);
  return element;
}

// Content is a JSON block array string.
function content(blocks) {
  return JSON.stringify(blocks);
}

// Two microtasks: one for this component to render its c-mi-report-block children, one for those
// children to render their own DOM (they render in their own shadow root).
async function flush() {
  await Promise.resolve();
  await Promise.resolve();
}

afterEach(() => {
  while (document.body.firstChild) {
    document.body.removeChild(document.body.firstChild);
  }
});

describe("c-mi-report-section-card", () => {
  it("renders the section title from Display_Title__c (not the record Name) with its index prefix", async () => {
    const element = createComponent({
      Section_Index__c: 2,
      Name: "a03000000000XYZ",
      Display_Title__c: "시장 전망",
      Status__c: "Complete",
      Content__c: content([{ type: "paragraph", runs: [{ text: "본문" }] }])
    });
    await flush();

    const title =
      element.shadowRoot.querySelector(".section-title").textContent;
    expect(title).toContain("시장 전망");
    expect(title).toContain("3."); // Section_Index_Display is 1-based
    expect(title).not.toContain("a03000000000XYZ");
  });

  it("renders a Draft section's draft content and shows a 검증 중 badge", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Draft",
      Content__c: content([
        { type: "paragraph", runs: [{ text: "초안 본문" }] }
      ])
    });
    await flush();

    // Draft still renders its content blocks (not an empty/stalled card).
    const blocks = element.shadowRoot.querySelectorAll(
      ".section-content c-mi-report-block"
    );
    expect(blocks.length).toBe(1);

    // And surfaces a verifying badge so it doesn't look stalled.
    const badge = element.shadowRoot.querySelector("lightning-badge");
    expect(badge).not.toBeNull();
    expect(badge.label).toBe("검증 중");
  });

  it("renders a Complete section table via child report-block components", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: content([
        { type: "heading", level: 2, runs: [{ text: "제목" }] },
        {
          type: "table",
          header: [[{ runs: [{ text: "연도" }] }, { runs: [{ text: "값" }] }]],
          rows: [[{ runs: [{ text: "2024" }] }, { runs: [{ text: "18" }] }]]
        }
      ])
    });
    await flush();

    const blocks = element.shadowRoot.querySelectorAll(
      ".section-content c-mi-report-block"
    );
    // One block per content entry (heading + table).
    expect(blocks.length).toBe(2);
    // The table lives in the table block's own shadow root.
    const tableBlock = blocks[1];
    const table = tableBlock.shadowRoot.querySelector("table");
    expect(table).not.toBeNull();
    expect(tableBlock.shadowRoot.querySelectorAll("thead th").length).toBe(2);
    expect(tableBlock.shadowRoot.querySelectorAll("tbody tr").length).toBe(1);
  });

  it("renders legacy HTML content through lightning-formatted-rich-text", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: "<p>레거시</p><table><tr><td>1</td></tr></table>"
    });
    await flush();

    const rich = element.shadowRoot.querySelector(
      ".section-content lightning-formatted-rich-text"
    );
    expect(rich).not.toBeNull();
    expect(rich.value).toContain("레거시");
    // No structured blocks are rendered for legacy content.
    expect(
      element.shadowRoot.querySelector(".section-content c-mi-report-block")
    ).toBeNull();
  });

  it("renders no blocks when the content JSON is malformed", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: "[not valid json"
    });
    await flush();

    expect(
      element.shadowRoot.querySelectorAll(".section-content c-mi-report-block")
        .length
    ).toBe(0);
  });

  it("links every matched citation to its record page and leaves unmatched ones as text", async () => {
    const element = createElement("c-mi-report-section-card", {
      is: MiReportSectionCard
    });
    element.sourceRecordIdsByName = {
      "emerging-resilience.pdf": "a01000000000001",
      "Kearney_report.pdf": "a01000000000002"
    };
    element.section = {
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: content([{ type: "paragraph", runs: [{ text: "본문" }] }]),
      // Two matched files (both must link) plus one unmatched file (stays plain text).
      Sources_Used__c: "emerging-resilience.pdf, Kearney_report.pdf, 미발견.pdf"
    };
    document.body.appendChild(element);
    await flush();

    const links = element.shadowRoot.querySelectorAll(".section-sources a");
    expect(links.length).toBe(2);
    expect(links[0].getAttribute("href")).toBe(
      "/lightning/r/Market_Insight_Document__c/a01000000000001/view"
    );
    expect(links[1].getAttribute("href")).toBe(
      "/lightning/r/Market_Insight_Document__c/a01000000000002/view"
    );
    expect(
      element.shadowRoot.querySelector(".section-sources").textContent
    ).toContain("미발견.pdf");
  });

  it("renders all cited sources as plain text when no record ids are supplied", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: content([{ type: "paragraph", runs: [{ text: "본문" }] }]),
      Sources_Used__c: "A.pdf, B.pdf"
    });
    await flush();

    expect(
      element.shadowRoot.querySelectorAll(".section-sources a").length
    ).toBe(0);
    expect(
      element.shadowRoot.querySelector(".section-sources").textContent
    ).toContain("A.pdf");
  });

  it("marks only the section's first block so its heading top margin drops", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: content([
        { type: "heading", level: 2, runs: [{ text: "대제목" }] },
        { type: "heading", level: 3, runs: [{ text: "소제목" }] }
      ])
    });
    await flush();

    const blocks = element.shadowRoot.querySelectorAll("c-mi-report-block");
    expect(blocks[0].first).toBe(true);
    expect(blocks[1].first).toBe(false);
  });

  it("renders one report-chart per parsed chart spec", async () => {
    const charts = JSON.stringify([
      {
        type: "bar",
        title: "c1",
        labels: ["A"],
        series: [{ name: "s", values: [1] }]
      },
      {
        type: "line",
        title: "c2",
        labels: ["A"],
        series: [{ name: "s", values: [1] }]
      }
    ]);
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Complete",
      Content__c: content([{ type: "paragraph", runs: [{ text: "본문" }] }]),
      Charts__c: charts
    });
    await flush();

    const chartEls = element.shadowRoot.querySelectorAll("c-mi-report-chart");
    expect(chartEls.length).toBe(2);
  });

  it("renders the error content blocks with a retry button", async () => {
    const element = createComponent({
      Section_Index__c: 0,
      Display_Title__c: "섹션",
      Status__c: "Error",
      Content__c: content([
        {
          type: "paragraph",
          runs: [{ text: "이 섹션 생성 중 오류가 발생했습니다.", bold: true }]
        }
      ])
    });
    await flush();

    expect(
      element.shadowRoot.querySelector(".section-error c-mi-report-block")
    ).not.toBeNull();
    expect(element.shadowRoot.querySelector("lightning-button")).not.toBeNull();
  });
});
