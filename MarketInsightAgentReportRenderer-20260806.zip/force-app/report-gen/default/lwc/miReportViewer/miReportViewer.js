import { LightningElement, api, wire } from "lwc";
import { refreshApex } from "@salesforce/apex";
import { loadScript } from "lightning/platformResourceLoader";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getReportWithSections from "@salesforce/apex/MI_MarketReportController.getReportWithSections";
import retryFailedSection from "@salesforce/apex/MI_MarketReportController.retryFailedSection";
import DOCXJS from "@salesforce/resourceUrl/MI_DocxJs";
import CHARTJS from "@salesforce/resourceUrl/MI_ChartJs";
import { exportReportToDocx } from "./reportDocxBuilder";

const TERMINAL_STATUSES = new Set(["Complete", "Partial", "Error"]);
const STATUS_LABELS = {
  Generating_Sections: "생성 중",
  Complete: "완료",
  Partial: "일부 완료",
  Error: "오류"
};
// Which agent generated the report. Only one bundle creates reports today, so the label is fixed.
const GENERATED_BY_PREFIX = "생성 에이전트: ";
const DEFAULT_GENERATED_BY_AGENT = "Market Insight Agent v2";

/**
 * Progressive viewer for a Market Insight Report. Loads the report and its sections via a cacheable
 * wire and renders each section by status. The refresh button calls refreshApex on the wired result,
 * which re-queries the server and bypasses the Lightning Data Service cache — a plain imperative call
 * to the same cacheable method would just return the stale cached value and appear to "do nothing".
 */
export default class MiReportViewer extends LightningElement {
  @api recordId;

  // The raw wired result is retained so refreshApex can refresh exactly this provisioned value.
  wiredReport;
  report;
  sections = [];
  // Cited file name -> Market_Insight_Document__c Id, used to render citations as clickable links.
  sourceRecordIdsByName = {};
  loadError;
  isRefreshing = false;
  isExporting = false;
  _docxLibsLoaded = false;

  @wire(getReportWithSections, { reportId: "$recordId" })
  wiredGetReport(result) {
    this.wiredReport = result;
    const { data, error } = result;
    if (data) {
      this.report = data.report;
      this.sections = data.sections;
      this.sourceRecordIdsByName = data.sourceRecordIdsByName || {};
      this.loadError = undefined;
    } else if (error) {
      this.loadError = "보고서를 불러오지 못했습니다.";
    }
  }

  /**
   * Re-queries the report from the server (cache-bypassing) when the user clicks refresh.
   */
  async handleRefresh() {
    this.isRefreshing = true;
    try {
      await refreshApex(this.wiredReport);
    } finally {
      this.isRefreshing = false;
    }
  }

  /**
   * Retries the report's failed sections, then refreshes to reflect the restarted generation.
   */
  async handleRetry() {
    try {
      await retryFailedSection({ reportId: this.recordId });
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재시도 시작",
          message: "실패한 섹션을 다시 생성합니다. 잠시 후 새로고침해 주세요.",
          variant: "success"
        })
      );
      await refreshApex(this.wiredReport);
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재시도 실패",
          message: error?.body?.message || "재시도를 시작하지 못했습니다.",
          variant: "error"
        })
      );
    }
  }

  handlePrint() {
    window.print();
  }

  /**
   * Builds a Word document from the loaded report + sections (client-side, no Apex) and downloads
   * it. Lazily loads the docx and Chart.js static resources once on first use; charts are rendered
   * to images via Chart.js, so both libraries are required.
   */
  async handleExportDocx() {
    this.isExporting = true;
    try {
      if (!this._docxLibsLoaded) {
        await loadScript(this, DOCXJS);
        await loadScript(this, CHARTJS);
        this._docxLibsLoaded = true;
      }
      await exportReportToDocx(
        this.report,
        this.sections,
        this.generatedByLabel
      );
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "DOCX 출력 실패",
          message: error?.message || "문서를 생성하지 못했습니다.",
          variant: "error"
        })
      );
    } finally {
      this.isExporting = false;
    }
  }

  // ─── Derived state ────────────────────────────────────────────────────────

  get isLoading() {
    // Loading only on the very first provision (no data and no error yet).
    return !this.report && !this.loadError;
  }

  get hasReport() {
    return !!this.report;
  }

  get isInProgress() {
    return !TERMINAL_STATUSES.has(this.report?.Status__c);
  }

  get statusLabel() {
    return STATUS_LABELS[this.report?.Status__c] || this.report?.Status__c;
  }

  get statusBadgeClass() {
    const status = this.report?.Status__c;
    if (status === "Complete") {
      return "slds-theme_success";
    }
    if (status === "Error") {
      return "slds-theme_error";
    }
    // Partial and Generating_Sections both use the warning theme.
    return "slds-theme_warning";
  }

  get completedSections() {
    return this.report?.Completed_Sections__c ?? 0;
  }

  get totalSections() {
    return this.report?.Total_Sections__c ?? 0;
  }

  get showProgress() {
    return this.totalSections > 0 && this.isInProgress;
  }

  get progressPercent() {
    return this.totalSections > 0
      ? Math.round((this.completedSections / this.totalSections) * 100)
      : 0;
  }

  get hasAiSummary() {
    return !!this.report?.AI_Summary__c;
  }

  get hasStrategy() {
    return !!this.report?.Strategy_Overview__c;
  }

  /**
   * One-liner naming the agent that generated this report. Rendered in the header (and print) and
   * passed to the DOCX export.
   */
  get generatedByLabel() {
    return GENERATED_BY_PREFIX + DEFAULT_GENERATED_BY_AGENT;
  }
}
