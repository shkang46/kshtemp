import { buildChartConfig } from "c/miReportChartConfig";

// Logical pixel size of the rendered chart image. devicePixelRatio (set in buildChartConfig's
// forImage path) renders at 2x for crisp print while the DOCX sizes the image in logical points.
const PX_W = 640;
const PX_H = 360;

/**
 * Renders a chart spec to a PNG using Chart.js on an off-screen canvas and returns the image bytes.
 * Reuses the SAME config builder as the on-screen chart, so the embedded image matches the viewer.
 *
 * Timing: the config's `forImage` path disables animation, so Chart.js v4 draws synchronously inside
 * the constructor; we additionally call `chart.draw()` to force the draw cycle (which also runs the
 * white-background plugin) before capturing, so the PNG is never blank or transparent. The canvas is
 * attached off-screen (not fully detached) so Chart.js lays it out reliably, then removed.
 *
 * Must run after both the ChartJs and DocxJs static resources have loaded. Returns null (never
 * throws) on an unrenderable spec or a capture failure, so one bad chart can't abort the export.
 *
 * @param {*} spec A raw chart spec (one entry from a section's Charts__c array)
 * @returns {Promise<{data:Uint8Array,width:number,height:number}|null>} PNG bytes + logical size,
 *   or null when the spec is unrenderable
 */
export async function specToPng(spec) {
  const config = buildChartConfig(spec, { forImage: true });
  if (!config || !window.Chart) {
    return null;
  }

  const canvas = document.createElement("canvas");
  canvas.width = PX_W;
  canvas.height = PX_H;
  canvas.style.position = "absolute";
  canvas.style.left = "-9999px";
  canvas.style.top = "0";
  document.body.appendChild(canvas);

  let chart;
  try {
    chart = new window.Chart(canvas.getContext("2d"), config);
    // Force a synchronous draw (animation is disabled), running the background plugin too.
    chart.draw();
    const dataUrl = chart.toBase64Image("image/png", 1);
    const base64 = dataUrl.split(",")[1] || "";
    const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
    return { data: bytes, width: PX_W, height: PX_H };
  } catch {
    // one bad chart shouldn't abort the export
    return null;
  } finally {
    if (chart) {
      chart.destroy();
    }
    canvas.remove();
  }
}
