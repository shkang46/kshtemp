import { specToPng } from "../chartToImage";

const VALID_SPEC = {
  type: "bar",
  labels: ["a", "b"],
  series: [{ name: "s", values: [1, 2] }]
};
// "AAECAw==" decodes to bytes [0,1,2,3].
const FAKE_PNG = "data:image/png;base64,AAECAw==";

describe("specToPng", () => {
  afterEach(() => {
    delete window.Chart;
  });

  it("returns null when Chart.js is unavailable", async () => {
    delete window.Chart;
    const result = await specToPng(VALID_SPEC);
    expect(result).toBeNull();
  });

  it("returns null for an unrenderable spec", async () => {
    window.Chart = jest.fn();
    const result = await specToPng(null);
    expect(result).toBeNull();
    expect(window.Chart).not.toHaveBeenCalled();
  });

  it("renders to a PNG byte array of the expected size", async () => {
    const draw = jest.fn();
    const destroy = jest.fn();
    const toBase64Image = jest.fn(() => FAKE_PNG);
    window.Chart = jest.fn(() => ({ draw, destroy, toBase64Image }));

    const result = await specToPng(VALID_SPEC);

    expect(window.Chart).toHaveBeenCalledTimes(1);
    expect(draw).toHaveBeenCalled();
    expect(destroy).toHaveBeenCalled();
    expect(result.width).toBe(640);
    expect(result.height).toBe(360);
    expect(result.data).toBeInstanceOf(Uint8Array);
    expect(Array.from(result.data)).toEqual([0, 1, 2, 3]);
  });

  it("cleans up and returns null when capture throws", async () => {
    const destroy = jest.fn();
    window.Chart = jest.fn(() => ({
      draw: jest.fn(),
      destroy,
      toBase64Image: () => {
        throw new Error("boom");
      }
    }));

    const result = await specToPng(VALID_SPEC);
    expect(result).toBeNull();
    expect(destroy).toHaveBeenCalled();
  });
});
