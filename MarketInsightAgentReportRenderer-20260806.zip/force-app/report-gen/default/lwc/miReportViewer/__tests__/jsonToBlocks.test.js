import { jsonToBlocks } from "../jsonToBlocks";

// Light docx fakes: each constructor records the options object it was built with, so we can assert
// the converter's output tree without the real library. Enums are plain string maps.
class Paragraph {
  constructor(opts) {
    Object.assign(this, opts);
    this._type = "Paragraph";
  }
}
class Table {
  constructor(opts) {
    Object.assign(this, opts);
    this._type = "Table";
  }
}
class TableRow {
  constructor(opts) {
    Object.assign(this, opts);
    this._type = "TableRow";
  }
}
class TableCell {
  constructor(opts) {
    Object.assign(this, opts);
    this._type = "TableCell";
  }
}
class TextRun {
  constructor(opts) {
    if (typeof opts === "string") {
      this.text = opts;
    } else {
      Object.assign(this, opts);
    }
    this._type = "TextRun";
  }
}

// Convenience: build the JSON string the converter expects.
function json(blocks) {
  return JSON.stringify(blocks);
}

beforeEach(() => {
  window.docx = {
    Paragraph,
    Table,
    TableRow,
    TableCell,
    TextRun,
    HeadingLevel: {
      TITLE: "Title",
      HEADING_1: "Heading1",
      HEADING_2: "Heading2",
      HEADING_3: "Heading3"
    },
    WidthType: { PERCENTAGE: "pct", DXA: "dxa" },
    TableLayoutType: { FIXED: "fixed", AUTOFIT: "autofit" },
    BorderStyle: { SINGLE: "single" },
    LevelFormat: { BULLET: "bullet", DECIMAL: "decimal" },
    AlignmentType: { LEFT: "left", START: "start", CENTER: "center" }
  };
});

afterEach(() => {
  delete window.docx;
});

describe("jsonToBlocks", () => {
  it("returns an empty array for falsy or non-array input", () => {
    expect(jsonToBlocks("")).toEqual([]);
    expect(jsonToBlocks(null)).toEqual([]);
    expect(jsonToBlocks("{}")).toEqual([]);
  });

  it("returns an empty array for legacy HTML (unparseable as JSON)", () => {
    expect(jsonToBlocks("<p>legacy</p>")).toEqual([]);
  });

  it("maps heading levels 2/3 to heading paragraphs", () => {
    const blocks = jsonToBlocks(
      json([
        { type: "heading", level: 2, runs: [{ text: "제목2" }] },
        { type: "heading", level: 3, runs: [{ text: "제목3" }] }
      ])
    );
    expect(blocks).toHaveLength(2);
    expect(blocks[0].heading).toBe("Heading2");
    expect(blocks[1].heading).toBe("Heading3");
  });

  it("maps a paragraph to a paragraph with text runs", () => {
    const blocks = jsonToBlocks(
      json([{ type: "paragraph", runs: [{ text: "본문" }] }])
    );
    expect(blocks[0]._type).toBe("Paragraph");
    expect(blocks[0].children[0].text).toBe("본문");
  });

  it("carries bold and italic emphasis from run flags", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "paragraph",
          runs: [
            { text: "일반 " },
            { text: "굵게", bold: true },
            { text: "기울임", italic: true }
          ]
        }
      ])
    );
    const runs = blocks[0].children;
    expect(runs.find((r) => r.text === "굵게").bold).toBe(true);
    expect(runs.find((r) => r.text === "기울임").italics).toBe(true);
  });

  it("emits a line break for a br run", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "paragraph",
          runs: [{ text: "a" }, { br: true }, { text: "b" }]
        }
      ])
    );
    expect(blocks[0].children.find((r) => r.break === 1)).toBeDefined();
  });

  it("maps an unordered list to bullet paragraphs", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "list",
          ordered: false,
          items: [{ runs: [{ text: "하나" }] }, { runs: [{ text: "둘" }] }]
        }
      ])
    );
    expect(blocks).toHaveLength(2);
    expect(blocks[0].numbering.reference).toBe("report-bullets");
    expect(blocks[0].numbering.level).toBe(0);
  });

  it("gives each ordered list a fresh instance so numbering restarts", () => {
    const blocks = jsonToBlocks(
      json([
        { type: "list", ordered: true, items: [{ runs: [{ text: "a" }] }] },
        { type: "list", ordered: true, items: [{ runs: [{ text: "b" }] }] }
      ])
    );
    const ordered = blocks.filter(
      (b) => b.numbering && b.numbering.reference === "report-numbers"
    );
    expect(ordered).toHaveLength(2);
    expect(ordered[0].numbering.instance).not.toBe(
      ordered[1].numbering.instance
    );
  });

  it("nests a child list at level+1", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "list",
          ordered: false,
          items: [
            {
              runs: [{ text: "상위" }],
              list: {
                type: "list",
                ordered: true,
                items: [{ runs: [{ text: "하위" }] }]
              }
            }
          ]
        }
      ])
    );
    const nested = blocks.find(
      (b) => b.numbering && b.numbering.reference === "report-numbers"
    );
    expect(nested.numbering.level).toBe(1);
  });

  it("builds a table with a header row and body rows", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "table",
          header: [[{ runs: [{ text: "H1" }] }, { runs: [{ text: "H2" }] }]],
          rows: [
            [
              { runs: [{ text: "R" }], rowHeader: true },
              { runs: [{ text: "9" }] }
            ]
          ]
        }
      ])
    );
    const table = blocks.find((b) => b._type === "Table");
    expect(table).toBeDefined();
    expect(table.rows).toHaveLength(2);
    expect(table.rows[0].tableHeader).toBe(true);
    expect(table.rows[1].tableHeader).toBe(false);
    // Header cells are bold.
    expect(table.rows[0].children[0].children[0].children[0].bold).toBe(true);
    // rowHeader body cell is bold too.
    expect(table.rows[1].children[0].children[0].children[0].bold).toBe(true);
  });

  it("emits a caption paragraph before the table", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "table",
          caption: "표 제목",
          rows: [[{ runs: [{ text: "1" }] }]]
        }
      ])
    );
    expect(blocks[0]._type).toBe("Paragraph");
    expect(blocks[0].children[0].text).toBe("표 제목");
    expect(blocks[1]._type).toBe("Table");
  });

  it("gives the table a fixed layout with explicit, full-width column widths", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "table",
          header: [
            [
              { runs: [{ text: "A" }] },
              { runs: [{ text: "B" }] },
              { runs: [{ text: "C" }] }
            ]
          ],
          rows: [
            [
              { runs: [{ text: "1" }] },
              { runs: [{ text: "2" }] },
              { runs: [{ text: "3" }] }
            ]
          ]
        }
      ])
    );
    const table = blocks.find((b) => b._type === "Table");
    expect(table.layout).toBe("fixed");
    expect(table.width.type).toBe("dxa");
    expect(table.columnWidths).toHaveLength(3);
    expect(new Set(table.columnWidths).size).toBe(1);
    expect(table.width.size).toBeGreaterThan(0);
  });

  it("honours colspan: the grid width covers the widest row", () => {
    const blocks = jsonToBlocks(
      json([
        {
          type: "table",
          header: [[{ runs: [{ text: "A" }] }, { runs: [{ text: "B" }] }]],
          rows: [[{ runs: [{ text: "merged" }], colspan: 2 }]]
        }
      ])
    );
    const table = blocks.find((b) => b._type === "Table");
    expect(table.columnWidths).toHaveLength(2);
    expect(table.rows[1].children[0].columnSpan).toBe(2);
  });

  it("skips unknown block types", () => {
    const blocks = jsonToBlocks(
      json([
        { type: "mystery", runs: [{ text: "x" }] },
        { type: "paragraph", runs: [{ text: "본문" }] }
      ])
    );
    expect(blocks).toHaveLength(1);
    expect(blocks[0].children[0].text).toBe("본문");
  });
});
