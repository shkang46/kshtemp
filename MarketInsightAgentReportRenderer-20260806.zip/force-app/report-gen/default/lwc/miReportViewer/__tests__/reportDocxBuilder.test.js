import { exportReportToDocx } from "../reportDocxBuilder";
import { jsonToBlocks } from "../jsonToBlocks";
import { specToPng } from "../chartToImage";

// Mock the heavy relative helpers so the builder test focuses on ordering + packing.
jest.mock("../jsonToBlocks", () => ({
  jsonToBlocks: jest.fn(() => ["CONTENT_BLOCK"])
}));
jest.mock("../chartToImage", () => ({
  specToPng: jest.fn(() => Promise.resolve(null))
}));
// reportDocxStyles reads window.docx enums inside its functions; stub it to constants.
jest.mock("../reportDocxStyles", () => ({
  buildDocxStyles: jest.fn(() => ({ styles: true })),
  buildNumberingConfig: jest.fn(() => ({ numbering: true })),
  tableCellBorders: jest.fn(() => ({})),
  STYLE_IDS: { source: "ReportSource" },
  STYLES: { table: { headerFill: "FFF", cellMargin: 80 } }
}));

let toBase64Mock;
let docArg;
let anchorHref;
let anchorDownload;
let clickMock;

class Paragraph {
  constructor(opts) {
    this.opts = typeof opts === "string" ? { text: opts } : opts;
    this._type = "Paragraph";
    this.heading = this.opts.heading;
    this.text = this.opts.text;
  }
}

beforeEach(() => {
  jest.clearAllMocks();
  toBase64Mock = jest.fn(() => Promise.resolve("BASE64DATA"));
  window.docx = {
    Document: jest.fn((opts) => {
      docArg = opts;
      return { opts };
    }),
    Packer: {
      toBase64String: toBase64Mock,
      toBlob: jest.fn(),
      toBuffer: jest.fn()
    },
    Paragraph,
    Table: class {},
    TableRow: class {},
    TableCell: class {},
    TextRun: class {},
    ImageRun: class {},
    WidthType: { PERCENTAGE: "pct" },
    HeadingLevel: { TITLE: "Title", HEADING_1: "Heading1" }
  };
  // Capture the download anchor (data: URL, no createObjectURL).
  anchorHref = undefined;
  anchorDownload = undefined;
  clickMock = jest.fn();
  jest.spyOn(document, "createElement").mockImplementation(() => ({
    set href(v) {
      anchorHref = v;
    },
    set download(v) {
      anchorDownload = v;
    },
    click: clickMock,
    remove: jest.fn()
  }));
  jest.spyOn(document.body, "appendChild").mockImplementation(() => {});
});

afterEach(() => {
  delete window.docx;
  jest.restoreAllMocks();
});

const report = {
  Display_Title__c: "테스트 보고서",
  AI_Summary__c: "요약",
  Strategy_Overview__c: "전략"
};
const contentB = JSON.stringify([{ type: "paragraph", runs: [{ text: "b" }] }]);
const contentA = JSON.stringify([{ type: "paragraph", runs: [{ text: "a" }] }]);
const sections = [
  {
    Display_Title__c: "B",
    Section_Index__c: 1,
    Content__c: contentB,
    Charts__c: null
  },
  {
    Display_Title__c: "A",
    Section_Index__c: 0,
    Content__c: contentA,
    Charts__c: null
  }
];

describe("exportReportToDocx", () => {
  it("packs with toBase64String (never toBuffer/toBlob) and downloads via a data: URL", async () => {
    await exportReportToDocx(report, sections);
    expect(toBase64Mock).toHaveBeenCalledTimes(1);
    expect(window.docx.Packer.toBuffer).not.toHaveBeenCalled();
    expect(window.docx.Packer.toBlob).not.toHaveBeenCalled();
    expect(clickMock).toHaveBeenCalled();
    expect(anchorHref).toContain("base64,BASE64DATA");
    expect(anchorHref).toContain("wordprocessingml.document");
    expect(anchorDownload).toBe("테스트 보고서.docx");
  });

  it("orders content: title → AI 요약 → 전략 개요 → sections by index", async () => {
    await exportReportToDocx(report, sections);
    const children = docArg.sections[0].children;
    const headings = children.filter((c) => c.heading).map((c) => c.text);
    // Title first, then the two H1 section markers in sorted order.
    expect(children[0].heading).toBe("Title");
    expect(headings).toEqual([
      "테스트 보고서",
      "AI 요약",
      "전략 개요",
      "1. A",
      "2. B"
    ]);
  });

  it("feeds each section content through jsonToBlocks", async () => {
    await exportReportToDocx(report, sections);
    expect(jsonToBlocks).toHaveBeenCalledWith(contentA);
    expect(jsonToBlocks).toHaveBeenCalledWith(contentB);
  });

  it("does not render chart images when there are no charts", async () => {
    await exportReportToDocx(report, sections);
    expect(specToPng).not.toHaveBeenCalled();
  });

  it("inserts the generated-by label right after the title when provided", async () => {
    await exportReportToDocx(
      report,
      sections,
      "생성 에이전트: Market Insight Agent v2"
    );
    const children = docArg.sections[0].children;
    expect(children[0].text).toBe("테스트 보고서");
    expect(children[1].text).toBe("생성 에이전트: Market Insight Agent v2");
    expect(children[1].heading).toBeUndefined();
  });

  it("omits the generated-by label when none is provided", async () => {
    await exportReportToDocx(report, sections);
    const texts = docArg.sections[0].children.map((c) => c.text);
    expect(texts).not.toContain("생성 에이전트: Market Insight Agent v2");
  });
});
