import { normalizeSpec, formatNumber } from "c/miReportChartConfig";
import { jsonToBlocks } from "./jsonToBlocks";
import { specToPng } from "./chartToImage";
import {
  buildDocxStyles,
  buildNumberingConfig,
  STYLE_IDS,
  STYLES,
  tableCellBorders,
  equalColumnWidths,
  PAGE_CONTENT_WIDTH_DXA
} from "./reportDocxStyles";

/**
 * Builds a single .docx from a report and its sections (the JSON the viewer already holds) and
 * triggers a browser download. No Apex round-trip — the document is assembled client-side with the
 * docx library and saved via Packer.toBlob.
 *
 * Document order: report title → AI 요약 → 전략 개요 → each section (in Section_Index__c order)
 * as a heading, its content (JSON block array → docx via jsonToBlocks), then for each chart an image +
 * the chart's data table + a source caption. All styling is read from reportDocxStyles (the style
 * seam), so phase-2 tuning is a single file edit.
 *
 * Must run after both the MI_DocxJs and MI_ChartJs static resources have loaded.
 *
 * @param {object} report The Market_Insight_Report_Main__c record
 * @param {Array} sections The Market_Insight_Report_Section__c records
 * @param {string} [generatedByLabel] One-liner naming the agent that generated the report
 * @returns {Promise<void>}
 */
export async function exportReportToDocx(report, sections, generatedByLabel) {
  const { Document, Packer, Paragraph, HeadingLevel } = window.docx;
  const children = [];

  // 1. Report title
  children.push(
    new Paragraph({
      text: report?.Display_Title__c || "시장 인사이트 보고서",
      heading: HeadingLevel.TITLE
    })
  );

  // 1a. Generated-by one-liner (which agent produced the report)
  if (generatedByLabel) {
    children.push(new Paragraph({ text: generatedByLabel }));
  }

  // 2. AI 요약 (plain text)
  if (report?.AI_Summary__c) {
    children.push(
      new Paragraph({ text: "AI 요약", heading: HeadingLevel.HEADING_1 })
    );
    children.push(new Paragraph({ text: report.AI_Summary__c }));
  }

  // 3. 전략 개요 (plain text)
  if (report?.Strategy_Overview__c) {
    children.push(
      new Paragraph({ text: "전략 개요", heading: HeadingLevel.HEADING_1 })
    );
    children.push(new Paragraph({ text: report.Strategy_Overview__c }));
  }

  // 4. Sections in index order
  const ordered = [...(sections || [])].sort(
    (a, b) => (a?.Section_Index__c ?? 0) - (b?.Section_Index__c ?? 0)
  );

  // Pre-render every chart image in parallel (one Promise.all) so assembly stays synchronous and
  // the slowest chart, not the sum of all charts, bounds the wait. Keyed by section+chart index.
  const pngByKey = await renderChartImages(ordered);

  ordered.forEach((section, sectionIdx) => {
    const index = (section?.Section_Index__c ?? 0) + 1;
    children.push(
      new Paragraph({
        text: `${index}. ${section?.Display_Title__c || ""}`.trim(),
        heading: HeadingLevel.HEADING_1
      })
    );

    // Section content (JSON block array) → docx blocks
    for (const block of jsonToBlocks(section?.Content__c)) {
      children.push(block);
    }

    // Charts: image + data table + source caption
    parseCharts(section?.Charts__c).forEach((spec, chartIdx) => {
      const png = pngByKey[`${sectionIdx}:${chartIdx}`];
      for (const block of chartBlocks(spec, section?.Sources_Used__c, png)) {
        children.push(block);
      }
    });
  });

  const doc = new Document({
    styles: buildDocxStyles(),
    numbering: buildNumberingConfig(),
    sections: [{ children }]
  });

  // Export as base64 and download via a data: URL. Lightning Web Security wraps
  // URL.createObjectURL and rejects the .docx MIME type ("Unsupported MIME type"), so we avoid it
  // entirely; the anchor's `download` attribute still forces the .docx filename.
  const base64 = await Packer.toBase64String(doc);
  triggerDownload(
    base64,
    `${report?.Display_Title__c || "Market_Insight_Report"}.docx`
  );
}

/**
 * Renders every chart across all sections to PNGs concurrently and returns a map keyed by
 * `"<sectionIndex>:<chartIndex>"`. Rendering up front in one Promise.all keeps document assembly
 * synchronous and bounds the wait by the slowest chart rather than the sum of all charts.
 *
 * @param {Array} orderedSections Sections already sorted by index
 * @returns {Promise<Object<string,({data:Uint8Array,width:number,height:number}|null)>>}
 */
async function renderChartImages(orderedSections) {
  const jobs = [];
  orderedSections.forEach((section, sectionIdx) => {
    parseCharts(section?.Charts__c).forEach((spec, chartIdx) => {
      jobs.push(
        specToPng(spec).then((png) => ({
          key: `${sectionIdx}:${chartIdx}`,
          png
        }))
      );
    });
  });
  const results = await Promise.all(jobs);
  return results.reduce((map, { key, png }) => {
    map[key] = png;
    return map;
  }, {});
}

/**
 * Builds the docx blocks for a single chart: the pre-rendered PNG (when present), its value data
 * table, and a source caption. Mirrors what the on-screen reportChart shows.
 *
 * @param {*} spec A raw chart spec
 * @param {string} fallbackSource The section's Sources_Used__c, used when the chart omits a source
 * @param {{data:Uint8Array,width:number,height:number}|null} png The pre-rendered chart image
 * @returns {Array} docx block elements
 */
function chartBlocks(spec, fallbackSource, png) {
  const { Paragraph, ImageRun } = window.docx;
  const n = normalizeSpec(spec);
  if (n.hasError) {
    return [];
  }
  const blocks = [];

  if (png) {
    blocks.push(
      new Paragraph({
        children: [
          new ImageRun({
            type: "png",
            data: png.data,
            transformation: { width: 480, height: 270 }
          })
        ]
      })
    );
  }

  blocks.push(chartDataTable(n));

  const source = n.source || fallbackSource;
  if (source) {
    blocks.push(
      new Paragraph({ text: `출처: ${source}`, style: STYLE_IDS.source })
    );
  }
  return blocks;
}

/**
 * Builds the chart's value table (header row of series names, one row per label) as a docx Table,
 * using the shared formatNumber so the numbers match the on-screen table exactly.
 *
 * @param {{labels:string[],series:{name:string,values:number[]}[]}} n A normalized chart spec
 * @returns {object} A docx Table
 */
function chartDataTable(n) {
  const { Table, TableRow, TableCell, Paragraph, TextRun, WidthType } =
    window.docx;

  const headerTexts = ["", ...n.series.map((s) => s.name)];
  const headerRow = new TableRow({
    tableHeader: true,
    children: headerTexts.map((text) => cell(text, true))
  });

  const bodyRows = n.labels.map((label, rowIdx) => {
    const cells = [cell(label, true)];
    for (const s of n.series) {
      cells.push(cell(formatNumber(s.values[rowIdx]), false));
    }
    return new TableRow({ children: cells });
  });

  function cell(text, isHeader) {
    return new TableCell({
      children: [
        new Paragraph({
          children: [new TextRun({ text: `${text}`, bold: isHeader })]
        })
      ],
      shading: isHeader ? { fill: STYLES.table.headerFill } : undefined,
      margins: {
        top: STYLES.table.cellMargin,
        bottom: STYLES.table.cellMargin,
        left: STYLES.table.cellMargin,
        right: STYLES.table.cellMargin
      },
      borders: tableCellBorders()
    });
  }

  // Fixed layout with explicit equal column widths (label column + one per series). Autofit would
  // otherwise collapse Korean labels to one character per line, mirroring the HTML-table bug.
  const columnWidths = equalColumnWidths(headerTexts.length);

  return new Table({
    rows: [headerRow, ...bodyRows],
    columnWidths,
    width: { size: PAGE_CONTENT_WIDTH_DXA, type: WidthType.DXA },
    layout: window.docx.TableLayoutType.FIXED
  });
}

/**
 * Safely parses a section's Charts__c JSON into an array of chart specs. Returns an empty array on
 * missing or malformed JSON, so a bad charts blob never breaks the export.
 *
 * @param {string} chartsJson The raw Charts__c value
 * @returns {Array} chart spec objects
 */
function parseCharts(chartsJson) {
  if (!chartsJson) {
    return [];
  }
  try {
    const parsed = JSON.parse(chartsJson);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

// .docx MIME type for the data: URL.
const DOCX_MIME =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

/**
 * Triggers a browser download of the document via a base64 data: URL and a transient anchor (no
 * FileSaver dependency, and no URL.createObjectURL — which Lightning Web Security rejects for the
 * .docx MIME type). The anchor's `download` attribute forces the file name.
 *
 * @param {string} base64 The document encoded as a base64 string
 * @param {string} filename The download file name
 */
function triggerDownload(base64, filename) {
  const a = document.createElement("a");
  a.href = `data:${DOCX_MIME};base64,${base64}`;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
