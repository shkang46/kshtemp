/**
 * DOCX style seam. This is the ONE module to edit when tuning the look of the exported Word document
 * — fonts, sizes, colours, spacing, table borders, list indents. The HTML→DOCX walker and the
 * document builder read everything visual from `STYLES`; `buildDocxStyles()` and
 * `buildNumberingConfig()` translate that config into the docx `Document` options.
 *
 * Units (docx conventions):
 *   - run `size` is in half-points (22 = 11pt)
 *   - paragraph `spacing.before/after` and `indent` are in twips (1440 = 1 inch)
 *   - paragraph `spacing.line` is in 240ths of a line (276 ≈ 1.15 line spacing)
 *   - colours are 6 hex digits, no leading '#'
 *   - table cell border `size` is in eighths of a point
 *
 * docx enums (`LevelFormat`, `AlignmentType`, `BorderStyle`) are read off the global `window.docx`
 * at call time, so these functions must only be invoked after the MI_DocxJs static resource has loaded.
 */

// Paragraph style ids that the HeadingLevel.* helpers resolve to — must be defined or headings
// render unstyled. ListParagraph must exist or bullets/numbers may not show.
export const STYLE_IDS = {
  title: "Title",
  h1: "Heading1",
  h2: "Heading2",
  h3: "Heading3",
  listParagraph: "ListParagraph",
  caption: "ReportCaption",
  source: "ReportSource"
};

/**
 * The single editable style configuration. Tweak here in the styling phase.
 */
export const STYLES = {
  fontAscii: "Calibri",
  fontEastAsia: "맑은 고딕", // covers Hangul; Word substitutes if unavailable
  body: { sizeHalfPts: 22, color: "181818" },
  paragraph: { spacingAfter: 120, line: 276 },
  heading: {
    title: {
      sizeHalfPts: 48,
      bold: true,
      color: "0B5CAB",
      spacingBefore: 0,
      spacingAfter: 240
    },
    h1: {
      sizeHalfPts: 30,
      bold: true,
      color: "0176D3",
      spacingBefore: 280,
      spacingAfter: 120
    },
    h2: {
      sizeHalfPts: 26,
      bold: true,
      color: "181818",
      spacingBefore: 220,
      spacingAfter: 100
    },
    h3: {
      sizeHalfPts: 24,
      bold: true,
      color: "5C6770",
      spacingBefore: 180,
      spacingAfter: 80
    }
  },
  table: {
    headerFill: "F2F4F7",
    border: { style: "single", size: 4, color: "D0D5DD" }, // style maps to BorderStyle[...]
    cellMargin: 80
  },
  caption: {
    sizeHalfPts: 18,
    italics: true,
    color: "5C6770",
    alignment: "CENTER",
    spacingAfter: 60
  },
  source: {
    sizeHalfPts: 16,
    italics: true,
    color: "5C6770",
    spacingBefore: 40,
    spacingAfter: 160
  },
  list: {
    bulletRef: "report-bullets",
    numberRef: "report-numbers",
    indentPerLevel: 720, // twips of left indent per nesting level
    hanging: 360
  }
};

// Usable text width of an A4 portrait page with default 1-inch margins: 11906 − 1440 − 1440 ≈ 9026
// twips. Tables are laid out against this so columns get a fixed width rather than autofitting to
// their narrowest content (which collapses CJK cells to one character per line).
export const PAGE_CONTENT_WIDTH_DXA = 9026;

/**
 * Returns an array of `columnCount` equal column widths (in twips) that together fill the usable page
 * width. Paired with a FIXED table layout so Word honours these widths instead of autofitting.
 *
 * @param {number} columnCount Number of grid columns in the table (>= 1)
 * @returns {number[]} Equal per-column widths in twips
 */
export function equalColumnWidths(columnCount) {
  const n = Math.max(1, Math.floor(columnCount) || 1);
  const w = Math.floor(PAGE_CONTENT_WIDTH_DXA / n);
  return Array.from({ length: n }, () => w);
}

/**
 * Resolves a BorderStyle enum value from a lowercase style name, defaulting to single.
 *
 * @param {object} docx The global docx object
 * @param {string} name e.g. 'single'
 * @returns {*} A BorderStyle enum value
 */
function borderStyle(docx, name) {
  const key = (name || "single").toUpperCase();
  return docx.BorderStyle[key] || docx.BorderStyle.SINGLE;
}

/**
 * Returns the docx table-cell `borders` object (all four sides) from the style config. Used by the
 * HTML→DOCX table builder for every cell.
 *
 * @returns {object} A docx cell borders object
 */
export function tableCellBorders() {
  const docx = window.docx;
  const b = STYLES.table.border;
  const side = {
    style: borderStyle(docx, b.style),
    size: b.size,
    color: b.color
  };
  return { top: side, bottom: side, left: side, right: side };
}

/**
 * Builds the docx `Document.styles` object: document run defaults plus the named paragraph styles
 * the builder/walker reference (Title, Heading1–3, ListParagraph, caption, source).
 *
 * @returns {object} A docx styles configuration
 */
export function buildDocxStyles() {
  const font = {
    ascii: STYLES.fontAscii,
    eastAsia: STYLES.fontEastAsia,
    hAnsi: STYLES.fontAscii
  };

  const mkHeading = (id, name, cfg) => ({
    id,
    name,
    basedOn: "Normal",
    next: "Normal",
    quickFormat: true,
    run: { font, size: cfg.sizeHalfPts, bold: cfg.bold, color: cfg.color },
    paragraph: {
      spacing: { before: cfg.spacingBefore, after: cfg.spacingAfter }
    }
  });

  return {
    default: {
      document: {
        run: { font, size: STYLES.body.sizeHalfPts, color: STYLES.body.color },
        paragraph: {
          spacing: {
            after: STYLES.paragraph.spacingAfter,
            line: STYLES.paragraph.line
          }
        }
      }
    },
    paragraphStyles: [
      mkHeading(STYLE_IDS.title, "Title", STYLES.heading.title),
      mkHeading(STYLE_IDS.h1, "Heading 1", STYLES.heading.h1),
      mkHeading(STYLE_IDS.h2, "Heading 2", STYLES.heading.h2),
      mkHeading(STYLE_IDS.h3, "Heading 3", STYLES.heading.h3),
      {
        id: STYLE_IDS.listParagraph,
        name: "List Paragraph",
        basedOn: "Normal",
        next: "Normal",
        run: { font }
      },
      {
        id: STYLE_IDS.caption,
        name: "Report Caption",
        basedOn: "Normal",
        next: "Normal",
        run: {
          font,
          size: STYLES.caption.sizeHalfPts,
          italics: STYLES.caption.italics,
          color: STYLES.caption.color
        },
        paragraph: { spacing: { after: STYLES.caption.spacingAfter } }
      },
      {
        id: STYLE_IDS.source,
        name: "Report Source",
        basedOn: "Normal",
        next: "Normal",
        run: {
          font,
          size: STYLES.source.sizeHalfPts,
          italics: STYLES.source.italics,
          color: STYLES.source.color
        },
        paragraph: {
          spacing: {
            before: STYLES.source.spacingBefore,
            after: STYLES.source.spacingAfter
          }
        }
      }
    ]
  };
}

/**
 * Builds the docx `Document.numbering` config: one bullet list reference (two levels) and one
 * ordered (decimal) list reference. Ordered-list restart is handled by passing a fresh `instance`
 * per <ol> at the call site.
 *
 * @returns {object} A docx numbering configuration
 */
export function buildNumberingConfig() {
  const { LevelFormat, AlignmentType } = window.docx;
  const indentFor = (level) => ({
    paragraph: {
      indent: {
        left: STYLES.list.indentPerLevel * (level + 1),
        hanging: STYLES.list.hanging
      }
    }
  });

  return {
    config: [
      {
        reference: STYLES.list.bulletRef,
        levels: [
          {
            level: 0,
            format: LevelFormat.BULLET,
            text: "•",
            alignment: AlignmentType.LEFT,
            style: indentFor(0)
          },
          {
            level: 1,
            format: LevelFormat.BULLET,
            text: "◦",
            alignment: AlignmentType.LEFT,
            style: indentFor(1)
          },
          {
            level: 2,
            format: LevelFormat.BULLET,
            text: "▪",
            alignment: AlignmentType.LEFT,
            style: indentFor(2)
          }
        ]
      },
      {
        reference: STYLES.list.numberRef,
        levels: [
          {
            level: 0,
            format: LevelFormat.DECIMAL,
            text: "%1.",
            alignment: AlignmentType.START,
            style: indentFor(0)
          },
          {
            level: 1,
            format: LevelFormat.LOWER_LETTER,
            text: "%2.",
            alignment: AlignmentType.START,
            style: indentFor(1)
          },
          {
            level: 2,
            format: LevelFormat.LOWER_ROMAN,
            text: "%3.",
            alignment: AlignmentType.START,
            style: indentFor(2)
          }
        ]
      }
    ]
  };
}
