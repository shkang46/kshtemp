import {
  STYLE_IDS,
  STYLES,
  tableCellBorders,
  equalColumnWidths,
  PAGE_CONTENT_WIDTH_DXA
} from "./reportDocxStyles";

/**
 * Converts a section's generated content (Content__c — a JSON block array, the same schema the
 * reportBlock/reportInline LWCs render on screen) into an array of docx block elements
 * (Paragraph / Table) for the .docx export. This is the DOCX counterpart of the on-screen renderer,
 * so screen and export stay in sync.
 *
 * Block schema (see the section prompt): each block's `type` is "heading" | "paragraph" | "list" |
 * "table"; inline text is a `runs` array of { text, bold?, italic?, br? }.
 *
 * Returns an empty array for a blank value, non-JSON (legacy HTML), or a non-array root — so a
 * not-yet-migrated or malformed record never breaks the export (the section just contributes no body).
 *
 * docx constructors are read off the global `window.docx`, so this must run after the MI_DocxJs static
 * resource has loaded.
 *
 * @param {string} contentJson The section's Content__c (JSON block array string)
 * @returns {Array} An array of docx Paragraph/Table block elements (empty when unusable)
 */
export function jsonToBlocks(contentJson) {
  if (!contentJson) {
    return [];
  }
  let parsed;
  try {
    parsed = JSON.parse(contentJson);
  } catch {
    return [];
  }
  if (!Array.isArray(parsed)) {
    return [];
  }
  // A mutable counter so each ordered list gets a fresh numbering instance (restarts at 1).
  const ctx = { olInstance: 1 };
  const blocks = [];
  for (const block of parsed) {
    appendBlock(block, blocks, ctx);
  }
  return blocks;
}

/**
 * Strips control characters that produce an unopenable ("corrupt") .docx. LLM-generated text can
 * carry stray control chars; docx writes them verbatim into XML, which Word then rejects.
 *
 * @param {string} text Raw text
 * @returns {string} Text with control characters removed
 */
// eslint-disable-next-line no-control-regex -- deliberately targeting XML-invalid control chars
const CONTROL_CHARS = /[\x00-\x08\x0B\x0C\x0E-\x1F]/g;
function clean(text) {
  return typeof text === "string" ? text.replace(CONTROL_CHARS, "") : text;
}

/**
 * Appends the docx block(s) for a single content block to `blocks`. Unknown block types are skipped.
 *
 * @param {object} block A content block { type, ... }
 * @param {Array} out The accumulating block array (mutated)
 * @param {{olInstance:number}} ctx Conversion context (ordered-list instance counter)
 */
function appendBlock(block, out, ctx) {
  if (!block || typeof block !== "object") {
    return;
  }
  const { Paragraph, HeadingLevel } = window.docx;

  switch (block.type) {
    case "heading": {
      const heading =
        block.level === 3 ? HeadingLevel.HEADING_3 : HeadingLevel.HEADING_2;
      out.push(
        new Paragraph({ children: runsToTextRuns(block.runs), heading })
      );
      break;
    }
    case "paragraph":
      out.push(new Paragraph({ children: runsToTextRuns(block.runs) }));
      break;
    case "list":
      appendList(block, out, ctx, 0);
      break;
    case "table":
      for (const b of tableToBlocks(block)) {
        out.push(b);
      }
      break;
    default:
    // Unknown block type: skip (no content contributed).
  }
}

/**
 * Emits one list-item paragraph per item, attaching the bullet or numbered list reference at the
 * given nesting level. A nested `list` on an item recurses at level+1. A fresh `instance` is
 * allocated for each ordered list so sibling ordered lists each restart at 1.
 *
 * @param {object} listBlock The list block { ordered, items }
 * @param {Array} out The accumulating block array (mutated)
 * @param {{olInstance:number}} ctx Conversion context
 * @param {number} level Zero-based nesting level
 */
function appendList(listBlock, out, ctx, level) {
  const { Paragraph } = window.docx;
  const ordered = listBlock.ordered === true;
  const reference = ordered ? STYLES.list.numberRef : STYLES.list.bulletRef;
  const instance = ordered ? ctx.olInstance++ : undefined;
  const items = Array.isArray(listBlock.items) ? listBlock.items : [];

  for (const item of items) {
    if (!item || typeof item !== "object") {
      continue;
    }
    const numbering = ordered
      ? { reference, level, instance }
      : { reference, level };
    out.push(
      new Paragraph({
        children: runsToTextRuns(item.runs),
        style: STYLE_IDS.listParagraph,
        numbering
      })
    );
    // A nested list on this item recurses one level deeper.
    if (item.list && item.list.type === "list") {
      appendList(item.list, out, ctx, level + 1);
    }
  }
}

/**
 * Converts a `runs` array into docx TextRun objects, carrying bold/italic emphasis and turning a
 * `{ br: true }` run into a line break. `forceBold` makes every run bold regardless of its own flag
 * (used for table header/rowHeader cells). A block with no usable runs still yields one empty run so
 * the paragraph/cell is valid.
 *
 * @param {Array} runs The block's inline runs
 * @param {boolean} [forceBold] Force every run bold (table header / rowHeader cells)
 * @returns {Array} An array of docx TextRun objects (at least one)
 */
function runsToTextRuns(runs, forceBold) {
  const { TextRun } = window.docx;
  const out = [];
  const list = Array.isArray(runs) ? runs : [];

  for (const run of list) {
    if (!run || typeof run !== "object") {
      continue;
    }
    if (run.br) {
      out.push(new TextRun({ text: "", break: 1 }));
      continue;
    }
    if (typeof run.text === "string") {
      out.push(
        new TextRun({
          text: clean(run.text),
          bold: forceBold || run.bold === true ? true : undefined,
          italics: run.italic === true ? true : undefined
        })
      );
    }
  }

  if (out.length === 0) {
    out.push(new TextRun({ text: "", bold: forceBold ? true : undefined }));
  }
  return out;
}

/**
 * Converts a table block into docx blocks: an optional caption paragraph (docx tables have no native
 * caption) followed by the Table. Header rows repeat across page breaks and get a shaded fill; header
 * cells and `rowHeader` body cells render bold.
 *
 * The table is given a FIXED layout with explicit, equal column widths summing to the usable page
 * width. Without this, docx emits an autofit table and Word collapses each column to its narrowest
 * content — which wraps Korean/CJK text to one character per line. `colspan`/`rowspan` are honoured so
 * merged cells keep the grid aligned; the column count covers the widest row (accounting for colspan).
 *
 * @param {object} tableBlock The table block { caption?, header?, rows? }
 * @returns {Array} [captionParagraph?, Table]
 */
function tableToBlocks(tableBlock) {
  const { Table, TableRow, Paragraph, WidthType, TableLayoutType } =
    window.docx;
  const out = [];

  if (tableBlock.caption && String(tableBlock.caption).trim()) {
    out.push(
      new Paragraph({
        children: [new window.docx.TextRun(clean(String(tableBlock.caption)))],
        style: STYLE_IDS.caption
      })
    );
  }

  const headerRows = Array.isArray(tableBlock.header) ? tableBlock.header : [];
  const bodyRows = Array.isArray(tableBlock.rows) ? tableBlock.rows : [];

  // Grid width = widest row (accounting for colspan) so every row spans the full table and the fixed
  // column widths line up.
  let columnCount = 1;
  for (const row of [...headerRows, ...bodyRows]) {
    const cells = Array.isArray(row) ? row : [];
    let span = 0;
    for (const cell of cells) {
      span += Math.max(1, (cell && parseInt(cell.colspan, 10)) || 1);
    }
    columnCount = Math.max(columnCount, span);
  }
  const columnWidths = equalColumnWidths(columnCount);

  const buildRow = (row, isHeaderRow) => {
    const cells = (Array.isArray(row) ? row : []).map((cell) =>
      buildCell(cell || {}, isHeaderRow)
    );
    return new TableRow({ children: cells, tableHeader: isHeaderRow });
  };

  const rows = [
    ...headerRows.map((row) => buildRow(row, true)),
    ...bodyRows.map((row) => buildRow(row, false))
  ];

  out.push(
    new Table({
      rows,
      columnWidths,
      width: { size: PAGE_CONTENT_WIDTH_DXA, type: WidthType.DXA },
      layout: TableLayoutType.FIXED
    })
  );
  return out;
}

/**
 * Builds a single docx TableCell from a content cell. Header-row cells and cells flagged
 * `rowHeader:true` render their runs bold; header rows also get a shaded fill. colspan/rowspan
 * greater than 1 are applied.
 *
 * @param {object} cell The content cell { runs?, colspan?, rowspan?, rowHeader? }
 * @param {boolean} isHeaderRow Whether this cell belongs to a header row
 * @returns {object} A docx TableCell
 */
function buildCell(cell, isHeaderRow) {
  const { TableCell, Paragraph } = window.docx;
  const bold = isHeaderRow || cell.rowHeader === true;
  const colSpan = Math.max(1, parseInt(cell.colspan, 10) || 1);
  const rowSpan = Math.max(1, parseInt(cell.rowspan, 10) || 1);

  return new TableCell({
    children: [new Paragraph({ children: runsToTextRuns(cell.runs, bold) })],
    columnSpan: colSpan > 1 ? colSpan : undefined,
    rowSpan: rowSpan > 1 ? rowSpan : undefined,
    shading: isHeaderRow ? { fill: STYLES.table.headerFill } : undefined,
    margins: {
      top: STYLES.table.cellMargin,
      bottom: STYLES.table.cellMargin,
      left: STYLES.table.cellMargin,
      right: STYLES.table.cellMargin
    },
    borders: tableCellBorders()
  });
}
