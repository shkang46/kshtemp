import { LightningElement, api } from "lwc";
import { loadScript } from "lightning/platformResourceLoader";
import CHARTJS from "@salesforce/resourceUrl/MI_ChartJs";
import {
  buildChartConfig,
  normalizeSpec,
  formatNumber
} from "c/miReportChartConfig";

/**
 * Renders a single report chart with Chart.js (bar, horizontal bar, line, or pie) from a chart-spec
 * object, paired with a data table and a source caption.
 *
 * Chart.js (loaded from the MI_ChartJs static resource) replaces the previous hand-rolled SVG so the
 * exact same chart config can be reused to render the chart as an image in the DOCX export. The
 * paired data table remains both the accessible alternative and the representation that copy-pastes
 * cleanly into Word; any malformed spec degrades to the table-only view rather than throwing.
 *
 * Expected spec shape:
 *   { type: 'bar'|'hbar'|'line'|'pie', title, unit, labels: [], series: [{ name, values: [] }], source }
 */
export default class MiReportChart extends LightningElement {
  _spec;
  _config; // Chart.js config computed from the spec; null when the spec is unrenderable
  chartLoaded = false; // guards the one-time loadScript
  chart; // the live Chart.js instance

  // Derived render state bound by the template.
  chartType = "";
  title = "";
  source = "";
  hasError = false;
  tableHeaders = [];
  tableRows = [];

  /**
   * Fallback source citation (the section's Sources_Used__c) used when the chart spec itself omits
   * a `source`, so every chart always shows a 출처 line.
   */
  @api fallbackSource;

  /**
   * Map of source file name -> Lightning record-page URL, supplied by the section card. When the
   * displayed source matches an entry, the 출처 caption renders as a clickable link to the source
   * document's record.
   */
  @api sourceUrlsByName = {};

  /**
   * The chart specification object (one entry from a section's Charts__c array).
   */
  @api
  get spec() {
    return this._spec;
  }
  set spec(value) {
    this._spec = value;
    const n = normalizeSpec(value);
    this.hasError = n.hasError;
    this.title = n.title;
    this.source = n.source;
    this.chartType = n.type;
    this.buildTable(n.labels, n.series);
    this._config = this.hasError ? null : buildChartConfig(value);
    this.renderChart();
  }

  /**
   * The citation shown beneath the chart: the chart's own source when present, otherwise the
   * section's sources. Empty only when neither is available.
   */
  get displaySource() {
    return this.source || this.fallbackSource || "";
  }

  get hasSource() {
    return !!this.displaySource;
  }

  /**
   * The Lightning record-page URL for the displayed source, when its file name resolved to a
   * Market_Insight_Document__c record; empty otherwise.
   */
  get sourceUrl() {
    return (
      (this.sourceUrlsByName && this.sourceUrlsByName[this.displaySource]) || ""
    );
  }

  get hasSourceUrl() {
    return !!this.sourceUrl;
  }

  get hasChart() {
    return !this.hasError && !!this._config;
  }

  /**
   * Accessible description read by assistive tech, summarizing the chart in words.
   */
  get ariaDescription() {
    if (this.hasError) {
      return "차트 데이터를 표시할 수 없습니다.";
    }
    const seriesNames = this.tableHeaders
      .slice(1)
      .map((h) => h.text)
      .join(", ");
    const categories = this.tableRows.map((r) => r.label).join(", ");
    return `${this.title || "차트"} — ${this.chartType} 차트. 항목: ${categories}. 계열: ${seriesNames}. 자세한 값은 아래 데이터 표를 참고하세요.`;
  }

  /**
   * Loads Chart.js once, then (re)renders. renderChart is idempotent and also called from the spec
   * setter, so it handles both the initial load race and later spec changes.
   */
  renderedCallback() {
    if (this.chartLoaded) {
      this.renderChart();
      return;
    }
    this.chartLoaded = true;
    loadScript(this, CHARTJS)
      .then(() => this.renderChart())
      .catch(() => {
        this.hasError = true;
      });
  }

  /**
   * (Re)draws the chart on the canvas. Destroys any existing instance first to avoid Chart.js's
   * "Canvas is already in use" error, and bails until the library is loaded and a config exists.
   */
  renderChart() {
    if (!this.chartLoaded || !window.Chart || !this._config) {
      return;
    }
    const canvas = this.refs?.canvas;
    if (!canvas) {
      return;
    }
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
    this.chart = new window.Chart(canvas.getContext("2d"), this._config);
  }

  disconnectedCallback() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
  }

  /**
   * Builds the data table (headers + rows) shown beneath the chart. This is the accessible view and
   * the copy-paste-into-Word representation; numbers are formatted with the shared formatNumber.
   *
   * @param {string[]} labels Category labels
   * @param {{name:string,values:number[]}[]} series Normalized series
   */
  buildTable(labels, series) {
    this.tableHeaders = ["", ...series.map((s) => s.name)].map((text, i) => ({
      key: `head-${i}`,
      text
    }));
    this.tableRows = labels.map((label, rowIdx) => ({
      key: `row-${rowIdx}`,
      label,
      cells: series.map((s, colIdx) => ({
        key: `cell-${rowIdx}-${colIdx}`,
        value: formatNumber(s.values[rowIdx])
      }))
    }));
  }
}
