import { createElement } from "lwc";
import MiReportChart from "c/miReportChart";

// Mock the static-resource loader so loadScript resolves immediately.
jest.mock(
  "lightning/platformResourceLoader",
  () => ({ loadScript: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

const VALID_SPEC = {
  type: "bar",
  title: "판매",
  labels: ["Q1", "Q2"],
  series: [{ name: "DRAM", values: [1.5, 2] }]
};

function flushPromises() {
  return Promise.resolve();
}

describe("c-mi-report-chart", () => {
  let destroy;

  beforeEach(() => {
    destroy = jest.fn();
    window.Chart = jest.fn(() => ({ destroy }));
  });

  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    delete window.Chart;
    jest.clearAllMocks();
  });

  it("renders the data table from the spec", async () => {
    const el = createElement("c-mi-report-chart", { is: MiReportChart });
    el.spec = VALID_SPEC;
    document.body.appendChild(el);
    await flushPromises();

    const headerCells = el.shadowRoot.querySelectorAll("thead th");
    // Leading empty corner + one column per series.
    expect(headerCells).toHaveLength(2);
    expect(headerCells[1].textContent).toBe("DRAM");

    const bodyRows = el.shadowRoot.querySelectorAll("tbody tr");
    expect(bodyRows).toHaveLength(2);
    expect(bodyRows[0].querySelector("th").textContent).toBe("Q1");
  });

  it("creates a Chart instance once the canvas and library are ready", async () => {
    const el = createElement("c-mi-report-chart", { is: MiReportChart });
    el.spec = VALID_SPEC;
    document.body.appendChild(el);
    await flushPromises();
    await flushPromises();

    expect(window.Chart).toHaveBeenCalled();
    expect(el.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("shows the error fallback and no canvas for a bad spec", async () => {
    const el = createElement("c-mi-report-chart", { is: MiReportChart });
    el.spec = { type: "bar", labels: [], series: [] };
    document.body.appendChild(el);
    await flushPromises();

    expect(el.shadowRoot.querySelector("canvas")).toBeNull();
    expect(el.shadowRoot.textContent).toContain("데이터 표만");
  });

  it("uses the fallback source for the citation", async () => {
    const el = createElement("c-mi-report-chart", { is: MiReportChart });
    el.spec = VALID_SPEC;
    el.fallbackSource = "A.pdf";
    document.body.appendChild(el);
    await flushPromises();

    const source = el.shadowRoot.querySelector(".chart-source");
    expect(source.textContent).toContain("A.pdf");
  });

  it("destroys the chart on disconnect", async () => {
    const el = createElement("c-mi-report-chart", { is: MiReportChart });
    el.spec = VALID_SPEC;
    document.body.appendChild(el);
    await flushPromises();
    await flushPromises();

    document.body.removeChild(el);
    expect(destroy).toHaveBeenCalled();
  });
});
