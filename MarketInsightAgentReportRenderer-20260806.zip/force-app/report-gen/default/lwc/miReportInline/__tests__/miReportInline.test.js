import { createElement } from "lwc";
import MiReportInline from "c/miReportInline";

function createComponent(runs) {
  const element = createElement("c-mi-report-inline", { is: MiReportInline });
  element.runs = runs;
  document.body.appendChild(element);
  return element;
}

async function flush() {
  return Promise.resolve();
}

afterEach(() => {
  while (document.body.firstChild) {
    document.body.removeChild(document.body.firstChild);
  }
});

describe("c-mi-report-inline", () => {
  it("renders plain text runs as spans", async () => {
    const element = createComponent([{ text: "일반 텍스트" }]);
    await flush();

    const spans = element.shadowRoot.querySelectorAll("span");
    expect(spans.length).toBe(1);
    expect(spans[0].textContent).toBe("일반 텍스트");
    expect(spans[0].className).toBe("");
  });

  it("applies run-strong and run-em classes for emphasis", async () => {
    const element = createComponent([
      { text: "굵게", bold: true },
      { text: "기울임", italic: true },
      { text: "둘다", bold: true, italic: true }
    ]);
    await flush();

    const spans = element.shadowRoot.querySelectorAll("span");
    expect(spans[0].classList.contains("run-strong")).toBe(true);
    expect(spans[1].classList.contains("run-em")).toBe(true);
    expect(spans[2].classList.contains("run-strong")).toBe(true);
    expect(spans[2].classList.contains("run-em")).toBe(true);
  });

  it("renders a break run as a <br> instead of a span", async () => {
    const element = createComponent([
      { text: "앞" },
      { br: true },
      { text: "뒤" }
    ]);
    await flush();

    expect(element.shadowRoot.querySelector("br")).not.toBeNull();
    expect(element.shadowRoot.querySelectorAll("span").length).toBe(2);
  });

  it("renders markup inside run text as inert text, not HTML", async () => {
    const element = createComponent([{ text: "<script>alert(1)</script>" }]);
    await flush();

    expect(element.shadowRoot.querySelector("script")).toBeNull();
    expect(element.shadowRoot.querySelector("span").textContent).toContain(
      "<script>"
    );
  });

  it("renders nothing when runs is not an array", async () => {
    const element = createComponent(null);
    await flush();

    expect(element.shadowRoot.querySelectorAll("span").length).toBe(0);
    expect(element.shadowRoot.querySelector("br")).toBeNull();
  });
});
