import { LightningElement, api } from "lwc";

/**
 * Renders an array of inline "runs" — the leaf inline unit of a section's structured content. Each
 * run is either a line break (`{ br: true }`) or a text run with optional `bold`/`italic` emphasis.
 * Text is bound as a text node (never innerHTML), so any markup inside run text is inert and there is
 * no sanitization step. Emphasis is applied via the component's own scoped CSS classes.
 */
export default class MiReportInline extends LightningElement {
  _runs = [];

  /**
   * The runs to render. Each run is `{ text, bold?, italic? }` or `{ br: true }`.
   */
  @api
  get runs() {
    return this._runs;
  }
  set runs(value) {
    this._runs = Array.isArray(value) ? value : [];
  }

  /**
   * Normalizes the runs into render items with a stable key, a break flag, and the emphasis class
   * so the template stays declarative.
   *
   * @returns {Array<{key:string,isBreak:boolean,text:string,className:string}>}
   */
  get renderRuns() {
    return this._runs.map((run, index) => {
      const isBreak = !!(run && run.br);
      const classes = [];
      if (run && run.bold) {
        classes.push("run-strong");
      }
      if (run && run.italic) {
        classes.push("run-em");
      }
      return {
        key: `run-${index}`,
        isBreak,
        text: run && run.text != null ? String(run.text) : "",
        className: classes.join(" ")
      };
    });
  }
}
