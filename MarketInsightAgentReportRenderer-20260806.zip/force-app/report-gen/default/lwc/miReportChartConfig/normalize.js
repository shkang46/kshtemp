// Supported chart types. 'hbar' is a horizontal bar chart (Chart.js bar + indexAxis:'y'); 'doughnut' is a
// pie with a hollow centre (single dataset, per-slice colours), used for compact count/total gauges.
const CHART_TYPES = ["bar", "hbar", "line", "pie", "doughnut"];

/**
 * Coerces a raw chart spec (one entry from a section's Charts__c array) into a clean, predictable
 * shape used by both the Chart.js config builder and the DOCX data-table builder. Any malformed
 * spec yields `hasError: true` rather than throwing, so one bad chart never breaks rendering.
 *
 * The series are padded/truncated to the label count and every value is coerced to a finite number
 * (non-numeric entries become 0), mirroring the original reportChart behaviour.
 *
 * Expected raw shape:
 *   { type: 'bar'|'hbar'|'line'|'pie', title, unit, labels: [], series: [{ name, values: [] }], source }
 *
 * @param {*} spec The raw chart spec
 * @returns {{type:string,title:string,unit:string,source:string,labels:string[],
 *            series:{name:string,values:number[]}[],hasError:boolean}} The normalized spec
 */
export function normalizeSpec(spec) {
  const empty = {
    type: "bar",
    title: "",
    unit: "",
    source: "",
    labels: [],
    series: [],
    hasError: true
  };
  if (!spec || typeof spec !== "object") {
    return empty;
  }

  const type = CHART_TYPES.includes(spec.type) ? spec.type : "bar";
  const title = typeof spec.title === "string" ? spec.title : "";
  const unit = typeof spec.unit === "string" ? spec.unit : "";
  const source = typeof spec.source === "string" ? spec.source : "";

  const labels = Array.isArray(spec.labels)
    ? spec.labels.map((l) => `${l}`)
    : [];
  const series = normalizeSeries(spec.series, labels.length);

  if (!labels.length || !series.length) {
    return { type, title, unit, source, labels, series, hasError: true };
  }
  return { type, title, unit, source, labels, series, hasError: false };
}

/**
 * Coerces the raw series into a clean [{name, values:[numbers]}] shape, padding/truncating each
 * series to the label count and converting non-numeric entries to 0.
 *
 * @param {*} rawSeries The raw series array
 * @param {number} labelCount The number of category labels (target value-array length)
 * @returns {{name:string,values:number[]}[]} The normalized series
 */
export function normalizeSeries(rawSeries, labelCount) {
  if (!Array.isArray(rawSeries)) {
    return [];
  }
  return rawSeries
    .filter((s) => s && Array.isArray(s.values))
    .map((s, i) => {
      const values = [];
      for (let j = 0; j < labelCount; j++) {
        const n = Number(s.values[j]);
        values.push(Number.isFinite(n) ? n : 0);
      }
      return {
        name: typeof s.name === "string" && s.name ? s.name : `계열 ${i + 1}`,
        values
      };
    });
}
