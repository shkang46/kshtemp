/**
 * Formats a number compactly: integers as-is, decimals to at most 2 places (trailing zeros
 * trimmed), with thousands separators. Shared by the chart value labels, the chart data table, and
 * the DOCX data table so every numeric rendering matches exactly.
 *
 * @param {*} value The raw value (coerced to Number)
 * @returns {string} The formatted number, or '0' for non-finite input
 */
export function formatNumber(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) {
    return "0";
  }
  const rounded = Math.round(n * 100) / 100;
  return rounded.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
