/**
 * Shared chart-config module. The single source of truth for turning a raw chart spec (one entry
 * from a section's Charts__c array) into a Chart.js config, plus the palette / number-formatting /
 * normalization helpers. Imported by BOTH the on-screen reportChart component and the DOCX export
 * helpers in miReportViewer, so the visual chart and the exported chart/table never diverge.
 *
 * This bundle has no template — it is a pure JS utility module imported as `c/miReportChartConfig`.
 */
export { PALETTE, colorAt } from "./palette";
export { formatNumber } from "./format";
export { normalizeSpec, normalizeSeries } from "./normalize";
export {
  buildChartConfig,
  backgroundColorPlugin,
  valueLabelPlugin
} from "./buildChartConfig";
