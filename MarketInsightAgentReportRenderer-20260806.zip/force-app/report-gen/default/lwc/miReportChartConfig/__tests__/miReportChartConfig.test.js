import {
  PALETTE,
  colorAt,
  formatNumber,
  normalizeSpec,
  buildChartConfig
} from "c/miReportChartConfig";

describe("formatNumber", () => {
  it("formats integers without decimals", () => {
    expect(formatNumber(42)).toBe("42");
  });

  it("rounds to at most 2 decimals and trims trailing zeros", () => {
    expect(formatNumber(1.5)).toBe("1.5");
    expect(formatNumber(1.234)).toBe("1.23");
  });

  it("adds thousands separators", () => {
    expect(formatNumber(1234567)).toBe("1,234,567");
  });

  it("returns 0 for non-finite input", () => {
    expect(formatNumber("abc")).toBe("0");
    expect(formatNumber(NaN)).toBe("0");
    expect(formatNumber(undefined)).toBe("0");
  });

  it("handles negatives", () => {
    expect(formatNumber(-12.5)).toBe("-12.5");
  });
});

describe("colorAt", () => {
  it("returns the palette colour at an index", () => {
    expect(colorAt(0)).toBe(PALETTE[0]);
    expect(colorAt(1)).toBe(PALETTE[1]);
  });

  it("wraps around past the palette length", () => {
    expect(colorAt(PALETTE.length)).toBe(PALETTE[0]);
    expect(colorAt(PALETTE.length + 2)).toBe(PALETTE[2]);
  });
});

describe("normalizeSpec", () => {
  it("flags a null/invalid spec as error", () => {
    expect(normalizeSpec(null).hasError).toBe(true);
    expect(normalizeSpec("nope").hasError).toBe(true);
  });

  it("coerces an unknown type to bar", () => {
    const n = normalizeSpec({
      type: "wat",
      labels: ["a"],
      series: [{ name: "s", values: [1] }]
    });
    expect(n.type).toBe("bar");
    expect(n.hasError).toBe(false);
  });

  it("pads and truncates series values to the label count", () => {
    const n = normalizeSpec({
      type: "bar",
      labels: ["a", "b", "c"],
      series: [{ name: "s", values: [1, 2] }]
    });
    expect(n.series[0].values).toEqual([1, 2, 0]);
  });

  it("coerces non-numeric values to 0", () => {
    const n = normalizeSpec({
      type: "bar",
      labels: ["a", "b"],
      series: [{ name: "s", values: ["x", 3] }]
    });
    expect(n.series[0].values).toEqual([0, 3]);
  });

  it("errors when there are no labels or no usable series", () => {
    expect(
      normalizeSpec({
        type: "bar",
        labels: [],
        series: [{ name: "s", values: [] }]
      }).hasError
    ).toBe(true);
    expect(
      normalizeSpec({ type: "bar", labels: ["a"], series: [] }).hasError
    ).toBe(true);
  });

  it("defaults a missing series name", () => {
    const n = normalizeSpec({
      type: "bar",
      labels: ["a"],
      series: [{ values: [1] }]
    });
    expect(n.series[0].name).toBe("계열 1");
  });
});

describe("buildChartConfig", () => {
  const bar = {
    type: "bar",
    title: "T",
    unit: "U",
    labels: ["a", "b"],
    series: [{ name: "s", values: [1, 2] }]
  };

  it("returns null for an unrenderable spec", () => {
    expect(buildChartConfig(null)).toBeNull();
  });

  it("maps hbar to a bar chart with indexAxis y", () => {
    const cfg = buildChartConfig({ ...bar, type: "hbar" });
    expect(cfg.type).toBe("bar");
    expect(cfg.options.indexAxis).toBe("y");
  });

  it("maps a vertical bar to indexAxis x", () => {
    const cfg = buildChartConfig(bar);
    expect(cfg.type).toBe("bar");
    expect(cfg.options.indexAxis).toBe("x");
  });

  it("builds a pie with a single dataset and per-slice colours", () => {
    const cfg = buildChartConfig({
      type: "pie",
      labels: ["a", "b"],
      series: [{ name: "s", values: [3, 7] }]
    });
    expect(cfg.type).toBe("pie");
    expect(cfg.data.datasets).toHaveLength(1);
    expect(cfg.data.datasets[0].backgroundColor).toEqual([
      PALETTE[0],
      PALETTE[1]
    ]);
  });

  it("builds a doughnut like a pie but with the doughnut type", () => {
    const cfg = buildChartConfig({
      type: "doughnut",
      labels: ["미수행", "완료"],
      series: [{ name: "s", values: [3, 9] }]
    });
    expect(cfg.type).toBe("doughnut");
    // Single dataset with per-slice colours and no cartesian scales, same shape as a pie.
    expect(cfg.data.datasets).toHaveLength(1);
    expect(cfg.data.datasets[0].data).toEqual([3, 9]);
    expect(cfg.options.scales).toEqual({});
  });

  it("clamps negative pie values to 0", () => {
    const cfg = buildChartConfig({
      type: "pie",
      labels: ["a", "b"],
      series: [{ name: "s", values: [-5, 7] }]
    });
    expect(cfg.data.datasets[0].data).toEqual([0, 7]);
  });

  it("builds one dataset per series for bar/line", () => {
    const cfg = buildChartConfig({
      type: "line",
      labels: ["a", "b"],
      series: [
        { name: "s1", values: [1, 2] },
        { name: "s2", values: [3, 4] }
      ]
    });
    expect(cfg.type).toBe("line");
    expect(cfg.data.datasets).toHaveLength(2);
  });

  it("shows the legend only when there is more than one series", () => {
    expect(buildChartConfig(bar).options.plugins.legend.display).toBe(false);
    const two = buildChartConfig({
      ...bar,
      series: [
        { name: "s1", values: [1, 2] },
        { name: "s2", values: [3, 4] }
      ]
    });
    expect(two.options.plugins.legend.display).toBe(true);
  });

  it("disables animation and responsiveness in image mode", () => {
    const cfg = buildChartConfig(bar, { forImage: true });
    expect(cfg.options.responsive).toBe(false);
    expect(cfg.options.maintainAspectRatio).toBe(false);
    expect(cfg.options.animation).toBe(false);
    expect(cfg.options.devicePixelRatio).toBe(2);
  });

  it("attaches the background and value-label plugins inline", () => {
    const cfg = buildChartConfig(bar);
    const ids = cfg.plugins.map((p) => p.id);
    expect(ids).toContain("customCanvasBackgroundColor");
    expect(ids).toContain("reportValueLabels");
  });
});
