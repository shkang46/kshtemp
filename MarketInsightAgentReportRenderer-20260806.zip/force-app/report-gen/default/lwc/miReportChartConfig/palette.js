// Colour-blind-safe categorical palette (Okabe–Ito), brand-blue first. Applied per series/slice.
// Shared by the on-screen Chart.js chart and the DOCX data tables so colours never drift.
export const PALETTE = [
  "#0176D3", // SLDS brand blue
  "#E8912D",
  "#3BA755",
  "#D4504C",
  "#7E57C2",
  "#16808C",
  "#B58100",
  "#5C6770"
];

/**
 * Returns the palette colour for a series/slice index, wrapping around when the index exceeds the
 * palette length.
 *
 * @param {number} index Zero-based series or slice index
 * @returns {string} A hex colour string
 */
export function colorAt(index) {
  return PALETTE[((index % PALETTE.length) + PALETTE.length) % PALETTE.length];
}
