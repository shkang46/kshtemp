import { colorAt } from "./palette";
import { formatNumber } from "./format";
import { normalizeSpec } from "./normalize";

/**
 * Paints a solid background behind the chart. The canvas is transparent by default, so exported
 * PNGs (and prints) would otherwise have no background. `destination-over` draws beneath the
 * existing pixels. Reads its colour from `options.plugins.customCanvasBackgroundColor.color`.
 */
export const backgroundColorPlugin = {
  id: "customCanvasBackgroundColor",
  beforeDraw(chart, args, options) {
    const { ctx } = chart;
    ctx.save();
    ctx.globalCompositeOperation = "destination-over";
    ctx.fillStyle = (options && options.color) || "#ffffff";
    ctx.fillRect(0, 0, chart.width, chart.height);
    ctx.restore();
  }
};

/**
 * Draws the numeric value on each bar / point / pie slice, restoring the value labels the previous
 * SVG renderer showed (Chart.js core has no datalabels plugin). White text on pie slices, dark text
 * elsewhere. Reads no options; uses the shared formatNumber so labels match the data table.
 */
export const valueLabelPlugin = {
  id: "reportValueLabels",
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    const isPie =
      chart.config.type === "pie" || chart.config.type === "doughnut";
    ctx.save();
    ctx.font = "600 11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    chart.data.datasets.forEach((dataset, datasetIndex) => {
      const meta = chart.getDatasetMeta(datasetIndex);
      if (!meta || meta.hidden) {
        return;
      }
      meta.data.forEach((element, index) => {
        const raw = dataset.data[index];
        if (raw === null || raw === undefined) {
          return;
        }
        const text = formatNumber(raw);
        const pos = element.tooltipPosition
          ? element.tooltipPosition()
          : element.getCenterPoint();

        if (isPie) {
          // Centroid label, white for contrast on the coloured slice.
          const center = element.getCenterPoint
            ? element.getCenterPoint()
            : pos;
          ctx.fillStyle = "#ffffff";
          ctx.fillText(text, center.x, center.y);
        } else {
          // Dark label nudged off the mark (above for vertical, right for horizontal bars).
          ctx.fillStyle = "#181818";
          const horizontal = chart.options.indexAxis === "y";
          const x = horizontal ? pos.x + 16 : pos.x;
          const y = horizontal ? pos.y : pos.y - 9;
          ctx.fillText(text, x, y);
        }
      });
    });
    ctx.restore();
  }
};

/**
 * Builds a Chart.js `{ type, data, options, plugins }` config from a raw chart spec. Shared by the
 * on-screen reportChart canvas and the offscreen DOCX image render, so both look identical.
 *
 * Type mapping: 'hbar' → Chart.js bar with `indexAxis:'y'`; 'pie' → single dataset from the FIRST
 * series (values clamped ≥ 0) with per-slice colours and slice-name labels; 'bar'/'line' → one
 * dataset per series.
 *
 * @param {*} spec The raw chart spec (one entry from Charts__c)
 * @param {{forImage?:boolean}} [opts] When `forImage` is true the chart is sized/animated for a
 *   deterministic offscreen capture (no animation, fixed size, 2x pixel ratio).
 * @returns {object|null} A Chart.js config, or null when the spec is unrenderable
 */
export function buildChartConfig(spec, opts) {
  const forImage = !!(opts && opts.forImage);
  const n = normalizeSpec(spec);
  if (n.hasError) {
    return null;
  }

  // 'pie' and 'doughnut' share the same single-dataset / per-slice-colour shape; they differ only in the
  // Chart.js type string (a doughnut is a pie with a hollow centre).
  const isCircular = n.type === "pie" || n.type === "doughnut";
  const isHbar = n.type === "hbar";
  // 'bar' and 'hbar' both render as Chart.js 'bar'; hbar flips the index axis below.
  const chartType = n.type === "line" ? "line" : isCircular ? n.type : "bar";

  let data;
  if (isCircular) {
    const values = n.series[0].values.map((v) => Math.max(v, 0));
    data = {
      labels: n.labels,
      datasets: [
        {
          data: values,
          backgroundColor: n.labels.map((_, i) => colorAt(i)),
          borderColor: "#ffffff",
          borderWidth: 1
        }
      ]
    };
  } else {
    const isLine = n.type === "line";
    data = {
      labels: n.labels,
      datasets: n.series.map((s, i) => ({
        label: s.name,
        data: s.values,
        backgroundColor: colorAt(i),
        borderColor: colorAt(i),
        borderWidth: isLine ? 2.5 : 1,
        fill: false,
        tension: 0,
        pointRadius: isLine ? 3 : undefined
      }))
    };
  }

  const showLegend = isCircular ? n.labels.length > 1 : n.series.length > 1;
  const valueAxisTitle = n.unit
    ? { display: true, text: n.unit }
    : { display: false };

  const options = {
    indexAxis: isHbar ? "y" : "x",
    responsive: !forImage,
    maintainAspectRatio: !forImage,
    animation: forImage ? false : undefined,
    devicePixelRatio: forImage ? 2 : undefined,
    layout: { padding: 8 },
    plugins: {
      legend: { display: showLegend, position: "bottom" },
      title: { display: !!n.title, text: n.title },
      tooltip: { enabled: !forImage },
      customCanvasBackgroundColor: { color: "#ffffff" }
    },
    scales: isCircular
      ? {}
      : {
          x: isHbar ? { title: valueAxisTitle } : {},
          y: isHbar ? {} : { title: valueAxisTitle }
        }
  };

  return {
    type: chartType,
    data,
    options,
    plugins: [backgroundColorPlugin, valueLabelPlugin]
  };
}
