import { LightningElement, api } from "lwc";

/**
 * Renders one structured-content block — heading, paragraph, list, or table — declaratively, and
 * owns all of that block's styling in its own scoped CSS (headings, lists, tables). Because the
 * elements are this component's own template DOM (not manually-injected HTML), the scoped CSS applies
 * reliably; there is no innerHTML and no sanitization.
 *
 * Nested lists are handled by self-reference: a list item that carries a child `list` renders another
 * `<c-mi-report-block>`. The base case is an item with no nested list, so recursion always terminates.
 */
export default class MiReportBlock extends LightningElement {
  _block = {};

  /**
   * The block to render: `{ type, ... }` where type is heading | paragraph | list | table.
   */
  @api
  get block() {
    return this._block;
  }
  set block(value) {
    this._block = value || {};
  }

  /**
   * True when this block is the section's first block, so the heading's top margin is dropped
   * (each block renders in its own shadow root, so a CSS `:first-child` rule cannot see siblings).
   */
  @api first = false;

  get isHeading() {
    return this._block.type === "heading";
  }

  get isParagraph() {
    return this._block.type === "paragraph";
  }

  get isList() {
    return this._block.type === "list";
  }

  get isTable() {
    return this._block.type === "table";
  }

  get isHeading2() {
    return this.isHeading && this._block.level !== 3;
  }

  get isHeading3() {
    return this.isHeading && this._block.level === 3;
  }

  /**
   * CSS class for the heading level, plus `mi-first` on the section's first block so its top margin
   * is removed.
   *
   * @returns {string}
   */
  get headingClass() {
    const base = this._block.level === 3 ? "mi-section-h3" : "mi-section-h2";
    return this.first ? `${base} mi-first` : base;
  }

  get runs() {
    return Array.isArray(this._block.runs) ? this._block.runs : [];
  }

  get isOrdered() {
    return !!this._block.ordered;
  }

  /**
   * List items with stable keys and a normalized nested-list reference for recursion.
   *
   * @returns {Array<{key:string,runs:Array,nestedList:object|null,hasNested:boolean}>}
   */
  get listItems() {
    const items = Array.isArray(this._block.items) ? this._block.items : [];
    return items.map((item, index) => {
      const nestedList =
        item && item.list && item.list.type === "list" ? item.list : null;
      return {
        key: `li-${index}`,
        runs: item && Array.isArray(item.runs) ? item.runs : [],
        nestedList,
        hasNested: !!nestedList
      };
    });
  }

  get hasCaption() {
    return !!this._block.caption;
  }

  get caption() {
    return this._block.caption;
  }

  get hasHeader() {
    return this.headerRows.length > 0;
  }

  /**
   * Table header rows (thead), each a keyed list of header cells.
   *
   * @returns {Array<{key:string,cells:Array}>}
   */
  get headerRows() {
    return this.mapRows(this._block.header, "thr", true);
  }

  /**
   * Table body rows (tbody), each a keyed list of cells (which may themselves be row headers).
   *
   * @returns {Array<{key:string,cells:Array}>}
   */
  get bodyRows() {
    return this.mapRows(this._block.rows, "tbr", false);
  }

  /**
   * Normalizes a raw row array into keyed rows of keyed cells for the template. Header rows force
   * every cell to a `<th>`; body cells become `<th>` only when the cell sets `rowHeader`.
   *
   * @param {Array} rawRows The raw header/rows array
   * @param {string} rowPrefix Key prefix for the rows
   * @param {boolean} isHeaderRow Whether these are thead rows
   * @returns {Array<{key:string,cells:Array}>}
   */
  mapRows(rawRows, rowPrefix, isHeaderRow) {
    const rows = Array.isArray(rawRows) ? rawRows : [];
    return rows.map((cells, rowIndex) => {
      const cellList = Array.isArray(cells) ? cells : [];
      return {
        key: `${rowPrefix}-${rowIndex}`,
        cells: cellList.map((cell, cellIndex) => {
          const isTh = isHeaderRow || !!(cell && cell.rowHeader);
          return {
            key: `${rowPrefix}-${rowIndex}-c-${cellIndex}`,
            runs: cell && Array.isArray(cell.runs) ? cell.runs : [],
            colspan: cell && cell.colspan > 1 ? cell.colspan : null,
            rowspan: cell && cell.rowspan > 1 ? cell.rowspan : null,
            isTh,
            isTd: !isTh
          };
        })
      };
    });
  }
}
