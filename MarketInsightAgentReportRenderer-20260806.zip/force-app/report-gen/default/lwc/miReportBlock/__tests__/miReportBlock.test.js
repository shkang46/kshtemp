import { createElement } from "lwc";
import MiReportBlock from "c/miReportBlock";

function createComponent(block, first) {
  const element = createElement("c-mi-report-block", { is: MiReportBlock });
  element.block = block;
  if (first !== undefined) {
    element.first = first;
  }
  document.body.appendChild(element);
  return element;
}

async function flush() {
  return Promise.resolve();
}

afterEach(() => {
  while (document.body.firstChild) {
    document.body.removeChild(document.body.firstChild);
  }
});

describe("c-mi-report-block", () => {
  it("renders a level-2 heading with the mi-section-h2 class", async () => {
    const element = createComponent({
      type: "heading",
      level: 2,
      runs: [{ text: "개요" }]
    });
    await flush();

    const h2 = element.shadowRoot.querySelector("h2");
    expect(h2).not.toBeNull();
    expect(h2.classList.contains("mi-section-h2")).toBe(true);
    expect(element.shadowRoot.querySelector("h3")).toBeNull();
  });

  it("renders a level-3 heading with the mi-section-h3 class", async () => {
    const element = createComponent({
      type: "heading",
      level: 3,
      runs: [{ text: "소제목" }]
    });
    await flush();

    expect(
      element.shadowRoot.querySelector("h3").classList.contains("mi-section-h3")
    ).toBe(true);
  });

  it("adds mi-first to the first block heading so its top margin drops", async () => {
    const element = createComponent(
      { type: "heading", level: 2, runs: [{ text: "첫" }] },
      true
    );
    await flush();

    expect(
      element.shadowRoot.querySelector("h2").classList.contains("mi-first")
    ).toBe(true);
  });

  it("renders a paragraph delegating inline runs to c-mi-report-inline", async () => {
    const element = createComponent({
      type: "paragraph",
      runs: [{ text: "본문" }]
    });
    await flush();

    expect(element.shadowRoot.querySelector("p")).not.toBeNull();
    expect(
      element.shadowRoot.querySelector("p c-mi-report-inline")
    ).not.toBeNull();
  });

  it("renders an unordered list with one li per item", async () => {
    const element = createComponent({
      type: "list",
      ordered: false,
      items: [{ runs: [{ text: "가" }] }, { runs: [{ text: "나" }] }]
    });
    await flush();

    expect(element.shadowRoot.querySelector("ul")).not.toBeNull();
    expect(element.shadowRoot.querySelectorAll("li").length).toBe(2);
    expect(element.shadowRoot.querySelector("ol")).toBeNull();
  });

  it("renders a nested list by recursing into a child c-mi-report-block", async () => {
    const element = createComponent({
      type: "list",
      ordered: false,
      items: [
        {
          runs: [{ text: "상위" }],
          list: {
            type: "list",
            ordered: true,
            items: [{ runs: [{ text: "하위" }] }]
          }
        }
      ]
    });
    await flush();

    const nested = element.shadowRoot.querySelector("li c-mi-report-block");
    expect(nested).not.toBeNull();
    expect(nested.block.ordered).toBe(true);
  });

  it("renders a table with header cells and colspan/rowspan honored", async () => {
    const element = createComponent({
      type: "table",
      caption: "표 1",
      header: [
        [{ runs: [{ text: "연도" }] }, { runs: [{ text: "매출" }], colspan: 2 }]
      ],
      rows: [
        [
          { runs: [{ text: "합계" }], rowHeader: true },
          { runs: [{ text: "18" }] },
          { runs: [{ text: "20" }], rowspan: 2 }
        ]
      ]
    });
    await flush();

    expect(element.shadowRoot.querySelector("caption").textContent).toContain(
      "표 1"
    );
    const headerCells = element.shadowRoot.querySelectorAll("thead th");
    expect(headerCells.length).toBe(2);
    expect(headerCells[1].getAttribute("colspan")).toBe("2");

    // Body: the rowHeader cell is a <th scope=row>, data cells are <td>.
    const rowHeader = element.shadowRoot.querySelector("tbody th");
    expect(rowHeader).not.toBeNull();
    expect(rowHeader.getAttribute("scope")).toBe("row");
    const dataCells = element.shadowRoot.querySelectorAll("tbody td");
    expect(dataCells.length).toBe(2);
    expect(dataCells[1].getAttribute("rowspan")).toBe("2");
  });

  it("renders nothing for an unknown block type", async () => {
    const element = createComponent({ type: "mystery", runs: [{ text: "x" }] });
    await flush();

    expect(element.shadowRoot.querySelector("h2")).toBeNull();
    expect(element.shadowRoot.querySelector("p")).toBeNull();
    expect(element.shadowRoot.querySelector("table")).toBeNull();
    expect(element.shadowRoot.querySelector("ul")).toBeNull();
  });
});
