/* eslint-disable no-unused-expressions */
({
  doInit: function (component) {
    var navService = component.find("navService");

    // Navigate in-place to the Lightning search page.
    var pageReference = {
      type: "standard__webPage",
      attributes: {
        url: "/lightning/search/agent?c__ts=1782954937118"
      }
    };

    // Aura context so the framework calls are valid after the timeout.
    window.setTimeout(
      $A.getCallback(function () {
        navService.navigate(pageReference);
        $A.get("e.force:closeQuickAction").fire();
      }),
      75
    );
  }
});
