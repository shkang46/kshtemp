import { LightningElement, api, wire } from "lwc";
import getPreview from "@salesforce/apex/MI_InteractivePreviewController.getPreview";

const FILE_RENDITION_BASE =
  "/sfc/servlet.shepherd/version/renditionDownload?rendition=ORIGINAL_Pdf&operationContext=CHATTER&versionId=";

export default class MiInteractivePreviewV2 extends LightningElement {
  @api recordId;

  _versionId;
  _error;

  @wire(getPreview, { recordId: "$recordId" })
  wiredPreview({ data, error }) {
    if (data) {
      this._versionId = data.hasFile ? data.contentVersionId : undefined;
      this._error = undefined;
    } else if (error) {
      this._error = this._reduceError(error);
      this._versionId = undefined;
    }
  }

  get fileUrl() {
    return this._versionId ? FILE_RENDITION_BASE + this._versionId : null;
  }

  get hasFile() {
    return !!this.fileUrl;
  }

  get hasError() {
    return !!this._error;
  }

  get errorMessage() {
    return this._error;
  }

  _reduceError(error) {
    if (typeof error === "string") {
      return error;
    }
    if (error?.body?.message) {
      return error.body.message;
    }
    if (error?.message) {
      return error.message;
    }
    return "An unexpected error occurred while loading the document preview.";
  }
}
