import { createElement } from "lwc";
import MiInteractivePreviewV2 from "c/miInteractivePreview_v2";
import getPreview from "@salesforce/apex/MI_InteractivePreviewController.getPreview";

// getPreview is consumed with @wire here, so it needs a wire-adapter stub (emit/error),
// not the plain { default: jest.fn() } imperative mock.
jest.mock(
  "@salesforce/apex/MI_InteractivePreviewController.getPreview",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

const FILE_INFO = {
  hasFile: true,
  title: "report",
  fileExtension: "pdf",
  contentVersionId: "068000000000001",
  renditionBaseUrl:
    "/sfc/servlet.shepherd/version/renditionDownload?rendition=SVGZ&versionId=068000000000001"
};

function createComponent() {
  const element = createElement("c-mi-interactive-preview-v2", {
    is: MiInteractivePreviewV2
  });
  element.recordId = "a0X000000000001";
  document.body.appendChild(element);
  return element;
}

async function flush() {
  return Promise.resolve().then(() => Promise.resolve());
}

describe("c-mi-interactive-preview-v2", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders the file iframe when a file is attached", async () => {
    const element = createComponent();
    getPreview.emit(FILE_INFO);
    await flush();

    const iframe = element.shadowRoot.querySelector("iframe");
    expect(iframe).not.toBeNull();
    expect(iframe.src).toContain("rendition=ORIGINAL_Pdf");
    expect(iframe.src).toContain("versionId=068000000000001");
  });

  it("shows the empty state when no file is attached", async () => {
    const element = createComponent();
    getPreview.emit({ hasFile: false });
    await flush();

    expect(element.shadowRoot.querySelector("iframe")).toBeNull();
    expect(element.shadowRoot.textContent).toContain(
      "No document attached to this record yet."
    );
  });

  it("shows an error message when the wire errors", async () => {
    const element = createComponent();
    // createApexTestWireAdapter.error(body, status, statusText) wraps its first
    // arg as the FetchResponse `body`, so pass the message-bearing object directly.
    getPreview.error({ message: "오류 발생" });
    await flush();

    expect(element.shadowRoot.querySelector("iframe")).toBeNull();
    expect(element.shadowRoot.textContent).toContain("오류 발생");
  });
});
