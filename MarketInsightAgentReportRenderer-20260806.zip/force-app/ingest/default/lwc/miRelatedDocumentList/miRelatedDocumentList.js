import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getRelatedFiles from '@salesforce/apex/MI_DocumentPreviewController.getRelatedFiles';

/**
 * miRelatedDocumentList — record-page list of attached files. Shows each file
 * (type icon + title); clicking a row navigates to the standalone
 * Document_Preview tab with the document id + starting page in URL state.
 * Read-only; file sharing is enforced by getRelatedFiles (with sharing).
 * Drop it on a Lightning record page (target: lightning__RecordPage).
 */

const ICON_BY_EXT = {
    pdf: 'doctype:pdf',
    ppt: 'doctype:ppt',
    pptx: 'doctype:ppt',
    doc: 'doctype:word',
    docx: 'doctype:word',
    xls: 'doctype:excel',
    xlsx: 'doctype:excel',
    png: 'doctype:image',
    jpg: 'doctype:image',
    jpeg: 'doctype:image',
    gif: 'doctype:image'
};

export default class MiRelatedDocumentList extends NavigationMixin(LightningElement) {
    @api recordId;
    files = [];
    error;

    @wire(getRelatedFiles, { recordId: '$recordId' })
    wiredFiles({ data, error }) {
        if (data) {
            this.files = data.map((f) => ({
                ...f,
                iconName: ICON_BY_EXT[(f.fileExtension || '').toLowerCase()] || 'doctype:unknown'
            }));
            this.error = undefined;
        } else if (error) {
            this.error = (error.body && error.body.message) || '파일을 불러오지 못했습니다.';
            this.files = [];
        }
    }

    get hasFiles() {
        return this.files && this.files.length > 0;
    }

    // Clicking a file navigates to the standalone preview page (Document_Preview
    // tab), passing the document id + starting page as URL state.
    handleOpen(event) {
        const docId = event.currentTarget.dataset.docId;
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: { apiName: 'Document_Preview' },
            state: { c__docId: docId, c__page: '1' }
        });
    }
}