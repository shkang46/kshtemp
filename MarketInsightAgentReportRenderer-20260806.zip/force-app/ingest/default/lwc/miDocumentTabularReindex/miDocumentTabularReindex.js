import { LightningElement, api, wire } from "lwc";
import {
  getRecord,
  getFieldValue,
  notifyRecordUpdateAvailable
} from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import reindexTabular from "@salesforce/apex/MI_MarketInsightDocumentController.reindexTabular";
import STATUS_FIELD from "@salesforce/schema/Market_Insight_Document__c.Tabular_Status__c";
import ROW_COUNT_FIELD from "@salesforce/schema/Market_Insight_Document__c.Tabular_Row_Count__c";
import GENERATED_AT_FIELD from "@salesforce/schema/Market_Insight_Document__c.Tabular_Generated_At__c";
import ERROR_FIELD from "@salesforce/schema/Market_Insight_Document__c.Tabular_Error__c";
import FILE_NAME_FIELD from "@salesforce/schema/Market_Insight_Document__c.File_Name__c";

const GENERATING = "Generating";
const ERROR = "Error";
// Prefixes the Apex side writes onto Tabular_Error__c to mark a note as something OTHER than a failure.
// Keep in sync with MI_TabularExtractionService.NO_TABLE_PREFIX / WARNING_PREFIX.
const NO_TABLE_PREFIX = "[표 없음]";
const PARTIAL_PREFIX = "[일부 미추출]";
// Re-extraction scope. "full" reruns the whole document (LLM locate + clear prior rows); "targeted"
// re-extracts only the caller-named PDF pages and keeps existing rows (Row_Key__c upsert).
const MODE_FULL = "full";
const MODE_TARGETED = "targeted";

/**
 * Re-extract card for the Market_Insight_Document__c record page. Shows the current tabular-extraction
 * status and row count, and lets the user force-re-extract the document's quantitative tables on
 * demand — regardless of the current status (unlike the on-upload run, which only runs once). The Apex
 * service reads the attached original file (PDF/Office) and replaces the document's normalized
 * Market_Insight_Tabular__c rows.
 *
 * The button is disabled while extraction is already in flight. Because extraction is asynchronous,
 * the status won't flip to Complete immediately — the user refreshes to see the result;
 * notifyRecordUpdateAvailable refreshes the displayed fields after the request is accepted.
 */
export default class MiDocumentTabularReindex extends LightningElement {
  @api recordId;

  isExtracting = false;
  // Which re-extraction scope the user picked. Defaults to a full refresh (today's behavior).
  mode = MODE_FULL;
  // The raw page selection the user typed for targeted mode (e.g. "3, 5, 7-9").
  pageRangesInput = "";

  // Retained so notifyRecordUpdateAvailable can target exactly this provisioned record.
  @wire(getRecord, {
    recordId: "$recordId",
    fields: [
      STATUS_FIELD,
      ROW_COUNT_FIELD,
      GENERATED_AT_FIELD,
      ERROR_FIELD,
      FILE_NAME_FIELD
    ]
  })
  document;

  get status() {
    return getFieldValue(this.document.data, STATUS_FIELD);
  }

  get rowCount() {
    return getFieldValue(this.document.data, ROW_COUNT_FIELD);
  }

  get generatedAt() {
    return getFieldValue(this.document.data, GENERATED_AT_FIELD);
  }

  get fileName() {
    return getFieldValue(this.document.data, FILE_NAME_FIELD);
  }

  // Targeted (page-scoped) re-extraction is PDF-only: Office/legacy files are addressed by sheet/row,
  // not page number. Offer the mode choice only for PDFs so a non-PDF card stays a plain full refresh.
  get isPdf() {
    return (this.fileName || "").toLowerCase().endsWith(".pdf");
  }

  get modeOptions() {
    return [
      { label: "전체 페이지 (Full Refresh)", value: MODE_FULL },
      { label: "지정 페이지 (Upsert)", value: MODE_TARGETED }
    ];
  }

  get isTargetedMode() {
    return this.isPdf && this.mode === MODE_TARGETED;
  }

  get statusLabel() {
    return this.status || "미처리";
  }

  get isGenerating() {
    return this.status === GENERATING;
  }

  get isError() {
    return this.status === ERROR;
  }

  // The verbatim note the extraction service recorded on Tabular_Error__c. Despite the field name this is
  // not always a failure: it also carries "[표 없음]" (the document holds no figures — a successful run) and
  // "[일부 미추출]" (a partial extraction), both of which accompany a Complete status.
  get errorDetail() {
    return getFieldValue(this.document.data, ERROR_FIELD);
  }

  // Show the detail panel whenever there IS detail, not only when the status is Error. Gating on isError
  // hid exactly the notes worth reading: a "[표 없음]" verdict and a "[일부 미추출]" partial-extraction
  // warning both sit on a Complete document, so a user would have seen a clean Complete and never learned
  // that data was missing or that the file had no figures at all.
  get hasErrorDetail() {
    return !!this.errorDetail;
  }

  // True when the note says the document simply holds no figures — a successful run, so it must not be
  // presented as a failure.
  get isNoTableNote() {
    return (this.errorDetail || "").startsWith(NO_TABLE_PREFIX);
  }

  // True when extraction succeeded but knowingly left data out.
  get isPartialNote() {
    return (this.errorDetail || "").startsWith(PARTIAL_PREFIX);
  }

  get detailTitle() {
    if (this.isNoTableNote) {
      return "정량 표 없음";
    }
    return this.isPartialNote ? "일부 미추출 안내" : "추출 오류 상세";
  }

  get detailGuidance() {
    if (this.isNoTableNote) {
      return "이 문서에서는 추출할 정량 표를 찾지 못했습니다. 수치 표가 없는 문서라면 정상입니다.";
    }
    return this.isPartialNote
      ? "일부 데이터가 추출되지 않았습니다. 전체가 필요하면 재추출해 주세요."
      : "아래 오류를 확인한 뒤 재추출해 주세요.";
  }

  get detailIconName() {
    return this.isNoTableNote || this.isPartialNote
      ? "utility:info"
      : "utility:error";
  }

  get detailIconVariant() {
    return this.isNoTableNote || this.isPartialNote ? "" : "error";
  }

  get detailTitleClass() {
    return this.isNoTableNote || this.isPartialNote
      ? "slds-text-title_caps"
      : "slds-text-title_caps slds-text-color_error";
  }

  // Disable while a request is being sent or while extraction is already running.
  get isButtonDisabled() {
    return this.isExtracting || this.isGenerating;
  }

  handleModeChange(event) {
    this.mode = event.detail.value;
  }

  handlePageInput(event) {
    this.pageRangesInput = event.detail.value;
  }

  /**
   * Kicks off an on-demand tabular re-extraction, then refreshes the displayed fields. Extraction runs
   * asynchronously, so success here means "started", not "finished". In targeted mode the caller's page
   * selection is passed through; in full mode a blank pageRanges tells Apex to run a full refresh.
   */
  async handleReindex() {
    let pageRanges = "";
    if (this.isTargetedMode) {
      pageRanges = (this.pageRangesInput || "").trim();
      if (!pageRanges) {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "페이지를 입력하세요",
            message: "추출할 페이지 번호를 입력해 주세요. 예: 3, 5, 7-9",
            variant: "warning"
          })
        );
        return;
      }
    }
    this.isExtracting = true;
    try {
      await reindexTabular({ recordId: this.recordId, pageRanges });
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재추출 시작",
          message: "표 데이터를 다시 추출합니다. 잠시 후 새로고침해 주세요.",
          variant: "success"
        })
      );
      await notifyRecordUpdateAvailable([{ recordId: this.recordId }]);
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재추출 실패",
          message:
            error?.body?.message || "표 데이터 재추출을 시작하지 못했습니다.",
          variant: "error"
        })
      );
    } finally {
      this.isExtracting = false;
    }
  }
}
