import { createElement } from "lwc";
import MiDocumentTabularReindex from "c/miDocumentTabularReindex";
import { getRecord } from "lightning/uiRecordApi";
import reindexTabular from "@salesforce/apex/MI_MarketInsightDocumentController.reindexTabular";

// @salesforce/apex and lightning/* are auto-mocked by sfdx-lwc-jest; give the imperative Apex a
// resolvable default so awaits complete.
jest.mock(
  "@salesforce/apex/MI_MarketInsightDocumentController.reindexTabular",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

const RECORD_ID = "a01000000000001AAA";

function createComponent() {
  const element = createElement("c-mi-document-tabular-reindex", {
    is: MiDocumentTabularReindex
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

// Emit a record into the getRecord wire with the given Tabular_Status__c value (and optional
// Tabular_Error__c detail / file name). Defaults to a PDF so the mode controls render.
function emitStatus(
  status,
  rowCount = 0,
  errorDetail = null,
  fileName = "report.pdf"
) {
  getRecord.emit({
    fields: {
      Tabular_Status__c: { value: status },
      Tabular_Row_Count__c: { value: rowCount },
      Tabular_Generated_At__c: { value: null },
      Tabular_Error__c: { value: errorDetail },
      File_Name__c: { value: fileName }
    }
  });
}

function flushPromises() {
  return Promise.resolve();
}

describe("c-mi-document-tabular-reindex", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows a placeholder status and an enabled button before any record loads", () => {
    const element = createComponent();
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button).not.toBeNull();
      expect(button.disabled).toBe(false);
      expect(element.shadowRoot.textContent).toContain("미처리");
    });
  });

  it("disables the button while status is Generating", () => {
    const element = createComponent();
    emitStatus("Generating");
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button.disabled).toBe(true);
    });
  });

  it("enables the button and shows the status and row count when Complete", () => {
    const element = createComponent();
    emitStatus("Complete", 12);
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button.disabled).toBe(false);
      expect(element.shadowRoot.textContent).toContain("Complete");
      expect(element.shadowRoot.textContent).toContain("12");
    });
  });

  it("calls reindexTabular with a blank pageRanges (full refresh) by default", () => {
    reindexTabular.mockResolvedValue(undefined);
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises()
      .then(() => {
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => {
        expect(reindexTabular).toHaveBeenCalledTimes(1);
        expect(reindexTabular).toHaveBeenCalledWith({
          recordId: RECORD_ID,
          pageRanges: ""
        });
      });
  });

  it("offers the mode radio group for a PDF document", () => {
    const element = createComponent();
    emitStatus("Complete", 12, null, "report.pdf");
    return flushPromises().then(() => {
      expect(
        element.shadowRoot.querySelector("lightning-radio-group")
      ).not.toBeNull();
    });
  });

  it("hides the mode radio group for a non-PDF document", () => {
    const element = createComponent();
    emitStatus("Complete", 12, null, "workbook.xlsx");
    return flushPromises().then(() => {
      expect(
        element.shadowRoot.querySelector("lightning-radio-group")
      ).toBeNull();
      // Non-PDF still shows the page input never, so a click is a plain full refresh.
      expect(element.shadowRoot.querySelector("lightning-input")).toBeNull();
    });
  });

  it("shows the page input only after switching to targeted mode", () => {
    const element = createComponent();
    emitStatus("Complete", 12, null, "report.pdf");
    return flushPromises()
      .then(() => {
        expect(element.shadowRoot.querySelector("lightning-input")).toBeNull();
        const radio = element.shadowRoot.querySelector("lightning-radio-group");
        radio.dispatchEvent(
          new CustomEvent("change", { detail: { value: "targeted" } })
        );
      })
      .then(() => flushPromises())
      .then(() => {
        expect(
          element.shadowRoot.querySelector("lightning-input")
        ).not.toBeNull();
      });
  });

  it("passes the typed pageRanges when targeted mode is used", () => {
    reindexTabular.mockResolvedValue(undefined);
    const element = createComponent();
    emitStatus("Complete", 12, null, "report.pdf");
    return flushPromises()
      .then(() => {
        const radio = element.shadowRoot.querySelector("lightning-radio-group");
        radio.dispatchEvent(
          new CustomEvent("change", { detail: { value: "targeted" } })
        );
      })
      .then(() => flushPromises())
      .then(() => {
        const input = element.shadowRoot.querySelector("lightning-input");
        input.dispatchEvent(
          new CustomEvent("change", { detail: { value: "3, 5, 7-9" } })
        );
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => {
        expect(reindexTabular).toHaveBeenCalledTimes(1);
        expect(reindexTabular).toHaveBeenCalledWith({
          recordId: RECORD_ID,
          pageRanges: "3, 5, 7-9"
        });
      });
  });

  it("does not call Apex when targeted mode has no page input", () => {
    reindexTabular.mockResolvedValue(undefined);
    const element = createComponent();
    emitStatus("Complete", 12, null, "report.pdf");
    return flushPromises()
      .then(() => {
        const radio = element.shadowRoot.querySelector("lightning-radio-group");
        radio.dispatchEvent(
          new CustomEvent("change", { detail: { value: "targeted" } })
        );
      })
      .then(() => flushPromises())
      .then(() => {
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => {
        expect(reindexTabular).not.toHaveBeenCalled();
      });
  });

  it("renders the error-detail panel with the verbatim message when status is Error", () => {
    const element = createComponent();
    emitStatus("Error", 0, "Tabular prompt returned no output.");
    return flushPromises().then(() => {
      const panel = element.shadowRoot.querySelector(".error-detail");
      expect(panel).not.toBeNull();
      const detail = panel.querySelector("lightning-formatted-text");
      expect(detail).not.toBeNull();
      expect(detail.value).toBe("Tabular prompt returned no output.");
      expect(element.shadowRoot.textContent).toContain("추출 오류 상세");
      // The button stays enabled so the user can re-extract after reading the error.
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button.disabled).toBe(false);
    });
  });

  it("does not render the detail panel when a Complete document has no note", () => {
    const element = createComponent();
    emitStatus("Complete", 12);
    return flushPromises().then(() => {
      expect(element.shadowRoot.querySelector(".error-detail")).toBeNull();
      expect(element.shadowRoot.textContent).not.toContain("추출 오류 상세");
    });
  });

  it("shows a Complete document's '표 없음' note as information, not as an error", () => {
    // A figure-free document is a successful run. Gating the panel on status === Error used to hide this
    // note entirely, so the card read as a plain Complete and the user never learned why 0 rows came back.
    const element = createComponent();
    emitStatus(
      "Complete",
      0,
      "[표 없음] 문서에서 정량 수치를 찾지 못했습니다."
    );
    return flushPromises().then(() => {
      const panel = element.shadowRoot.querySelector(".error-detail");
      expect(panel).not.toBeNull();
      expect(element.shadowRoot.textContent).toContain("정량 표 없음");
      expect(element.shadowRoot.textContent).not.toContain("추출 오류 상세");
      const icon = element.shadowRoot.querySelector("lightning-icon");
      expect(icon.iconName).toBe("utility:info");
    });
  });

  it("shows a Complete document's '일부 미추출' note as a partial-extraction warning", () => {
    const element = createComponent();
    emitStatus(
      "Complete",
      40,
      "[일부 미추출] 표 3개가 상한을 넘어 제외되었습니다."
    );
    return flushPromises().then(() => {
      expect(element.shadowRoot.querySelector(".error-detail")).not.toBeNull();
      expect(element.shadowRoot.textContent).toContain("일부 미추출 안내");
      expect(element.shadowRoot.textContent).not.toContain("추출 오류 상세");
    });
  });

  it("does not render the error panel when Error carries no detail text", () => {
    const element = createComponent();
    emitStatus("Error", 0, null);
    return flushPromises().then(() => {
      expect(element.shadowRoot.querySelector(".error-detail")).toBeNull();
    });
  });

  it("does not throw when the reindex Apex call rejects", () => {
    reindexTabular.mockRejectedValue({ body: { message: "boom" } });
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises()
      .then(() => {
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => flushPromises())
      .then(() => {
        expect(reindexTabular).toHaveBeenCalledTimes(1);
        // Button re-enabled after the failure (finally cleared isExtracting).
        const button = element.shadowRoot.querySelector("lightning-button");
        expect(button.disabled).toBe(false);
      });
  });
});
