import { LightningElement, api, track } from "lwc";
import getSpreadsheet from "@salesforce/apex/MI_DocumentPreviewController.getSpreadsheet";

// Rendering stays entirely in-org.
//
// PDF / PPT / Word: Salesforce auto-generates a per-page SVG preview
// ("rendition"). We point an <img> at the platform's own rendition servlet:
//   /sfc/servlet.shepherd/version/renditionDownload?rendition=SVGZ&versionId=<cv>&operationContext=CHATTER&page=<n>
// Two servlet quirks we must honor (learned the hard way against this org):
//   1. operationContext=CHATTER is required, or the servlet returns
//      errorduringprocessing instead of the image.
//   2. page is 0-INDEXED (first page = 0). Our UI/page state is 1-based
//      (page 1 = first), so buildSrc() subtracts one. Requesting page=1 for a
//      single-page PDF asks for a non-existent page -> error -> download fallback.
// Page N is the same axis for every type (PDF page N == PPT slide N), so page
// navigation and deep-linking are one uniform mechanism.
//
// Excel (.xlsx): the platform does NOT generate SVG renditions for
// spreadsheets, so instead Apex unzips the file (Compression.ZipReader) and
// parses the worksheet OOXML into a cell grid, which we render as an HTML
// table. Still fully in-org: no external viewer, no callout.
//
// Anything with no rendition / unsupported falls back to a download link.

const RENDITION = "SVGZ";
const MAX_PAGES = 100000;

export default class MiDocumentPreview extends LightningElement {
  @api contentDocumentId;
  @api fileTitle;
  @api fileExtension;

  _versionId;
  @api
  get versionId() {
    return this._versionId;
  }
  set versionId(value) {
    this._versionId = value;
    this.maybeStart();
  }

  _initialPage = 1;
  @api
  get initialPage() {
    return this._initialPage;
  }
  set initialPage(value) {
    const n = parseInt(value, 10);
    const page = Number.isNaN(n) || n < 1 ? 1 : n;
    if (page === this._initialPage) {
      return;
    }
    this._initialPage = page;
    // The deep-linked start page can arrive AFTER the viewer has already
    // begun rendering (the URL-state wire and the file wire resolve in no
    // guaranteed order). If we've already started this file, jump to the
    // requested page; otherwise start() will pick it up from _initialPage.
    if (
      this._startedFor === this._versionId &&
      this._versionId &&
      !this.isSpreadsheet
    ) {
      this.loadPage(page);
    } else {
      this.currentPage = page;
    }
  }

  @track loading = true;
  @track failed = false;
  @track errorMsg;
  @track currentPage = 1;
  @track pageCount = 0;
  // First page has rendered at least once for the current file. The nav bar
  // keys off this (plus knownMultiPage) so it appears WITH the preview image
  // instead of waiting for the full page-count scan to finish.
  @track imageReady = false;
  // We've confirmed the document has more than one page (a deep-linked page
  // > 1 rendered, or a probe past page 1 succeeded) even before the exact
  // total is known.
  @track knownMultiPage = false;

  // spreadsheet state
  @track isSpreadsheet = false;
  @track sheets = [];

  imgSrc;
  _probeCache = new Map();
  _connected = false;
  _startedFor;
  _lastGoodPage = 1;

  connectedCallback() {
    this._connected = true;
    this.maybeStart();
  }

  // @api properties are assigned in no guaranteed order, so wait until the
  // component is connected (all inputs set) before choosing a render path,
  // and only (re)start when the target version actually changes.
  maybeStart() {
    if (!this._connected || !this._versionId) {
      return;
    }
    if (this._startedFor === this._versionId) {
      return;
    }
    this._startedFor = this._versionId;
    this.start();
  }

  start() {
    this.failed = false;
    this.errorMsg = undefined;
    const ext = (this.fileExtension || "").toLowerCase();
    this.isSpreadsheet = ext === "xlsx" || ext === "xls";
    if (this.isSpreadsheet) {
      this.loadSpreadsheet();
      return;
    }
    // image/rendition path
    this.pageCount = 0;
    this.imageReady = false;
    this.knownMultiPage = false;
    this._lastGoodPage = this._initialPage;
    this._probeCache = new Map();
    this.currentPage = this._initialPage;
    this.loadPage(this.currentPage);
    this.discoverPageCount();
  }

  // --- Excel path -----------------------------------------------------------
  async loadSpreadsheet() {
    this.loading = true;
    this.failed = false;
    this.sheets = [];
    try {
      const result = await getSpreadsheet({ versionId: this._versionId });
      if (!result || !result.supported || !result.sheets) {
        this.fail(
          (result && result.message) ||
            "이 스프레드시트는 미리보기를 지원하지 않습니다. 아래에서 다운로드하세요."
        );
        return;
      }
      this.sheets = result.sheets.map((sheet, sIdx) => ({
        key: `s${sIdx}`,
        name: sheet.name || `Sheet ${sIdx + 1}`,
        truncated: sheet.truncated,
        rows: (sheet.rows || []).map((cells, rIdx) => ({
          key: `r${rIdx}`,
          cells: cells.map((value, cIdx) => ({
            key: `c${cIdx}`,
            value
          }))
        }))
      }));
      this.loading = false;
    } catch (e) {
      this.fail(
        (e && e.body && e.body.message) ||
          "스프레드시트를 불러오지 못했습니다. 아래에서 다운로드하세요."
      );
    }
  }

  fail(msg) {
    this.loading = false;
    this.failed = true;
    this.errorMsg = msg;
  }

  // --- image / rendition path ----------------------------------------------
  buildSrc(page) {
    // UI page state is 1-based; the rendition servlet is 0-based and needs
    // operationContext=CHATTER (see file header).
    const renditionPage = Math.max(0, (parseInt(page, 10) || 1) - 1);
    return (
      "/sfc/servlet.shepherd/version/renditionDownload" +
      `?rendition=${RENDITION}&versionId=${this._versionId}` +
      `&operationContext=CHATTER&page=${renditionPage}`
    );
  }

  loadPage(page) {
    this.currentPage = page;
    this.loading = true;
    this.failed = false;
    this.errorMsg = undefined;
    this.imgSrc = this.buildSrc(page);
  }

  handleImgLoad() {
    this.loading = false;
    this.imageReady = true;
    this._lastGoodPage = this.currentPage;
    // Rendering a page > 1 proves the document is multi-page, so reveal the
    // nav bar immediately (don't wait for the page-count scan).
    if (this.currentPage > 1) {
      this.knownMultiPage = true;
    }
  }

  handleImgError() {
    // If we've already shown a page, an error now means navigation landed on
    // a non-existent page (e.g. clicked past the end before the count was
    // known). Cap the count and bounce back to the last good page instead of
    // tearing the viewer down to the download fallback.
    if (this.imageReady && this._lastGoodPage >= 1) {
      this.pageCount = this._lastGoodPage;
      if (this.currentPage !== this._lastGoodPage) {
        this.loadPage(this._lastGoodPage); // cached -> loads instantly
      } else {
        this.loading = false;
      }
      return;
    }
    this.fail(
      "이 문서의 미리보기를 표시할 수 없습니다. 아래에서 다운로드하세요."
    );
  }

  // --- page count discovery (exponential probe + binary search) -------------
  probe(page) {
    if (this._probeCache.has(page)) {
      return this._probeCache.get(page);
    }
    const result = new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
      img.src = this.buildSrc(page);
    });
    this._probeCache.set(page, result);
    return result;
  }

  async discoverPageCount() {
    const vid = this._versionId;
    // Renditions are contiguous from page 0, so if the currently requested
    // page exists then every earlier page does too. Seed the lower bound at
    // currentPage (typically a deep link) and search only upward, which cuts
    // round-trips and lets the nav bar appear as soon as multi-page is known.
    const seed = Math.max(1, this.currentPage);
    let good;
    if (await this.probe(seed)) {
      good = seed;
    } else if (seed !== 1 && (await this.probe(1))) {
      good = 1; // deep link past the end; fall back to scanning from 1
    } else {
      if (this._versionId === vid) {
        this.pageCount = 0;
      }
      return;
    }
    if (good > 1) {
      this.knownMultiPage = true;
    }
    let bad = good + 1;
    let step = 1;
    // eslint-disable-next-line no-await-in-loop -- galloping search: each probe depends on the previous result, so it cannot be parallelized
    while (bad <= MAX_PAGES && (await this.probe(bad))) {
      good = bad;
      this.knownMultiPage = true;
      step *= 2;
      bad = good + step;
    }
    while (bad - good > 1) {
      const mid = Math.floor((good + bad) / 2);
      // eslint-disable-next-line no-await-in-loop -- binary search narrows the bound one probe at a time; the next mid needs this result
      if (await this.probe(mid)) {
        good = mid;
      } else {
        bad = mid;
      }
    }
    if (this._versionId !== vid) {
      return; // a newer file was selected while we were probing
    }
    this.pageCount = good;
    if (this.currentPage > this.pageCount) {
      this.loadPage(this.pageCount);
    }
  }

  // --- navigation -----------------------------------------------------------
  handlePrev() {
    if (!this.disablePrev) {
      this.loadPage(this.currentPage - 1);
    }
  }
  handleNext() {
    if (!this.disableNext) {
      this.loadPage(this.currentPage + 1);
    }
  }
  handlePageInput(event) {
    if (event.key && event.key !== "Enter") {
      return;
    }
    let target = parseInt(event.target.value, 10);
    if (Number.isNaN(target) || target < 1) {
      target = 1;
    }
    if (this.pageCount && target > this.pageCount) {
      target = this.pageCount;
    }
    this.loadPage(target);
  }

  get disablePrev() {
    return this.currentPage <= 1;
  }
  get disableNext() {
    return this.pageCount ? this.currentPage >= this.pageCount : false;
  }
  get pageLabel() {
    return this.pageCount
      ? `${this.currentPage} / ${this.pageCount}`
      : `${this.currentPage}`;
  }
  get showNav() {
    // Appear together with the preview image (imageReady) as soon as we know
    // the doc is multi-page, rather than waiting for the full count scan.
    return (
      !this.failed &&
      !this.isSpreadsheet &&
      this.imageReady &&
      (this.knownMultiPage || this.pageCount > 1)
    );
  }
  get showImage() {
    return !this.failed && !this.isSpreadsheet;
  }
  get showSheets() {
    return !this.failed && this.isSpreadsheet;
  }

  get downloadUrl() {
    return `/sfc/servlet.shepherd/document/download/${this.contentDocumentId}`;
  }

  // Salesforce's own native file viewer for the original document (standard
  // preview player: page nav, zoom, download). Stays in-org.
  get originalFileUrl() {
    return `/lightning/r/ContentDocument/${this.contentDocumentId}/view`;
  }
}
