import { createElement } from "lwc";
import MiBulkFileUpload from "c/miBulkFileUpload";
import inspectStagedFiles from "@salesforce/apex/MI_BulkFileUploadController.inspectStagedFiles";
import registerUploadedFiles from "@salesforce/apex/MI_BulkFileUploadController.registerUploadedFiles";
import getProcessingStatus from "@salesforce/apex/MI_BulkFileUploadController.getProcessingStatus";

// @salesforce/apex is auto-mocked by sfdx-lwc-jest; give the imperative Apex resolvable defaults so
// awaits complete. inspectStagedFiles is called on staging; registerUploadedFiles on commit;
// getProcessingStatus refreshes the dashboard after a successful commit.
jest.mock(
  "@salesforce/apex/MI_BulkFileUploadController.inspectStagedFiles",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_BulkFileUploadController.registerUploadedFiles",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_BulkFileUploadController.deleteStagedFiles",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_BulkFileUploadController.getProcessingStatus",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

function createComponent() {
  const element = createElement("c-mi-bulk-file-upload", {
    is: MiBulkFileUpload
  });
  document.body.appendChild(element);
  return element;
}

function flushPromises() {
  return Promise.resolve();
}

// Stages `count` files through the lightning-file-upload finished event. Each gets a unique
// contentDocumentId (069...) and, unless overridden, a distinct name.
function makeUploaded(count, nameFn) {
  const files = [];
  for (let i = 0; i < count; i += 1) {
    files.push({
      name: nameFn ? nameFn(i) : `file-${i}.pdf`,
      documentId: `069000000000${String(1000 + i)}`
    });
  }
  return files;
}

// IMPORTANT — what these tests can and cannot prove: this helper FABRICATES the `uploadfinished`
// event, so every test below starts AFTER the platform's byte-upload/ContentVersion-finalize step.
// Under Jest, `lightning-file-upload` is a stub that never transfers bytes. A real upload can be
// completely broken (modal stuck at "0 of N file uploaded") while this whole suite stays green —
// that is exactly what happened once. A green run here means "the staging queue, chunking and
// result reconciliation are correct", NOT "upload works". Only a manual/org test proves that; the
// closest automated guard is the "uploader element contract" test at the bottom of this file.
async function stageFiles(element, uploaded) {
  const uploader = element.shadowRoot.querySelector("lightning-file-upload");
  uploader.dispatchEvent(
    new CustomEvent("uploadfinished", { detail: { files: uploaded } })
  );
  // Let handleUploadFinished + the inspectStagedFiles await settle.
  await flushPromises();
  await flushPromises();
}

function clickUploadAll(element) {
  const buttons = element.shadowRoot.querySelectorAll("lightning-button");
  const uploadBtn = Array.from(buttons).find((b) => b.label === "전체 업로드");
  uploadBtn.click();
}

function clickButton(element, label) {
  const buttons = element.shadowRoot.querySelectorAll("lightning-button");
  Array.from(buttons)
    .find((b) => b.label === label)
    .click();
}

// Builds a ProcessingStatusRow-shaped object as the Apex controller returns it.
function statusRow(overrides) {
  return {
    recordId: "a01000000000001",
    fileName: "file.pdf",
    documentType: "외부보고서",
    chunkCount: 3,
    indexCount: 3,
    fileSizeBytes: 2048,
    fileSize: "2.0 KB",
    isComplete: true,
    isError: false,
    uploadedAt: "2026-08-01 09:00",
    uploadedDate: "2026-08-01",
    ...overrides
  };
}

// Loads the 처리 현황 dashboard by clicking 새로고침 (unconditional), then draining the await.
async function loadDashboard(element) {
  clickButton(element, "새로고침");
  await flushPromises();
  await flushPromises();
}

// Finds a lightning-input by its label (the jest stub does not reflect `type` as a queryable
// attribute, so an attribute selector won't match — match on the label property instead).
function inputByLabel(element, label) {
  return Array.from(
    element.shadowRoot.querySelectorAll("lightning-input")
  ).find((i) => i.label === label);
}

// Default registerUploadedFiles stub: every input file succeeds, echoing its contentDocumentId.
function allSucceed(args) {
  return (args.files || []).map((f) => ({
    isSuccess: true,
    fileName: f.fileName,
    contentDocumentId: f.contentDocumentId,
    recordId: `a01_${f.contentDocumentId}`
  }));
}

describe("c-mi-bulk-file-upload", () => {
  beforeEach(() => {
    inspectStagedFiles.mockResolvedValue([]);
    getProcessingStatus.mockResolvedValue([]);
  });

  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders the uploader and the empty state before any file is staged", () => {
    const element = createComponent();
    return flushPromises().then(() => {
      expect(
        element.shadowRoot.querySelector("lightning-file-upload")
      ).not.toBeNull();
      expect(element.shadowRoot.textContent).toContain(
        "아직 업로드된 파일이 없습니다."
      );
    });
  });

  it("stages files and flags content duplicates from inspectStagedFiles", async () => {
    const uploaded = makeUploaded(2);
    inspectStagedFiles.mockResolvedValue([
      {
        contentDocumentId: uploaded[0].documentId,
        isDuplicate: true,
        existingDate: "2026-01-01"
      }
    ]);
    const element = createComponent();
    await stageFiles(element, uploaded);

    const rows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(rows.length).toBe(2);
    // The first file is flagged 중복; the second stays 대기.
    expect(element.shadowRoot.textContent).toContain("중복");
    expect(inspectStagedFiles).toHaveBeenCalledWith({
      contentDocumentIds: uploaded.map((f) => f.documentId)
    });
  });

  it("commits a small queue (< CHUNK_SIZE) in a single registerUploadedFiles call", async () => {
    registerUploadedFiles.mockImplementation((args) =>
      Promise.resolve(allSucceed(args))
    );
    const element = createComponent();
    await stageFiles(element, makeUploaded(5));

    clickUploadAll(element);
    await flushPromises();
    await flushPromises();

    expect(registerUploadedFiles).toHaveBeenCalledTimes(1);
    expect(registerUploadedFiles.mock.calls[0][0].files.length).toBe(5);
  });

  it("commits a large queue in sequential chunks of at most CHUNK_SIZE (15)", async () => {
    registerUploadedFiles.mockImplementation((args) =>
      Promise.resolve(allSucceed(args))
    );
    const element = createComponent();
    await stageFiles(element, makeUploaded(35));

    clickUploadAll(element);
    // Drain the sequential await chain: 3 chunks + result handling.
    for (let i = 0; i < 12; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await flushPromises();
    }

    // 35 files -> ceil(35/15) = 3 chunks.
    expect(registerUploadedFiles).toHaveBeenCalledTimes(3);
    const sizes = registerUploadedFiles.mock.calls.map(
      (c) => c[0].files.length
    );
    expect(sizes).toEqual([15, 15, 5]);
    // No chunk ever exceeds the cap.
    sizes.forEach((s) => expect(s).toBeLessThanOrEqual(15));
  });

  it("clears succeeded rows and keeps only failed rows after commit", async () => {
    const element = createComponent();
    await stageFiles(element, makeUploaded(3));

    // Fail the middle file only, matched back by contentDocumentId.
    registerUploadedFiles.mockImplementation((args) => {
      const files = args.files;
      return Promise.resolve(
        files.map((f, idx) => {
          if (idx === 1) {
            return {
              isSuccess: false,
              fileName: f.fileName,
              contentDocumentId: f.contentDocumentId,
              errorMessage: "권한 없음"
            };
          }
          return {
            isSuccess: true,
            fileName: f.fileName,
            contentDocumentId: f.contentDocumentId,
            recordId: `a01_${f.contentDocumentId}`
          };
        })
      );
    });

    clickUploadAll(element);
    await flushPromises();
    await flushPromises();
    await flushPromises();

    const rows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(rows.length).toBe(1);
    expect(element.shadowRoot.textContent).toContain("권한 없음");
    expect(element.shadowRoot.textContent).toContain("오류");
  });

  it("attributes failures to the correct row by contentDocumentId when file names collide", async () => {
    // Two files share the exact same name; only the SECOND (unique contentDocumentId) fails.
    const uploaded = makeUploaded(2, () => "dup-name.pdf");
    const element = createComponent();
    await stageFiles(element, uploaded);

    const failingId = uploaded[1].documentId;
    registerUploadedFiles.mockImplementation((args) =>
      Promise.resolve(
        args.files.map((f) => ({
          isSuccess: f.contentDocumentId !== failingId,
          fileName: f.fileName,
          contentDocumentId: f.contentDocumentId,
          errorMessage:
            f.contentDocumentId === failingId ? "그 파일만 실패" : undefined,
          recordId:
            f.contentDocumentId === failingId
              ? undefined
              : `a01_${f.contentDocumentId}`
        }))
      )
    );

    clickUploadAll(element);
    await flushPromises();
    await flushPromises();
    await flushPromises();

    // Exactly one row remains — and it is the one whose contentDocumentId failed, not merely a
    // name match (fileName matching would have collapsed both same-named rows).
    const rows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(rows.length).toBe(1);
    expect(element.shadowRoot.textContent).toContain("그 파일만 실패");
  });

  it("shows an error toast and keeps the queue when a chunk commit throws", async () => {
    const element = createComponent();
    await stageFiles(element, makeUploaded(3));
    registerUploadedFiles.mockRejectedValue({ body: { message: "서버 오류" } });

    clickUploadAll(element);
    await flushPromises();
    await flushPromises();
    await flushPromises();

    // The queue is preserved (nothing dropped) so the user can retry.
    const rows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(rows.length).toBe(3);
  });

  // ---- 처리 현황 dashboard: badges, new columns, filters ------------------------------------

  it("maps the RAG badges: fully indexed -> 처리완료, partial -> 오류, no chunks -> 처리중", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({
        recordId: "d1",
        fileName: "done.pdf",
        chunkCount: 4,
        indexCount: 4,
        isComplete: true,
        isError: false
      }),
      statusRow({
        recordId: "d2",
        fileName: "err.pdf",
        chunkCount: 4,
        indexCount: 1,
        isComplete: false,
        isError: true
      }),
      statusRow({
        recordId: "d3",
        fileName: "ingest.pdf",
        chunkCount: 0,
        indexCount: 0,
        isComplete: false,
        isError: false
      })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("처리완료");
    expect(text).toContain("오류");
    expect(text).toContain("처리중");
  });

  it("renders the new columns: 문서 유형, 청크 수, 파일 크기", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({
        documentType: "증권사보고서",
        chunkCount: 7,
        fileSize: "1.5 MB"
      })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("증권사보고서");
    expect(text).toContain("7");
    expect(text).toContain("1.5 MB");
  });

  it("filters the dashboard by file name search", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({ recordId: "d1", fileName: "삼성전자.pdf" }),
      statusRow({ recordId: "d2", fileName: "hynix.pdf" })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const search = inputByLabel(element, "파일명 검색");
    search.value = "hynix";
    search.dispatchEvent(new CustomEvent("change", { target: search }));
    await flushPromises();

    const bodyRows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(bodyRows.length).toBe(1);
    expect(element.shadowRoot.textContent).toContain("hynix.pdf");
    expect(element.shadowRoot.textContent).not.toContain("삼성전자.pdf");
  });

  it("filters the dashboard by status", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({
        recordId: "d1",
        fileName: "done.pdf",
        isComplete: true,
        isError: false
      }),
      statusRow({
        recordId: "d2",
        fileName: "err.pdf",
        chunkCount: 4,
        indexCount: 0,
        isComplete: false,
        isError: true
      })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const combobox = element.shadowRoot.querySelector("lightning-combobox");
    combobox.dispatchEvent(
      new CustomEvent("change", { detail: { value: "오류" } })
    );
    await flushPromises();

    const bodyRows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(bodyRows.length).toBe(1);
    expect(element.shadowRoot.textContent).toContain("err.pdf");
    expect(element.shadowRoot.textContent).not.toContain("done.pdf");
  });

  it("filters the dashboard by upload date range", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({
        recordId: "d1",
        fileName: "old.pdf",
        uploadedDate: "2026-01-01"
      }),
      statusRow({
        recordId: "d2",
        fileName: "new.pdf",
        uploadedDate: "2026-08-01"
      })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const fromInput = inputByLabel(element, "시작일");
    fromInput.value = "2026-06-01";
    fromInput.dispatchEvent(new CustomEvent("change", { target: fromInput }));
    await flushPromises();

    const bodyRows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(bodyRows.length).toBe(1);
    expect(element.shadowRoot.textContent).toContain("new.pdf");
    expect(element.shadowRoot.textContent).not.toContain("old.pdf");
  });

  it("clears all filters with 필터 초기화", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({ recordId: "d1", fileName: "삼성전자.pdf" }),
      statusRow({ recordId: "d2", fileName: "hynix.pdf" })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const search = inputByLabel(element, "파일명 검색");
    search.value = "hynix";
    search.dispatchEvent(new CustomEvent("change", { target: search }));
    await flushPromises();
    expect(element.shadowRoot.querySelectorAll("tbody tr").length).toBe(1);

    clickButton(element, "필터 초기화");
    await flushPromises();

    expect(element.shadowRoot.querySelectorAll("tbody tr").length).toBe(2);
  });

  it("shows a distinct empty state when no row matches the filters", async () => {
    getProcessingStatus.mockResolvedValue([
      statusRow({ recordId: "d1", fileName: "삼성전자.pdf" })
    ]);
    const element = createComponent();
    await loadDashboard(element);

    const search = inputByLabel(element, "파일명 검색");
    search.value = "no-such-file";
    search.dispatchEvent(new CustomEvent("change", { target: search }));
    await flushPromises();

    expect(element.shadowRoot.querySelectorAll("tbody tr").length).toBe(0);
    expect(element.shadowRoot.textContent).toContain(
      "필터 조건에 맞는 문서가 없습니다."
    );
  });
});
