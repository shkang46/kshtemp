import { LightningElement, track } from "lwc";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import inspectStagedFiles from "@salesforce/apex/MI_BulkFileUploadController.inspectStagedFiles";
import registerUploadedFiles from "@salesforce/apex/MI_BulkFileUploadController.registerUploadedFiles";
import deleteStagedFiles from "@salesforce/apex/MI_BulkFileUploadController.deleteStagedFiles";
import getProcessingStatus from "@salesforce/apex/MI_BulkFileUploadController.getProcessingStatus";

// Formats accepted by lightning-file-upload (mirrors the facet pipeline's supported types).
const ACCEPTED_FORMATS = ".pdf,.ppt,.pptx,.xls,.xlsx,.doc,.docx";

// Files committed per registerUploadedFiles call. The commit path costs ~3 DML + ~2 SOQL + 1
// enqueue PER file in a single transaction (record insert + link insert, plus the synchronous
// facet trigger), so an unbounded batch trips the 50-enqueue / 100-SOQL / 150-DML governor limits
// at ~50 files and rolls the whole commit back. Committing in chunks keeps each transaction well
// under those limits regardless of how large the accumulated queue grows.
const CHUNK_SIZE = 15;

// Per-file queue status. The value IS the Korean badge label (no separate label lookup needed).
// These are pre-commit states — nothing is uploaded to the library until 전체 업로드.
const STATUS = {
  STAGED: "대기", //     bytes staged, awaiting a document type / commit
  READY: "준비완료", //  type chosen — ready to commit
  DUPLICATE: "중복", //  same content already in the library (by checksum)
  ERROR: "오류" //       commit failed
};

// Dashboard (처리 현황) status — derived server-side from Data Cloud chunk + index row counts:
// 처리중 (no chunks yet) · 처리완료 (all chunks indexed) · 오류 (chunked but not fully indexed).
const PROCESSING = {
  PROCESSING: "처리중",
  DONE: "처리완료",
  ERROR: "오류"
};

// "전체" (all) sentinel for the status filter, plus the selectable filter options.
const STATUS_FILTER_ALL = "전체";
const STATUS_FILTER_OPTIONS = [
  { label: STATUS_FILTER_ALL, value: STATUS_FILTER_ALL },
  { label: PROCESSING.PROCESSING, value: PROCESSING.PROCESSING },
  { label: PROCESSING.DONE, value: PROCESSING.DONE },
  { label: PROCESSING.ERROR, value: PROCESSING.ERROR }
];

// The 5 document-type picklist values (Document_Type__c). Value == label (Korean).
const DOCUMENT_TYPE_OPTIONS = [
  { label: "공시자료", value: "공시자료" },
  { label: "외부보고서", value: "외부보고서" },
  { label: "증권사보고서", value: "증권사보고서" },
  { label: "컨설팅보고서", value: "컨설팅보고서" },
  { label: "내부보고서", value: "내부보고서" }
];

/**
 * Bulk uploader for market-research documents. Picking files stages their bytes via
 * lightning-file-upload (streamed server-side, no size limit) but commits nothing; the user assigns a
 * document type per file and then clicks 전체 업로드 to create the Market_Insight_Document__c records
 * and start downstream processing. Content duplicates are flagged (by checksum) before commit. The
 * queue clears after a successful commit; a second tab monitors Data Cloud processing. All
 * user-facing copy is Korean.
 */
export default class MiBulkFileUpload extends LightningElement {
  @track files = [];
  @track statusRows = [];
  showGuidance = true;
  isBusy = false;
  isLoadingStatus = false;
  hasLoadedStatus = false;
  selectedKeys = new Set();
  uploadDone = 0; // files committed so far in the in-flight chunked upload
  uploadTotal = 0; // total files in the in-flight chunked upload (0 when idle)
  _seq = 0; // monotonic row-key source (avoids Date.now/Math.random)

  // Dashboard filters (client-side, over the loaded statusRows — see filteredStatusRows).
  searchTerm = "";
  statusFilter = STATUS_FILTER_ALL;
  dateFrom = "";
  dateTo = "";

  acceptedFormats = ACCEPTED_FORMATS;
  documentTypeOptions = DOCUMENT_TYPE_OPTIONS;
  statusFilterOptions = STATUS_FILTER_OPTIONS;

  // ---- Staging (lightning-file-upload finishes; no commit yet) ------------------------------

  /**
   * Handles lightning-file-upload completion: adds a staged row per file, then runs a read-only
   * duplicate check so 중복 shows before the user commits. No record is created here.
   *
   * @param {CustomEvent} event carrying detail.files (each {name, documentId})
   */
  async handleUploadFinished(event) {
    const uploaded = event.detail.files || [];
    if (!uploaded.length) {
      return;
    }
    const newRows = uploaded.map((f) => this.toStagedRow(f));
    this.files = [...this.files, ...newRows];

    try {
      const infos =
        (await inspectStagedFiles({
          contentDocumentIds: newRows.map((r) => r.contentDocumentId)
        })) || [];
      const infoByDocId = new Map(infos.map((i) => [i.contentDocumentId, i]));
      this.files = this.files.map((row) => {
        const info = infoByDocId.get(row.contentDocumentId);
        if (info && info.isDuplicate) {
          return {
            ...row,
            status: STATUS.DUPLICATE,
            existingDate: info.existingDate
          };
        }
        return row;
      });
    } catch (error) {
      // Non-fatal: the files are still staged and committable; dup flagging is best-effort.
      this.toast("중복 확인 오류", this.resolveError(error), "warning");
    }
  }

  /**
   * Builds a staged queue row from a lightning-file-upload result.
   *
   * @param {object} uploadedFile an {name, documentId} entry
   * @returns {object} the row model
   */
  toStagedRow(uploadedFile) {
    this._seq += 1;
    return {
      key: `f-${this._seq}`,
      contentDocumentId: uploadedFile.documentId,
      name: uploadedFile.name,
      documentType: "",
      status: STATUS.STAGED,
      errorMessage: undefined,
      existingDate: undefined
    };
  }

  // ---- Document type (client-side only — no Apex until commit) ------------------------------

  /**
   * Records the chosen document type on the row and flips its status to 준비완료. Purely client-side;
   * the value is persisted only when the user commits via 전체 업로드.
   *
   * @param {Event} event the combobox change carrying the row key + value
   */
  handleTypeChange(event) {
    const key = event.target.dataset.key;
    const value = event.detail.value;
    this.files = this.files.map((row) => {
      if (row.key !== key) {
        return row;
      }
      // A duplicate stays flagged as 중복; otherwise choosing a type marks it ready.
      const status =
        row.status === STATUS.DUPLICATE ? STATUS.DUPLICATE : STATUS.READY;
      return { ...row, documentType: value, status };
    });
  }

  // ---- Commit (전체 업로드) ------------------------------------------------------------------

  /**
   * Commits every queued file in bounded chunks: each chunk creates its document records + starts
   * processing in its own Apex transaction, so an arbitrarily large queue never trips the per-file
   * governor limits that a single all-in-one commit would (see CHUNK_SIZE). Succeeded rows are
   * dropped, failed rows are kept and flagged, and any files staged mid-commit are preserved.
   */
  async handleUploadAll() {
    if (!this.files.length) {
      return;
    }
    this.isBusy = true;
    // Snapshot the queue at commit time so files staged mid-commit are not mistaken for failures.
    const snapshot = this.files.map((row) => ({
      fileName: row.name,
      contentDocumentId: row.contentDocumentId,
      documentType: row.documentType
    }));
    const committedIds = new Set(snapshot.map((f) => f.contentDocumentId));
    const chunks = this.chunk(snapshot, CHUNK_SIZE);

    // Failure message keyed by the unique contentDocumentId (never fileName — same-named files
    // must be attributed to their own row).
    const failedById = new Map();
    let successCount = 0;
    this.uploadDone = 0;
    this.uploadTotal = snapshot.length;

    try {
      for (const files of chunks) {
        // eslint-disable-next-line no-await-in-loop -- chunks MUST commit sequentially: each is its own transaction, and running them in parallel would recreate the governor-limit blow-up this chunking exists to prevent.
        const results = (await registerUploadedFiles({ files })) || [];
        // Plain for..of (not forEach) so this does not declare a function that closes over the
        // loop-scoped accumulators (no-loop-func).
        for (const r of results) {
          if (r.isSuccess) {
            successCount += 1;
          } else {
            failedById.set(
              r.contentDocumentId,
              r.errorMessage || "업로드에 실패했습니다."
            );
          }
        }
        this.uploadDone += files.length;
      }

      // Keep rows that failed OR were staged after this commit began; drop succeeded rows.
      this.files = this.files
        .filter(
          (row) =>
            !committedIds.has(row.contentDocumentId) ||
            failedById.has(row.contentDocumentId)
        )
        .map((row) => {
          if (!failedById.has(row.contentDocumentId)) {
            return row;
          }
          return {
            ...row,
            status: STATUS.ERROR,
            errorMessage: failedById.get(row.contentDocumentId)
          };
        });
      this.selectedKeys = new Set();

      this.toast(
        "업로드 완료",
        `${successCount}개 업로드 완료${failedById.size ? `, ${failedById.size}개 오류` : ""}`,
        failedById.size ? "warning" : "success"
      );

      if (this.hasLoadedStatus) {
        this.loadProcessingStatus();
      }
    } catch (error) {
      this.toast("업로드 오류", this.resolveError(error), "error");
    } finally {
      this.isBusy = false;
      this.uploadDone = 0;
      this.uploadTotal = 0;
    }
  }

  /**
   * Splits an array into fixed-size chunks (the last chunk may be smaller).
   *
   * @param {Array} items the array to split
   * @param {number} size the maximum chunk size
   * @returns {Array<Array>} the chunked array
   */
  chunk(items, size) {
    const chunks = [];
    for (let i = 0; i < items.length; i += size) {
      chunks.push(items.slice(i, i + size));
    }
    return chunks;
  }

  // ---- Selection + delete (staged files) ----------------------------------------------------

  handleSelectRow(event) {
    const key = event.target.dataset.key;
    if (event.target.checked) {
      this.selectedKeys.add(key);
    } else {
      this.selectedKeys.delete(key);
    }
    // Reassign to trigger reactivity on the derived getters.
    this.selectedKeys = new Set(this.selectedKeys);
  }

  handleSelectAll(event) {
    this.selectedKeys = event.target.checked
      ? new Set(this.files.map((r) => r.key))
      : new Set();
  }

  /**
   * Removes the selected staged files (deletes the orphan ContentDocuments), then drops them from
   * the reactive queue.
   */
  async handleDelete() {
    const selected = this.files.filter((r) => this.selectedKeys.has(r.key));
    if (!selected.length) {
      return;
    }
    this.isBusy = true;
    try {
      const contentDocumentIds = selected
        .map((r) => r.contentDocumentId)
        .filter((id) => !!id);
      if (contentDocumentIds.length) {
        await deleteStagedFiles({ contentDocumentIds });
      }
      const removed = new Set(selected.map((r) => r.key));
      this.files = this.files.filter((r) => !removed.has(r.key));
      this.selectedKeys = new Set();
    } catch (error) {
      this.toast("삭제 오류", this.resolveError(error), "error");
    } finally {
      this.isBusy = false;
    }
  }

  // ---- Processing dashboard -----------------------------------------------------------------

  handleTabActive(event) {
    if (event.target.value === "status" && !this.hasLoadedStatus) {
      this.loadProcessingStatus();
    }
  }

  handleRefreshStatus() {
    this.loadProcessingStatus();
  }

  // ---- Dashboard filters (client-side) ------------------------------------------------------

  handleSearchChange(event) {
    this.searchTerm = event.target.value || "";
  }

  handleStatusFilterChange(event) {
    this.statusFilter = event.detail.value;
  }

  handleDateFromChange(event) {
    this.dateFrom = event.target.value || "";
  }

  handleDateToChange(event) {
    this.dateTo = event.target.value || "";
  }

  handleClearFilters() {
    this.searchTerm = "";
    this.statusFilter = STATUS_FILTER_ALL;
    this.dateFrom = "";
    this.dateTo = "";
  }

  /**
   * Loads the dashboard from Apex (CRM list + derived Data Cloud chunk/index counts + file size).
   */
  async loadProcessingStatus() {
    this.isLoadingStatus = true;
    try {
      const rows = (await getProcessingStatus()) || [];
      this.statusRows = rows.map((r) => this.toStatusRow(r));
      this.hasLoadedStatus = true;
    } catch (error) {
      this.toast("현황 오류", this.resolveError(error), "error");
    } finally {
      this.isLoadingStatus = false;
    }
  }

  /**
   * Maps a ProcessingStatusRow to the dashboard view model, resolving the badge + icon. Status is
   * derived server-side from RAG chunk/index counts (오류 → 처리완료 → 처리중 precedence) and echoed
   * here via the isError/isComplete booleans.
   *
   * @param {object} row a ProcessingStatusRow
   * @returns {object} the dashboard row model
   */
  toStatusRow(row) {
    let status = PROCESSING.PROCESSING;
    if (row.isError) {
      status = PROCESSING.ERROR;
    } else if (row.isComplete) {
      status = PROCESSING.DONE;
    }
    return {
      recordId: row.recordId,
      name: row.fileName,
      documentType: row.documentType,
      chunkCount: row.chunkCount,
      indexCount: row.indexCount,
      fileSize: row.fileSize,
      uploadedAt: row.uploadedAt,
      uploadedDate: row.uploadedDate,
      status,
      badgeClass: this.processingBadgeClass(status),
      iconName: this.processingIconName(status),
      iconVariant: this.processingIconVariant(status)
    };
  }

  /**
   * @param {string} status a dashboard status
   * @returns {string} the SLDS icon for that status (traffic-light)
   */
  processingIconName(status) {
    switch (status) {
      case PROCESSING.DONE:
        return "utility:success";
      case PROCESSING.ERROR:
        return "utility:error";
      default:
        return "utility:clock"; // 처리중
    }
  }

  /**
   * @param {string} status a dashboard status
   * @returns {string} the lightning-icon variant for that status
   */
  processingIconVariant(status) {
    switch (status) {
      case PROCESSING.DONE:
        return "success";
      case PROCESSING.ERROR:
        return "error";
      default:
        return ""; // 처리중
    }
  }

  // ---- Helpers ------------------------------------------------------------------------------

  handleDismissGuidance() {
    this.showGuidance = false;
  }

  /**
   * @param {*} error a caught error
   * @returns {string} a sanitized Korean message
   */
  resolveError(error) {
    if (error && error.body && error.body.message) {
      return error.body.message;
    }
    if (error && error.message) {
      return error.message;
    }
    return "요청을 처리하지 못했습니다.";
  }

  toast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }

  /**
   * @param {string} status a queue status
   * @returns {string} the SLDS badge classes for that status
   */
  badgeClass(status) {
    const base = "slds-badge";
    switch (status) {
      case STATUS.READY:
        return `${base} slds-theme_success`;
      case STATUS.ERROR:
        return `${base} slds-theme_error`;
      case STATUS.DUPLICATE:
        return `${base} slds-theme_warning`;
      default:
        return base; // 대기
    }
  }

  /**
   * @param {string} status a dashboard status
   * @returns {string} the SLDS badge classes for that status (traffic-light)
   */
  processingBadgeClass(status) {
    const base = "slds-badge";
    switch (status) {
      case PROCESSING.DONE:
        return `${base} slds-theme_success`;
      case PROCESSING.ERROR:
        return `${base} slds-theme_error`;
      default:
        return `${base} slds-badge_inverse`; // 처리중
    }
  }

  // ---- Derived view state -------------------------------------------------------------------

  get hasFiles() {
    return this.files.length > 0;
  }

  get displayRows() {
    return this.files.map((row) => ({
      ...row,
      isDuplicate: row.status === STATUS.DUPLICATE,
      duplicateNote: row.existingDate
        ? `${row.existingDate}에 동일 파일이 이미 업로드됨`
        : "",
      badgeClass: this.badgeClass(row.status),
      typeDisabled: this.isBusy,
      selected: this.selectedKeys.has(row.key)
    }));
  }

  get selectedCount() {
    return this.selectedKeys.size;
  }

  get deleteDisabled() {
    return this.isBusy || this.selectedKeys.size === 0;
  }

  get uploadDisabled() {
    return this.isBusy || !this.hasFiles;
  }

  get allSelected() {
    return this.hasFiles && this.selectedKeys.size === this.files.length;
  }

  get hasStatusRows() {
    return this.statusRows.length > 0;
  }

  /**
   * Dashboard rows matching the search / status / date filters. Client-side over the loaded rows
   * (server caps at the newest 200), so it narrows the view but can't reach older docs.
   *
   * @returns {Array} the rows matching every active filter
   */
  get filteredStatusRows() {
    const term = this.searchTerm.trim().toLowerCase();
    const from = this.dateFrom;
    const to = this.dateTo;
    return this.statusRows.filter((row) => {
      if (term && !(row.name || "").toLowerCase().includes(term)) {
        return false;
      }
      if (
        this.statusFilter !== STATUS_FILTER_ALL &&
        row.status !== this.statusFilter
      ) {
        return false;
      }
      // uploadedDate is an ISO yyyy-MM-dd string, so lexicographic compare == date compare.
      const date = row.uploadedDate || "";
      if (from && date < from) {
        return false;
      }
      if (to && date > to) {
        return false;
      }
      return true;
    });
  }

  get hasFilteredRows() {
    return this.filteredStatusRows.length > 0;
  }

  get filteredCount() {
    return this.filteredStatusRows.length;
  }

  get isUploading() {
    return this.uploadTotal > 0;
  }

  get uploadProgressLabel() {
    return `업로드 중… ${this.uploadDone} / ${this.uploadTotal}`;
  }
}
