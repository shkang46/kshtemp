import { LightningElement, api, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import getRelatedFiles from '@salesforce/apex/MI_DocumentPreviewController.getRelatedFiles';

// Preview-capable extensions. Anything else (images already render natively in
// the Files list, zip, etc.) is filtered out so the inline viewer only shows
// files it can actually render (rendition servlet for PDF/PPT/Word, OOXML for
// Excel — see miDocumentPreview.js / MI_DocumentPreviewController.cls).
const PREVIEWABLE = new Set([
    'pdf',
    'ppt',
    'pptx',
    'doc',
    'docx',
    'xls',
    'xlsx'
]);

// Placed under the standard Files related list on a record page: auto-loads the
// record's attached files and renders the selected one inline (no click needed).
// Reuses getRelatedFiles (sharing-enforced) and the miDocumentPreview viewer.
export default class MiRecordFilePreview extends LightningElement {
    @api recordId;

    files = [];
    selectedDocId;
    error;
    loaded = false;

    // Deep-link inputs read from the record page URL state (c__ prefix is
    // required for custom params to survive on a standard record page):
    //   ?c__page=3            -> start the preview on page/slide 3
    //   ?c__docId=069...      -> preview this specific attached file (optional;
    //                            defaults to the first previewable file)
    _deepLinkPage = 1;
    _deepLinkDocId;
    _userSelected = false;

    @wire(CurrentPageReference)
    setPageRef(pageRef) {
        const state = (pageRef && pageRef.state) || {};
        const p = parseInt(state.c__page, 10);
        this._deepLinkPage = Number.isNaN(p) || p < 1 ? 1 : p;
        this._deepLinkDocId = state.c__docId;
        // If the URL targets a specific, already-loaded file, honor it.
        if (this._deepLinkDocId && this._hasDoc(this._deepLinkDocId)) {
            this.selectedDocId = this._deepLinkDocId;
            this._userSelected = false;
        }
    }

    @wire(getRelatedFiles, { recordId: '$recordId' })
    wiredFiles({ data, error }) {
        if (data) {
            this.files = data.filter((f) =>
                PREVIEWABLE.has((f.fileExtension || '').toLowerCase())
            );
            if (this.files.length && !this._stillSelected()) {
                // Prefer the deep-linked file if the URL named one; otherwise
                // default to the first previewable file so something shows at once.
                this.selectedDocId =
                    (this._deepLinkDocId &&
                        this._hasDoc(this._deepLinkDocId) &&
                        this._deepLinkDocId) ||
                    this.files[0].contentDocumentId;
            }
            this.error = undefined;
            this.loaded = true;
        } else if (error) {
            this.error =
                (error.body && error.body.message) ||
                '파일을 불러오지 못했습니다.';
            this.files = [];
            this.loaded = true;
        }
    }

    _stillSelected() {
        return this.selectedDocId && this._hasDoc(this.selectedDocId);
    }

    _hasDoc(docId) {
        return this.files.some((f) => f.contentDocumentId === docId);
    }

    // The deep-linked start page applies only to the file the URL actually
    // targets (or the auto-selected default when the URL gave only c__page).
    // Once the user picks a different file from the dropdown, start at page 1.
    get activeInitialPage() {
        if (this._userSelected) {
            return 1;
        }
        if (this._deepLinkDocId && this.selectedDocId !== this._deepLinkDocId) {
            return 1;
        }
        return this._deepLinkPage;
    }

    get selectedFile() {
        return this.files.find(
            (f) => f.contentDocumentId === this.selectedDocId
        );
    }

    get hasFiles() {
        return this.files.length > 0;
    }

    get hasMultiple() {
        return this.files.length > 1;
    }

    // Options for the file picker shown only when more than one file exists.
    get fileOptions() {
        return this.files.map((f) => ({
            label: f.title,
            value: f.contentDocumentId
        }));
    }

    get showEmpty() {
        return this.loaded && !this.error && !this.hasFiles;
    }

    handleSelect(event) {
        this.selectedDocId = event.detail.value;
        this._userSelected = true;
    }
}