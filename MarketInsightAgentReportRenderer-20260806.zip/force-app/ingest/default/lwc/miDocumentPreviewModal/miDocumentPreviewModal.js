import { api } from 'lwc';
import LightningModal from 'lightning/modal';

/**
 * miDocumentPreviewModal — thin LightningModal wrapper around miDocumentPreview,
 * for showing a file preview in a modal dialog (open via modal.open({...})).
 * Passes contentDocumentId / versionId / fileTitle / initialPage straight
 * through to the viewer; the footer button closes the modal.
 */

export default class MiDocumentPreviewModal extends LightningModal {
    @api contentDocumentId;
    @api versionId;
    @api fileTitle;
    @api initialPage;

    handleClose() {
        this.close('closed');
    }
}