import { createElement } from "lwc";
import MiDocumentFacetReindex from "c/miDocumentFacetReindex";
import { getRecord } from "lightning/uiRecordApi";
import reindexFacets from "@salesforce/apex/MI_MarketInsightDocumentController.reindexFacets";

// @salesforce/apex and lightning/* are auto-mocked by sfdx-lwc-jest; give the imperative Apex a
// resolvable default so awaits complete.
jest.mock(
  "@salesforce/apex/MI_MarketInsightDocumentController.reindexFacets",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

const RECORD_ID = "a01000000000001AAA";

function createComponent() {
  const element = createElement("c-mi-document-facet-reindex", {
    is: MiDocumentFacetReindex
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

// Emit a record into the getRecord wire with the given Extraction_Status__c value, and optionally an
// Extraction_Error__c note.
function emitStatus(status, errorDetail = null) {
  getRecord.emit({
    fields: {
      Extraction_Status__c: { value: status },
      Extraction_Generated_At__c: { value: null },
      Extraction_Error__c: { value: errorDetail }
    }
  });
}

function flushPromises() {
  return Promise.resolve();
}

describe("c-mi-document-facet-reindex", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows a placeholder status and an enabled button before any record loads", () => {
    const element = createComponent();
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button).not.toBeNull();
      expect(button.disabled).toBe(false);
      expect(element.shadowRoot.textContent).toContain("미처리");
    });
  });

  it("disables the button while status is Generating", () => {
    const element = createComponent();
    emitStatus("Generating");
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button.disabled).toBe(true);
    });
  });

  it("enables the button and shows the status when Complete", () => {
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises().then(() => {
      const button = element.shadowRoot.querySelector("lightning-button");
      expect(button.disabled).toBe(false);
      expect(element.shadowRoot.textContent).toContain("Complete");
    });
  });

  it("calls reindexFacets with the recordId when the button is clicked", () => {
    reindexFacets.mockResolvedValue(undefined);
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises()
      .then(() => {
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => {
        expect(reindexFacets).toHaveBeenCalledTimes(1);
        expect(reindexFacets).toHaveBeenCalledWith({ recordId: RECORD_ID });
      });
  });

  it("shows the body-text note on a Complete document so a metadata-only facet is visible", () => {
    // The defect this prevents: a "[본문 미반영]" note rides on a COMPLETE document, so a panel gated on
    // the Error status would render nothing and the user would read a clean Complete — never learning the
    // facets describe the file name rather than its contents.
    const element = createComponent();
    emitStatus("Complete", "[본문 미반영] 본문 텍스트를 추출하지 못했습니다.");
    return flushPromises().then(() => {
      const text = element.shadowRoot.textContent;
      expect(text).toContain("본문 미반영 안내");
      expect(text).toContain("파일 메타데이터만으로");
      // Presented as information, not as a failure — the facets really were generated.
      const icon = element.shadowRoot.querySelector("lightning-icon");
      expect(icon.iconName).toBe("utility:info");
      expect(icon.variant).toBe("");
    });
  });

  it("shows a real failure as an error panel", () => {
    const element = createComponent();
    emitStatus("Error", "Facet prompt returned no parseable JSON.");
    return flushPromises().then(() => {
      expect(element.shadowRoot.textContent).toContain("생성 오류 상세");
      const icon = element.shadowRoot.querySelector("lightning-icon");
      expect(icon.iconName).toBe("utility:error");
      expect(icon.variant).toBe("error");
    });
  });

  it("renders no detail panel when there is no note", () => {
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises().then(() => {
      expect(
        element.shadowRoot.querySelector("lightning-formatted-text")
      ).toBeNull();
    });
  });

  it("does not throw when the reindex Apex call rejects", () => {
    reindexFacets.mockRejectedValue({ body: { message: "boom" } });
    const element = createComponent();
    emitStatus("Complete");
    return flushPromises()
      .then(() => {
        element.shadowRoot.querySelector("lightning-button").click();
      })
      .then(() => flushPromises())
      .then(() => flushPromises())
      .then(() => {
        expect(reindexFacets).toHaveBeenCalledTimes(1);
        // Button re-enabled after the failure (finally cleared isReindexing).
        const button = element.shadowRoot.querySelector("lightning-button");
        expect(button.disabled).toBe(false);
      });
  });
});
