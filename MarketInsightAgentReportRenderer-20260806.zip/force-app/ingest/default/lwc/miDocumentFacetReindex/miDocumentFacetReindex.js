import { LightningElement, api, wire } from "lwc";
import {
  getRecord,
  getFieldValue,
  notifyRecordUpdateAvailable
} from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import reindexFacets from "@salesforce/apex/MI_MarketInsightDocumentController.reindexFacets";
import STATUS_FIELD from "@salesforce/schema/Market_Insight_Document__c.Extraction_Status__c";
import GENERATED_AT_FIELD from "@salesforce/schema/Market_Insight_Document__c.Extraction_Generated_At__c";
import ERROR_FIELD from "@salesforce/schema/Market_Insight_Document__c.Extraction_Error__c";

const GENERATING = "Generating";
// Prefix the Apex side writes onto Extraction_Error__c to mark a note as something OTHER than a failure.
// Keep in sync with MI_DocumentFacetGenerationService.BODY_TEXT_NOTE_PREFIX.
const BODY_TEXT_NOTE_PREFIX = "[본문 미반영]";

/**
 * REINDEX card for the Market_Insight_Document__c record page. Shows the current facet-extraction
 * status and lets the user force-regenerate the document's facet metadata on demand — regardless of
 * the current status (unlike the on-upload run, which only runs once). The Apex service feeds the
 * attached file (PDF/Office) into the prompt template's File input, so the button carries no mode.
 *
 * The button is disabled while generation is already in flight. Because generation is asynchronous,
 * the status won't flip to Complete immediately — the user refreshes (or reloads) to see the result;
 * notifyRecordUpdateAvailable refreshes the displayed status field after the request is accepted.
 *
 * It also surfaces Extraction_Error__c whenever one exists — NOT only on an Error status. The facet
 * service marks a metadata-only generation with a "[본문 미반영]" note on a COMPLETE document, so gating the
 * panel on the status would hide the one case a user most needs to know about: facets that describe the
 * file rather than its contents.
 */
export default class MiDocumentFacetReindex extends LightningElement {
  @api recordId;

  isReindexing = false;

  // Retained so notifyRecordUpdateAvailable can target exactly this provisioned record.
  @wire(getRecord, {
    recordId: "$recordId",
    fields: [STATUS_FIELD, GENERATED_AT_FIELD, ERROR_FIELD]
  })
  document;

  get status() {
    return getFieldValue(this.document.data, STATUS_FIELD);
  }

  get generatedAt() {
    return getFieldValue(this.document.data, GENERATED_AT_FIELD);
  }

  get statusLabel() {
    return this.status || "미처리";
  }

  get isGenerating() {
    return this.status === GENERATING;
  }

  // The verbatim note the facet service recorded on Extraction_Error__c. Despite the field name this is
  // not always a failure: it also carries "[본문 미반영]" — the facets WERE generated, but the document's
  // body text could not be recovered, so they lean on the file's metadata alone. That note rides on a
  // COMPLETE document, which is exactly why it has to be shown: without it a metadata-only facet is
  // indistinguishable on screen from one grounded in the document.
  get errorDetail() {
    return getFieldValue(this.document.data, ERROR_FIELD);
  }

  get hasErrorDetail() {
    return !!this.errorDetail;
  }

  // True when the note says the body text was missing rather than that generation failed.
  get isBodyTextNote() {
    return (this.errorDetail || "").startsWith(BODY_TEXT_NOTE_PREFIX);
  }

  get detailTitle() {
    return this.isBodyTextNote ? "본문 미반영 안내" : "생성 오류 상세";
  }

  get detailGuidance() {
    return this.isBodyTextNote
      ? "문서 본문을 읽지 못해 파일 메타데이터만으로 패싯을 생성했습니다. 내용 기반 패싯이 필요하면 PDF로 다시 올리거나 재생성해 주세요."
      : "아래 오류를 확인한 뒤 재생성해 주세요.";
  }

  get detailIconName() {
    return this.isBodyTextNote ? "utility:info" : "utility:error";
  }

  get detailIconVariant() {
    return this.isBodyTextNote ? "" : "error";
  }

  get detailTitleClass() {
    return this.isBodyTextNote
      ? "slds-text-title_caps"
      : "slds-text-title_caps slds-text-color_error";
  }

  // Disable while a request is being sent or while generation is already running.
  get isButtonDisabled() {
    return this.isReindexing || this.isGenerating;
  }

  /**
   * Kicks off an on-demand facet reindex, then refreshes the displayed status field. Generation runs
   * asynchronously, so success here means "started", not "finished".
   */
  async handleReindex() {
    this.isReindexing = true;
    try {
      await reindexFacets({ recordId: this.recordId });
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재생성 시작",
          message:
            "패싯 메타데이터를 다시 생성합니다. 잠시 후 새로고침해 주세요.",
          variant: "success"
        })
      );
      await notifyRecordUpdateAvailable([{ recordId: this.recordId }]);
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "재생성 실패",
          message: error?.body?.message || "패싯 재생성을 시작하지 못했습니다.",
          variant: "error"
        })
      );
    } finally {
      this.isReindexing = false;
    }
  }
}
