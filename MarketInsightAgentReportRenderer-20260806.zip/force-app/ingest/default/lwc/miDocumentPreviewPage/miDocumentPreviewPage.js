import { LightningElement, wire } from 'lwc';
import { CurrentPageReference, NavigationMixin } from 'lightning/navigation';
import getFileMeta from '@salesforce/apex/MI_DocumentPreviewController.getFileMeta';
import getRecentFiles from '@salesforce/apex/MI_DocumentPreviewController.getRecentFiles';

const ICON_BY_EXT = {
    pdf: 'doctype:pdf',
    ppt: 'doctype:ppt',
    pptx: 'doctype:ppt',
    doc: 'doctype:word',
    docx: 'doctype:word',
    xls: 'doctype:excel',
    xlsx: 'doctype:excel',
    png: 'doctype:image',
    jpg: 'doctype:image',
    jpeg: 'doctype:image',
    gif: 'doctype:image'
};

/**
 * Standalone deep-link entry point. Reads URL state:
 *   c__docId — ContentDocument id (069...)
 *   c__page  — page/slide number to open at (optional, default 1)
 * e.g. /lightning/n/Document_Preview?c__docId=069...&c__page=23
 *
 * When opened with no c__docId (e.g. clicking the tab directly), it shows a
 * list of recently viewed previewable files so a user can pick one to test.
 */
export default class MiDocumentPreviewPage extends NavigationMixin(LightningElement) {
    contentDocumentId;
    versionId;
    fileExtension;
    fileTitle;
    initialPage = 1;
    resolved = false;
    error;

    recentFiles = [];
    recentError;

    @wire(CurrentPageReference)
    async setStateParameters(pageRef) {
        if (!pageRef) {
            return;
        }
        const state = pageRef.state || {};
        this.contentDocumentId = state.c__docId;
        const page = parseInt(state.c__page, 10);
        this.initialPage = Number.isNaN(page) || page < 1 ? 1 : page;

        if (!this.contentDocumentId) {
            // No document requested: show the recent-files picker instead of an
            // error, so the tab can be opened directly to test previews.
            this.error = undefined;
            this.resolved = true;
            return;
        }

        try {
            const meta = await getFileMeta({ contentDocumentId: this.contentDocumentId });
            if (meta) {
                this.versionId = meta.versionId;
                this.fileExtension = meta.fileExtension;
                this.fileTitle = meta.title;
                this.error = undefined;
            } else {
                this.error = '문서를 찾을 수 없습니다.';
            }
        } catch (e) {
            this.error = (e && e.body && e.body.message) || '문서를 열 수 없습니다.';
        }
        this.resolved = true;
    }

    @wire(getRecentFiles)
    wiredRecent({ data, error }) {
        if (data) {
            this.recentFiles = data.map((f) => ({
                ...f,
                iconName:
                    ICON_BY_EXT[(f.fileExtension || '').toLowerCase()] ||
                    'doctype:unknown'
            }));
            this.recentError = undefined;
        } else if (error) {
            this.recentError =
                (error.body && error.body.message) ||
                '최근 파일을 불러오지 못했습니다.';
            this.recentFiles = [];
        }
    }

    get ready() {
        return this.resolved && this.contentDocumentId && !this.error;
    }

    // Show the picker only when the page was opened without a document id.
    get showPicker() {
        return this.resolved && !this.contentDocumentId && !this.error;
    }

    get hasRecentFiles() {
        return this.recentFiles && this.recentFiles.length > 0;
    }

    // Clicking a recent file re-opens this same page with the chosen doc id in
    // URL state, which re-fires CurrentPageReference and renders the preview.
    handlePick(event) {
        const docId = event.currentTarget.dataset.docId;
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: { apiName: 'Document_Preview' },
            state: { c__docId: docId, c__page: '1' }
        });
    }
}