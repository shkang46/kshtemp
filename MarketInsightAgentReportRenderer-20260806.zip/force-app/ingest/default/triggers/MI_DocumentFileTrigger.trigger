/**
 * Trigger on ContentDocumentLink. Fires whenever any file is linked to any record; the handler
 * filters down to supported files (PDF/Office) attached to Market_Insight_Document__c and starts
 * immediate facet generation for them. All logic is delegated to
 * MI_DocumentFileTriggerHandler.
 */
trigger MI_DocumentFileTrigger on ContentDocumentLink(after insert) {
  MI_DocumentFileTriggerHandler.afterInsert(Trigger.new);
}
