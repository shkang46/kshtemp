import { createElement } from "lwc";
import MiProbeDetail from "c/miProbeDetail";
import getDetail from "@salesforce/apex/MI_ProbeDetailController.getDetail";

// getDetail is a WIRED Apex method → needs a wire-adapter stub (emit/error).
jest.mock(
  "@salesforce/apex/MI_ProbeDetailController.getDetail",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// The component extends NavigationMixin and calls [GenerateUrl] to link the source document; the mock
// resolves a deterministic URL so the link assertion is stable.
jest.mock("lightning/navigation", () => {
  const GenerateUrl = Symbol("GenerateUrl");
  const NavigationMixin = (Base) =>
    class extends Base {
      [GenerateUrl](config) {
        return Promise.resolve(`/r/${config.attributes.recordId}/view`);
      }
    };
  NavigationMixin.GenerateUrl = GenerateUrl;
  return { NavigationMixin };
});

const RECORD_ID = "a4H000000000001AAA";

// A hit at rank 2, with a two-attempt mapping trace, a resolved target row, and the replayed result set.
const HIT = {
  found: true,
  recordId: RECORD_ID,
  name: "PRB-0001",
  probeType: "Relative_Period",
  difficulty: "simple",
  question: "Music 2024년 3분기 매출은?",
  failureReason: null,
  isHit: true,
  hitRank: 2,
  resultCount: 5,
  attemptCount: 2,
  targetRowKey: "k-music-q3",
  isNegative: false,
  isDocumentProbe: false,
  documentId: "a0X000000000001",
  fileName: "sony.pdf",
  attempts: [
    {
      rawLine: 'attempt 1: {"period":"2024 3Q"}',
      attemptLabel: "attempt 1",
      entity: "Music",
      metric: "sales",
      figurePeriod: "2024 3Q",
      valueType: "Actual",
      isFinal: false
    },
    {
      rawLine: 'attempt 2: {"period":"FY2024-Q3"}',
      attemptLabel: "attempt 2",
      entity: "Music",
      metric: "매출",
      figurePeriod: "FY2024-Q3",
      valueType: "Actual",
      isFinal: true
    }
  ],
  targetRow: {
    entity: "Music",
    metric: "매출",
    metricCategory: "revenue",
    figurePeriod: "FY2024-Q3",
    valueText: "9010",
    unit: "Billion yen",
    valueType: "Actual",
    sourcePage: "3"
  },
  targetRowMissing: false,
  returnedRowsReplayed: true,
  returnedRowCount: 2,
  returnedRows: [
    {
      rank: 1,
      isTarget: false,
      entity: "Music",
      metric: "매출",
      figurePeriod: "FY2024-Q2",
      value: "8500",
      unit: "Billion yen",
      valueType: "Actual",
      sourceFile: "sony.pdf"
    },
    {
      rank: 2,
      isTarget: true,
      entity: "Music",
      metric: "매출",
      figurePeriod: "FY2024-Q3",
      value: "9010",
      unit: "Billion yen",
      valueType: "Actual",
      sourceFile: "sony.pdf"
    }
  ]
};

function createComponent() {
  const element = createElement("c-mi-probe-detail", { is: MiProbeDetail });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(detail) {
  getDetail.emit(detail);
  await Promise.resolve();
}

describe("c-mi-probe-detail", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows the question, the outcome at its rank, and the per-attempt mapped filters", async () => {
    const element = createComponent();
    await emit(HIT);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("Music 2024년 3분기 매출은?");
    expect(text).toContain("적중 — 2위로 반환됨");
    // Both attempts are listed, with their mapped period values.
    const bodyText =
      element.shadowRoot.querySelectorAll("tbody")[0].textContent;
    expect(bodyText).toContain("2024 3Q");
    expect(bodyText).toContain("FY2024-Q3");
  });

  it("shows the replayed result set with the target row flagged, so a hit is diagnosable", async () => {
    const element = createComponent();
    await emit(HIT);

    const text = element.shadowRoot.textContent;
    // The returned-rows section names the count and shows the sibling that ranked ahead of the target.
    expect(text).toContain("이 필터가 돌려준 결과");
    // Both returned rows render (the crowding Q2 sibling + the Q3 target).
    const allRows = element.shadowRoot.querySelectorAll("tbody tr");
    expect(allRows.length).toBeGreaterThanOrEqual(3); // attempts(2) + returned(2) + target(1) across tables
  });

  it("resolves and shows the target answer row", async () => {
    const element = createComponent();
    await emit(HIT);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("찾아야 했던 정답 행");
    expect(text).toContain("9010");
  });

  it("marks a hit ranked beyond 5 as outside Recall@5", async () => {
    const element = createComponent();
    await emit({ ...HIT, hitRank: 7, isHit: true });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("Recall@5에는");
    expect(text).toContain("7위");
  });

  it("explains the empty-result (0건) miss distinctly from a wrong-row miss", async () => {
    const element = createComponent();
    await emit({
      ...HIT,
      isHit: false,
      hitRank: null,
      resultCount: 0,
      failureReason: "매핑된 필터로 조회 결과가 0건이었습니다.",
      returnedRowsReplayed: true,
      returnedRowCount: 0,
      returnedRows: []
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("미적중");
    expect(text).toContain("한 건도 반환되지 않았습니다");
  });

  it("scores a negative probe on the inverse axis (returning nothing is a pass)", async () => {
    const element = createComponent();
    await emit({
      ...HIT,
      probeType: "Adjacent_Negative",
      isNegative: true,
      isHit: true,
      hitRank: null,
      resultCount: 0,
      targetRow: null,
      targetRowKey: null,
      returnedRowsReplayed: false,
      returnedRows: []
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("음성 통과");
  });
});
