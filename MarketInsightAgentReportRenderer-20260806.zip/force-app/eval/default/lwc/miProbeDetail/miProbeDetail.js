import { LightningElement, api, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import getDetail from "@salesforce/apex/MI_ProbeDetailController.getDetail";

/**
 * The detailed view of one MI_Tabular_Eval_Probe__c known-item probe, shown on its record page beside the
 * plain field layout. Where the fields show raw values, this reconstructs the whole test a reviewer needs to
 * diagnose a miss: what was asked (Question__c), what filters the mapping LLM pulled out of it per attempt
 * (Extracted_Filters__c), whether the target was found and at what rank, and — the move a field dump cannot
 * make — WHAT the target row actually is, resolved from Target_Row_Key__c, so a "결과 0건" becomes a legible
 * "the mapping wrote metric=X but the answer is stored as Y".
 *
 * Read-only via getDetail. Static copy lives in the HTML; this JS only formats and decorates.
 */

// Per-type one-line "what this probe kind tests", keyed by Probe_Type__c. Hardcoded — it describes the fixed
// generation strategy in MI_TabularEvalProbeService / the retrieval service, not per-record data.
const TYPE_NOTES = {
  Structured: "저장된 라벨을 그대로 쓴 질문 — 매핑의 하한(컨트롤)입니다.",
  Natural: "자동 요약·단답 품질에 가까운 자연어 질문입니다.",
  Synonym: "저장 토큰과 다른 표현(동의어)으로 물어 매핑 견고성을 봅니다.",
  Relative_Period:
    "'작년 3분기'처럼 상대 기간으로 물어, 상대→절대 기간 해석을 봅니다.",
  Adjacent_Negative:
    "존재하지 않는 인접 조합(음성) — 아무것도 반환하지 않아야 통과입니다.",
  Negative: "코퍼스에 없는 대상(음성) — 반환이 없어야 통과입니다.",
  Doc_Structured: "facet 최강 키워드로 물은 문서 검색 컨트롤입니다.",
  Doc_Natural: "회사·산업·지역을 한국어로 물은 문서 검색 질문입니다.",
  Doc_Synonym: "저장 토큰과 다른 표현으로 물은 문서 검색 질문입니다.",
  Doc_Body: "실제 청크 본문 구절로 물은 문서 검색 질문입니다.",
  Doc_Negative: "코퍼스 부재 대상(음성) 문서 검색입니다."
};

export default class MiProbeDetail extends NavigationMixin(LightningElement) {
  @api recordId;

  detail;
  loadError;
  documentUrl;

  @wire(getDetail, { probeId: "$recordId" })
  wiredDetail({ data, error }) {
    if (data) {
      this.detail = data;
      this.loadError = undefined;
      this.resolveDocumentUrl();
    } else if (error) {
      this.detail = undefined;
      this.loadError = error?.body?.message || "상세를 불러오지 못했습니다.";
    }
  }

  /**
   * Resolves the source document's record-page URL so the reviewer can open it to confirm the mapping — a
   * miss is settled by reading how the answer is actually stored. A failure to generate leaves the file name
   * as plain text.
   */
  resolveDocumentUrl() {
    if (!this.detail?.documentId) {
      return;
    }
    this[NavigationMixin.GenerateUrl]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.detail.documentId,
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    })
      .then((url) => {
        this.documentUrl = url;
      })
      .catch(() => {
        // Leave documentUrl undefined; the template shows the file name as plain text.
      });
  }

  get hasDocumentUrl() {
    return !!this.documentUrl;
  }

  get hasDetail() {
    return this.detail != null && this.detail.found === true;
  }

  get question() {
    return this.detail?.question;
  }
  get probeType() {
    return this.detail?.probeType;
  }
  get difficulty() {
    return this.detail?.difficulty;
  }
  get typeNote() {
    return this.detail ? TYPE_NOTES[this.detail.probeType] || null : null;
  }

  // ---- outcome banner ----------------------------------------------------
  // Three outcomes: a negative probe passes by returning nothing; a positive is found (at a rank) or not.
  // Kept as distinct states so a passing negative never wears a failure icon.
  get isNegative() {
    return this.detail?.isNegative === true;
  }
  get isHit() {
    return this.detail?.isHit === true;
  }
  get outcomeLabel() {
    if (!this.detail) {
      return "";
    }
    if (this.isNegative) {
      return this.isHit
        ? "음성 통과 — 없는 조합에 아무것도 반환하지 않음"
        : "음성 실패 — 없어야 할 결과가 반환됨";
    }
    if (this.isHit) {
      return `적중 — ${this.detail.hitRank}위로 반환됨`;
    }
    return "미적중 — 정답 행이 반환되지 않음";
  }
  get outcomeIcon() {
    return this.isHit ? "utility:success" : "utility:error";
  }
  get outcomeVariant() {
    return this.isHit ? "success" : "error";
  }
  // Recall@5 is the headline metric this leg reports, so flag the "returned but ranked >5" case — that row
  // is a hit for Recall@10 but a MISS for Recall@5, the exact band the user is trying to raise.
  get isRankedBeyondFive() {
    return this.isHit && !this.isNegative && this.detail?.hitRank > 5;
  }

  get hitRankLabel() {
    return this.detail?.hitRank == null ? "—" : `${this.detail.hitRank}`;
  }
  get resultCountLabel() {
    return this.detail?.resultCount == null
      ? "—"
      : `${this.detail.resultCount}`;
  }
  get attemptCountLabel() {
    return this.detail?.attemptCount == null
      ? "—"
      : `${this.detail.attemptCount}`;
  }
  get failureReason() {
    return this.detail?.failureReason;
  }
  get fileName() {
    return this.detail?.fileName;
  }

  // ---- mapped filters per attempt ---------------------------------------
  get hasAttempts() {
    return this.detail && this.detail.attempts.length > 0;
  }
  get attempts() {
    if (!this.detail) {
      return [];
    }
    return this.detail.attempts.map((a, i) => ({
      ...a,
      key: `attempt-${i}`,
      entityLabel: a.entity || "—",
      metricLabel: a.metric || "—",
      periodLabel: a.figurePeriod || "—",
      valueTypeLabel: a.valueType || "—",
      rowClass: a.isFinal
        ? "slds-hint-parent final-attempt"
        : "slds-hint-parent"
    }));
  }

  // ---- resolved target row ----------------------------------------------
  // The answer the search was supposed to return. Shown next to the mapped filters so the reviewer can read
  // the mismatch directly: the mapping wrote period="2024 3Q" but the row is stored as "FY2024-Q3", etc.
  get hasTargetRow() {
    return this.detail?.targetRow != null;
  }
  get targetRow() {
    return this.detail?.targetRow;
  }
  get targetRowMissing() {
    return this.detail?.targetRowMissing === true;
  }
  get targetRowKey() {
    return this.detail?.targetRowKey;
  }
  get isDocumentProbe() {
    return this.detail?.isDocumentProbe === true;
  }

  // ---- returned rows (replayed final query) -----------------------------
  // What the final mapped filters actually return NOW, so the reviewer sees the concrete result set behind
  // the hit/miss — the target flagged, or the wrong-period siblings / cross-document rows that displaced it.
  get returnedRowsReplayed() {
    return this.detail?.returnedRowsReplayed === true;
  }
  get hasReturnedRows() {
    return this.detail && this.detail.returnedRows
      ? this.detail.returnedRows.length > 0
      : false;
  }
  get returnedRows() {
    if (!this.detail || !this.detail.returnedRows) {
      return [];
    }
    return this.detail.returnedRows.map((r, i) => ({
      ...r,
      key: `ret-${i}`,
      // The target row is set apart, and a row ranked beyond 5 is marked since it is outside Recall@5.
      rowClass: r.isTarget
        ? "slds-hint-parent target-hit-row"
        : "slds-hint-parent",
      beyondFive: r.rank > 5,
      entityLabel: r.entity || "—",
      metricLabel: r.metric || "—",
      periodLabel: r.figurePeriod || "—",
      valueLabel: r.value || "—",
      valueTypeLabel: r.valueType || "—"
    }));
  }
  // The empty-result case: the final filters returned nothing at all (the "조회 0건" failure), which is a
  // different diagnosis from "returned rows but not the target".
  get returnedEmpty() {
    return this.returnedRowsReplayed && !this.hasReturnedRows;
  }
  get returnedRowCountLabel() {
    return this.detail?.returnedRowCount == null
      ? "0"
      : `${this.detail.returnedRowCount}`;
  }
}
