import { createElement } from "lwc";
import MiEvalRunChart from "c/miEvalRunChart";

// MI_ChartJs and c/miReportChartConfig are auto-mocked by sfdx-lwc-jest, and window.Chart is never loaded
// under Jest, so renderChart() is a guaranteed no-op. These tests assert the component mounts and exposes its
// canvas without throwing across spec changes — not that a chart is painted (that needs a real browser). The
// value is guarding the husky Jest gate and the lifecycle contract, matching miMetricTrend's test.

function createComponent(spec) {
  const element = createElement("c-mi-eval-run-chart", { is: MiEvalRunChart });
  if (spec !== undefined) {
    element.spec = spec;
  }
  document.body.appendChild(element);
  return element;
}

const DOUGHNUT_SPEC = {
  type: "doughnut",
  title: "골든 판정",
  labels: ["일치", "오탐", "누락"],
  series: [{ name: "판정", values: [637, 50, 688] }]
};

describe("c-mi-eval-run-chart", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders a canvas for the chart", () => {
    const element = createComponent(DOUGHNUT_SPEC);
    expect(element.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("mounts without throwing when no spec is provided", () => {
    const element = createComponent();
    expect(element.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("accepts a spec update without throwing", () => {
    const element = createComponent(DOUGHNUT_SPEC);
    element.spec = {
      type: "bar",
      labels: ["@1", "@5", "@10"],
      series: [{ name: "recall", values: [0.6, 0.8, 0.9] }]
    };
    return Promise.resolve().then(() => {
      expect(element.shadowRoot.querySelector("canvas")).not.toBeNull();
    });
  });
});
