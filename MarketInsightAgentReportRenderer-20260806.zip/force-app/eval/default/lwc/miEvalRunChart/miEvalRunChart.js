import { LightningElement, api } from "lwc";
import { loadScript } from "lightning/platformResourceLoader";
import CHARTJS from "@salesforce/resourceUrl/MI_ChartJs";
import { buildChartConfig } from "c/miReportChartConfig";

/**
 * A single Chart.js visual for the eval-run report dashboard. Given a chart spec built by the parent
 * (a doughnut of Golden TP/FP/FN, a bar of per-family invariant violations, a bar of retrieval
 * recall@k, …), it renders one canvas chart.
 *
 * It reuses the shared c/miReportChartConfig builder and the MI_ChartJs static resource, per the repo
 * convention that every chart flows through that one module — the same path miMetricTrend
 * takes. A malformed spec degrades to an empty canvas rather than throwing, and under
 * Jest (where window.Chart is never loaded) renderChart is a guaranteed no-op.
 */
export default class MiEvalRunChart extends LightningElement {
  _spec;
  _config; // Chart.js config computed from the spec; null when unrenderable
  chartLoaded = false; // guards the one-time loadScript
  chart; // the live Chart.js instance

  /**
   * The chart spec — { type, title, unit, labels:[], series:[{ name, values:[] }] }. Setting it
   * rebuilds the config and redraws.
   */
  @api
  get spec() {
    return this._spec;
  }
  set spec(value) {
    this._spec = value;
    this._config = value ? buildChartConfig(value) : null;
    this.renderChart();
  }

  /**
   * Loads Chart.js once, then (re)renders. Idempotent and also called from the spec setter, so it
   * handles both the initial load race and later spec changes.
   */
  renderedCallback() {
    if (this.chartLoaded) {
      this.renderChart();
      return;
    }
    this.chartLoaded = true;
    loadScript(this, CHARTJS)
      .then(() => this.renderChart())
      .catch(() => {
        // A failed library load leaves the canvas blank; the parent tile still shows the numbers.
        this._config = null;
      });
  }

  /**
   * (Re)draws the chart, destroying any existing instance first to avoid Chart.js's "Canvas is already
   * in use" error, and bailing until the library is loaded and a config exists.
   */
  renderChart() {
    if (!this.chartLoaded || !window.Chart || !this._config) {
      return;
    }
    const canvas = this.refs?.canvas;
    if (!canvas) {
      return;
    }
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
    this.chart = new window.Chart(canvas.getContext("2d"), this._config);
  }

  disconnectedCallback() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
  }
}
