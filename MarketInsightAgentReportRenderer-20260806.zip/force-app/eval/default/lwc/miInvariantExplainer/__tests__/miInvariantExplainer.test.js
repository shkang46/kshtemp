import { createElement } from "lwc";
import MiInvariantExplainer from "c/miInvariantExplainer";
import { getRecord } from "lightning/uiRecordApi";

const RECORD_ID = "a40Ie000000LgLkIAK";

// Emit a record into the getRecord wire with the given Invariant_Type__c / Is_Violated__c /
// Is_Confirmed_By_Human__c values, matching the field set the component wires.
function emit(type, violated = false, confirmed = false) {
  getRecord.emit({
    fields: {
      Invariant_Type__c: { value: type },
      Is_Violated__c: { value: violated },
      Is_Confirmed_By_Human__c: { value: confirmed }
    }
  });
}

function createComponent() {
  const element = createElement("c-mi-invariant-explainer", {
    is: MiInvariantExplainer
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

describe("c-mi-invariant-explainer", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("explains what a Sum check tests", async () => {
    const element = createComponent();
    emit("Sum", false);
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    expect(text).toContain("합계 검사");
    expect(text).toContain("합계 행");
  });

  it("names the family for every known invariant type", async () => {
    const cases = [
      ["Sum", "합계 검사"],
      ["Quarterly", "분기 합산 검사"],
      ["YoY", "전년 대비"],
      ["Magnitude", "자릿수 급변 검사"],
      ["Conflict", "교차 모순 검사"]
    ];
    for (const [type, label] of cases) {
      const element = createComponent();
      emit(type, true);
      // eslint-disable-next-line no-await-in-loop
      await Promise.resolve();
      expect(element.shadowRoot.textContent).toContain(label);
      document.body.removeChild(element);
    }
  });

  it("tells the reviewer a violation does not identify which value is wrong", async () => {
    const element = createComponent();
    emit("YoY", true, false);
    await Promise.resolve();

    // RULE 1: arithmetic proves an error exists but not the culprit — the reviewer must open the source.
    const text = element.shadowRoot.textContent;
    expect(text).toContain("어느 값이 틀렸는지까지는 특정하지 못합니다");
    expect(text).toContain("Source Page");
  });

  it("does not show the confirm-me guidance once the violation is human-confirmed", async () => {
    const element = createComponent();
    emit("YoY", true, true);
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    expect(text).not.toContain("어느 값이 틀렸는지까지는 특정하지 못합니다");
    expect(text).toContain("실제 오류임을 확인했습니다");
  });

  it("states that a pass is not proof of correctness for a family that records passes", async () => {
    const element = createComponent();
    emit("Sum", false);
    await Promise.resolve();

    // RULE 2: a pass means only "this contradiction was not found", never "the figures are right".
    const text = element.shadowRoot.textContent;
    expect(text).toContain("모순이 발견되지 않았습니다");
    expect(text).toContain("수치가 옳다는 증명은 아닙니다");
  });

  it("offers no passing reading for a violation-only family", async () => {
    const element = createComponent();
    // Magnitude and Conflict only ever store a violation, so a non-violated record of that type has no
    // meaningful "passed" line to show.
    emit("Magnitude", false);
    await Promise.resolve();

    expect(element.shadowRoot.textContent).not.toContain(
      "모순이 발견되지 않았습니다"
    );
  });

  it("always carries the caveat that a pass rate is not an accuracy figure", async () => {
    const element = createComponent();
    emit("Sum", false);
    await Promise.resolve();

    expect(element.shadowRoot.textContent).toContain(
      "통과율을 정확도로 읽지 마세요"
    );
  });

  it("falls back to a plain notice for an unrecognized type instead of rendering blank", async () => {
    const element = createComponent();
    emit("SomethingNew", false);
    await Promise.resolve();

    expect(element.shadowRoot.textContent).toContain("알 수 없는 검사 종류");
  });
});
