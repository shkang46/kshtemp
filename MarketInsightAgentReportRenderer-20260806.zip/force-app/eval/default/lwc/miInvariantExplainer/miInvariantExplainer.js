import { LightningElement, api, wire } from "lwc";
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import TYPE_FIELD from "@salesforce/schema/MI_Tabular_Eval_Invariant__c.Invariant_Type__c";
import VIOLATED_FIELD from "@salesforce/schema/MI_Tabular_Eval_Invariant__c.Is_Violated__c";
import CONFIRMED_FIELD from "@salesforce/schema/MI_Tabular_Eval_Invariant__c.Is_Confirmed_By_Human__c";

/**
 * Explains, on the record page, what THIS invariant check actually tests and how to act on it. The fields
 * already carry help text, but a value like Invariant_Type__c = "Magnitude" with Expected 152.5 / Actual
 * 609.9 tells a reviewer nothing unless they already know the five families and the two interpretation rules
 * that otherwise live only in MI_TabularEvalInvariantService's header comment.
 *
 * THE TWO RULES THIS CARD EXISTS TO SURFACE — both are easy to misread off a raw field layout:
 *   1. A violation proves an error EXISTS but not WHICH value is wrong. The check contradicts a SET of
 *      figures; arithmetic cannot name the culprit, so confirming it means opening the source page. That is
 *      why Is_Confirmed_By_Human__c is a human step, not an automatic consequence of Is_Violated__c.
 *   2. A pass proves nothing about correctness — only that this particular contradiction was not found. So
 *      the card never congratulates a passing check; it states the narrow thing the pass actually means.
 *
 * Read-only by design (no DML, no Apex): getRecord supplies the three fields it branches on. The per-family
 * copy is hardcoded in the template — this JS only decides which branch shows, keyed off the exact
 * Invariant_Type__c strings the service writes ("Sum" / "Quarterly" / "YoY" / "Magnitude" / "Conflict").
 */

// The two families that only ever store a VIOLATION (they add no record on a pass), so the card offers no
// meaningless "passed" reading for them.
const VIOLATION_ONLY_TYPES = new Set(["Magnitude", "Conflict"]);
const KNOWN_TYPES = new Set([
  "Sum",
  "Quarterly",
  "YoY",
  "Magnitude",
  "Conflict"
]);

export default class MiInvariantExplainer extends LightningElement {
  @api recordId;

  @wire(getRecord, {
    recordId: "$recordId",
    fields: [TYPE_FIELD, VIOLATED_FIELD, CONFIRMED_FIELD]
  })
  invariant;

  get invariantType() {
    return getFieldValue(this.invariant.data, TYPE_FIELD);
  }

  get isViolated() {
    return getFieldValue(this.invariant.data, VIOLATED_FIELD) === true;
  }

  get isConfirmed() {
    return getFieldValue(this.invariant.data, CONFIRMED_FIELD) === true;
  }

  // One boolean per family so the template can branch to the right hardcoded copy.
  get isSum() {
    return this.invariantType === "Sum";
  }

  get isQuarterly() {
    return this.invariantType === "Quarterly";
  }

  get isYoY() {
    return this.invariantType === "YoY";
  }

  get isMagnitude() {
    return this.invariantType === "Magnitude";
  }

  get isConflict() {
    return this.invariantType === "Conflict";
  }

  get hasKnownType() {
    return KNOWN_TYPES.has(this.invariantType);
  }

  // A pass reading is shown only for a family that actually records passes (Sum/Quarterly/YoY) and only when
  // this record is not a violation.
  get showPassLine() {
    return (
      this.hasKnownType &&
      !this.isViolated &&
      !VIOLATION_ONLY_TYPES.has(this.invariantType)
    );
  }

  // RULE 1 guidance — a violation does not name the culprit; confirming it is a human step. Shown only while
  // the violation is still unconfirmed.
  get showViolationGuidance() {
    return this.hasKnownType && this.isViolated && !this.isConfirmed;
  }

  get showConfirmedNote() {
    return this.hasKnownType && this.isViolated && this.isConfirmed;
  }

  // Defensive branch: the service only ever writes the five families, but a hand-created or future-typed
  // record should not render blank.
  get showUnknownType() {
    return this.invariant.data != null && !this.hasKnownType;
  }
}
