import { createElement } from "lwc";
import MiPosteriorDensityChart from "c/miPosteriorDensityChart";

// c/miReportChartConfig is a real module; its buildChartConfig is pure, so it runs under Jest. Chart.js itself is
// never loaded in Jest (window.Chart is undefined), so renderChart is a guaranteed no-op — the component must
// mount and set its density without throwing regardless.
function createChart(density) {
  const element = createElement("c-mi-posterior-density-chart", {
    is: MiPosteriorDensityChart
  });
  element.density = density;
  document.body.appendChild(element);
  return element;
}

describe("c-mi-posterior-density-chart", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
  });

  it("mounts with a density curve and renders a canvas without throwing", () => {
    expect(() =>
      createChart([
        { x: 0.8, y: 2.1 },
        { x: 0.9, y: 5.0 },
        { x: 0.95, y: 6.4 }
      ])
    ).not.toThrow();
    const chart = document.body.querySelector("c-mi-posterior-density-chart");
    expect(chart.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("tolerates an empty or too-short density array", () => {
    expect(() => createChart([])).not.toThrow();
    const chart = document.body.querySelector("c-mi-posterior-density-chart");
    // The canvas still exists; there is simply no chart drawn on it under Jest.
    expect(chart.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("tolerates a null density value", () => {
    expect(() => createChart(null)).not.toThrow();
  });

  it("strips the per-point value labels and point markers so a 100-point curve is not a smear", async () => {
    // The bug this guards: the shared builder draws a numeric label on every point and a dot at each — fine for a
    // few-point sparkline, illegible on a dense posterior curve. Loading a fake window.Chart lets renderChart run
    // (after the auto-mocked loadScript resolves in renderedCallback) so we can capture the config the component
    // actually hands Chart.js.
    let captured;
    window.Chart = class {
      constructor(_ctx, config) {
        captured = config;
      }
      destroy() {}
    };
    try {
      // Enough points that per-point labels would smear if not removed.
      const density = Array.from({ length: 100 }, (_, i) => ({
        x: i / 100,
        y: Math.exp(-((i - 50) ** 2) / 200)
      }));
      createChart(density);
      // renderChart fires from renderedCallback → loadScript().then(...), a microtask — flush it.
      for (let i = 0; i < 4; i++) {
        // eslint-disable-next-line no-await-in-loop
        await Promise.resolve();
      }

      expect(captured).toBeDefined();
      // The reportValueLabels plugin (the per-point number overlay) must be gone; other plugins may remain.
      const pluginIds = (captured.plugins || []).map((p) => p && p.id);
      expect(pluginIds).not.toContain("reportValueLabels");
      // No per-point dots — a continuous curve.
      expect(captured.data.datasets[0].pointRadius).toBe(0);
      // The x axis is thinned rather than labelling all 100 ticks.
      expect(captured.options.scales.x.ticks.maxTicksLimit).toBe(6);
    } finally {
      delete window.Chart;
    }
  });
});
