import { LightningElement, api } from "lwc";
import { loadScript } from "lightning/platformResourceLoader";
import CHARTJS from "@salesforce/resourceUrl/MI_ChartJs";
import { buildChartConfig } from "c/miReportChartConfig";

/**
 * The posterior density curve for one prediction card: a line chart of the Beta(alpha, beta) density over a
 * probability window. The curve is what conveys sample size honestly — a tall narrow peak means the evidence is
 * settled, a broad flat one means it is not, a distinction a single percentage hides.
 *
 * The density points are computed server-side by MI_BetaPosterior.densityCurve so the lgamma implementation lives
 * in exactly one place and the chart can never drift from the Apex-side interval. This component only shapes them
 * into the shared c/miReportChartConfig line spec — the same MI_ChartJs / loadScript / renderedCallback path
 * miEvalRunChart and miMetricTrend take. A missing or too-short curve degrades to an empty canvas
 * rather than throwing, and under Jest (where window.Chart is never loaded) renderChart is a guaranteed no-op.
 */
export default class MiPosteriorDensityChart extends LightningElement {
  _density = [];
  _config; // Chart.js config computed from the density points; null when unrenderable
  chartLoaded = false; // guards the one-time loadScript
  chart; // the live Chart.js instance

  /**
   * The density points — an array of { x, y } from MI_BetaPosterior.DensityPoint, where x is a probability (0..1)
   * and y the density there. Setting it rebuilds the config and redraws.
   */
  @api
  get density() {
    return this._density;
  }
  set density(value) {
    this._density = Array.isArray(value) ? value : [];
    this._config = this.buildConfig();
    this.renderChart();
  }

  /**
   * Builds the line spec for the shared chart config, or null when there are too few points to draw a curve. x is
   * shown as a percentage on the axis; labels and values are the same length, as normalizeSeries requires.
   *
   * @returns {object|null} The Chart.js config, or null when unrenderable
   */
  buildConfig() {
    if (this._density.length < 2) {
      return null;
    }
    const spec = {
      type: "line",
      title: "",
      labels: this._density.map((p) => (p.x * 100).toFixed(1)),
      series: [{ name: "사후 밀도", values: this._density.map((p) => p.y) }]
    };
    const config = buildChartConfig(spec);
    if (config) {
      this.smoothForDensityCurve(config);
    }
    return config;
  }

  /**
   * Reshapes the shared line config into a smooth density curve. The shared builder is tuned for a few-point
   * sparkline: it draws a value label on EVERY point and marks each point, which on a 100-point posterior curve
   * turns into an illegible smear of numbers and dots, and it labels every x tick. This strips both — dropping the
   * per-point value-label plugin, hiding the point markers, curving the line — and thins the x-axis to a handful of
   * ticks. Done here (not in the shared builder) so the report viewer's few-point charts keep their value labels.
   *
   * @param {object} config The Chart.js config from buildChartConfig, mutated in place
   */
  smoothForDensityCurve(config) {
    // Drop the reportValueLabels plugin (the per-point number overlay); keep the background plugin.
    if (Array.isArray(config.plugins)) {
      config.plugins = config.plugins.filter(
        (p) => p && p.id !== "reportValueLabels"
      );
    }
    const dataset = config.data?.datasets?.[0];
    if (dataset) {
      dataset.pointRadius = 0; // no per-point dots — a continuous curve, not a scatter
      dataset.tension = 0.4; // gently smoothed
      dataset.borderWidth = 2;
    }
    config.options = config.options || {};
    // Axis titles so a first-time reader knows what the curve plots: x is the success-rate hypothesis (a
    // probability, %), y is how believable each rate is (relative density). Without them the bell shape reads
    // as "a graph" with no stated meaning. The y magnitude itself is not a figure a reader should quote, so its
    // TICKS stay hidden while the axis is still labelled.
    config.options.scales = config.options.scales || {};
    config.options.scales.y = {
      ...(config.options.scales.y || {}),
      ticks: { display: false },
      grid: { display: false },
      title: {
        display: true,
        text: "상대적 가능성 (믿을 만한 정도)"
      }
    };
    config.options.scales.x = {
      ...(config.options.scales.x || {}),
      ticks: { maxTicksLimit: 6, autoSkip: true },
      title: {
        display: true,
        text: "다음 실행 성공률 가설 (%)"
      }
    };
    // The single "사후 밀도" series needs no legend.
    config.options.plugins = config.options.plugins || {};
    config.options.plugins.legend = { display: false };
  }

  /**
   * Loads Chart.js once, then (re)renders. Idempotent and also called from the density setter, so it handles both
   * the initial load race and later data changes.
   */
  renderedCallback() {
    if (this.chartLoaded) {
      this.renderChart();
      return;
    }
    this.chartLoaded = true;
    loadScript(this, CHARTJS)
      .then(() => this.renderChart())
      .catch(() => {
        // A failed library load leaves the canvas blank; the card still shows the point estimate and interval.
        this._config = null;
      });
  }

  /**
   * (Re)draws the chart, destroying any existing instance first to avoid Chart.js's "Canvas is already in use"
   * error, and bailing until the library is loaded and a config exists.
   */
  renderChart() {
    if (!this.chartLoaded || !window.Chart || !this._config) {
      return;
    }
    const canvas = this.refs?.canvas;
    if (!canvas) {
      return;
    }
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
    this.chart = new window.Chart(canvas.getContext("2d"), this._config);
  }

  disconnectedCallback() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
  }
}
