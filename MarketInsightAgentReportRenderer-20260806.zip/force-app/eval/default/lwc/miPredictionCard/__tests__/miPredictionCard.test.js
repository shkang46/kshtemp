import { createElement } from "lwc";
import MiPredictionCard from "c/miPredictionCard";

function createCard(leg, cardTitle = "테스트 전망") {
  const element = createElement("c-mi-prediction-card", {
    is: MiPredictionCard
  });
  element.cardTitle = cardTitle;
  element.leg = leg;
  document.body.appendChild(element);
  return element;
}

function textOf(element) {
  return element.shadowRoot.textContent;
}

describe("c-mi-prediction-card", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
  });

  it("shows the point estimate, interval and sampling caveat for a measured leg", async () => {
    createCard({
      legKey: "golden",
      trials: 53,
      pointEstimate: 0.927,
      ciLower: 0.83,
      ciUpper: 0.975,
      density: [
        { x: 0.8, y: 2.1 },
        { x: 0.95, y: 6.4 }
      ],
      gated: false,
      presentable: true,
      versionLabel: null
    });
    await Promise.resolve();

    const card = document.body.querySelector("c-mi-prediction-card");
    const text = textOf(card);
    expect(text).toContain("92.7%");
    expect(text).toContain("표본 53건 기준");
    expect(text).toContain("94% 신용구간");
    // The sampling-uncertainty caveat rides with every shown number.
    expect(text).toContain("표본 불확실성만");
    // The density chart child renders when there are >= 2 points.
    expect(
      card.shadowRoot.querySelector("c-mi-posterior-density-chart")
    ).not.toBeNull();
  });

  it("never shows a bare 0% for an unmeasured leg", async () => {
    createCard({
      legKey: "golden",
      trials: null,
      pointEstimate: null,
      ciLower: null,
      ciUpper: null,
      density: [],
      gated: false,
      presentable: true,
      versionLabel: null
    });
    await Promise.resolve();

    const card = document.body.querySelector("c-mi-prediction-card");
    const text = textOf(card);
    expect(text).toContain("아직 예측할 실행 기록이 없습니다");
    expect(text).not.toContain("0.0%");
    expect(
      card.shadowRoot.querySelector("c-mi-posterior-density-chart")
    ).toBeNull();
  });

  it("shows the gate badge and NO number for a gated, unvalidated leg", async () => {
    createCard({
      legKey: "judge",
      trials: null,
      pointEstimate: null,
      ciLower: null,
      ciUpper: null,
      density: [],
      gated: true,
      presentable: false,
      versionLabel: null
    });
    await Promise.resolve();

    const card = document.body.querySelector("c-mi-prediction-card");
    const text = textOf(card);
    // The gate string is on the badge's `label` attribute (not text content, since lightning-badge is stubbed).
    const badge = card.shadowRoot.querySelector("lightning-badge");
    expect(badge).not.toBeNull();
    expect(badge.label).toBe("미검증 — 고객 제시 불가");
    expect(text).toContain("제시할 수 없습니다");
    // No prediction headline and no chart when gated off.
    expect(text).not.toContain("맞을 확률");
    expect(
      card.shadowRoot.querySelector("c-mi-posterior-density-chart")
    ).toBeNull();
  });

  it("shows the shortfall note instead of a curve when there are fewer than two density points", async () => {
    createCard({
      legKey: "retrieval",
      trials: 4,
      pointEstimate: 0.8,
      ciLower: 0.4,
      ciUpper: 0.97,
      density: [{ x: 0.8, y: 3.0 }],
      gated: false,
      presentable: true,
      versionLabel: null
    });
    await Promise.resolve();

    const card = document.body.querySelector("c-mi-prediction-card");
    const text = textOf(card);
    // The estimate still shows, but the curve is replaced by the shortfall note.
    expect(text).toContain("80.0%");
    expect(text).toContain("표본이 부족해 곡선을 그릴 수 없습니다");
    expect(
      card.shadowRoot.querySelector("c-mi-posterior-density-chart")
    ).toBeNull();
  });

  it("discloses the unversioned bucket in the version caveat", async () => {
    createCard({
      legKey: "golden",
      trials: 10,
      pointEstimate: 0.9,
      ciLower: 0.6,
      ciUpper: 0.98,
      density: [
        { x: 0.7, y: 1.0 },
        { x: 0.95, y: 5.0 }
      ],
      gated: false,
      presentable: true,
      versionLabel: null
    });
    await Promise.resolve();

    const card = document.body.querySelector("c-mi-prediction-card");
    expect(textOf(card)).toContain("버전 미기록");
  });
});
