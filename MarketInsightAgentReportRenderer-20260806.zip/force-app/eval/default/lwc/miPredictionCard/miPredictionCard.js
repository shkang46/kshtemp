import { LightningElement, api } from "lwc";

/**
 * One leg's forward-looking prediction card: "based on N accumulated trials, the next extraction/retrieval will be
 * correct with probability ≈ p̂ (94% credible interval [lo, hi])", with a posterior density curve beneath it.
 *
 * IT RENDERS THE SAME HONESTY THE CONTROLLER ENFORCES. A gated leg (judge precision, faithfulness) whose judge has
 * not cleared the golden-set gate carries NO figures from the server, and this card shows the "미검증 — 고객 제시
 * 불가" badge instead of a number. An unmeasured leg shows "측정 안 됨", never a fabricated 0%. Whenever a number is
 * shown, the sampling-uncertainty caveat and the version-boundary note ride with it, because a credible interval
 * quantifies sampling noise only — not judge bias, and not the pooled-vs-cluster-corrected difference.
 *
 * It owns its own formatting (rather than importing the parent's helpers) so it stays a self-contained presentation
 * component; the discipline is identical: measured-or-null, never a defaulted zero.
 */
export default class MiPredictionCard extends LightningElement {
  /** The LegPrediction DTO from MI_QualityHomeController.getPrediction: { legKey, trials, pointEstimate, ciLower,
   *  ciUpper, density, gated, presentable, versionLabel }. */
  @api leg;

  /** The Korean title shown on the card, chosen by the parent per leg. */
  @api cardTitle;

  /**
   * An optional plain-language caption explaining WHAT this card forecasts and how its sample differs from the
   * metric card above it — so a first-time reader does not misread the projection as the same number the metric
   * tile shows. E.g. the golden card headlines precision/recall from the LATEST run, while this forecasts recall
   * pooled over ALL runs; naming that here prevents "정확도 73.6%인데 전망 45.4%?" confusion.
   */
  @api caption;

  get hasCaption() {
    return !!this.caption;
  }

  /** Whether this leg is gated behind the judge-presentability check (judge precision / faithfulness). */
  get isGated() {
    return this.leg?.gated === true;
  }

  /** True when a gated leg's judge has not cleared the gate — the card then shows the badge and no figures. */
  get isBlockedByGate() {
    return this.isGated && this.leg?.presentable !== true;
  }

  /** Whether a point estimate was actually returned (present and not gated off). */
  get hasEstimate() {
    return !this.isBlockedByGate && this.isMeasured(this.leg?.pointEstimate);
  }

  /** The predicted next-run success probability as a percentage, or "측정 안 됨" — never a bare 0%. */
  get pointEstimateLabel() {
    return this.formatPercent(this.leg?.pointEstimate);
  }

  /** The predictive headline, carrying the trial count so a small sample cannot read as a settled figure. The
   *  count is the sample the projection is based on (for golden/facet, the latest scoring run's figure count —
   *  NOT every re-scoring summed, which would inflate it). */
  get predictionLine() {
    if (!this.hasEstimate) {
      return "";
    }
    return `표본 ${this.leg?.trials ?? 0}건 기준, 다음 실행이 맞을 확률 ≈ ${this.pointEstimateLabel}`;
  }

  /** The 94% credible interval bracket, or "" when either bound is unmeasured. */
  get intervalLabel() {
    return this.formatInterval(this.leg?.ciLower, this.leg?.ciUpper);
  }

  /** Whether the interval line should render (both bounds measured). */
  get hasInterval() {
    return (
      this.hasEstimate &&
      this.isMeasured(this.leg?.ciLower) &&
      this.isMeasured(this.leg?.ciUpper)
    );
  }

  /** The density points for the chart; only rendered when there are at least two and the leg is not gated off. */
  get densityPoints() {
    return this.leg?.density ?? [];
  }

  /** Whether the density curve can be drawn (>= 2 points and a shown estimate). */
  get hasDensity() {
    return this.hasEstimate && this.densityPoints.length >= 2;
  }

  /** The "not enough sample for a curve" note, shown in place of the chart when an estimate exists but the curve
   *  cannot be drawn. */
  get showCurveShortfall() {
    return this.hasEstimate && this.densityPoints.length < 2;
  }

  /** The version-boundary caveat, disclosing the unversioned bucket when the version fields are unpopulated. */
  get versionCaveat() {
    if (this.leg?.versionLabel) {
      return `버전 경계를 넘어 누적하지 않습니다 — 현재 버전: ${this.leg.versionLabel}.`;
    }
    return "버전 경계를 넘어 누적하지 않습니다 (버전 미기록 — 모든 실행이 하나의 버킷으로 합산됨).";
  }

  // ================================================================ 포맷 헬퍼 (measured-or-null 규율)

  /**
   * Whether a numeric value was actually measured (present), as opposed to null/undefined.
   *
   * @param {number} value The stored value
   * @returns {boolean} True when present
   */
  isMeasured(value) {
    return value !== null && value !== undefined;
  }

  /**
   * A stored rate as a percentage string, or "측정 안 됨" — never a bare 0%.
   *
   * @param {number} rate The stored rate (0..1), possibly null/undefined
   * @returns {string} The display string
   */
  formatPercent(rate) {
    if (!this.isMeasured(rate)) {
      return "측정 안 됨";
    }
    return `${(rate * 100).toFixed(1)}%`;
  }

  /**
   * A credible-interval range as a percentage bracket, or "" when either bound is unmeasured.
   *
   * @param {number} lower The lower bound (0..1)
   * @param {number} upper The upper bound (0..1)
   * @returns {string} The display string
   */
  formatInterval(lower, upper) {
    if (!this.isMeasured(lower) || !this.isMeasured(upper)) {
      return "";
    }
    return `94% 신용구간 [${(lower * 100).toFixed(1)}% – ${(upper * 100).toFixed(1)}%]`;
  }
}
