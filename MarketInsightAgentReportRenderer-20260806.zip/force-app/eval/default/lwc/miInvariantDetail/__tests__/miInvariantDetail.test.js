import { createElement } from "lwc";
import MiInvariantDetail from "c/miInvariantDetail";
import getDetail from "@salesforce/apex/MI_InvariantDetailController.getDetail";

// getDetail is a WIRED Apex method → needs a wire-adapter stub (emit/error).
jest.mock(
  "@salesforce/apex/MI_InvariantDetailController.getDetail",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// The component extends NavigationMixin and calls [GenerateUrl] to link the source document; the mock
// resolves a deterministic URL so the link assertion is stable.
jest.mock("lightning/navigation", () => {
  const GenerateUrl = Symbol("GenerateUrl");
  const NavigationMixin = (Base) =>
    class extends Base {
      [GenerateUrl](config) {
        return Promise.resolve(`/r/${config.attributes.recordId}/view`);
      }
    };
  NavigationMixin.GenerateUrl = GenerateUrl;
  return { NavigationMixin };
});

const RECORD_ID = "a40000000000001AAA";

const BASE = {
  found: true,
  recordId: RECORD_ID,
  name: "INV-0001",
  invariantType: "Sum",
  isViolated: true,
  isConfirmed: false,
  humanJudgment: "Not_Reviewed",
  expectedValue: "100",
  expectedValueMatched: "100",
  actualValue: "152.5",
  absoluteDelta: "52.5",
  relativeDeltaPercent: 52.5,
  sourcePage: "10",
  detail: "Sum of 2 segments vs the total row.",
  documentId: "a0X000000000001",
  fileName: "facts.pdf",
  involvedRows: [
    {
      rowKey: "k-total",
      role: "asserted",
      missing: false,
      entity: "Total",
      metric: "Sales",
      period: "FY2025",
      valueText: "152.5",
      unit: "Billion yen",
      valueType: "Actual",
      sourcePage: "10"
    },
    {
      rowKey: "k-a",
      role: "component",
      missing: false,
      entity: "Segment A",
      metric: "Sales",
      period: "FY2025",
      valueText: "60",
      unit: "Billion yen",
      valueType: "Actual",
      sourcePage: "10"
    }
  ]
};

function createComponent() {
  const element = createElement("c-mi-invariant-detail", {
    is: MiInvariantDetail
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(detail) {
  getDetail.emit(detail);
  await Promise.resolve();
}

describe("c-mi-invariant-detail", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows the method, the expected-vs-actual difference, and the verdict", async () => {
    const element = createComponent();
    await emit(BASE);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("모순 검출");
    // The family method line.
    expect(text).toContain("세부 행 값을 모두 더한");
    expect(text).toContain("100");
    expect(text).toContain("152.5");
    expect(text).toContain("52.5");
  });

  it("lists the involved fact rows, marking the asserted row apart from the components", async () => {
    const element = createComponent();
    await emit(BASE);

    const bodyText = element.shadowRoot.querySelector("tbody").textContent;
    expect(bodyText).toContain("원문 주장값");
    expect(bodyText).toContain("구성 요소");
    expect(bodyText).toContain("Total");
    expect(bodyText).toContain("Segment A");
  });

  it("marks a missing fact row rather than hiding it", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      involvedRows: [
        {
          rowKey: "k-gone",
          role: "component",
          missing: true
        }
      ]
    });

    const bodyText = element.shadowRoot.querySelector("tbody").textContent;
    expect(bodyText).toContain("누락");
    expect(bodyText).toContain("현재 사실 행 없음");
  });

  it("reports a non-violated check as 모순 없음", async () => {
    const element = createComponent();
    await emit({ ...BASE, isViolated: false });

    expect(element.shadowRoot.textContent).toContain("모순 없음");
  });

  it("shows a passing check as 일치 with the rounded expected value, not a phantom delta", async () => {
    // A YoY pass stores the full-precision expected (-7.0175) next to a whole-percent print (-7). The card
    // must show the rounded expected and an "일치" note, never the phantom "차이 0.0175 / 상대 0.25%".
    const element = createComponent();
    await emit({
      ...BASE,
      isViolated: false,
      expectedValue: "-7.0175",
      expectedValueMatched: "-7",
      actualValue: "-7",
      absoluteDelta: "0.0175",
      relativeDeltaPercent: 0.25
    });

    const text = element.shadowRoot.textContent;
    // The expected value is shown at the stored precision...
    expect(text).toContain("-7");
    // ...the "일치" note replaces the delta...
    expect(text).toContain("일치");
    expect(text).toContain("반올림 허용 범위 내");
    // ...and the phantom delta is NOT shown.
    expect(text).not.toContain("0.0175");
    expect(text).not.toContain("0.25%");
    expect(text).not.toContain("-7.0175");
  });

  it("still shows the full-precision expected and the delta on a violation", async () => {
    const element = createComponent();
    // BASE is a violation (isViolated: true) with expectedValue 100, expectedValueMatched 100.
    await emit({
      ...BASE,
      expectedValue: "100.4",
      expectedValueMatched: "100",
      absoluteDelta: "52.5"
    });

    const text = element.shadowRoot.textContent;
    // On a violation the full-precision expected is shown, not the rounded one.
    expect(text).toContain("100.4");
    expect(text).toContain("차이");
    expect(text).toContain("52.5");
    expect(text).not.toContain("일치");
  });

  it("shows the human judgment and explains a violation can be a false positive", async () => {
    const element = createComponent();
    await emit({ ...BASE, humanJudgment: "False_Positive" });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("사람 판정");
    expect(text).toContain("오탐 (검사가 부적절)");
    // The load-bearing caveat: the expected value itself can be inappropriate.
    expect(text).toContain("오탐");
    expect(text).toContain('"실제 오류"만');
  });

  it("surfaces the load failure reason", async () => {
    const element = createComponent();
    getDetail.error({ message: "FLS 오류" });
    await Promise.resolve();

    expect(element.shadowRoot.textContent).toContain("FLS 오류");
  });
});
