import { LightningElement, api, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import getDetail from "@salesforce/apex/MI_InvariantDetailController.getDetail";

/**
 * The detailed view of one MI_Tabular_Eval_Invariant__c check, shown on its record page beside the plain
 * field layout. Where the fields show the raw values, this reconstructs the whole test: what data was pulled
 * (the involved fact rows, resolved from Involved_Row_Keys__c), how the check was run (the family's method),
 * and exactly how the actual figure differs from what the invariant expected.
 *
 * Pairs with miInvariantExplainer (which explains what the family means in general); this one is specific to
 * THIS check's numbers. Read-only via getDetail. Static copy lives in the HTML; this JS only formats and
 * decorates.
 */

// Per-family one-line "how it was run" method, keyed by Invariant_Type__c. Hardcoded rather than fetched —
// it describes the fixed algorithm in MI_TabularEvalInvariantService, not per-record data.
const METHODS = {
  Sum: "한 지표·기간의 세부 행 값을 모두 더한 뒤, 원문에 적힌 합계 행과 비교했습니다.",
  Quarterly:
    "한 해 네 분기 값을 모두 더한 뒤, 같은 계열의 연간 값과 비교했습니다.",
  YoY: "당해·전년 실적치로 전년 대비 증감률을 다시 계산한 뒤, 원문에 적힌 YoY 값과 비교했습니다.",
  Magnitude:
    "한 계열의 인접 기간 값 비율을 계산해, 약 1000배 규모의 도약(단위 오독 신호)이 있는지 확인했습니다.",
  Conflict:
    "같은 좌표(지표·대상·기간)가 여러 페이지 범위에서 서로 다른 값으로 저장됐는지 대조했습니다."
};

export default class MiInvariantDetail extends NavigationMixin(
  LightningElement
) {
  @api recordId;

  detail;
  loadError;
  documentUrl;

  @wire(getDetail, { invariantId: "$recordId" })
  wiredDetail({ data, error }) {
    if (data) {
      this.detail = data;
      this.loadError = undefined;
      this.resolveDocumentUrl();
    } else if (error) {
      this.detail = undefined;
      this.loadError = error?.body?.message || "상세를 불러오지 못했습니다.";
    }
  }

  /**
   * Resolves the source document's record-page URL so the reviewer can jump straight to it — arithmetic
   * cannot say which figure is wrong, so opening the source is the required next step. A failure to generate
   * leaves the file name as plain text.
   */
  resolveDocumentUrl() {
    if (!this.detail?.documentId) {
      return;
    }
    this[NavigationMixin.GenerateUrl]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.detail.documentId,
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    })
      .then((url) => {
        this.documentUrl = url;
      })
      .catch(() => {
        // Leave documentUrl undefined; the template shows the file name as plain text.
      });
  }

  get hasDocumentUrl() {
    return !!this.documentUrl;
  }

  get hasDetail() {
    return this.detail != null && this.detail.found === true;
  }

  get invariantType() {
    return this.detail ? this.detail.invariantType : null;
  }

  get methodLine() {
    return this.detail ? METHODS[this.detail.invariantType] || null : null;
  }

  // The verdict banner: a violation is an arithmetic contradiction; a pass means only "no contradiction
  // found" for this check.
  get isViolated() {
    return this.detail?.isViolated === true;
  }
  get isConfirmed() {
    return this.detail?.isConfirmed === true;
  }
  get verdictLabel() {
    if (!this.detail) {
      return "";
    }
    return this.isViolated ? "모순 검출" : "모순 없음";
  }
  get verdictIcon() {
    return this.isViolated ? "utility:warning" : "utility:success";
  }
  get verdictVariant() {
    return this.isViolated ? "warning" : "success";
  }

  get expectedValue() {
    // On a pass, show the expected value rounded to the stored value's printed precision (so a whole-percent
    // pass reads "-7", not "-7.0175"); on a violation, show the full-precision figure so the discrepancy is
    // visible.
    if (!this.isViolated && this.detail?.expectedValueMatched != null) {
      return this.detail.expectedValueMatched;
    }
    return this.detail?.expectedValue ?? "—";
  }
  get actualValue() {
    return this.detail?.actualValue ?? "—";
  }
  get absoluteDelta() {
    return this.detail?.absoluteDelta ?? "—";
  }
  get relativeDeltaLabel() {
    return this.detail?.relativeDeltaPercent == null
      ? "—"
      : `${this.detail.relativeDeltaPercent}%`;
  }
  // The "차이" column is only meaningful on a violation. On a pass, the expected value is displayed already
  // rounded to the stored precision, so any residual delta is a display artifact of the recompute, not a
  // real discrepancy — showing it reads as a failure on a check that agreed. The HTML swaps in an "일치"
  // note instead.
  get showDelta() {
    return this.isViolated;
  }
  get sourcePage() {
    return this.detail?.sourcePage;
  }

  // The human's review verdict, decoded for display. Not_Reviewed (or null) is the "needs a human" state;
  // the point of this whole card is that the arithmetic cannot decide between a real error and a false
  // positive, so the human's call is a distinct, load-bearing fact.
  get humanJudgmentLabel() {
    return (
      {
        Not_Reviewed: "미검토",
        Real_Error: "실제 오류 (추출 문제)",
        False_Positive: "오탐 (검사가 부적절)",
        Cannot_Determine: "판단 불가"
      }[this.detail?.humanJudgment] || "미검토"
    );
  }
  get judgmentIsRealError() {
    return this.detail?.humanJudgment === "Real_Error";
  }
  get judgmentIsFalsePositive() {
    return this.detail?.humanJudgment === "False_Positive";
  }
  get judgmentReviewed() {
    const j = this.detail?.humanJudgment;
    return j != null && j !== "Not_Reviewed";
  }
  get detailText() {
    return this.detail?.detail;
  }
  get fileName() {
    return this.detail?.fileName;
  }

  get hasInvolvedRows() {
    return this.detail && this.detail.involvedRows.length > 0;
  }

  // The involved fact rows decorated for display: the asserted row (the total/annual/stored figure the
  // source claimed) is marked apart from the components the check summed or recomputed from.
  get involvedRows() {
    if (!this.detail) {
      return [];
    }
    return this.detail.involvedRows.map((row, i) => {
      const isAsserted = row.role === "asserted";
      return {
        ...row,
        key: `${row.rowKey}-${i}`,
        roleLabel: row.missing
          ? "누락"
          : isAsserted
            ? "원문 주장값"
            : "구성 요소",
        rowClass: isAsserted
          ? "slds-hint-parent asserted-row"
          : "slds-hint-parent",
        valueDisplay: row.missing ? "(현재 사실 행 없음)" : row.valueText
      };
    });
  }
}
