import { LightningElement, api, track } from "lwc";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getPageContext from "@salesforce/apex/MI_GoldenRowCaptureController.getPageContext";
import validateDraft from "@salesforce/apex/MI_GoldenRowCaptureController.validateDraft";
import saveGoldenRow from "@salesforce/apex/MI_GoldenRowCaptureController.saveGoldenRow";
import markReviewed from "@salesforce/apex/MI_GoldenRowCaptureController.markReviewed";
import getPendingProposals from "@salesforce/apex/MI_GoldenRowCaptureController.getPendingProposals";
import confirmProposals from "@salesforce/apex/MI_GoldenRowCaptureController.confirmProposals";
import rejectProposals from "@salesforce/apex/MI_GoldenRowCaptureController.rejectProposals";

/**
 * Records a ground-truth figure for one page of a document, checked against what the pipeline actually
 * extracted there BEFORE it is saved.
 *
 * WHY THIS COMPONENT EXISTS. The golden set used to be authored outside the org — an HTML review app, a
 * conversion script, a CSV bulk load — and that path could not see the pipeline's conventions. It failed
 * exactly there: on the line-item tables of Sony pages 10, 11 and 13 the reviewer put the company in Entity
 * and the line-item label in Metric, while the pipeline puts the row label in Entity. 165 figures whose values
 * were all correct scored as a total miss (three pages at 0% recall), and it was invisible until the rows were
 * loaded and scored. Capturing next to the data, validated by the SAME matcher that scores it, is what closes
 * that gap.
 *
 * The warnings never block a save. A reviewer reading the source page is the authority — if the pipeline stored
 * the wrong thing, they must be able to record the right thing and have it counted as a real defect. Blocking
 * would quietly redefine ground truth as "whatever the pipeline already did", making the evaluation circular.
 */
export default class MiGoldenRowCapture extends LightningElement {
  /** Set by the record page. */
  @api recordId;

  /** The page being reviewed, as the reviewer types it (e.g. "10" or "p.10"). */
  @track sourcePage = "";

  /** The draft being entered. Mirrored into a private object so no @api prop is ever mutated. */
  @track draft = {
    entity: "",
    entityParent: "",
    entityLabel: "",
    metricKey: "",
    metricLabel: "",
    figurePeriod: "",
    valueText: "",
    unit: "",
    valueType: "Actual",
    tableName: "",
    columnNote: "",
    note: ""
  };

  @track context;
  @track warnings = [];
  @track isLoading = false;
  @track savedCount = 0;

  /** Review-scope form state. */
  @track reviewStatus = "Complete";
  @track reviewFigureCount = "";
  /** LLM-proposed rows awaiting human confirmation on this page. NOT reference data until approved. */
  @track proposals = [];
  @track selectedProposalIds = [];

  valueTypeOptions = [
    { label: "Actual", value: "Actual" },
    { label: "Estimate", value: "Estimate" },
    { label: "Guidance", value: "Guidance" },
    { label: "YoY", value: "YoY" },
    { label: "QoQ", value: "QoQ" },
    { label: "Consensus", value: "Consensus" },
    { label: "Target", value: "Target" }
  ];

  reviewStatusOptions = [
    {
      label: "Complete — 이 범위의 모든 수치를 기록했습니다",
      value: "Complete"
    },
    { label: "Partial — 일부만 기록했습니다", value: "Partial" },
    {
      label: "No Figures — 검수했으나 수치가 없는 표입니다",
      value: "No_Figures"
    }
  ];

  /** Whether a page has been loaded, which gates the entry form. */
  get hasContext() {
    return !!this.context;
  }

  /** True when the loaded page has no extracted rows — the reviewer is working without a comparison. */
  get hasNoExtractedRows() {
    return !!this.context && this.context.extractedRows.length === 0;
  }

  /**
   * The convention this page's extracted rows follow, phrased as guidance rather than as a field name — a
   * reviewer should not have to know the project's schema history to enter a row correctly.
   */
  get conventionHint() {
    if (!this.context || this.context.extractedRows.length === 0) {
      return null;
    }
    return this.context.rowShape === "line_item"
      ? `이 페이지는 항목 행(line-item) 형식입니다 (${this.context.lineItemRowCount}행). 지표명을 Entity 에 넣으세요 — 예: Entity="Operating income", Metric Key="operating_income".`
      : `이 페이지는 주체 행 형식입니다 (${this.context.entityRowCount}행). 회사·세그먼트를 Entity 에, 측정값을 Metric Key 에 넣으세요 — 예: Entity="Music", Metric Key="sales".`;
  }

  /** Review state of the loaded page, or an explicit "not yet reviewed". */
  get reviewStateLabel() {
    if (!this.context) {
      return null;
    }
    if (!this.context.reviewStatus) {
      return "미검수 — 이 페이지는 아직 검수 기록이 없습니다. 채점에서 재현율 0%와 구분되지 않으므로, 끝내고 나면 아래에서 검수 완료를 기록해 주세요.";
    }
    return `검수 기록: ${this.context.reviewStatus}${
      this.context.reviewedFigureCount
        ? ` (${this.context.reviewedFigureCount}건)`
        : ""
    } · 정답 ${this.context.goldenRowCount}건 저장됨`;
  }

  get hasWarnings() {
    return this.warnings.length > 0;
  }

  /** Warnings decorated for display, since the template cannot compute a class from a value. */
  get decoratedWarnings() {
    return this.warnings.map((warning, index) => ({
      // A stable client-minted key: never the array index alone, so re-renders keep row identity.
      key: `${warning.field}-${index}`,
      severity: warning.severity,
      message: warning.message,
      iconName:
        warning.severity === "error"
          ? "utility:error"
          : warning.severity === "warning"
            ? "utility:warning"
            : "utility:info",
      variant: warning.severity === "error" ? "error" : "warning",
      cssClass:
        warning.severity === "error"
          ? "slds-text-color_error slds-m-bottom_xx-small"
          : "slds-m-bottom_xx-small"
    }));
  }

  /** True when at least one warning says the row will be mis-scored as entered. */
  get hasBlockingWarning() {
    return this.warnings.some((warning) => warning.severity === "error");
  }

  get saveButtonLabel() {
    return this.hasBlockingWarning ? "경고를 무시하고 저장" : "정답 행 저장";
  }

  get saveButtonVariant() {
    return this.hasBlockingWarning ? "destructive-text" : "brand";
  }

  /** The extracted rows, keyed for the comparison table. */
  get extractedRowsForDisplay() {
    if (!this.context) {
      return [];
    }
    return this.context.extractedRows.map((row, index) => ({
      key: `${row.entity}-${row.figurePeriod}-${index}`,
      ...row,
      subject: row.entityParent
        ? `${row.entityParent} › ${row.entity}`
        : row.entity
    }));
  }

  handlePageChange(event) {
    this.sourcePage = event.target.value;
  }

  handleDraftChange(event) {
    const field = event.target.dataset.field;
    if (!field) {
      return;
    }
    // Reassigned rather than mutated in place so the tracked getter re-evaluates.
    this.draft = { ...this.draft, [field]: event.target.value };
  }

  handleReviewStatusChange(event) {
    this.reviewStatus = event.detail.value;
  }

  handleReviewCountChange(event) {
    this.reviewFigureCount = event.target.value;
  }

  /** Loads the page's extracted rows and existing review state. */
  async handleLoadPage() {
    if (!this.sourcePage) {
      this.toast(
        "페이지를 입력하세요",
        "검수할 페이지 번호가 필요합니다.",
        "warning"
      );
      return;
    }
    this.isLoading = true;
    try {
      this.context = await getPageContext({
        documentId: this.recordId,
        sourcePage: this.sourcePage
      });
      this.warnings = [];
      // Pre-fill the fields a whole page shares, so the reviewer types them once instead of per row — the
      // repetition is where transcription slips creep in.
      if (this.context.tableNames.length === 1) {
        this.draft = { ...this.draft, tableName: this.context.tableNames[0] };
      }
      if (this.context.units.length === 1) {
        this.draft = { ...this.draft, unit: this.context.units[0] };
      }
      // Loaded alongside the page, because approving an existing proposal is almost always cheaper than typing
      // the same figure by hand — the reviewer should see the queue before starting to transcribe.
      await this.loadProposals();
    } catch (error) {
      this.toast(
        "페이지를 불러오지 못했습니다",
        this.messageOf(error),
        "error"
      );
    } finally {
      this.isLoading = false;
    }
  }

  /** Validates without saving, so the reviewer can see a convention mismatch while it is still cheap to fix. */
  async handleValidate() {
    this.isLoading = true;
    try {
      this.warnings = await validateDraft({ draft: this.draftPayload() });
      if (this.warnings.length === 0) {
        this.toast("확인 완료", "추출 데이터의 표기와 일치합니다.", "success");
      }
    } catch (error) {
      this.toast("검증에 실패했습니다", this.messageOf(error), "error");
    } finally {
      this.isLoading = false;
    }
  }

  async handleSave() {
    this.isLoading = true;
    try {
      const result = await saveGoldenRow({ draft: this.draftPayload() });
      this.warnings = result.warnings || [];
      this.savedCount += 1;
      // Keep the shared fields, clear the per-figure ones: the next row of the same table shares its title,
      // unit and often its subject, and retyping those is the main source of inconsistency in a golden set.
      this.draft = {
        ...this.draft,
        metricLabel: "",
        figurePeriod: "",
        valueText: "",
        note: ""
      };
      this.toast(
        "정답 행 저장",
        `${this.savedCount}건 저장했습니다.`,
        "success"
      );
    } catch (error) {
      this.toast("저장하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isLoading = false;
    }
  }

  /** Records that this page has been reviewed, which is what lets scoring tell 0% from "not measured". */
  async handleMarkReviewed() {
    if (!this.sourcePage) {
      this.toast(
        "페이지를 입력하세요",
        "검수 범위를 지정해야 합니다.",
        "warning"
      );
      return;
    }
    this.isLoading = true;
    try {
      await markReviewed({
        documentId: this.recordId,
        sourcePage: this.sourcePage,
        tableName: this.draft.tableName,
        reviewStatus: this.reviewStatus,
        figureCount: this.reviewFigureCount
      });
      this.toast(
        "검수 범위 기록",
        "이 범위는 이제 채점에서 검수된 범위로 계산됩니다.",
        "success"
      );
      await this.handleLoadPage();
    } catch (error) {
      this.toast("기록하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isLoading = false;
    }
  }

  /**
   * Loads the LLM-proposed rows awaiting confirmation for this page.
   *
   * The queue is what turns the reviewer's job from transcription into confirmation — the reason a golden set
   * costs 1–2 hours per document is typing, not judgement. Nothing here is reference data until it is approved.
   */
  async loadProposals() {
    try {
      this.proposals = await getPendingProposals({
        documentId: this.recordId,
        sourcePage: this.sourcePage
      });
      this.selectedProposalIds = [];
    } catch (error) {
      this.toast("제안 목록을 읽지 못했습니다", this.messageOf(error), "error");
    }
  }

  handleProposalSelect(event) {
    const recordId = event.target.dataset.id;
    if (event.target.checked) {
      this.selectedProposalIds = [...this.selectedProposalIds, recordId];
    } else {
      this.selectedProposalIds = this.selectedProposalIds.filter(
        (id) => id !== recordId
      );
    }
  }

  handleSelectAllProposals(event) {
    this.selectedProposalIds = event.target.checked
      ? this.proposals.map((row) => row.recordId)
      : [];
  }

  /**
   * Promotes the selected proposals to human-confirmed reference rows.
   *
   * This is the only transition that turns a model's suggestion into ground truth, which is why it is an explicit
   * button rather than something that happens on load.
   */
  async handleConfirmProposals() {
    if (!this.hasSelectedProposals) {
      return;
    }
    this.isLoading = true;
    try {
      const promoted = await confirmProposals({
        recordIds: this.selectedProposalIds
      });
      this.toast(
        "승인 완료",
        `${promoted}건을 정답으로 확정했습니다. 이제 채점의 기준으로 쓰입니다.`,
        "success"
      );
      await this.loadProposals();
    } catch (error) {
      this.toast("승인하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isLoading = false;
    }
  }

  /**
   * Discards the selected proposals.
   *
   * Rejection has to be available: a wrong candidate left in place would be scored as reference data by the next
   * run, which would report correct extraction as a defect.
   */
  async handleRejectProposals() {
    if (!this.hasSelectedProposals) {
      return;
    }
    this.isLoading = true;
    try {
      const removed = await rejectProposals({
        recordIds: this.selectedProposalIds
      });
      this.toast("제안 삭제", `${removed}건을 버렸습니다.`, "success");
      await this.loadProposals();
    } catch (error) {
      this.toast("삭제하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isLoading = false;
    }
  }

  get hasProposals() {
    return (this.proposals || []).length > 0;
  }

  get proposalCount() {
    return (this.proposals || []).length;
  }

  get hasSelectedProposals() {
    return (this.selectedProposalIds || []).length > 0;
  }

  get selectedProposalCount() {
    return (this.selectedProposalIds || []).length;
  }

  /**
   * Whether the approve/discard buttons are disabled.
   *
   * Expressed as the negative because a template cannot negate — `disabled={hasSelectedProposals}` would invert
   * the intent, which is the sort of bug that silently ships.
   */
  get isConfirmDisabled() {
    return !this.hasSelectedProposals;
  }

  /** The draft plus the page context the server needs to validate it. */
  draftPayload() {
    return {
      ...this.draft,
      documentId: this.recordId,
      sourcePage: this.sourcePage
    };
  }

  /**
   * The message from an Apex error, falling back to something actionable rather than "undefined".
   *
   * @param {object} error The rejected Apex error
   * @returns {string} A displayable message
   */
  messageOf(error) {
    return (
      error?.body?.message ||
      error?.message ||
      "알 수 없는 오류가 발생했습니다."
    );
  }

  /**
   * Shows a toast.
   *
   * @param {string} title The toast title
   * @param {string} message The body
   * @param {string} variant success | warning | error | info
   */
  toast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }
}
