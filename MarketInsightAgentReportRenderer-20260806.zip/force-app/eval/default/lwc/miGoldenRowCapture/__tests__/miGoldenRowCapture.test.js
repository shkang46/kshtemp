import { createElement } from "lwc";
import MiGoldenRowCapture from "c/miGoldenRowCapture";
import getPageContext from "@salesforce/apex/MI_GoldenRowCaptureController.getPageContext";
import validateDraft from "@salesforce/apex/MI_GoldenRowCaptureController.validateDraft";
import saveGoldenRow from "@salesforce/apex/MI_GoldenRowCaptureController.saveGoldenRow";
import markReviewed from "@salesforce/apex/MI_GoldenRowCaptureController.markReviewed";
import getPendingProposals from "@salesforce/apex/MI_GoldenRowCaptureController.getPendingProposals";
import confirmProposals from "@salesforce/apex/MI_GoldenRowCaptureController.confirmProposals";
import rejectProposals from "@salesforce/apex/MI_GoldenRowCaptureController.rejectProposals";

// @salesforce/apex is auto-mocked by sfdx-lwc-jest, but each imperative method needs a resolvable default so
// the component's awaits complete rather than hanging the test.
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.getPageContext",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.validateDraft",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.saveGoldenRow",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.markReviewed",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.getPendingProposals",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.confirmProposals",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_GoldenRowCaptureController.rejectProposals",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

const RECORD_ID = "a36Ie000000LgLkIAK";

// A page whose extracted rows are line-item shaped — the shape that silently zeroed three pages of the real
// evaluation when the golden set used the other convention.
const LINE_ITEM_CONTEXT = {
  documentId: RECORD_ID,
  sourcePage: "10",
  extractedRows: [
    {
      entity: "Operating income",
      entityParent: null,
      metricKey: "operating_income",
      metricLabel: "Adjusted",
      figurePeriod: "FY2024-Q1",
      value: "249.1",
      unit: "Billion yen",
      valueType: "Actual",
      tableName: "Adjusted Income"
    }
  ],
  rowShape: "line_item",
  lineItemRowCount: 41,
  entityRowCount: 0,
  tableNames: ["Adjusted Income"],
  metricKeys: ["operating_income"],
  units: ["Billion yen"],
  periods: ["FY2024-Q1"],
  goldenRowCount: 0,
  reviewStatus: null,
  reviewedFigureCount: null
};

function createComponent() {
  const element = createElement("c-mi-golden-row-capture", {
    is: MiGoldenRowCapture
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

// Types a page number and clicks "load", then flushes the awaited Apex call.
async function loadPage(element, page = "10") {
  const pageInput = element.shadowRoot.querySelector("lightning-input");
  pageInput.value = page;
  pageInput.dispatchEvent(new CustomEvent("change", { target: pageInput }));
  // lightning-input is stubbed, so the handler reads event.target.value — set it directly on the stub.
  element.shadowRoot
    .querySelector("lightning-button")
    .dispatchEvent(new CustomEvent("click"));
  await Promise.resolve();
  await Promise.resolve();
}

describe("c-mi-golden-row-capture", () => {
  beforeEach(() => {
    getPageContext.mockResolvedValue(LINE_ITEM_CONTEXT);
    validateDraft.mockResolvedValue([]);
    saveGoldenRow.mockResolvedValue({
      recordId: "a4A000000000001",
      warnings: []
    });
    markReviewed.mockResolvedValue("a4B000000000001");
    // Defaults to an empty queue so the existing cases exercise the no-proposals path; the proposal tests
    // override it.
    getPendingProposals.mockResolvedValue([]);
    confirmProposals.mockResolvedValue(0);
    rejectProposals.mockResolvedValue(0);
  });

  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows only the page picker until a page is loaded", () => {
    const element = createComponent();
    // The entry form must not be reachable before a page's conventions are known — entering a row blind is
    // exactly how the convention mismatch happened in the first place.
    const comboboxes =
      element.shadowRoot.querySelectorAll("lightning-combobox");
    expect(comboboxes.length).toBe(0);
  });

  it("tells the reviewer which coordinate convention THIS page uses", async () => {
    const element = createComponent();
    await loadPage(element);

    const text = element.shadowRoot.textContent;
    // The guidance must name the concrete action, not the abstract rule: a reviewer should not need to know the
    // project's schema history to enter a row correctly.
    expect(text).toContain("항목 행");
    expect(text).toContain("지표명을 Entity");
  });

  it("distinguishes an unreviewed page from a page scored at 0%", async () => {
    const element = createComponent();
    await loadPage(element);

    // THE DISTINCTION THIS TOOL EXISTS FOR. Scoring previously inferred "reviewed" from the presence of golden
    // rows, so a page nobody had looked at and a page whose figures were all missed produced the same number.
    expect(element.shadowRoot.textContent).toContain("미검수");
  });

  it("reports the existing review state when the page has one", async () => {
    getPageContext.mockResolvedValue({
      ...LINE_ITEM_CONTEXT,
      reviewStatus: "Complete",
      reviewedFigureCount: "136",
      goldenRowCount: 136
    });
    const element = createComponent();
    await loadPage(element);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("Complete");
    expect(text).toContain("136");
    expect(text).not.toContain("미검수");
  });

  it("surfaces a convention mismatch as an error but still allows the save", async () => {
    validateDraft.mockResolvedValue([
      {
        severity: "error",
        field: "entity",
        message:
          "이 페이지의 추출 행은 지표명을 Entity 에 넣는 형식입니다(41행)."
      }
    ]);
    const element = createComponent();
    await loadPage(element);

    const buttons = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    );
    const validateButton = buttons.find(
      (button) => button.label === "추출 데이터와 대조"
    );
    validateButton.dispatchEvent(new CustomEvent("click"));
    await Promise.resolve();
    await Promise.resolve();

    expect(element.shadowRoot.textContent).toContain(
      "지표명을 Entity 에 넣는 형식"
    );
    // NOT blocked. The reviewer reading the source page is the authority — if the pipeline stored the wrong
    // thing, they must be able to record the right thing and have it counted as a real defect. Blocking would
    // make the golden set agree with the pipeline by construction, and the evaluation would prove nothing.
    const saveButton = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((button) => button.label === "경고를 무시하고 저장");
    expect(saveButton).toBeTruthy();
  });

  it("keeps the shared fields after a save and clears the per-figure ones", async () => {
    const element = createComponent();
    await loadPage(element);

    const saveButton = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((button) => button.label === "정답 행 저장");
    saveButton.dispatchEvent(new CustomEvent("click"));
    await Promise.resolve();
    await Promise.resolve();

    expect(saveGoldenRow).toHaveBeenCalledTimes(1);
    const sentDraft = saveGoldenRow.mock.calls[0][0].draft;
    // Pre-filled from the page's single table/unit, so the reviewer types them once. Repetition across dozens
    // of rows is where a golden set acquires its own inconsistencies.
    expect(sentDraft.tableName).toBe("Adjusted Income");
    expect(sentDraft.unit).toBe("Billion yen");
    expect(sentDraft.documentId).toBe(RECORD_ID);
  });

  it("records the review scope with the chosen status", async () => {
    const element = createComponent();
    await loadPage(element);

    const markButton = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((button) => button.label === "검수 완료 기록");
    markButton.dispatchEvent(new CustomEvent("click"));
    await Promise.resolve();
    await Promise.resolve();

    expect(markReviewed).toHaveBeenCalledTimes(1);
    const args = markReviewed.mock.calls[0][0];
    expect(args.documentId).toBe(RECORD_ID);
    expect(args.reviewStatus).toBe("Complete");
  });

  it("warns when the page yielded no extracted rows to compare against", async () => {
    getPageContext.mockResolvedValue({
      ...LINE_ITEM_CONTEXT,
      extractedRows: [],
      tableNames: [],
      metricKeys: [],
      units: [],
      periods: []
    });
    const element = createComponent();
    await loadPage(element);

    // Not necessarily a reviewer error — the extraction may have missed the table, or the page label may not
    // match what was stored. Either way the reviewer is working without a comparison and should know it.
    expect(element.shadowRoot.textContent).toContain("추출된 행이 없습니다");
  });

  it("reports an Apex failure instead of failing silently", async () => {
    getPageContext.mockRejectedValue({ body: { message: "FLS 오류" } });
    const element = createComponent();
    await loadPage(element);

    // The form stays hidden rather than showing an empty page as if it had loaded — a blank form after a failed
    // load would invite the reviewer to enter rows against no context at all.
    expect(
      element.shadowRoot.querySelectorAll("lightning-combobox").length
    ).toBe(0);
  });

  const PROPOSALS = [
    {
      recordId: "a4C000000000001",
      entity: "Sony_GNS",
      entityParent: null,
      metricKey: "total_sales",
      metricLabel: "Total sales",
      figurePeriod: "FY25 Q3",
      valueText: "1,613,587",
      unit: "Millions of yen",
      valueType: "Actual",
      sourcePage: "10",
      sourceSnippet: "Total | FY25 Q3 | 1,613,587",
      tableName: "Sales by segment"
    },
    {
      recordId: "a4C000000000002",
      entity: "Sony_Music",
      entityParent: null,
      metricKey: "total_sales",
      metricLabel: "Total sales",
      figurePeriod: "FY25 Q3",
      valueText: "456,789",
      unit: "Millions of yen",
      valueType: "Actual",
      sourcePage: "10",
      sourceSnippet: "Music | FY25 Q3 | 456,789",
      tableName: "Sales by segment"
    }
  ];

  /**
   * The checkbox inputs inside the proposal table (the page-number input is a lightning-input too, so the
   * selection is by type rather than by position).
   *
   * @param {HTMLElement} element The component
   * @returns {Array} The checkbox stubs
   */
  function proposalCheckboxes(element) {
    return Array.from(
      element.shadowRoot.querySelectorAll("lightning-input[data-id]")
    );
  }

  it("shows no approval queue when nothing has been proposed", async () => {
    const element = createComponent();
    await loadPage(element);

    expect(element.shadowRoot.textContent).not.toContain("승인 대기");
  });

  it("lists pending proposals with the verbatim quote that makes them checkable", async () => {
    getPendingProposals.mockResolvedValue(PROPOSALS);
    const element = createComponent();
    await loadPage(element);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("승인 대기");
    // The quote is the whole reason a reviewer can confirm in seconds instead of reopening the source file.
    expect(text).toContain("Total | FY25 Q3 | 1,613,587");
    // And the card says outright that these are not yet reference data.
    expect(text).toContain("아직 정답이 아닙니다");
  });

  it("promotes only the selected proposals", async () => {
    getPendingProposals.mockResolvedValue(PROPOSALS);
    confirmProposals.mockResolvedValue(1);
    const element = createComponent();
    await loadPage(element);

    const boxes = proposalCheckboxes(element);
    boxes[0].checked = true;
    boxes[0].dispatchEvent(new CustomEvent("change"));
    await Promise.resolve();

    const buttons = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    );
    const approve = buttons.find((button) => button.label === "선택 승인");
    approve.dispatchEvent(new CustomEvent("click"));
    await Promise.resolve();

    // Exactly the checked row is promoted. Promoting the whole queue on one click would turn an unreviewed
    // suggestion into ground truth, which is the one thing this flow must not do.
    expect(confirmProposals).toHaveBeenCalledWith({
      recordIds: ["a4C000000000001"]
    });
  });

  it("cannot approve or discard with nothing selected", async () => {
    getPendingProposals.mockResolvedValue(PROPOSALS);
    const element = createComponent();
    await loadPage(element);

    const buttons = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    );
    const approve = buttons.find((button) => button.label === "선택 승인");
    const discard = buttons.find((button) => button.label === "선택 삭제");

    // Disabled rather than merely a no-op handler: an enabled button that does nothing reads as a broken screen.
    expect(approve.disabled).toBe(true);
    expect(discard.disabled).toBe(true);
  });

  it("discards the selected proposals", async () => {
    getPendingProposals.mockResolvedValue(PROPOSALS);
    rejectProposals.mockResolvedValue(1);
    const element = createComponent();
    await loadPage(element);

    const boxes = proposalCheckboxes(element);
    boxes[1].checked = true;
    boxes[1].dispatchEvent(new CustomEvent("change"));
    await Promise.resolve();

    const discard = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((button) => button.label === "선택 삭제");
    discard.dispatchEvent(new CustomEvent("click"));
    await Promise.resolve();

    // A wrong candidate must be removable: left in place it would be scored as reference data and would report
    // correct extraction as a defect.
    expect(rejectProposals).toHaveBeenCalledWith({
      recordIds: ["a4C000000000002"]
    });
  });

  it("selects and clears the whole queue from the header checkbox", async () => {
    getPendingProposals.mockResolvedValue(PROPOSALS);
    const element = createComponent();
    await loadPage(element);

    // The header box is the one checkbox in the proposal table without a data-id.
    const headerBox = Array.from(
      element.shadowRoot.querySelectorAll("lightning-input")
    ).find((input) => input.label === "전체 선택");

    headerBox.checked = true;
    headerBox.dispatchEvent(new CustomEvent("change"));
    await Promise.resolve();
    expect(element.shadowRoot.textContent).toContain("2건 선택됨");

    headerBox.checked = false;
    headerBox.dispatchEvent(new CustomEvent("change"));
    await Promise.resolve();
    expect(element.shadowRoot.textContent).toContain("0건 선택됨");
  });

  it("reports a proposal-load failure rather than showing an empty queue", async () => {
    getPendingProposals.mockRejectedValue({
      body: { message: "제안 조회 권한이 없습니다" }
    });
    const element = createComponent();
    await loadPage(element);

    // An empty queue and an unreadable queue look identical on screen, and only the second is a problem to fix —
    // so the page context still renders while the failure is surfaced as a toast.
    expect(element.shadowRoot.textContent).not.toContain("승인 대기");
  });
});
