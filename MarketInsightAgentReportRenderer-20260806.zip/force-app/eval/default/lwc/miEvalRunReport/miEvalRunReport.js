import { LightningElement, api, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getRunReport from "@salesforce/apex/MI_EvalRunReportController.getRunReport";
import getRunChecks from "@salesforce/apex/MI_EvalRunReportController.getRunChecks";
import validateJudgeRun from "@salesforce/apex/MI_QualityRunController.validateJudgeRun";

/**
 * The comprehensive report for one MI_Tabular_Eval_Run__c, shown on the run record page in place of a raw
 * field dump. Answers the questions the ~95 aggregate fields cannot on their own: which documents were
 * evaluated, on what dataset, what kind of validation ran, and how far the numbers can be trusted.
 *
 * Layout is three bands: (A) a summary dashboard — KPI tiles + a run-type-aware Chart.js visual; (B) a
 * dataset / coverage / trust section rendering the run's stored Coverage_Note__c and Power_Note__c verbatim;
 * (C) a per-document drill-down (and, for a single-document Golden run, a per-page table). All figures come
 * from MI_EvalRunReportController.getRunReport already formatted (a percentage Decimal, or null), so this JS
 * only appends "%" or prints "측정 안 됨" — it never re-scales.
 *
 * The static labels, captions and caveats live in the HTML; this JS only picks the leg's block, formats the
 * numbers, decorates the drill-down rows, and builds the chart specs.
 */

// Display decoration per page-verdict state, copied from miDocumentTabularAccuracy. Deliberately NOT a
// red/green gradient: several of these states are not quality judgments (no_figures is a pass, not_reviewed
// carries no information), so colouring them like a score would misread a pass as a failure.
const PAGE_DECORATIONS = {
  good: { label: "양호", icon: "utility:success", variant: "success" },
  partial: { label: "부분 일치", icon: "utility:warning", variant: "warning" },
  weak: { label: "미흡", icon: "utility:warning", variant: "error" },
  no_match: { label: "전량 불일치", icon: "utility:error", variant: "error" },
  no_figures: { label: "수치 없음 (정상)", icon: "utility:info", variant: "" },
  unexpected_rows: {
    label: "불필요한 행",
    icon: "utility:error",
    variant: "error"
  },
  reviewed_no_reference: {
    label: "정답 미입력",
    icon: "utility:info",
    variant: ""
  },
  not_reviewed: { label: "미검수", icon: "utility:dash", variant: "" }
};

const NOT_MEASURED = "측정 안 됨";

export default class MiEvalRunReport extends NavigationMixin(LightningElement) {
  @api recordId;

  report;
  loadError;
  checkList;
  isValidating = false;
  // Resolved record-page URLs keyed by document Id, so each drill-down row is a real (cmd-clickable) link.
  urlByDoc = {};

  // The entire wire result is retained (not just .data) so refreshApex can re-fetch it after the validation
  // button runs — refreshApex needs the provisioned wire object, and .data alone will not refresh.
  _reportResult;

  @wire(getRunReport, { runId: "$recordId" })
  wiredReport(result) {
    this._reportResult = result;
    const { data, error } = result;
    if (data) {
      this.report = data;
      this.loadError = undefined;
      this.resolveDocumentUrls();
    } else if (error) {
      this.report = undefined;
      this.loadError = error?.body?.message || "리포트를 불러오지 못했습니다.";
    }
  }

  @wire(getRunChecks, { runId: "$recordId" })
  wiredChecks({ data }) {
    // A failure here is non-fatal: the aggregate report above still renders, only the raw-records table is
    // withheld. So the error branch just leaves checkList undefined rather than surfacing an error.
    if (data) {
      this.checkList = data;
    }
  }

  /**
   * Resolves a record-page URL for each evaluated document via NavigationMixin.GenerateUrl, so the drill-down
   * renders real anchors (cmd/ctrl-click to open in a new tab) rather than onclick-only jumps. A failure to
   * generate leaves the row as plain text — the table still renders.
   */
  resolveDocumentUrls() {
    const docs = this.report?.documents || [];
    docs.forEach((doc) => {
      this[NavigationMixin.GenerateUrl]({
        type: "standard__recordPage",
        attributes: {
          recordId: doc.documentId,
          objectApiName: "Market_Insight_Document__c",
          actionName: "view"
        }
      })
        .then((url) => {
          this.urlByDoc = { ...this.urlByDoc, [doc.documentId]: url };
        })
        .catch(() => {
          // Leave this row without a URL; documentRows falls back to plain text.
        });
    });
  }

  // ---- format helpers ----------------------------------------------------
  // The controller already returns percentages (e.g. 92.7) or null, so a present value is only suffixed.
  pct(value) {
    return value === null || value === undefined ? NOT_MEASURED : `${value}%`;
  }

  num(value) {
    return value === null || value === undefined ? NOT_MEASURED : `${value}`;
  }

  // ---- top-level state ---------------------------------------------------
  get hasReport() {
    return this.report != null && this.report.found === true;
  }

  get runType() {
    return this.report ? this.report.runType : null;
  }

  get cardTitle() {
    return `평가 실행 리포트 — ${this.runTypeLabel}`;
  }

  get runTypeLabel() {
    return (
      {
        Golden: "골든셋 정확도·완전성",
        Invariant: "산술 불변식 검사",
        Judge: "LLM 심판 (표 수치)",
        Answer_Judge: "답변 품질 심판 (RAGAS)",
        Probe: "검색 정확도 프로브",
        Retrieval_Probe: "검색 정확도 프로브 (인덱스 비교)",
        Golden_Proposal: "골든셋 후보 생성",
        Answer_Judge_Validation: "답변 품질 심판 검증",
        // Facet_Golden reuses the Golden_* run fields → golden block. The facet/answer JUDGE legs render their
        // OWN table block (their verdict vocabulary differs from the tabular judge), so the label names the
        // facet-value / answer axis rather than implying it is only a Faithfulness score.
        Facet_Golden: "패싯 골든 정확도·완전성",
        Facet_Judge: "패싯 심판 (값 확인 + 요약 근거)",
        Facet_Judge_Validation: "패싯 심판 검증",
        Facet_Golden_Proposal: "패싯 골든셋 후보 생성"
      }[this.runType] || this.runType
    );
  }

  // ---- block dispatch ----------------------------------------------------
  // Facet_Golden folds into the golden block (same Golden_* run fields + Match/Not_In_Source verdicts). The
  // three JUDGE legs are kept SEPARATE, because they write DIFFERENT Verdict__c vocabularies: the tabular
  // judge speaks Match/*_Mismatch, the facet judge Present/Not_In_Source + Grounded/Ungrounded, the answer
  // judge Grounded/Ungrounded + Relevant/Irrelevant. Rendering all three with the tabular Match/Mismatch
  // columns is what made a facet "Present" (correct) read as "불일치(오류)" — so each has its own table block.
  get isGolden() {
    return this.runType === "Golden" || this.runType === "Facet_Golden";
  }
  get isInvariant() {
    return this.runType === "Invariant";
  }
  // The TABULAR judge only (Match/*_Mismatch vocabulary). Facet_Judge is deliberately NOT here anymore.
  get isTabularJudge() {
    return this.runType === "Judge";
  }
  get isFacetJudge() {
    return this.runType === "Facet_Judge";
  }
  get isAnswerJudge() {
    return this.runType === "Answer_Judge";
  }
  // Shared by anything that reports a RAGAS Faithfulness headline + the synthetic/faithfulness caveats + the
  // Faithfulness doughnut. The per-document TABLE is NOT shared — each leg picks its own columns below.
  get isJudgeFamily() {
    return this.isTabularJudge || this.isFacetJudge || this.isAnswerJudge;
  }
  get isRetrieval() {
    return this.runType === "Probe" || this.runType === "Retrieval_Probe";
  }
  get isProposal() {
    return (
      this.runType === "Golden_Proposal" ||
      this.runType === "Facet_Golden_Proposal"
    );
  }
  get isUnhandled() {
    return (
      this.hasReport &&
      !this.isGolden &&
      !this.isInvariant &&
      !this.isJudgeFamily &&
      !this.isRetrieval &&
      !this.isProposal
    );
  }

  // ---- Power/Coverage notes ---------------------------------------------
  get powerNote() {
    return this.report ? this.report.powerNote : null;
  }
  get hasPowerNote() {
    return !!this.powerNote;
  }
  get coverageNote() {
    return this.report ? this.report.coverageNote : null;
  }
  get hasCoverageNote() {
    return !!this.coverageNote;
  }
  get coverageLine() {
    if (!this.report) {
      return null;
    }
    const parts = [
      this.report.coveredFormats,
      this.report.coveredRoutes,
      this.report.coveredDocumentTypes
    ].filter((p) => p);
    return parts.length ? parts.join(" · ") : null;
  }
  get judgeTemplate() {
    return this.report ? this.report.judgeTemplate : null;
  }
  get documentCount() {
    return this.report ? this.num(this.report.documentCount) : NOT_MEASURED;
  }
  get sampledRowCount() {
    // "표본 행 수" is a TABULAR concept (rows scored). The facet judge evaluates per-document facet VALUES and
    // the answer judge per-CLAIM, so neither sets Sampled_Row_Count__c — showing a bare 0 there reads as "no
    // data" when the leg simply isn't row-based. Say so instead of printing 0.
    if (this.report && (this.isFacetJudge || this.isAnswerJudge)) {
      return this.isFacetJudge
        ? "해당 없음 (패싯 값 단위 평가)"
        : "해당 없음 (답변 항목 단위 평가)";
    }
    return this.report ? this.num(this.report.sampledRowCount) : NOT_MEASURED;
  }
  get goldenFigureCount() {
    return this.report ? this.num(this.report.goldenFigureCount) : NOT_MEASURED;
  }
  get hasClusterStats() {
    return this.report && this.report.effectiveN != null;
  }
  get effectiveN() {
    return this.report ? this.num(this.report.effectiveN) : NOT_MEASURED;
  }
  get designEffect() {
    return this.report ? this.num(this.report.designEffect) : NOT_MEASURED;
  }

  // ---- Golden band -------------------------------------------------------
  get goldenPrecision() {
    return this.pct(this.report?.goldenPrecision);
  }
  get goldenRecall() {
    return this.pct(this.report?.goldenRecall);
  }
  get goldenF1() {
    return this.pct(this.report?.goldenF1);
  }
  get goldenRecallCi() {
    const lo = this.report?.goldenRecallCiLower;
    const hi = this.report?.goldenRecallCiUpper;
    return lo == null || hi == null ? null : `${lo}% – ${hi}%`;
  }
  get goldenCounts() {
    const r = this.report;
    return `일치 ${r.goldenTp} · 오탐 ${r.goldenFp} · 누락 ${r.goldenFn}`;
  }

  // ---- Invariant band ----------------------------------------------------
  get invariantPassRate() {
    return this.pct(this.report?.invariantPassRate);
  }
  get invariantChecked() {
    return this.num(this.report?.invariantChecked);
  }
  get invariantViolated() {
    return this.num(this.report?.invariantViolated);
  }
  // Detector precision: of the reviewed violations, the share judged a real error. "측정 안 됨" until a
  // human reviews at least one violation — never a fabricated 0%.
  get invariantPrecision() {
    return this.pct(this.report?.invariantPrecision);
  }
  get hasInvariantPrecisionCi() {
    return (
      this.report?.invariantPrecisionCiLower !== null &&
      this.report?.invariantPrecisionCiLower !== undefined &&
      this.report?.invariantPrecisionCiUpper !== null &&
      this.report?.invariantPrecisionCiUpper !== undefined
    );
  }
  get invariantPrecisionCi() {
    if (!this.hasInvariantPrecisionCi) {
      return "";
    }
    const lo = this.report.invariantPrecisionCiLower;
    const hi = this.report.invariantPrecisionCiUpper;
    return `94% 신뢰구간 ${lo}–${hi}%`;
  }
  // Always shown next to the precision so a high number on 2 reviewed items can't read as a corpus claim.
  get invariantReviewedLine() {
    const real = this.report?.invariantRealError ?? 0;
    const fp = this.report?.invariantFalsePositive ?? 0;
    const unreviewed = this.report?.invariantUnreviewed ?? 0;
    const reviewed = real + fp;
    return `검토 완료 ${reviewed}건 (실제 오류 ${real} · 오탐 ${fp}) · 미검토 ${unreviewed}건`;
  }

  // ---- Judge band --------------------------------------------------------
  get faithfulness() {
    return this.pct(this.report?.faithfulness);
  }
  get faithfulnessBasis() {
    const g = this.report?.faithfulnessGrounded;
    const d = this.report?.faithfulnessDenominator;
    if (d == null || d === 0) {
      return "판정 가능한 행이 없었습니다";
    }
    return `${g}/${d}행 원문 인용 확인`;
  }
  get unverifiable() {
    return this.num(this.report?.unverifiable);
  }
  get missed() {
    return this.num(this.report?.missed);
  }
  get unitsJudged() {
    return this.num(this.report?.unitsJudged);
  }
  get unitsRelevant() {
    return this.num(this.report?.unitsRelevant);
  }
  get syntheticLine() {
    const injected = this.report?.syntheticInjected;
    const caught = this.report?.syntheticCaught;
    if (injected == null || injected === 0) {
      return "합성 오류가 주입되지 않아 심판이 놓치는 결함은 측정되지 않았습니다.";
    }
    return `합성 오류 ${caught}/${injected}건 검출`;
  }
  get isValidated() {
    return this.report?.isValidated === true;
  }

  // ---- Facet / Answer judge value-verdict roll-up ------------------------
  // These come from the run's verdict CHILDREN (the run object stores only the abstract Faithfulness for
  // these legs), so the headline can report the leg's real subject — the extracted facet values / answer
  // claims — instead of only the abstract's Faithfulness. `verdictConfirmedRate` is null → "측정 안 됨"
  // when nothing was scorable, never a false 0%.
  get verdictConfirmed() {
    return this.num(this.report?.verdictConfirmed);
  }
  get verdictRefuted() {
    return this.num(this.report?.verdictRefuted);
  }
  get verdictOmitted() {
    return this.num(this.report?.verdictOmitted);
  }
  get verdictConfirmedRate() {
    return this.pct(this.report?.verdictConfirmedRate);
  }
  // The facet headline: of the extracted facet values the judge could adjudicate, the share confirmed
  // present in the source. Written next to the count so a high rate on few values can't read as a corpus claim.
  get facetConfirmedBasis() {
    const c = this.report?.verdictConfirmed ?? 0;
    const r = this.report?.verdictRefuted ?? 0;
    const o = this.report?.verdictOmitted ?? 0;
    const scorable = c + r + o;
    if (scorable === 0) {
      return "판정 가능한 패싯 값이 없었습니다";
    }
    return `원문 확인 ${c} · 허위 ${r} · 누락 ${o} (판정 대상 ${scorable})`;
  }
  // The answer headline uses the same roll-up but the leg's own words (claims, not facet values).
  get answerConfirmedBasis() {
    const c = this.report?.verdictConfirmed ?? 0;
    const r = this.report?.verdictRefuted ?? 0;
    const scorable = c + r;
    if (scorable === 0) {
      return "판정 가능한 근거·관련성 항목이 없었습니다";
    }
    return `근거·관련 확인 ${c} · 문제 ${r} (판정 대상 ${scorable})`;
  }

  // The in-screen validation button shows only for a TABULAR Judge run that is NOT yet validated — the exact
  // case that reads "심판 미검증". Gated on isTabularJudge (not the whole judge family) because handleValidate
  // calls validateJudgeRun → MI_TabularEvalJudgeValidator, which scores the tabular judge against the tabular
  // golden set; a facet judge needs MI_FacetEvalJudgeValidator instead, so this button must not offer to
  // "validate" a facet run with the wrong validator.
  get canValidate() {
    return this.isTabularJudge && !this.isValidated;
  }

  /**
   * Runs golden scoring + this run's judge-validation server-side, then refreshes the report so the "미검증"
   * banner and the validated-metrics block update in place. Replaces the run-tabular-golden-scoring.apex +
   * run-tabular-judge-validation anon-script step for the common case. Both legs are zero-callout.
   */
  async handleValidate() {
    this.isValidating = true;
    try {
      const result = await validateJudgeRun({ runId: this.recordId });
      await refreshApex(this._reportResult);
      this.dispatchEvent(
        new ShowToastEvent({
          title: result?.launched ? "검증 완료" : "검증 미측정",
          message:
            result?.message ||
            (result?.launched
              ? "심판을 골든셋 대비 검증했습니다."
              : "비교할 골든 채점 결과가 없습니다."),
          variant: result?.launched ? "success" : "warning"
        })
      );
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "검증 실패",
          message: error?.body?.message || "심판 검증을 실행하지 못했습니다.",
          variant: "error"
        })
      );
    } finally {
      this.isValidating = false;
    }
  }

  get judgePrecision() {
    return this.pct(this.report?.judgePrecision);
  }
  get judgeRecall() {
    return this.pct(this.report?.judgeRecall);
  }
  get judgeKappa() {
    return this.num(this.report?.judgeKappa);
  }
  get humanSampleSize() {
    return this.num(this.report?.humanSampleSize);
  }

  /**
   * Whether this validation is the "not compared" case — precision recorded as 0 AND recall unmeasured (null).
   * That is the signature of a judge run whose verdicts never paired to golden-confirmed rows (nothing to score
   * against), NOT a judge that scored zero. Without saying so, the bare "정밀도 0% · 재현율 측정 안 됨 · kappa 0"
   * reads as if the LLM failed completely. Gated tightly (precision === 0 AND recall == null) so a genuine, fully
   * measured low score is never explained away.
   */
  get showJudgeNotComparedNote() {
    return (
      this.report?.judgePrecision === 0 &&
      (this.report?.judgeRecall === null ||
        this.report?.judgeRecall === undefined)
    );
  }

  // ---- Retrieval band ----------------------------------------------------
  // The retrieval report covers TWO different probe types that both land here — Probe (SOQL figure lookup,
  // "맞았다" = the right numeric ROW) and Retrieval_Probe (hybrid index, "맞았다" = the right DOCUMENT). The
  // headline percentage is identical in shape but means a different thing, so the tile must name the unit or a
  // reader compares it against the wrong sibling card.
  get retrievalUnit() {
    return this.runType === "Retrieval_Probe" ? "문서" : "수치 행";
  }
  // A one-line clarifier under the headline: what "맞았다" counts here, and that the % is over the probe set —
  // so this run's number is not mistaken for the other retrieval card's (document vs figure, @1 vs any-rank).
  get retrievalUnitCaption() {
    return this.runType === "Retrieval_Probe"
      ? "하이브리드 인덱스가 의도한 문서를 상위에 가져온 프로브 비율(문서 단위). 수치 검색 카드의 Recall@1과는 대상·집계가 다릅니다."
      : "SOQL 정형 조회가 정답 수치 행을 가져온 프로브 비율(수치 행 단위). 문서 검색 카드와는 대상이 다릅니다.";
  }
  get retrievalMean() {
    return this.pct(this.report?.retrievalMean);
  }
  get retrievalCi() {
    const lo = this.report?.retrievalCiLower;
    const hi = this.report?.retrievalCiUpper;
    return lo == null || hi == null ? null : `${lo}% – ${hi}%`;
  }
  get probeCount() {
    return this.num(this.report?.probeCount);
  }
  get probeHit() {
    return this.num(this.report?.probeHit);
  }
  get recallAt1() {
    return this.pct(this.report?.recallAt1);
  }
  get recallAt5() {
    return this.pct(this.report?.recallAt5);
  }
  get recallAt10() {
    return this.pct(this.report?.recallAt10);
  }
  get mrr() {
    return this.num(this.report?.mrr);
  }
  get negativeProbePass() {
    return this.pct(this.report?.negativeProbePass);
  }

  // ---- Proposal band -----------------------------------------------------
  get proposedCandidates() {
    return this.num(this.report?.proposedCandidates);
  }

  // ---- charts ------------------------------------------------------------
  // A run-type-aware spec for the dashboard's Chart.js visual, or null when the leg has no chart / no data.
  get chartSpec() {
    if (!this.report) {
      return null;
    }
    if (this.isGolden) {
      const { goldenTp, goldenFp, goldenFn } = this.report;
      if (goldenTp + goldenFp + goldenFn === 0) {
        return null;
      }
      return {
        type: "doughnut",
        title: "골든셋 판정 분포",
        labels: ["일치", "오탐", "누락"],
        series: [{ name: "판정", values: [goldenTp, goldenFp, goldenFn] }]
      };
    }
    if (this.isInvariant) {
      const r = this.report;
      // The Sum-invariant bar is intentionally omitted: a bar the user reads as "합계" looks like a grand
      // total in a per-family chart. Its count still appears in the run's raw Inv_Sum__c field below.
      const total = r.invQuarterly + r.invYoY + r.invMagnitude + r.invConflict;
      if (total === 0) {
        return null;
      }
      return {
        type: "bar",
        title: "유형별 위반 건수",
        labels: ["분기", "YoY", "자릿수", "교차모순"],
        series: [
          {
            name: "위반",
            values: [r.invQuarterly, r.invYoY, r.invMagnitude, r.invConflict]
          }
        ]
      };
    }
    if (this.isRetrieval) {
      const r = this.report;
      if (r.recallAt1 == null && r.recallAt5 == null && r.recallAt10 == null) {
        return null;
      }
      return {
        type: "bar",
        title: "순위별 재현율 (%)",
        unit: "%",
        labels: ["@1", "@5", "@10", "3회 시도"],
        series: [
          {
            name: "재현율",
            values: [r.recallAt1, r.recallAt5, r.recallAt10, r.recall3Attempt]
          }
        ]
      };
    }
    if (this.isFacetJudge) {
      // The facet chart shows the VALUE verdicts (the leg's subject), not the small abstract Faithfulness.
      const c = this.report.verdictConfirmed ?? 0;
      const r = this.report.verdictRefuted ?? 0;
      const o = this.report.verdictOmitted ?? 0;
      const u = this.report.verdictUnverifiable ?? 0;
      if (c + r + o + u === 0) {
        return null;
      }
      return {
        type: "doughnut",
        title: "패싯 값 판정 분포",
        labels: ["확인됨", "허위", "누락", "판정 불가"],
        series: [{ name: "값", values: [c, r, o, u] }]
      };
    }
    if (this.isTabularJudge || this.isAnswerJudge) {
      const g = this.report.faithfulnessGrounded;
      const d = this.report.faithfulnessDenominator;
      if (d == null || d === 0) {
        return null;
      }
      return {
        type: "doughnut",
        title: "Faithfulness 근거",
        labels: ["원문 인용 확인", "미확인"],
        series: [{ name: "행", values: [g, Math.max(d - g, 0)] }]
      };
    }
    return null;
  }

  get hasChart() {
    return this.chartSpec != null;
  }

  // ---- drill-down --------------------------------------------------------
  get hasDocuments() {
    return this.report && this.report.documents.length > 0;
  }

  // Per-document rows decorated for display, with the leg-appropriate columns pre-formatted, a per-document
  // pass/match rate, and a resolved record-page URL when one is available.
  get documentRows() {
    if (!this.report) {
      return [];
    }
    return this.report.documents.map((doc) => {
      const matchRate =
        doc.matchRatePercent == null ? "—" : `${doc.matchRatePercent}%`;
      // Invariant pass rate per document = (checked − violated) / checked, to one decimal; dash when nothing
      // was checkable on that document (never 0%, which would read as "all failed").
      let passRate = "—";
      if (doc.invariantChecked > 0) {
        const rate =
          ((doc.invariantChecked - doc.invariantViolated) * 100) /
          doc.invariantChecked;
        passRate = `${rate.toFixed(1)}%`;
      }
      // Probe hit rate per document = hits / probes.
      let hitRate = "—";
      if (doc.probeCount > 0) {
        hitRate = `${((doc.probeHit * 100) / doc.probeCount).toFixed(1)}%`;
      }
      // All four value-comparison mismatch buckets, summed into one "불일치(오류)" figure. The table previously
      // showed only unitMismatch (Golden) or nothing (Judge), so the visible row summed to LESS than the
      // document's real verdict count (e.g. 111 일치 + 27 누락 + 1 판정불가 = 139, hiding 25 mismatch rows of the
      // true 164). Summing them makes 일치 + 불일치 + 누락 + 판정불가 reconcile to figuresScored.
      const mismatchTotal =
        (doc.unitMismatch ?? 0) +
        (doc.valueMismatch ?? 0) +
        (doc.periodMismatch ?? 0) +
        (doc.entityMismatch ?? 0) +
        (doc.otherVerdicts ?? 0);
      return {
        ...doc,
        key: doc.documentId,
        fileName: doc.fileName,
        url: this.urlByDoc[doc.documentId],
        hasUrl: !!this.urlByDoc[doc.documentId],
        matchRateLabel: matchRate,
        passRateLabel: passRate,
        hitRateLabel: hitRate,
        mismatchTotal
      };
    });
  }

  get hasPages() {
    return this.report && this.report.pages.length > 0;
  }

  // Per-page rows decorated with the verdict state's label/icon/variant.
  get pageRows() {
    if (!this.report) {
      return [];
    }
    return this.report.pages.map((page) => {
      const deco =
        PAGE_DECORATIONS[page.verdict] || PAGE_DECORATIONS.not_reviewed;
      return {
        ...page,
        key: page.page,
        rateLabel:
          page.matchRatePercent == null ? "—" : `${page.matchRatePercent}%`,
        stateLabel: deco.label,
        iconName: deco.icon,
        iconVariant: deco.variant
      };
    });
  }

  // ---- raw individual checks --------------------------------------------
  get hasChecks() {
    return this.checkList && this.checkList.checks.length > 0;
  }

  // True for the leg whose raw rows carry an arithmetic expected/actual (invariant); drives which raw-table
  // columns render.
  get isInvariantChecks() {
    return this.checkList && this.checkList.runType === "Invariant";
  }
  get isVerdictChecks() {
    return (
      this.checkList &&
      (this.checkList.runType === "Golden" ||
        this.checkList.runType === "Judge" ||
        this.checkList.runType === "Answer_Judge" ||
        this.checkList.runType === "Facet_Golden" ||
        this.checkList.runType === "Facet_Judge")
    );
  }
  get isProbeChecks() {
    return (
      this.checkList &&
      (this.checkList.runType === "Probe" ||
        this.checkList.runType === "Retrieval_Probe")
    );
  }

  // The raw check rows decorated with a defect icon so violations/mismatches/misses read at a glance.
  // A NEGATIVE probe is scored on the inverse axis (it passes by surfacing nothing), so it gets its own icon
  // and a "음성" type tag — otherwise a passing negative and a missed positive both showed ⚠️ and the table
  // read as a wall of failures (the harness bug had also forced every negative to Is_Hit__c=false).
  get checkRows() {
    if (!this.checkList) {
      return [];
    }
    return this.checkList.checks.map((c, i) => {
      const label = c.isNegative ? `${c.checkType} (음성)` : c.checkType;
      let icon = c.isViolation ? "utility:warning" : "utility:success";
      let iconVariant = c.isViolation ? "warning" : "success";
      if (c.isNegative) {
        // A negative that surfaced nothing is a PASS (success); one that surfaced a file is the real failure.
        icon = c.isViolation ? "utility:error" : "utility:check";
        iconVariant = c.isViolation ? "error" : "success";
      }
      // A verdict row whose 원문값 (Source_Value__c) and 추출값 (Stored_Value__c) are the SAME string, yet is
      // flagged a mismatch, is the matcher-failure signature: the golden row and the stored row were never
      // paired (a label drift like "매출" vs "매출액"), so Source_Value__c is the golden value echoed and the
      // extraction is very likely correct, not wrong. Flag it so the row can carry a "라벨 상이(추정)" note
      // instead of reading as a genuine value error. Only for verdict families; blanks never count as "same".
      const sameValueMismatch =
        this.isVerdictChecks &&
        c.isViolation &&
        c.expected != null &&
        c.expected !== "" &&
        c.expected === c.actual;
      return {
        ...c,
        key: c.recordId || `check-${i}`,
        deltaLabel: c.relativeDelta == null ? "—" : `${c.relativeDelta}%`,
        typeLabel: sameValueMismatch ? `${label} · 라벨 상이(추정)` : label,
        sameValueMismatch,
        icon,
        iconVariant
      };
    });
  }

  // Whether any listed verdict row is a same-value mismatch (원문값==추출값), so the table can show the
  // matcher-drift caveat legend only when it is relevant.
  get hasSameValueMismatch() {
    return this.checkRows.some((r) => r.sameValueMismatch);
  }

  // Whether the raw list was capped, and by how much, so a truncated table never reads as the whole set.
  get hasOmittedChecks() {
    return this.checkList && this.checkList.omittedCount > 0;
  }
  get omittedChecksLabel() {
    return this.checkList ? `${this.checkList.omittedCount}` : "0";
  }

  // The child object each raw row points at, by run family — so a row click opens the right record page.
  // The three families write to three different child objects; the run type tells them apart.
  get checkObjectApiName() {
    if (this.isVerdictChecks) {
      return "MI_Tabular_Eval_Verdict__c";
    }
    if (this.isProbeChecks) {
      return "MI_Tabular_Eval_Probe__c";
    }
    // Invariant is the default (and the only family that lands here otherwise).
    return "MI_Tabular_Eval_Invariant__c";
  }

  /**
   * Opens the underlying check record when its row is clicked (or activated by keyboard). Each raw row is one
   * child record (invariant / verdict / probe); the reviewer wants to jump to it to confirm against the
   * source. The record Id rides on the row's data attribute, and objectApiName is passed explicitly for
   * robustness even though the Id prefix would resolve it.
   *
   * @param {Event} event The click/keydown event from the row
   */
  handleCheckRowClick(event) {
    const recordId = event.currentTarget.dataset.recordId;
    if (!recordId) {
      return;
    }
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId,
        objectApiName: this.checkObjectApiName,
        actionName: "view"
      }
    });
  }

  /**
   * Keyboard activation of a check row (Enter or Space), so the row is reachable without a mouse.
   *
   * @param {KeyboardEvent} event The keydown event
   */
  handleCheckRowKeydown(event) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      this.handleCheckRowClick(event);
    }
  }
}
