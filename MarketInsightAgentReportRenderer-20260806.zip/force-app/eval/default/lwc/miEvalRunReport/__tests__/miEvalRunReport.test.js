import { createElement } from "lwc";
import MiEvalRunReport from "c/miEvalRunReport";
import getRunReport from "@salesforce/apex/MI_EvalRunReportController.getRunReport";
import getRunChecks from "@salesforce/apex/MI_EvalRunReportController.getRunChecks";
import validateJudgeRun from "@salesforce/apex/MI_QualityRunController.validateJudgeRun";

// The validation button calls this imperatively (not wired), so it is a plain jest.fn resolving a LaunchResult.
jest.mock(
  "@salesforce/apex/MI_QualityRunController.validateJudgeRun",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

// refreshApex is a no-op in the test; the component awaits it after the imperative call succeeds.
jest.mock(
  "@salesforce/apex",
  () => ({ refreshApex: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

// Both are WIRED Apex methods, so each needs a wire-adapter stub (emit/error), not the plain
// { default: jest.fn() } an imperative call would use. Same pattern as miDocumentTabularAccuracy.test.js.
jest.mock(
  "@salesforce/apex/MI_EvalRunReportController.getRunReport",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

jest.mock(
  "@salesforce/apex/MI_EvalRunReportController.getRunChecks",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// The component extends NavigationMixin and calls [GenerateUrl] to turn each document Id into a record-page
// link. GenerateUrl must resolve a Promise for resolveDocumentUrls() to store a URL; the mock returns a
// deterministic per-record URL so the link assertions are stable.
jest.mock("lightning/navigation", () => {
  const GenerateUrl = Symbol("GenerateUrl");
  const Navigate = Symbol("Navigate");
  // The component's [Navigate] runs on its internal instance, unreachable from the host element the test
  // holds — so forward it to a jest.fn exposed on the mock (the miQualityAppHome pattern).
  const navigateMock = jest.fn();
  const NavigationMixin = (Base) =>
    class extends Base {
      [GenerateUrl](config) {
        return Promise.resolve(`/r/${config.attributes.recordId}/view`);
      }
      [Navigate](...args) {
        navigateMock(...args);
      }
    };
  NavigationMixin.GenerateUrl = GenerateUrl;
  NavigationMixin.Navigate = Navigate;
  NavigationMixin.__navigateMock = navigateMock;
  return { NavigationMixin };
});

const { NavigationMixin: NavMock } = require("lightning/navigation");

const RECORD_ID = "a4J000000000001AAA";

const BASE = {
  found: true,
  runId: RECORD_ID,
  runLabel: "test run",
  statusLabel: "Complete",
  runType: "Golden",
  documentCount: 1,
  sampledRowCount: 1375,
  coveredFormats: "pdf",
  coveredRoutes: "PDF",
  coveredDocumentTypes: null,
  coverageNote: null,
  powerNote: null,
  judgeTemplate: null,
  goldenFigureCount: 1375,
  effectiveN: null,
  designEffect: null,
  goldenPrecision: 92.7,
  goldenRecall: 48.1,
  goldenF1: 63.3,
  goldenRecallCiLower: 43.8,
  goldenRecallCiUpper: 48.9,
  goldenTp: 637,
  goldenFp: 50,
  goldenFn: 688,
  unverifiable: 653,
  documents: [],
  pages: []
};

function createComponent() {
  const element = createElement("c-mi-eval-run-report", {
    is: MiEvalRunReport
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

function cardTitle(element) {
  const card = element.shadowRoot.querySelector("lightning-card");
  return card ? card.title : "";
}

async function emit(report) {
  getRunReport.emit(report);
  await Promise.resolve();
}

describe("c-mi-eval-run-report", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders Golden headline metrics and the scope caveat", async () => {
    const element = createComponent();
    await emit(BASE);

    const text = element.shadowRoot.textContent;
    expect(cardTitle(element)).toContain("골든셋 정확도");
    expect(text).toContain("92.7%");
    expect(text).toContain("48.1%");
    expect(text).toContain("43.8% – 48.9%");
    expect(text).toContain("정답셋이 커버한 페이지에 한한 결과");
  });

  it("renders the run-type-aware chart for a Golden run with verdict counts", async () => {
    const element = createComponent();
    await emit(BASE);

    // The doughnut spec is non-null when TP+FP+FN > 0, so the chart child is rendered.
    expect(
      element.shadowRoot.querySelector("c-mi-eval-run-chart")
    ).not.toBeNull();
  });

  it("shows the invariant pass-rate caveat, not an accuracy claim", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Invariant",
      goldenPrecision: null,
      goldenRecall: null,
      invariantPassRate: 98.7,
      invariantChecked: 300,
      invariantViolated: 4,
      invSum: 1,
      invQuarterly: 0,
      invYoY: 3,
      invMagnitude: 0,
      invConflict: 0
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("98.7%");
    expect(text).toContain("통과율은 정확도가 아니라");
  });

  it("shows detector precision with its interval and reviewed remainder, and the recall caveat", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Invariant",
      goldenPrecision: null,
      goldenRecall: null,
      invariantPassRate: 50.0,
      invariantChecked: 100,
      invariantViolated: 4,
      invariantPrecision: 75.0,
      invariantPrecisionCiLower: 30.1,
      invariantPrecisionCiUpper: 95.4,
      invariantRealError: 3,
      invariantFalsePositive: 1,
      invariantUnreviewed: 2
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("탐지기 정밀도");
    expect(text).toContain("75%");
    expect(text).toContain("94% 신뢰구간 30.1–95.4%");
    // The reviewed/unreviewed remainder line.
    expect(text).toContain("검토 완료 4건");
    expect(text).toContain("미검토 2건");
    // The load-bearing caveat: recall is not knowable here, it belongs to the golden set.
    expect(text).toContain("재현율");
    expect(text).toContain("골든셋");
  });

  it("shows precision as 측정 안 됨 when no violation has been reviewed", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Invariant",
      goldenPrecision: null,
      goldenRecall: null,
      invariantPassRate: 50.0,
      invariantChecked: 100,
      invariantViolated: 4,
      invariantPrecision: null,
      invariantPrecisionCiLower: null,
      invariantPrecisionCiUpper: null,
      invariantRealError: 0,
      invariantFalsePositive: 0,
      invariantUnreviewed: 4
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("탐지기 정밀도");
    expect(text).toContain("측정 안 됨");
    // No fabricated 0% and no interval string when unmeasured.
    expect(text).not.toContain("94% 신뢰구간");
    expect(text).toContain("검토 완료 0건");
    expect(text).toContain("미검토 4건");
  });

  it("renders Faithfulness with its denominator and leads with the Power_Note caveat", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      goldenPrecision: null,
      goldenRecall: null,
      faithfulness: 88.0,
      faithfulnessGrounded: 44,
      faithfulnessDenominator: 50,
      missed: 3,
      syntheticInjected: 8,
      syntheticCaught: 6,
      isValidated: false,
      powerNote: "심판 미검증 — 고객에게 제시할 수 없습니다."
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("88%");
    expect(text).toContain("44/50행");
    expect(text).toContain("고객에게 제시할 수 없습니다");
  });

  it("hides the validation sub-block until the judge run is validated", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      faithfulness: 88.0,
      faithfulnessGrounded: 44,
      faithfulnessDenominator: 50,
      isValidated: false
    });

    expect(element.shadowRoot.textContent).not.toContain("심판 검증");
  });

  it("shows the validation sub-block once the judge run is validated", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      faithfulness: 88.0,
      faithfulnessGrounded: 44,
      faithfulnessDenominator: 50,
      isValidated: true,
      judgePrecision: 91.0,
      judgeRecall: 64.0,
      judgeKappa: 0.78,
      humanSampleSize: 50
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("심판 검증");
    expect(text).toContain("91%");
    expect(text).toContain("0.78");
  });

  it("renders retrieval recall@k and the ranking caveat", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Retrieval_Probe",
      goldenPrecision: null,
      goldenRecall: null,
      retrievalMean: 82.0,
      retrievalCiLower: 75.0,
      retrievalCiUpper: 88.0,
      probeCount: 40,
      probeHit: 33,
      recallAt1: 60.0,
      recallAt5: 80.0,
      recallAt10: 90.0,
      recall3Attempt: 95.0,
      mrr: 0.712,
      negativeProbePass: 100.0
    });

    const text = element.shadowRoot.textContent;
    expect(cardTitle(element)).toContain("검색 정확도");
    expect(text).toContain("82%");
    expect(text).toContain("순위를 함께 보세요");
  });

  it("states a proposal run measured no accuracy", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Golden_Proposal",
      goldenPrecision: null,
      goldenRecall: null,
      proposedCandidates: 210
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("생성된 후보");
    expect(text).toContain("210");
    expect(text).toContain("정확도를 측정하지 않았습니다");
  });

  it("prints 측정 안 됨 for a null rate instead of 0%", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      statusLabel: "Running",
      goldenPrecision: null,
      goldenRecall: null,
      goldenF1: null,
      goldenRecallCiLower: null,
      goldenRecallCiUpper: null
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("측정 안 됨");
    expect(text).not.toContain("0.0%");
  });

  it("renders the per-document drill-down table with a link to each document", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      documents: [
        {
          documentId: "a0X000000000001",
          fileName: "quarterly.pdf",
          documentType: "증권사보고서",
          matched: 5,
          missed: 2,
          unitMismatch: 1,
          matchRatePercent: 62.5
        }
      ]
    });
    // GenerateUrl resolves asynchronously in resolveDocumentUrls, so let its Promise settle and re-render.
    await Promise.resolve();
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    expect(text).toContain("문서별 상세");
    expect(text).toContain("quarterly.pdf");
    expect(text).toContain("62.5%");
    // The document name is a real anchor pointing at the resolved record-page URL.
    const link = element.shadowRoot.querySelector("tbody a");
    expect(link).not.toBeNull();
    expect(link.href).toContain("/r/a0X000000000001/view");
  });

  it("shows a per-document pass rate and the check-count explanation for an invariant run", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Invariant",
      goldenPrecision: null,
      goldenRecall: null,
      invariantPassRate: 50.6,
      invariantChecked: 263,
      invariantViolated: 130,
      invSum: 48,
      invQuarterly: 11,
      invYoY: 29,
      invMagnitude: 13,
      invConflict: 29,
      documents: [
        {
          documentId: "a0X000000000002",
          fileName: "sony.pdf",
          documentType: null,
          invariantChecked: 185,
          invariantViolated: 87
        }
      ]
    });
    await Promise.resolve();
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    // Per-document pass rate = (185 − 87) / 185 = 52.97 → 53.0%.
    expect(text).toContain("53.0%");
    // The explanation for why the check count is far below the sampled-row count must be present.
    expect(text).toContain("대조 가능한 산술 관계");
  });

  it("renders the per-page breakdown for a single-document golden run", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      pages: [
        {
          page: "10",
          goldenFigures: 2,
          matched: 1,
          missed: 1,
          matchRatePercent: 50.0,
          verdict: "partial"
        }
      ]
    });

    const text = element.shadowRoot.querySelector("tbody").textContent;
    expect(element.shadowRoot.textContent).toContain("페이지별");
    expect(text).toContain("p.10");
    expect(text).toContain("부분 일치");
  });

  it("reports the failure reason instead of an empty card", async () => {
    const element = createComponent();
    getRunReport.error({ message: "FLS 오류" });
    await Promise.resolve();

    expect(element.shadowRoot.textContent).toContain("FLS 오류");
  });

  it("lists the raw checks labelled by source (원문 값 / 검산 기대값), source value first", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Invariant" });
    getRunChecks.emit({
      runType: "Invariant",
      omittedCount: 0,
      checks: [
        {
          recordId: "a40000000000001",
          checkType: "Sum",
          isViolation: true,
          expected: "100", // the check-computed value
          actual: "152.5", // the source-stored value
          relativeDelta: 52.5,
          sourcePage: "10",
          detail: "Sum of 3 segments vs the total row."
        }
      ]
    });
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    expect(text).toContain("실제 검사 레코드");
    // Source-based headers, not the confusing 기대값/실제값.
    expect(text).toContain("원문 값");
    expect(text).toContain("검산 기대값");
    expect(text).not.toContain("실제값");
    expect(text).toContain("152.5");
    expect(text).toContain("52.5%");

    // The source value (원문 값 = actual) must render in the column BEFORE the computed value (검산 기대값 =
    // expected) — assert the cell order directly.
    const rows = element.shadowRoot.querySelectorAll("tbody tr");
    const cells = rows[0].querySelectorAll("td");
    // cells: [icon, checkType, 원문 값, 검산 기대값, 차이, 페이지, 설명]
    expect(cells[2].textContent).toContain("152.5"); // source first
    expect(cells[3].textContent).toContain("100"); // computed second
  });

  it("opens the underlying check record when a raw row is clicked", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Invariant" });
    getRunChecks.emit({
      runType: "Invariant",
      omittedCount: 0,
      checks: [
        {
          recordId: "a4Gxx0000000001",
          checkType: "Sum",
          isViolation: true,
          expected: "100",
          actual: "152.5",
          relativeDelta: 52.5,
          sourcePage: "10",
          detail: "Sum of 3 segments vs the total row."
        }
      ]
    });
    await Promise.resolve();

    const row = element.shadowRoot.querySelector("tbody tr.clickable-row");
    expect(row).not.toBeNull();
    row.click();

    expect(NavMock.__navigateMock).toHaveBeenCalledTimes(1);
    expect(NavMock.__navigateMock).toHaveBeenCalledWith(
      expect.objectContaining({
        type: "standard__recordPage",
        attributes: expect.objectContaining({
          recordId: "a4Gxx0000000001",
          objectApiName: "MI_Tabular_Eval_Invariant__c",
          actionName: "view"
        })
      })
    );
  });

  it("navigates to the verdict object for a Golden run's raw rows", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Golden" });
    getRunChecks.emit({
      runType: "Golden",
      omittedCount: 0,
      checks: [
        {
          recordId: "a4Vxx0000000001",
          checkType: "Value_Mismatch",
          isViolation: true,
          entity: "Sony",
          metric: "sales",
          period: "FY2025",
          expected: "100",
          actual: "110",
          sourcePage: "5"
        }
      ]
    });
    await Promise.resolve();

    element.shadowRoot.querySelector("tbody tr.clickable-row").click();
    expect(NavMock.__navigateMock).toHaveBeenCalledWith(
      expect.objectContaining({
        attributes: expect.objectContaining({
          recordId: "a4Vxx0000000001",
          objectApiName: "MI_Tabular_Eval_Verdict__c"
        })
      })
    );
  });

  it("says how many checks were omitted when the raw list is capped", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Invariant" });
    getRunChecks.emit({
      runType: "Invariant",
      omittedCount: 63,
      checks: [
        {
          recordId: "a40000000000002",
          checkType: "YoY",
          isViolation: true,
          expected: "10",
          actual: "12",
          relativeDelta: 20.0
        }
      ]
    });
    await Promise.resolve();

    // A truncated list must never read as the whole set.
    expect(element.shadowRoot.textContent).toContain("63건은 생략");
  });

  it("shows the validation button for an unvalidated Judge run", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      goldenPrecision: null,
      isValidated: false,
      powerNote: "심판 미검증 — 고객 제시 불가"
    });

    const button = element.shadowRoot.querySelector("lightning-button");
    expect(button).not.toBeNull();
    expect(button.label).toBe("이 실행 검증하기");
  });

  it("hides the validation button once the Judge run is validated", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      isValidated: true,
      judgePrecision: 90.0
    });

    expect(element.shadowRoot.querySelector("lightning-button")).toBeNull();
  });

  it("calls validateJudgeRun with the record Id when the button is clicked", async () => {
    validateJudgeRun.mockResolvedValue({
      launched: true,
      message: "검증 완료"
    });
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      goldenPrecision: null,
      isValidated: false,
      powerNote: "심판 미검증 — 고객 제시 불가"
    });

    element.shadowRoot.querySelector("lightning-button").click();
    await Promise.resolve();

    expect(validateJudgeRun).toHaveBeenCalledWith({ runId: RECORD_ID });
  });

  it("labels a negative probe distinctly in the raw checks table", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Retrieval_Probe" });
    getRunChecks.emit({
      runType: "Retrieval_Probe",
      omittedCount: 0,
      checks: [
        {
          recordId: "a4V0000000000n1",
          checkType: "Doc_Negative",
          isNegative: true,
          isViolation: false,
          isHit: true,
          question: "Zorblax 시장 동향",
          hitRank: 0
        }
      ]
    });
    await Promise.resolve();

    // A passing negative must be tagged "음성", not rendered identically to a positive probe.
    expect(element.shadowRoot.textContent).toContain("음성");
  });

  it("caveats the judge's 누락 as an unmatched self-report, pointing to golden FN", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      goldenPrecision: null,
      goldenRecall: null,
      faithfulness: 100.0,
      faithfulnessGrounded: 27,
      faithfulnessDenominator: 27,
      missed: 27,
      isValidated: false
    });

    const text = element.shadowRoot.textContent;
    // The judge's 누락 count is a matcher-less self-report (an upper bound), so the tile must say so and point
    // the reader to the golden run's FN for the authoritative completeness number.
    expect(text).toContain("심판의 자기보고");
    expect(text).toContain("골든 채점의 누락");
  });

  it("sums all four mismatch buckets in the per-document 불일치 column so the row reconciles to its total", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      goldenPrecision: null,
      goldenRecall: null,
      documents: [
        {
          documentId: "a0X000000000009",
          fileName: "sony.pdf",
          documentType: "공시자료",
          matched: 111,
          missed: 27,
          unverifiable: 1,
          unitMismatch: 6,
          valueMismatch: 11,
          periodMismatch: 4,
          entityMismatch: 4,
          otherVerdicts: 0
        }
      ]
    });
    await Promise.resolve();
    await Promise.resolve();

    // The 불일치(오류) column must show 6+11+4+4 = 25, not just unitMismatch(6) — so 111+25+27+1 = 164 reconciles
    // to the document's full verdict count instead of the old visible 139.
    const cells = Array.from(
      element.shadowRoot.querySelectorAll("tbody td div")
    ).map((d) => d.textContent.trim());
    expect(cells).toContain("25");
    expect(element.shadowRoot.textContent).toContain("불일치(오류)");
  });

  it("explains that precision 0% + unmeasured recall + kappa 0 is 'not compared', not a zero score", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Judge",
      isValidated: true,
      judgePrecision: 0,
      judgeRecall: null,
      judgeKappa: 0,
      humanSampleSize: 16
    });

    const text = element.shadowRoot.textContent;
    // The note must reframe the bare zeros as an uncomputable comparison, and define kappa so it doesn't read
    // as "the AI is completely wrong".
    expect(text).toContain("심판이 틀렸다는 뜻이 아닙니다");
    expect(text).toContain("계산할 수 없었던");
    expect(text).toContain("Cohen's kappa");
  });

  it("flags a same-value verdict mismatch as a label-drift (matcher) failure, not a wrong figure", async () => {
    const element = createComponent();
    await emit({ ...BASE, runType: "Golden" });
    getRunChecks.emit({
      runType: "Golden",
      omittedCount: 0,
      checks: [
        {
          recordId: "a4Vxx0000000abc",
          checkType: "Not_In_Source",
          isViolation: true,
          entity: "Samsung",
          metric: "sales",
          period: "FY2025-Q3",
          // 원문값 == 추출값: the golden and stored rows were never paired (label drift), so Source_Value__c is
          // the golden echo and the extraction is very likely correct — not a genuine value error.
          expected: "100",
          actual: "100",
          sourcePage: "10"
        }
      ]
    });
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    // The row is tagged as a probable label mismatch, and the caveat legend explains the same-value signature.
    expect(text).toContain("라벨 상이(추정)");
    expect(text).toContain("원문값과 추출값이 같은데도");
  });

  it("renders a Facet_Judge run's Present values as 확인됨 (correct), NOT as 불일치(오류)", async () => {
    // The reported screen: Faithfulness 100% next to a table that used to read 일치 0 / 불일치 80. The redesign
    // shows the facet VALUE verdicts (확인됨) with their own confirmation rate, kept apart from the abstract.
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Facet_Judge",
      goldenPrecision: null,
      goldenRecall: null,
      faithfulness: 100.0,
      faithfulnessGrounded: 5,
      faithfulnessDenominator: 5,
      verdictConfirmed: 80,
      verdictRefuted: 3,
      verdictOmitted: 44,
      verdictUnverifiable: 12,
      verdictConfirmedRate: 63.0,
      documents: [
        {
          documentId: "a0X00000000000F",
          fileName: "2025-Q2_Semicon.pdf",
          documentType: "공시자료",
          confirmed: 80,
          refuted: 3,
          omitted: 44,
          unverifiable: 12,
          matchRatePercent: 63.0,
          matched: 0
        }
      ]
    });
    await Promise.resolve();
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    // The headline is the facet value confirmation rate, and the "different axes" explainer is present.
    expect(text).toContain("패싯 값 확인율");
    expect(text).toContain("확인됨");
    expect(text).toContain("오류가 아닙니다");
    // The abstract Faithfulness still shows, framed as a separate axis — not summed into the value table.
    expect(text).toContain("요약 Faithfulness");
    // The per-document table shows the confirmed count as a real cell, not a 0% match rate.
    const cells = Array.from(
      element.shadowRoot.querySelectorAll("tbody td div")
    ).map((d) => d.textContent.trim());
    expect(cells).toContain("80");
    expect(cells).toContain("63%");
  });

  it("does not offer the (tabular) validation button on a Facet_Judge run", async () => {
    // handleValidate runs MI_TabularEvalJudgeValidator; a facet run needs the facet validator, so the inline
    // button must not appear for it.
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Facet_Judge",
      faithfulness: 100.0,
      faithfulnessGrounded: 5,
      faithfulnessDenominator: 5,
      isValidated: false,
      verdictConfirmed: 80,
      verdictConfirmedRate: 63.0
    });

    const button = element.shadowRoot.querySelector("lightning-button");
    const label = button ? button.label : "";
    expect(label).not.toBe("이 실행 검증하기");
  });

  it("renders an Answer_Judge run's Grounded/Relevant as 근거·관련 (correct), not errors", async () => {
    const element = createComponent();
    await emit({
      ...BASE,
      runType: "Answer_Judge",
      goldenPrecision: null,
      goldenRecall: null,
      faithfulness: 90.0,
      faithfulnessGrounded: 9,
      faithfulnessDenominator: 10,
      unitsJudged: 6,
      unitsRelevant: 4,
      verdictConfirmed: 13,
      verdictRefuted: 3,
      verdictUnverifiable: 0,
      verdictConfirmedRate: 81.3,
      documents: [
        {
          documentId: "a0X00000000000G",
          fileName: "answer.pdf",
          documentType: "보고서",
          confirmed: 13,
          refuted: 3,
          unverifiable: 0,
          matchRatePercent: 81.3,
          matched: 0
        }
      ]
    });
    await Promise.resolve();
    await Promise.resolve();

    const text = element.shadowRoot.textContent;
    expect(text).toContain("근거·관련");
    expect(text).toContain("오류가 아닙니다");
    const cells = Array.from(
      element.shadowRoot.querySelectorAll("tbody td div")
    ).map((d) => d.textContent.trim());
    expect(cells).toContain("13");
  });
});
