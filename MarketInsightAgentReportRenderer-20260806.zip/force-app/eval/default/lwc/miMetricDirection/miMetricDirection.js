import { LightningElement, api } from "lwc";

/**
 * A tiny, shared "higher is better / lower is better" indicator that rides next to a metric value or column
 * header across the Market Insight Quality app. Every eval number carries a direction — a reviewer must not
 * have to guess whether 27 누락 or kappa 0 is good or bad — and the wording MUST be identical everywhere, so
 * it lives in one component (used by miQualityAppHome and miEvalRunReport) rather than hand-typed per tile.
 *
 * `direction`:
 *   - "higher"  → 높을수록 좋음 (precision, recall, F1, Recall@k, MRR, Faithfulness, 통과율, 탐지기 정밀도,
 *                  합성 민감도, kappa)
 *   - "lower"   → 낮을수록 좋음 (위반/모순 건수, 누락, 불일치(오류) 등 결함 개수)
 *   - "neutral" → 값 자체로 판단 (판정 불가 같은 유보 — 많다고 나쁘거나 좋다고 할 수 없음)
 * Any unknown value degrades to neutral rather than throwing.
 */
export default class MiMetricDirection extends LightningElement {
  /** One of "higher" | "lower" | "neutral". */
  @api direction = "neutral";

  get isHigher() {
    return this.direction === "higher";
  }

  get isLower() {
    return this.direction === "lower";
  }

  get isNeutral() {
    return !this.isHigher && !this.isLower;
  }

  /** The arrow/dash glyph shown before the text. */
  get glyph() {
    if (this.isHigher) {
      return "▲";
    }
    if (this.isLower) {
      return "▼";
    }
    return "—";
  }

  /** The plain-Korean direction phrase. */
  get text() {
    if (this.isHigher) {
      return "높을수록 좋음";
    }
    if (this.isLower) {
      return "낮을수록 좋음";
    }
    return "값 자체로 판단 (좋고 나쁨 없음)";
  }

  /** Colour class per direction, so the hint reads at a glance without shouting. */
  get cssClass() {
    if (this.isHigher) {
      return "dir dir_higher";
    }
    if (this.isLower) {
      return "dir dir_lower";
    }
    return "dir dir_neutral";
  }
}
