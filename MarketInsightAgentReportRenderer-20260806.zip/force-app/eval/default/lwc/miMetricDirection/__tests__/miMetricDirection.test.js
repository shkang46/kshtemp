import { createElement } from "lwc";
import MiMetricDirection from "c/miMetricDirection";

function create(direction) {
  const element = createElement("c-mi-metric-direction", {
    is: MiMetricDirection
  });
  if (direction !== undefined) {
    element.direction = direction;
  }
  document.body.appendChild(element);
  return element;
}

describe("c-mi-metric-direction", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
  });

  it("shows 높을수록 좋음 with an up glyph for higher", () => {
    const el = create("higher");
    const text = el.shadowRoot.textContent;
    expect(text).toContain("높을수록 좋음");
    expect(text).toContain("▲");
    expect(el.shadowRoot.querySelector(".dir_higher")).not.toBeNull();
  });

  it("shows 낮을수록 좋음 with a down glyph for lower", () => {
    const el = create("lower");
    const text = el.shadowRoot.textContent;
    expect(text).toContain("낮을수록 좋음");
    expect(text).toContain("▼");
    expect(el.shadowRoot.querySelector(".dir_lower")).not.toBeNull();
  });

  it("shows the value-judgement phrase for neutral", () => {
    const el = create("neutral");
    expect(el.shadowRoot.textContent).toContain("값 자체로 판단");
    expect(el.shadowRoot.querySelector(".dir_neutral")).not.toBeNull();
  });

  it("degrades an unknown/absent direction to neutral rather than throwing", () => {
    const el = create(); // default "neutral"
    expect(el.shadowRoot.querySelector(".dir_neutral")).not.toBeNull();
    const el2 = create("bogus");
    expect(el2.shadowRoot.querySelector(".dir_neutral")).not.toBeNull();
  });
});
