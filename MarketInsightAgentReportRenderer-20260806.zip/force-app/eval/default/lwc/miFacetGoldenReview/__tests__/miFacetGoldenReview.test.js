import { createElement } from "lwc";
import MiFacetGoldenReview from "c/miFacetGoldenReview";
import { getRecord } from "lightning/uiRecordApi";
import confirmProposal from "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal";
import deleteValue from "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue";
import LightningConfirm from "lightning/confirm";

// The two writes are IMPERATIVE → plain jest.fn. getRecord is auto-mocked by sfdx-lwc-jest as an LDS wire.
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

const RECORD_ID = "a4J000000000001AAA";
const DOCUMENT_ID = "a36000000000001AAA";

// Shapes a getRecord payload for one MI_Facet_Golden__c row with the given field values.
function recordPayload({
  facetField = "Facet_Companies_Mentioned__c",
  valueText = "NXP Semiconductors",
  provenance = "LLM_Proposed",
  sourceSnippet = "NXP 15%",
  note = "LLM 제안 — 사람 승인 전입니다.",
  document = DOCUMENT_ID,
  verifiedByName = null,
  verifiedDate = null
} = {}) {
  return {
    id: RECORD_ID,
    apiName: "MI_Facet_Golden__c",
    fields: {
      Facet_Field__c: { value: facetField },
      Value_Text__c: { value: valueText },
      Provenance__c: { value: provenance },
      Source_Snippet__c: { value: sourceSnippet },
      Note__c: { value: note },
      Market_Insight_Document__c: { value: document },
      Verified_By__c: { value: null, displayValue: verifiedByName },
      Verified_Date__c: { value: verifiedDate }
    }
  };
}

function createComponent() {
  const element = createElement("c-mi-facet-golden-review", {
    is: MiFacetGoldenReview
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(payload) {
  getRecord.emit(payload);
  await Promise.resolve();
}

async function flushPromises() {
  for (let i = 0; i < 4; i++) {
    // eslint-disable-next-line no-await-in-loop
    await Promise.resolve();
  }
}

function findButton(element, labelFragment) {
  return Array.from(
    element.shadowRoot.querySelectorAll("lightning-button")
  ).find((b) => b.label && b.label.includes(labelFragment));
}

// lightning-formatted-text is auto-stubbed under Jest and does NOT render its `value` into textContent, so
// content passed through it (source snippet, verified-by name) is read from the element's `value` prop.
function formattedTextValues(element) {
  return Array.from(
    element.shadowRoot.querySelectorAll("lightning-formatted-text")
  ).map((n) => n.value);
}

describe("c-mi-facet-golden-review", () => {
  beforeEach(() => {
    confirmProposal.mockResolvedValue(undefined);
    deleteValue.mockResolvedValue(undefined);
    LightningConfirm.open = jest.fn(() => Promise.resolve(true));
  });

  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("shows the facet value, source snippet and a friendly facet-field label", async () => {
    const element = createComponent();
    await emit(recordPayload());

    const text = element.shadowRoot.textContent;
    expect(text).toContain("NXP Semiconductors"); // the value
    expect(text).toContain("언급된 회사"); // friendly label for Facet_Companies_Mentioned__c
    expect(text).toContain("원문 인용 (근거)");
    // The snippet renders through lightning-formatted-text (stubbed), so read it off the element's value.
    expect(formattedTextValues(element)).toContain("NXP 15%");
  });

  it("offers 승인/삭제 buttons for an LLM-proposed row with the decision explained", async () => {
    const element = createComponent();
    await emit(recordPayload({ provenance: "LLM_Proposed" }));

    expect(findButton(element, "승인")).toBeTruthy();
    expect(findButton(element, "삭제")).toBeTruthy();
    expect(element.shadowRoot.textContent).toContain(
      "승인 전까지는 채점 기준(정답)으로 쓰이지 않습니다"
    );
  });

  it("shows NO decision buttons for a human-confirmed row, only its status", async () => {
    const element = createComponent();
    await emit(
      recordPayload({
        provenance: "Human",
        note: null,
        verifiedByName: "SUNGEON PARK",
        verifiedDate: "2026-08-04T04:44:00.000Z"
      })
    );

    expect(findButton(element, "승인")).toBeFalsy();
    expect(findButton(element, "삭제")).toBeFalsy();
    expect(element.shadowRoot.textContent).toContain(
      "사람이 직접 입력한 확정 정답"
    );
    // The verifier name renders through lightning-formatted-text (stubbed), so read it off the value.
    expect(formattedTextValues(element)).toContain("SUNGEON PARK");
  });

  it("confirms the proposal through the controller after the dialog", async () => {
    const element = createComponent();
    await emit(recordPayload({ provenance: "LLM_Proposed" }));

    findButton(element, "승인").dispatchEvent(new CustomEvent("click"));
    await flushPromises();

    expect(LightningConfirm.open).toHaveBeenCalledTimes(1);
    expect(confirmProposal).toHaveBeenCalledWith({ goldenId: RECORD_ID });
  });

  it("deletes the candidate through the controller after the destructive dialog", async () => {
    const element = createComponent();
    await emit(recordPayload({ provenance: "LLM_Proposed" }));

    findButton(element, "삭제").dispatchEvent(new CustomEvent("click"));
    await flushPromises();

    expect(LightningConfirm.open).toHaveBeenCalledTimes(1);
    expect(deleteValue).toHaveBeenCalledWith({ goldenId: RECORD_ID });
  });

  it("notes when there is no source snippet so the reviewer opens the original", async () => {
    const element = createComponent();
    await emit(recordPayload({ sourceSnippet: null }));

    expect(element.shadowRoot.textContent).toContain("원문 인용이 없습니다");
  });
});
