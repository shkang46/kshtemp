import { LightningElement, api, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { getRecord, getRecordNotifyChange } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import LightningConfirm from "lightning/confirm";
import confirmProposal from "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal";
import deleteValue from "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue";
import FACET_FIELD from "@salesforce/schema/MI_Facet_Golden__c.Facet_Field__c";
import VALUE_TEXT from "@salesforce/schema/MI_Facet_Golden__c.Value_Text__c";
import PROVENANCE from "@salesforce/schema/MI_Facet_Golden__c.Provenance__c";
import SOURCE_SNIPPET from "@salesforce/schema/MI_Facet_Golden__c.Source_Snippet__c";
import NOTE from "@salesforce/schema/MI_Facet_Golden__c.Note__c";
import DOCUMENT from "@salesforce/schema/MI_Facet_Golden__c.Market_Insight_Document__c";
import VERIFIED_BY from "@salesforce/schema/MI_Facet_Golden__c.Verified_By__c";
import VERIFIED_DATE from "@salesforce/schema/MI_Facet_Golden__c.Verified_Date__c";

/**
 * The review card for ONE MI_Facet_Golden__c record, shown on that object's record page. The object had no
 * FlexiPage, so its record page fell back to a bare layout (Name / Owner / Currency) that showed none of the
 * facet content — a reviewer landing there could not tell what the row asserts, where it came from, or what
 * to do with it. The sibling `miFacetGoldenCapture` reviews ALL of a document's golden rows side-by-side on
 * the DOCUMENT page; this component is the single-row counterpart for when someone opens one golden record
 * directly (e.g. from the "Pending_LLM_Proposals" list view).
 *
 * It answers the three questions the blank page could not: (1) WHAT this row asserts — the facet field + value;
 * (2) WHERE it came from — the verbatim source snippet + its provenance grade; (3) WHAT to do — for an
 * LLM-proposed row, 승인 (promote to a confirmed golden answer) or 삭제 (discard the candidate), each with an
 * explicit description of its consequence. A Human/confirmed row shows its verified-by/date instead of the
 * decision buttons, because there is nothing to decide.
 *
 * Fields are read with getRecord (no Apex change); the two actions reuse the existing
 * MI_FacetGoldenCaptureController.confirmProposal / deleteValue, which the document-page card already uses.
 */
const FIELDS = [
  FACET_FIELD,
  VALUE_TEXT,
  PROVENANCE,
  SOURCE_SNIPPET,
  NOTE,
  DOCUMENT,
  VERIFIED_BY,
  VERIFIED_DATE
];

export default class MiFacetGoldenReview extends NavigationMixin(
  LightningElement
) {
  @api recordId;

  record;
  loadError;
  isBusy = false;

  @wire(getRecord, { recordId: "$recordId", fields: FIELDS })
  wiredRecord(result) {
    const { data, error } = result;
    if (data) {
      this.record = data;
      this.loadError = undefined;
    } else if (error) {
      this.loadError =
        error?.body?.message ||
        error?.message ||
        "레코드를 불러오지 못했습니다.";
    }
  }

  /**
   * The value of one field from the wired record, or "" when unresolved.
   *
   * @param {object} field The imported schema field reference
   * @returns {string} The display value
   */
  fieldValue(field) {
    return this.record?.fields?.[field.fieldApiName]?.value ?? "";
  }

  get facetField() {
    return this.fieldValue(FACET_FIELD);
  }

  get valueText() {
    return this.fieldValue(VALUE_TEXT);
  }

  get provenance() {
    return this.fieldValue(PROVENANCE);
  }

  get sourceSnippet() {
    return this.fieldValue(SOURCE_SNIPPET);
  }

  get note() {
    return this.fieldValue(NOTE);
  }

  get hasSourceSnippet() {
    return !!this.sourceSnippet;
  }

  get hasNote() {
    return !!this.note;
  }

  get documentId() {
    return this.fieldValue(DOCUMENT);
  }

  get hasDocument() {
    return !!this.documentId;
  }

  get verifiedByName() {
    // The Verified_By__c lookup's display value rides on the field's displayValue, not .value (which is the Id).
    return this.record?.fields?.[VERIFIED_BY.fieldApiName]?.displayValue ?? "";
  }

  get verifiedDate() {
    return this.fieldValue(VERIFIED_DATE);
  }

  // ---- provenance state --------------------------------------------------
  // Provenance is the whole decision: an LLM_Proposed row is a candidate awaiting a human call (승인/삭제);
  // a Human or LLM_Confirmed row is already an accepted golden answer, so it shows status, not buttons.
  get isProposed() {
    return this.provenance === "LLM_Proposed";
  }

  get isConfirmed() {
    return this.provenance === "LLM_Confirmed";
  }

  get isHuman() {
    return this.provenance === "Human";
  }

  /** The provenance badge label + variant, so the grade reads at a glance. */
  get provenanceLabel() {
    return (
      {
        Human: "사람 입력 (확정 정답)",
        LLM_Confirmed: "LLM 제안 → 사람 승인 (확정 정답)",
        LLM_Proposed: "LLM 제안 (승인 전 — 아직 정답 아님)"
      }[this.provenance] || this.provenance
    );
  }

  get provenanceVariant() {
    if (this.isProposed) {
      return "warning";
    }
    return "success";
  }

  /** The one-line "what state is this in" explanation under the badge. */
  get stateExplanation() {
    if (this.isProposed) {
      return "이 값은 LLM이 제안한 후보입니다. 아래 원문 인용과 대조해 맞으면 승인하고, 틀리면 삭제하세요 — 승인 전까지는 채점 기준(정답)으로 쓰이지 않습니다.";
    }
    if (this.isConfirmed) {
      return "LLM이 제안한 값을 사람이 승인해 확정 정답이 되었습니다. 패싯 채점의 기준으로 쓰입니다.";
    }
    if (this.isHuman) {
      return "사람이 직접 입력한 확정 정답입니다. 가장 높은 신뢰 등급이며, 패싯 채점의 기준으로 쓰입니다.";
    }
    return "";
  }

  get hasVerifier() {
    return !!this.verifiedByName;
  }

  /** The picklist API name of the facet field is developer-facing; show a friendlier Korean label. */
  get facetFieldLabel() {
    return (
      {
        Facet_Companies_Mentioned__c: "언급된 회사",
        Facet_Industry__c: "산업",
        Facet_Geography__c: "지역",
        Facet_As_Of_Date__c: "기준일",
        Facet_Abstract__c: "요약"
      }[this.facetField] || this.facetField
    );
  }

  // ---- actions -----------------------------------------------------------
  /**
   * Promotes an LLM-proposed row to a confirmed golden answer (Provenance__c → LLM_Confirmed), after a
   * confirm dialog. Reuses the controller the document-page card uses; on success it notifies the record UI so
   * the highlights panel and this card re-read the new provenance in place.
   */
  async handleConfirm() {
    const proceed = await LightningConfirm.open({
      label: "패싯 정답 승인",
      message:
        "이 제안을 확정 정답으로 승인합니다. 이후 패싯 채점의 기준으로 사용됩니다. 계속할까요?",
      theme: "success"
    });
    if (!proceed) {
      return;
    }
    this.isBusy = true;
    try {
      await confirmProposal({ goldenId: this.recordId });
      getRecordNotifyChange([{ recordId: this.recordId }]);
      this.toast("승인 완료", "제안을 확정 정답으로 승인했습니다.", "success");
    } catch (error) {
      this.toast(
        "승인 실패",
        error?.body?.message || "승인하지 못했습니다.",
        "error"
      );
    } finally {
      this.isBusy = false;
    }
  }

  /**
   * Discards the candidate row (hard delete via the controller), after a destructive-action confirm. On
   * success it navigates to the parent document (the row no longer exists to display), or to the object list
   * when there is no parent.
   */
  async handleDelete() {
    const proceed = await LightningConfirm.open({
      label: "패싯 정답 후보 삭제",
      message:
        "이 후보를 삭제합니다. 되돌릴 수 없으며, 채점 기준에서 제외됩니다. 계속할까요?",
      theme: "warning"
    });
    if (!proceed) {
      return;
    }
    this.isBusy = true;
    try {
      await deleteValue({ goldenId: this.recordId });
      this.toast("삭제 완료", "후보를 삭제했습니다.", "success");
      this.navigateAwayAfterDelete();
    } catch (error) {
      this.toast(
        "삭제 실패",
        error?.body?.message || "삭제하지 못했습니다.",
        "error"
      );
    } finally {
      this.isBusy = false;
    }
  }

  /** Opens the parent document's record page, where the full side-by-side facet review lives. */
  handleOpenDocument() {
    if (!this.documentId) {
      return;
    }
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.documentId,
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    });
  }

  /** After a delete, the record is gone — go to the parent document if known, else the golden list view. */
  navigateAwayAfterDelete() {
    if (this.documentId) {
      this.handleOpenDocument();
      return;
    }
    this[NavigationMixin.Navigate]({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "MI_Facet_Golden__c",
        actionName: "list"
      },
      state: { filterName: "Recent" }
    });
  }

  /**
   * Fires a toast.
   *
   * @param {string} title The toast title
   * @param {string} message The toast body
   * @param {string} variant success | warning | error | info
   */
  toast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }
}
