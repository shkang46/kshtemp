import { createElement } from "lwc";
import MiMetricTrend from "c/miMetricTrend";

// The MI_ChartJs static resource and the c/miReportChartConfig module are auto-mocked by sfdx-lwc-jest.
// window.Chart is never loaded under Jest, so renderChart() is a guaranteed no-op — these tests therefore
// assert the component mounts and exposes its canvas without throwing, not that a chart is painted (that path
// needs a real browser). The value here is guarding the husky Jest gate and the lifecycle contract.

function createComponent(spec) {
  const element = createElement("c-mi-metric-trend", { is: MiMetricTrend });
  if (spec !== undefined) {
    element.spec = spec;
  }
  document.body.appendChild(element);
  return element;
}

const LINE_SPEC = {
  type: "line",
  title: "",
  labels: ["07/01", "07/15", "07/30"],
  series: [{ name: "골든 정밀도", values: [0.9, 0.95, 0.99] }]
};

describe("c-mi-metric-trend", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders a canvas for the sparkline", () => {
    const element = createComponent(LINE_SPEC);
    const canvas = element.shadowRoot.querySelector("canvas");
    expect(canvas).not.toBeNull();
  });

  it("mounts without throwing when no spec is provided", () => {
    const element = createComponent();
    expect(element.shadowRoot.querySelector("canvas")).not.toBeNull();
  });

  it("accepts a spec update without throwing", () => {
    const element = createComponent(LINE_SPEC);
    // Re-setting the spec exercises the setter's rebuild + renderChart path (no-op under Jest, but must not
    // throw or leave the canvas missing).
    element.spec = {
      type: "line",
      labels: ["08/01", "08/02"],
      series: [{ name: "x", values: [0.5, 0.6] }]
    };
    return Promise.resolve().then(() => {
      expect(element.shadowRoot.querySelector("canvas")).not.toBeNull();
    });
  });
});
