import { LightningElement, api } from "lwc";
import { loadScript } from "lightning/platformResourceLoader";
import CHARTJS from "@salesforce/resourceUrl/MI_ChartJs";
import { buildChartConfig } from "c/miReportChartConfig";

/**
 * A compact run-history sparkline for one eval metric on the Quality Home dashboard. Given a chart spec
 * (built by the parent from a leg's TrendPoint list), it renders a single Chart.js line so a reviewer can
 * see whether the metric is moving, not just its latest value.
 *
 * It deliberately reuses the shared c/miReportChartConfig builder rather than hand-rolling a config, per the
 * repo convention that all charts flow through that one module — the same builder the report viewer uses. The
 * Chart.js library is loaded from the shared MI_ChartJs static resource. A spec with fewer than two points is
 * never passed here (the parent renders a "not enough runs" note instead), so this component only ever draws a
 * real line; any malformed spec degrades to an empty canvas rather than throwing.
 */
export default class MiMetricTrend extends LightningElement {
  _spec;
  _config; // Chart.js config computed from the spec; null when the spec is unrenderable
  chartLoaded = false; // guards the one-time loadScript
  chart; // the live Chart.js instance

  /**
   * The chart spec for this trend — { type:'line', labels:[], series:[{ name, values:[] }] }. Setting it
   * rebuilds the config and redraws.
   */
  @api
  get spec() {
    return this._spec;
  }
  set spec(value) {
    this._spec = value;
    this._config = value ? buildChartConfig(value) : null;
    // The shared builder sets maintainAspectRatio:true, which makes Chart.js honour the default 2:1 ratio and
    // shrink the sparkline into a narrow box left-aligned in a wide tile. Here the wrapper fixes the height
    // (7rem) and spans full width, so let the canvas fill it in both dimensions instead. Scoped to this
    // component so the report viewer's aspect-preserving charts are unaffected.
    if (this._config && this._config.options) {
      this._config.options.maintainAspectRatio = false;
    }
    this.renderChart();
  }

  /**
   * Loads Chart.js once, then (re)renders. renderChart is idempotent and also called from the spec setter, so
   * it handles both the initial load race and later spec changes.
   */
  renderedCallback() {
    if (this.chartLoaded) {
      this.renderChart();
      return;
    }
    this.chartLoaded = true;
    loadScript(this, CHARTJS)
      .then(() => this.renderChart())
      .catch(() => {
        // A failed library load leaves the canvas blank; the parent tile still shows the numeric value.
        this._config = null;
      });
  }

  /**
   * (Re)draws the sparkline. Destroys any existing instance first to avoid Chart.js's "Canvas is already in
   * use" error, and bails until the library is loaded and a config exists (which is also why this is a safe
   * no-op under Jest, where window.Chart is never loaded).
   */
  renderChart() {
    if (!this.chartLoaded || !window.Chart || !this._config) {
      return;
    }
    const canvas = this.refs?.canvas;
    if (!canvas) {
      return;
    }
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
    this.chart = new window.Chart(canvas.getContext("2d"), this._config);
  }

  disconnectedCallback() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = undefined;
    }
  }
}
