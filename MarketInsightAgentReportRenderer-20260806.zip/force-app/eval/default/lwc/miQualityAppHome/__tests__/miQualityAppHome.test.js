import { createElement } from "lwc";
import MiQualityAppHome from "c/miQualityAppHome";
import getSnapshot from "@salesforce/apex/MI_QualityHomeController.getSnapshot";
import getPrediction from "@salesforce/apex/MI_QualityHomeController.getPrediction";
import runGoldenScoring from "@salesforce/apex/MI_QualityRunController.runGoldenScoring";
import runInvariantCheck from "@salesforce/apex/MI_QualityRunController.runInvariantCheck";
import runJudgeValidation from "@salesforce/apex/MI_QualityRunController.runJudgeValidation";
import runJudgeAudit from "@salesforce/apex/MI_QualityRunController.runJudgeAudit";
import runRetrievalProbe from "@salesforce/apex/MI_QualityRunController.runRetrievalProbe";
import runDocumentRetrievalProbe from "@salesforce/apex/MI_QualityRunController.runDocumentRetrievalProbe";
import runGoldenProposal from "@salesforce/apex/MI_QualityRunController.runGoldenProposal";
import runFacetGoldenScoring from "@salesforce/apex/MI_QualityRunController.runFacetGoldenScoring";
import runFacetJudge from "@salesforce/apex/MI_QualityRunController.runFacetJudge";
import runFacetJudgeValidation from "@salesforce/apex/MI_QualityRunController.runFacetJudgeValidation";
import runFacetGoldenProposal from "@salesforce/apex/MI_QualityRunController.runFacetGoldenProposal";
import { refreshApex } from "@salesforce/apex";
import LightningConfirm from "lightning/confirm";

// A WIRED Apex method needs a wire-adapter stub, not the `{ default: jest.fn() }` shape used for imperative
// calls — that shape has no emit()/error(), so a wired method mocked that way can never be fed data.
jest.mock(
  "@salesforce/apex/MI_QualityHomeController.getSnapshot",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// getPrediction is also WIRED — same wire-adapter stub so the prediction cards can be fed a payload.
jest.mock(
  "@salesforce/apex/MI_QualityHomeController.getPrediction",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// The run methods are IMPERATIVE, so each is a plain jest.fn resolving a LaunchResult the handler toasts.
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runGoldenScoring",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runInvariantCheck",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runJudgeValidation",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runJudgeAudit",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runRetrievalProbe",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runDocumentRetrievalProbe",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runGoldenProposal",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runFacetGoldenScoring",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runFacetJudge",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runFacetJudgeValidation",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runFacetGoldenProposal",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runAnswerJudge",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_QualityRunController.runAnswerBakeoff",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
// The bake-off catalogue + recent-list reads are WIRED → wire-adapter stubs.
jest.mock(
  "@salesforce/apex/MI_AnswerBakeoffController.getGenerators",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_AnswerBakeoffController.getRecentBakeoffs",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// refreshApex is imported from the bare '@salesforce/apex' module.
jest.mock(
  "@salesforce/apex",
  () => ({ refreshApex: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

// NavigationMixin's [Navigate]() runs against the component's INTERNAL instance, so replacing the whole module
// with a version whose [Navigate] forwards to a jest.fn is the only approach that reaches the call.
jest.mock("lightning/navigation", () => {
  const Navigate = Symbol("Navigate");
  const GenerateUrl = Symbol("GenerateUrl");
  const navigateMock = jest.fn();
  const NavigationMixin = (Base) =>
    class extends Base {
      [Navigate](...args) {
        navigateMock(...args);
      }
      [GenerateUrl]() {
        return Promise.resolve("https://example.com");
      }
    };
  NavigationMixin.Navigate = Navigate;
  NavigationMixin.GenerateUrl = GenerateUrl;
  NavigationMixin.__navigateMock = navigateMock;
  return { NavigationMixin };
});

const { NavigationMixin } = require("lightning/navigation");

const EMPTY_SNAPSHOT = {
  documentCount: 0,
  pendingProposals: 0,
  needsTriage: 0,
  unconfirmedViolations: 0,
  judgeRunsNeedingValidation: 0,
  answerRunsNeedingValidation: 0,
  pendingFacetProposals: 0,
  facetJudgeRunsNeedingValidation: 0,
  totalProposals: 0,
  totalVerdicts: 0,
  totalInvariants: 0,
  totalJudgeRuns: 0,
  totalAnswerRuns: 0,
  totalFacetJudgeRuns: 0,
  evalEnabled: false,
  latestGoldenPrecision: null,
  latestGoldenRecall: null,
  latestGoldenF1: null,
  latestGoldenCiLower: null,
  latestGoldenCiUpper: null,
  latestGoldenFigureCount: null,
  latestFacetGoldenPrecision: null,
  latestFacetGoldenRecall: null,
  latestFacetGoldenF1: null,
  latestFacetGoldenCiLower: null,
  latestFacetGoldenCiUpper: null,
  latestFacetGoldenFigureCount: null,
  latestFacetJudgePrecision: null,
  latestFacetFaithfulnessScore: null,
  facetJudgePresentable: false,
  latestRetrievalRecallAt1: null,
  latestRetrievalRecallAt5: null,
  latestRetrievalRecallAt10: null,
  latestRetrievalMrr: null,
  latestRetrievalLabel: null,
  latestDocRetrievalRecallAt1: null,
  latestDocRetrievalRecallAt5: null,
  latestDocRetrievalRecallAt10: null,
  latestDocRetrievalMrr: null,
  latestDocRetrievalLabel: null,
  latestInvariantChecked: null,
  latestInvariantViolated: null,
  latestInvariantMean: null,
  latestInvariantCiLower: null,
  latestInvariantCiUpper: null,
  invariantRuns: [],
  latestJudgePrecision: null,
  latestJudgeRecall: null,
  latestJudgeKappa: null,
  latestJudgeSyntheticInjected: null,
  latestJudgeSyntheticCaught: null,
  judgePresentable: false,
  latestFaithfulnessScore: null,
  latestFaithfulnessGrounded: null,
  latestFaithfulnessDenominator: null,
  coverageFormats: null,
  coverageRoutes: null,
  coverageDocumentTypes: null,
  coverageNote: null,
  coverageDocumentCount: null,
  goldenTrend: [],
  retrievalTrend: [],
  docRetrievalTrend: [],
  invariantTrend: [],
  judgeTrend: [],
  faithfulnessTrend: []
};

// A validated, fully-measured org.
const BUSY_SNAPSHOT = {
  documentCount: 3,
  pendingProposals: 5,
  needsTriage: 7,
  unconfirmedViolations: 102,
  confirmedRealErrors: 1,
  reviewedFalsePositives: 1,
  detectorPrecision: 0.5,
  detectorPrecisionCiLower: 0.095,
  detectorPrecisionCiUpper: 0.905,
  judgeRunsNeedingValidation: 1,
  answerRunsNeedingValidation: 1,
  pendingFacetProposals: 4,
  facetJudgeRunsNeedingValidation: 1,
  totalProposals: 12,
  totalVerdicts: 40,
  totalInvariants: 150,
  totalJudgeRuns: 4,
  totalAnswerRuns: 3,
  totalFacetJudgeRuns: 2,
  evalEnabled: true,
  latestGoldenPrecision: 0.996,
  latestGoldenRecall: 0.527,
  latestGoldenF1: 0.69,
  latestGoldenCiLower: 0.91,
  latestGoldenCiUpper: 0.999,
  latestGoldenFigureCount: 53,
  latestFacetGoldenPrecision: 0.92,
  latestFacetGoldenRecall: 0.85,
  latestFacetGoldenF1: 0.884,
  latestFacetGoldenCiLower: 0.8,
  latestFacetGoldenCiUpper: 0.97,
  latestFacetGoldenFigureCount: 41,
  latestFacetJudgePrecision: 0.88,
  latestFacetFaithfulnessScore: 0.9,
  facetJudgePresentable: true,
  latestRetrievalRecallAt1: 0.82,
  latestRetrievalRecallAt5: 0.94,
  latestRetrievalRecallAt10: 0.97,
  latestRetrievalMrr: 0.905,
  latestRetrievalLabel: "Single-figure retrieval probes",
  latestDocRetrievalRecallAt1: 0.78,
  latestDocRetrievalRecallAt5: 0.9,
  latestDocRetrievalRecallAt10: 0.95,
  latestDocRetrievalMrr: 0.83,
  latestDocRetrievalLabel: "Hybrid retrieval — index=FILTERABLE",
  latestInvariantChecked: 218,
  latestInvariantViolated: 51,
  latestInvariantMean: 0.766,
  latestInvariantCiLower: 0.7,
  latestInvariantCiUpper: 0.82,
  invariantRuns: [
    {
      runId: "a0Bxx0000000002",
      runLabel: "Invariant baseline (2차)",
      runDate: "08/01 09:12",
      checked: 218,
      violated: 51,
      passRate: 0.766
    },
    {
      runId: "a0Bxx0000000001",
      runLabel: "Invariant baseline (1차)",
      runDate: "07/31 18:40",
      checked: 218,
      violated: 51,
      passRate: 0.766
    }
  ],
  latestJudgePrecision: 0.91,
  latestJudgeRecall: 0.74,
  latestJudgeKappa: 0.62,
  latestJudgeSyntheticInjected: 20,
  latestJudgeSyntheticCaught: 18,
  judgePresentable: true,
  latestFaithfulnessScore: 0.88,
  latestFaithfulnessGrounded: 44,
  latestFaithfulnessDenominator: 50,
  latestFaithfulnessJudgeRecall: 0.74,
  faithfulnessPresentable: true,
  coverageFormats: "pdf",
  coverageRoutes: "PDF 3-pass",
  coverageDocumentTypes: "Market Report",
  coverageNote: "차트·OCR 수치는 측정 범위 밖입니다.",
  coverageDocumentCount: 1,
  goldenTrend: [
    { pointLabel: "07/01", value: 0.9 },
    { pointLabel: "07/15", value: 0.95 },
    { pointLabel: "07/30", value: 0.996 }
  ],
  // A single point: not enough for a trend line, so the leg shows the "실행 1회 …" note (B-1 UX).
  retrievalTrend: [{ pointLabel: "07/30", value: 0.82 }],
  docRetrievalTrend: [
    { pointLabel: "07/01", value: 0.72 },
    { pointLabel: "07/30", value: 0.78 }
  ],
  invariantTrend: [
    { pointLabel: "07/01", value: 0.98 },
    { pointLabel: "07/30", value: 0.987 }
  ],
  judgeTrend: [
    { pointLabel: "07/01", value: 0.85 },
    { pointLabel: "07/30", value: 0.91 }
  ],
  faithfulnessTrend: [
    { pointLabel: "07/01", value: 0.8 },
    { pointLabel: "07/30", value: 0.88 }
  ]
};

const PREDICTION_SNAPSHOT = {
  judgePresentable: true,
  golden: {
    legKey: "golden",
    successes: 50,
    failures: 3,
    trials: 53,
    pointEstimate: 0.927,
    ciLower: 0.83,
    ciUpper: 0.975,
    density: [
      { x: 0.8, y: 2.1 },
      { x: 0.95, y: 6.4 }
    ],
    gated: false,
    presentable: true,
    versionLabel: null
  },
  retrieval: {
    legKey: "retrieval",
    successes: 40,
    failures: 5,
    trials: 45,
    pointEstimate: 0.87,
    ciLower: 0.75,
    ciUpper: 0.94,
    density: [
      { x: 0.7, y: 1.5 },
      { x: 0.9, y: 5.0 }
    ],
    gated: false,
    presentable: true,
    versionLabel: null
  },
  judge: {
    legKey: "judge",
    successes: 18,
    failures: 2,
    trials: 20,
    pointEstimate: 0.86,
    ciLower: 0.7,
    ciUpper: 0.95,
    density: [
      { x: 0.6, y: 1.0 },
      { x: 0.9, y: 4.0 }
    ],
    gated: true,
    presentable: true,
    versionLabel: null
  },
  faithfulness: {
    legKey: "faithfulness",
    successes: 44,
    failures: 6,
    trials: 50,
    pointEstimate: 0.865,
    ciLower: 0.75,
    ciUpper: 0.93,
    density: [
      { x: 0.7, y: 1.2 },
      { x: 0.9, y: 4.5 }
    ],
    gated: true,
    presentable: true,
    versionLabel: null
  },
  facet: {
    legKey: "facet",
    successes: 38,
    failures: 3,
    trials: 41,
    pointEstimate: 0.91,
    ciLower: 0.79,
    ciUpper: 0.97,
    density: [
      { x: 0.75, y: 1.4 },
      { x: 0.95, y: 5.2 }
    ],
    gated: false,
    presentable: true,
    versionLabel: null
  }
};

function createComponent() {
  const element = createElement("c-mi-quality-app-home", {
    is: MiQualityAppHome
  });
  document.body.appendChild(element);
  return element;
}

async function emit(data) {
  getSnapshot.emit(data);
  await Promise.resolve();
}

async function emitPrediction(data) {
  getPrediction.emit(data);
  await Promise.resolve();
}

/**
 * Selects a leg in the left vertical-nav by dispatching its select event, then lets the DOM update.
 *
 * @param {HTMLElement} element The component under test
 * @param {string} legId The leg id (prepare/numeric/retrieval/trust/facet/intro)
 */
async function selectLeg(element, legId) {
  const nav = element.shadowRoot.querySelector("lightning-vertical-navigation");
  nav.dispatchEvent(new CustomEvent("select", { detail: { name: legId } }));
  await Promise.resolve();
  await Promise.resolve();
}

async function flushPromises() {
  for (let i = 0; i < 4; i++) {
    // eslint-disable-next-line no-await-in-loop
    await Promise.resolve();
  }
}

function findButton(element, label) {
  return Array.from(
    element.shadowRoot.querySelectorAll("lightning-button")
  ).find((b) => b.label === label);
}

async function clickAndCaptureNavigation(element, label) {
  const button = findButton(element, label);
  button.dispatchEvent(new CustomEvent("click"));
  await Promise.resolve();
  const calls = NavigationMixin.__navigateMock.mock.calls;
  return calls.length ? calls[calls.length - 1][0] : undefined;
}

describe("c-mi-quality-app-home", () => {
  beforeEach(() => {
    runGoldenScoring.mockResolvedValue({
      launched: true,
      async: false,
      message: "골든 채점 완료"
    });
    runInvariantCheck.mockResolvedValue({
      launched: true,
      async: false,
      message: "산술 검사 완료"
    });
    runJudgeValidation.mockResolvedValue({
      launched: true,
      async: false,
      message: "심판 검증 완료"
    });
    runJudgeAudit.mockResolvedValue({
      launched: true,
      async: true,
      message: "심판 배치 시작됨"
    });
    runRetrievalProbe.mockResolvedValue({
      launched: true,
      async: true,
      message: "수치 검색 재현 시작됨"
    });
    runDocumentRetrievalProbe.mockResolvedValue({
      launched: true,
      async: true,
      message: "문서 검색 재현 시작됨"
    });
    runGoldenProposal.mockResolvedValue({
      launched: true,
      async: true,
      message: "정답셋 제안 시작됨"
    });
    runFacetGoldenScoring.mockResolvedValue({
      launched: true,
      async: false,
      message: "패싯 골든 채점 완료"
    });
    runFacetJudge.mockResolvedValue({
      launched: true,
      async: true,
      message: "패싯 심판 배치 시작됨"
    });
    runFacetJudgeValidation.mockResolvedValue({
      launched: true,
      async: false,
      message: "패싯 심판 검증 완료"
    });
    runFacetGoldenProposal.mockResolvedValue({
      launched: true,
      async: true,
      message: "패싯 정답 제안 시작됨"
    });
    LightningConfirm.open = jest.fn(() => Promise.resolve(true));
  });

  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("explains what the app measures before any data loads", () => {
    const element = createComponent();

    // The intro leg is selected by default and is static, so it renders even before the wire resolves.
    const text = element.shadowRoot.textContent;
    expect(text).toContain("정확한지");
    expect(text).toContain("빠뜨린 숫자는 없는지");
    expect(text).toContain("골든셋");
    expect(text).toContain("LLM 심판");
  });

  it("renders a left vertical-nav grouped by verification target with one item per leg and no count badges", () => {
    const element = createComponent();

    const nav = element.shadowRoot.querySelector(
      "lightning-vertical-navigation"
    );
    expect(nav).not.toBeNull();
    // The nav is grouped by verification target (추출 데이터 / 검색 / AI 답변 / AI 심판), one section per group.
    const sections = element.shadowRoot.querySelectorAll(
      "lightning-vertical-navigation-section"
    );
    // 시작 + ① 데이터 + ② 검색 + ③ 답변 + ④ 심판 = 5 groups.
    expect(sections.length).toBe(5);
    const items = element.shadowRoot.querySelectorAll(
      "lightning-vertical-navigation-item-icon"
    );
    // intro + prepare + numeric + facet + search + answer + trust = 7 legs (retrieval split into search+answer).
    expect(items.length).toBe(7);
    const names = Array.from(items).map((i) => i.name);
    expect(names).toEqual([
      "intro",
      "prepare",
      "numeric",
      "facet",
      "search",
      "answer",
      "trust"
    ]);
  });

  it("shows the full methodology as an always-open card in the intro leg (no modal, no toggle)", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);

    // The methodology is now a full always-open card (not collapsible), so its overview copy renders without
    // any click — and there is no methodology toggle button to expand.
    const richText = Array.from(
      element.shadowRoot.querySelectorAll("lightning-formatted-rich-text")
    ).map((n) => n.value);
    expect(richText.join(" ")).toContain("사람이 검수한 정답과 대조");

    const methodologyToggle = Array.from(
      element.shadowRoot.querySelectorAll("button.flow-toggle")
    ).find((b) => b.textContent.includes("평가 방법론 전체"));
    expect(methodologyToggle).toBeUndefined();
  });

  it("switches legs from the vertical-nav and shows that leg's summary banner", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);

    await selectLeg(element, "numeric");
    const text = element.shadowRoot.textContent;
    // The numeric leg's what/how/why banner + coverage banner + golden metric now render.
    expect(text).toContain("무엇을 검증하나");
    expect(text).toContain("어떻게 재나");
    expect(text).toContain("측정 범위 (커버리지)");
    expect(text).toContain("99.6%");
  });

  it("attaches the credible interval to RECALL, not precision, in the golden card", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "numeric");

    const text = element.shadowRoot.textContent;
    // The CI line must be prefixed with 재현율 (recall), and the term is 신용구간 (credible), not 신뢰구간.
    expect(text).toContain("재현율 94% 신용구간");
    expect(text).not.toContain("신뢰구간");
  });

  it("shows the run-1-only note instead of a trend line when a leg has a single point", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    // The numeric-figure retrieval tile lives in the search leg, and retrievalTrend has one point in
    // BUSY_SNAPSHOT, so the leg reports the count rather than a flat line.
    await selectLeg(element, "search");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("실행 1회 — 추세선은 2회 이상부터 표시됩니다");
  });

  it("splits the old retrieval leg into a search leg and an answer leg", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);

    // Assert on rendered BODY text, not lightning-card `title` attributes — the Jest stub does not render the
    // title attribute into textContent (which is why every other test checks body copy). The search leg holds
    // both retrieval tiles (numeric SOQL derivation + hybrid document) and no RAGAS faithfulness derivation.
    await selectLeg(element, "search");
    let text = element.shadowRoot.textContent;
    expect(text).toContain("SOQL 정형 조회로 실제로"); // numeric-figure retrieval tile body
    expect(text).toContain("하이브리드(의미+키워드)"); // hybrid document retrieval tile body
    expect(text).not.toContain("근거 있는 주장 ÷"); // RAGAS faithfulness derivation lives in the answer leg

    // The answer leg holds RAGAS faithfulness + the bake-off, and no retrieval tile.
    await selectLeg(element, "answer");
    text = element.shadowRoot.textContent;
    expect(text).toContain("근거 있는 주장 ÷"); // RAGAS faithfulness derivation
    expect(text).toContain("답변 품질 비교 평가"); // bake-off card-title-text span (a real element, rendered)
    expect(text).not.toContain("SOQL 정형 조회로 실제로");
  });

  it("reports an unmeasured golden run as 'not measured', never a bare 0%", async () => {
    const element = createComponent();
    await emit(EMPTY_SNAPSHOT);
    await selectLeg(element, "numeric");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("아직 골든 채점을 실행하지 않았습니다");
    expect(text).not.toContain("0.0%");
  });

  it("shows the numeric leg's live counts once the snapshot resolves", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "numeric");

    const text = element.shadowRoot.textContent;
    // The invariant card lists each run's own result, labelled as unconfirmed candidates.
    expect(text).toContain("모순 후보 51건(미확정) / 검사 218건");
  });

  it("shows the trust leg's judge validation and triage queue", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "trust");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("7건이 사람의 분류를 기다리고 있습니다");
    expect(text).toContain(
      "1건의 심판 실행이 아직 골든셋으로 검증되지 않았습니다"
    );
    expect(text).toContain("숫자 하나하나");
  });

  it("explains 합성 민감도 and shows its rate on the card without a button press", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT); // synthetic 18/20 injected/caught
    await selectLeg(element, "trust");

    const text = element.shadowRoot.textContent;
    // The rate is rendered inline (18/20 = 90.0%), not only in a post-run toast, and the term is defined.
    expect(text).toContain("합성 오류 18/20 탐지 · 합성 민감도 90.0%");
    expect(text).toContain("가짜 오류(합성 오류)");
    expect(text).toContain("유일한 단서");
  });

  it("clarifies that judge precision 0% with unmeasured recall is 'not compared', not a zero score", async () => {
    const element = createComponent();
    // The org's real state: a judge run recorded precision 0 but recall never computed (verdicts never paired
    // to golden rows). Synthetic sensitivity is still a real, separate value.
    await emit({
      ...BUSY_SNAPSHOT,
      latestJudgePrecision: 0,
      latestJudgeRecall: null,
      latestJudgeSyntheticInjected: 16,
      latestJudgeSyntheticCaught: 15,
      judgePresentable: false
    });
    await selectLeg(element, "trust");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("측정 자체가 안 된");
    expect(text).toContain("합성 민감도 93.8%"); // 15/16, shown as a real separate value
  });

  it("surfaces the facet judge precision (previously hidden) in the facet leg", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "facet");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("92.0%"); // facet golden precision
    expect(text).toContain("88.0%"); // facet judge precision — now shown
    expect(text).toContain("요약 Faithfulness");
  });

  it("uses positive phrasing for an empty prepare queue, not a bare zero", async () => {
    const element = createComponent();
    await emit(EMPTY_SNAPSHOT);
    await selectLeg(element, "prepare");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("지금 승인할 제안이 없습니다");
  });

  it("navigates to the pending-proposals list view when its button is clicked", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "prepare");

    const navigation = await clickAndCaptureNavigation(
      element,
      "승인 대기 목록 열기"
    );
    expect(navigation).toEqual({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "MI_Tabular_Golden_Row__c",
        actionName: "list"
      },
      state: { filterName: "Pending_LLM_Proposals" }
    });
  });

  it("navigates to the needs-triage list view from the trust leg", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "trust");

    const navigation = await clickAndCaptureNavigation(
      element,
      "분류 대기 목록 열기"
    );
    expect(navigation).toEqual({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "MI_Tabular_Eval_Verdict__c",
        actionName: "list"
      },
      state: { filterName: "Needs_Human_Triage" }
    });
  });

  it("runs golden scoring, toasts, and refreshes on success", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "numeric");

    findButton(element, "골든 채점 실행").dispatchEvent(
      new CustomEvent("click")
    );
    await flushPromises();

    expect(runGoldenScoring).toHaveBeenCalledTimes(1);
    expect(refreshApex).toHaveBeenCalled();
  });

  it("confirms cost before a callout leg (LLM 심판 실행) and launches on confirm", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "trust");

    findButton(element, "LLM 심판 실행").dispatchEvent(
      new CustomEvent("click")
    );
    await flushPromises();

    expect(LightningConfirm.open).toHaveBeenCalledTimes(1);
    expect(runJudgeAudit).toHaveBeenCalledTimes(1);
  });

  it("renders the leg's prediction card once the prediction wire resolves", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await emitPrediction(PREDICTION_SNAPSHOT);
    await selectLeg(element, "numeric");

    const cards = element.shadowRoot.querySelectorAll("c-mi-prediction-card");
    expect(cards.length).toBeGreaterThanOrEqual(1);
  });

  it("renders a facet prediction card in the facet leg", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await emitPrediction(PREDICTION_SNAPSHOT);
    await selectLeg(element, "facet");

    const cards = element.shadowRoot.querySelectorAll("c-mi-prediction-card");
    expect(cards.length).toBe(1);
  });

  it("disables callout run buttons when the eval gate is off", async () => {
    const element = createComponent();
    await emit(EMPTY_SNAPSHOT); // evalEnabled: false
    await selectLeg(element, "prepare");

    // The 정답셋 제안 실행 button spends callouts, so it is disabled while the gate is off.
    const proposalButton = findButton(element, "정답셋 제안 실행");
    expect(proposalButton.disabled).toBe(true);
  });

  it("reads '아직 실행 없음' — not '검증을 마쳤습니다' — when zero answer runs exist", async () => {
    // The reported vacuous-truth bug: 0 unvalidated runs made the tile claim "all validated" over an empty set.
    const element = createComponent();
    await emit(EMPTY_SNAPSHOT); // totalAnswerRuns: 0
    await selectLeg(element, "answer");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("아직 답변 품질 실행이 없습니다");
    expect(text).not.toContain("모든 답변 품질 실행이 검증을 마쳤습니다");
  });

  it("says '검증을 마쳤습니다' only when answer runs exist and none need validation", async () => {
    const element = createComponent();
    await emit({
      ...BUSY_SNAPSHOT,
      totalAnswerRuns: 3,
      answerRunsNeedingValidation: 0
    });
    await selectLeg(element, "answer");

    const text = element.shadowRoot.textContent;
    expect(text).toContain("모든 답변 품질 실행(3건)이 검증을 마쳤습니다");
    expect(text).not.toContain("아직 답변 품질 실행이 없습니다");
  });

  it("opens the NUMERIC probe list from the 수치 검색 재현 실행 card", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "search");

    const navigation = await clickAndCaptureNavigation(
      element,
      "수치 검색 재현 목록 열기"
    );
    expect(navigation).toEqual({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "MI_Tabular_Eval_Run__c",
        actionName: "list"
      },
      state: { filterName: "Numeric_Probe_Runs" }
    });
  });

  it("opens the DOCUMENT retrieval list from the 문서 검색 재현 실행 card", async () => {
    const element = createComponent();
    await emit(BUSY_SNAPSHOT);
    await selectLeg(element, "search");

    const navigation = await clickAndCaptureNavigation(
      element,
      "문서 검색 재현 목록 열기"
    );
    expect(navigation).toEqual({
      type: "standard__objectPage",
      attributes: {
        objectApiName: "MI_Tabular_Eval_Run__c",
        actionName: "list"
      },
      state: { filterName: "Retrieval_Runs" }
    });
  });
});
