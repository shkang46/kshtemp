import { LightningElement, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import LightningConfirm from "lightning/confirm";
import { legGroups, LEG } from "c/miEvalLegs";
import { renderSections } from "c/miEvalMethodology";
import getSnapshot from "@salesforce/apex/MI_QualityHomeController.getSnapshot";
import getPrediction from "@salesforce/apex/MI_QualityHomeController.getPrediction";
import runGoldenScoring from "@salesforce/apex/MI_QualityRunController.runGoldenScoring";
import runInvariantCheck from "@salesforce/apex/MI_QualityRunController.runInvariantCheck";
import runJudgeValidation from "@salesforce/apex/MI_QualityRunController.runJudgeValidation";
import runJudgeAudit from "@salesforce/apex/MI_QualityRunController.runJudgeAudit";
import runRetrievalProbe from "@salesforce/apex/MI_QualityRunController.runRetrievalProbe";
import runDocumentRetrievalProbe from "@salesforce/apex/MI_QualityRunController.runDocumentRetrievalProbe";
import runGoldenProposal from "@salesforce/apex/MI_QualityRunController.runGoldenProposal";
import runAnswerJudge from "@salesforce/apex/MI_QualityRunController.runAnswerJudge";
import runAnswerBakeoff from "@salesforce/apex/MI_QualityRunController.runAnswerBakeoff";
import runFacetGoldenScoring from "@salesforce/apex/MI_QualityRunController.runFacetGoldenScoring";
import runFacetJudge from "@salesforce/apex/MI_QualityRunController.runFacetJudge";
import runFacetJudgeValidation from "@salesforce/apex/MI_QualityRunController.runFacetJudgeValidation";
import runFacetGoldenProposal from "@salesforce/apex/MI_QualityRunController.runFacetGoldenProposal";
import getGenerators from "@salesforce/apex/MI_AnswerBakeoffController.getGenerators";
import getRecentBakeoffs from "@salesforce/apex/MI_AnswerBakeoffController.getRecentBakeoffs";

/**
 * The Market Insight Quality app's Home tab. The app opened directly onto a bare document list view with
 * nothing explaining what it measures, no visualization of the eval numbers, and no obvious "what do I do
 * here". The page is organized into FIVE tabs (lightning-tabset), each holding one concern's metric tiles
 * AND its run/navigation cards, because evaluation is done one leg at a time and a single vertical scroll
 * of every leg ran past 1,200 lines:
 *
 *   ① 소개 (intro) — the pipeline and the three evidence grades, always rendered (even before the wire
 *      resolves) so a first-time user is never staring at a blank page. No navigation.
 *   ② 준비·입력 (prepare) — the document list and the golden-set (Tabular_Golden_Row) approval/proposal cards.
 *   ③ 수치 데이터 (numeric) — coverage banner, golden accuracy, arithmetic invariants, LLM-judge validation,
 *      their run/validation/triage cards, and the golden + judge prediction cards.
 *   ④ 에이전트 답변 품질 (answer) — SOQL + hybrid retrieval, RAGAS faithfulness, the bake-off, and the
 *      retrieval + faithfulness prediction cards.
 *   ⑤ Facet 데이터 검증 (facet) — facet accuracy + abstract faithfulness, and the four facet run buttons
 *      (golden scoring / judge / judge validation / golden proposal) with links to the facet golden set and
 *      the facet run list view.
 *
 * Each metric tile shows the latest measured value, its verification caveat, its credible interval, and a
 * run-history sparkline. A metric that has never been measured says so — never a bare 0%, which would assert
 * a failure nobody observed. Inactive tabs are lazy-rendered by lightning-tabset, so a chart (c-mi-metric-
 * trend / c-mi-prediction-card) is first sized when its tab is opened, not while hidden at 0x0.
 *
 * The read side (getSnapshot) is cacheable and can only orient the user; the RUN buttons delegate to
 * MI_QualityRunController, the write-side sibling, which is where any run actually starts.
 */
export default class MiQualityAppHome extends NavigationMixin(
  LightningElement
) {
  snapshot;
  loadError;
  // The whole @wire result is retained (not just .data) so a successful run can refreshApex(this.wiredResult)
  // to re-pull the dashboard/queue figures the run just changed.
  wiredResult;
  // Which leg is currently running, or "" when idle. A single field (rather than six booleans) disables every
  // run button while any run is in flight, so two launches can never overlap.
  runningLeg = "";
  // Whether the 5-step pipeline flow diagram is expanded. Starts open so a first-time visitor sees the flow
  // without a click; the toggle lets a returning user collapse it once they know it.
  flowExpanded = true;

  // The leg currently selected in the left vertical-nav. Replaces the old lightning-tabset: the page is now a
  // left nav (one item per leg, NO count badges) + a right content area, and each leg's content is a single
  // block (metrics + trend + prediction + run buttons + result lists), so a concern is never split across the
  // screen. Starts on the intro leg so a first-time visitor lands on the how-it-works content.
  selectedLeg = "intro";

  // The forward-looking predictions (posterior-predictive projection per leg). Retained whole so a run can
  // refreshApex it alongside the dashboard snapshot.
  prediction;
  wiredPredictionResult;

  @wire(getSnapshot)
  wiredSnapshot(result) {
    this.wiredResult = result;
    const { data, error } = result;
    if (data) {
      this.snapshot = data;
      this.loadError = undefined;
    } else if (error) {
      this.loadError =
        error?.body?.message || error?.message || "현황을 읽지 못했습니다.";
      this.snapshot = undefined;
    }
  }

  @wire(getPrediction)
  wiredPrediction(result) {
    this.wiredPredictionResult = result;
    if (result.data) {
      this.prediction = result.data;
    }
    // A prediction read failure is non-fatal — the dashboard tiers above still render; the section simply hides.
  }

  // ================================================================ ② 예측 (다음 실행 전망)

  /** True once the prediction wire has resolved, so the section renders only when there is something to show. */
  get hasPrediction() {
    return !!this.prediction;
  }

  /** The golden-accuracy prediction leg (ungated). */
  get goldenPrediction() {
    return this.prediction?.golden;
  }

  /** The hybrid document-retrieval prediction leg (ungated). */
  get retrievalPrediction() {
    return this.prediction?.retrieval;
  }

  /** The LLM-judge precision prediction leg (gated behind judge presentability). */
  get judgePrediction() {
    return this.prediction?.judge;
  }

  /** The RAGAS faithfulness prediction leg (gated behind judge presentability). */
  get faithfulnessPrediction() {
    return this.prediction?.faithfulness;
  }

  /** The facet-accuracy prediction leg (ungated), shown in the facet leg block. */
  get facetPrediction() {
    return this.prediction?.facet;
  }

  /** True once the prediction wire resolved AND a facet prediction leg is present. */
  get hasFacetPrediction() {
    return !!this.prediction?.facet;
  }

  /**
   * The empty-state note for a trend that has fewer than 2 points. This is NOT an error or a "not measured"
   * state — one run exists, but a trend needs at least two to draw a line. Naming the count makes it clear the
   * chart appears on the next run, rather than reading as a failure. `count` is the leg's trend-point count.
   *
   * @param {Array} trend The leg's TrendPoint list
   * @returns {string} The empty-state note
   */
  trendEmptyLabel(trend) {
    const count = Array.isArray(trend) ? trend.length : 0;
    if (count === 0) {
      return "실행 기록이 없어 추세를 그릴 수 없습니다.";
    }
    return `실행 ${count}회 — 추세선은 2회 이상부터 표시됩니다.`;
  }

  get goldenTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.goldenTrend);
  }

  get invariantTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.invariantTrend);
  }

  get judgeTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.judgeTrend);
  }

  get retrievalTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.retrievalTrend);
  }

  get docRetrievalTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.docRetrievalTrend);
  }

  get faithfulnessTrendEmptyLabel() {
    return this.trendEmptyLabel(this.snapshot?.faithfulnessTrend);
  }

  get hasError() {
    return !!this.loadError;
  }

  get hasSnapshot() {
    return !!this.snapshot;
  }

  get documentCount() {
    return this.snapshot?.documentCount ?? 0;
  }

  // ================================================================ ② 지표 대시보드 — 골든 정확도

  /** Null (not 0%) when no Golden run has ever completed — an unmeasured run must never read as a measured zero. */
  get latestGoldenPrecisionLabel() {
    return this.formatPercent(this.snapshot?.latestGoldenPrecision);
  }

  get latestGoldenRecallLabel() {
    return this.formatPercent(this.snapshot?.latestGoldenRecall);
  }

  get latestGoldenF1Label() {
    return this.formatPercent(this.snapshot?.latestGoldenF1);
  }

  get hasGoldenRun() {
    return this.isMeasured(this.snapshot?.latestGoldenPrecision);
  }

  /** The 94% credible interval on golden accuracy — the reason a 100%-of-3 result must not be read as "100%". */
  get goldenCiLabel() {
    return this.formatInterval(
      this.snapshot?.latestGoldenCiLower,
      this.snapshot?.latestGoldenCiUpper
    );
  }

  get hasGoldenCi() {
    return (
      this.isMeasured(this.snapshot?.latestGoldenCiLower) &&
      this.isMeasured(this.snapshot?.latestGoldenCiUpper)
    );
  }

  get goldenFigureCountLabel() {
    const count = this.snapshot?.latestGoldenFigureCount;
    return this.isMeasured(count) ? `${count} 개 정답 수치 기준` : "";
  }

  get goldenTrendSpec() {
    return this.trendSpec("골든 정밀도", this.snapshot?.goldenTrend);
  }

  get hasGoldenTrend() {
    return this.hasTrend(this.snapshot?.goldenTrend);
  }

  // ================================================================ ② 지표 대시보드 — 패싯 정확도

  /** Whether a facet golden-scoring run has ever completed — null (not 0%) reads as unmeasured, never zero. */
  get hasFacetGoldenRun() {
    return this.isMeasured(this.snapshot?.latestFacetGoldenPrecision);
  }

  get latestFacetGoldenPrecisionLabel() {
    return this.formatPercent(this.snapshot?.latestFacetGoldenPrecision);
  }

  get latestFacetGoldenRecallLabel() {
    return this.formatPercent(this.snapshot?.latestFacetGoldenRecall);
  }

  get latestFacetGoldenF1Label() {
    return this.formatPercent(this.snapshot?.latestFacetGoldenF1);
  }

  /** The 94% credible interval on facet set-accuracy — the reason a 100%-of-3 result must not read as "100%". */
  get facetGoldenCiLabel() {
    return this.formatInterval(
      this.snapshot?.latestFacetGoldenCiLower,
      this.snapshot?.latestFacetGoldenCiUpper
    );
  }

  get hasFacetGoldenCi() {
    return (
      this.isMeasured(this.snapshot?.latestFacetGoldenCiLower) &&
      this.isMeasured(this.snapshot?.latestFacetGoldenCiUpper)
    );
  }

  get facetGoldenFigureCountLabel() {
    const count = this.snapshot?.latestFacetGoldenFigureCount;
    return this.isMeasured(count) ? `${count} 개 정답 값 기준` : "";
  }

  /** The facet abstract's RAGAS faithfulness — measured by the facet judge, gated behind its validation. */
  get hasFacetJudgeRun() {
    return this.isMeasured(this.snapshot?.latestFacetJudgePrecision);
  }

  get facetJudgePresentable() {
    return this.snapshot?.facetJudgePresentable === true;
  }

  get latestFacetJudgePrecisionLabel() {
    return this.formatPercent(this.snapshot?.latestFacetJudgePrecision);
  }

  get latestFacetFaithfulnessLabel() {
    return this.formatPercent(this.snapshot?.latestFacetFaithfulnessScore);
  }

  get facetJudgeGateLabel() {
    if (!this.hasFacetJudgeRun) {
      return "아직 패싯 심판을 골든셋으로 검증하지 않았습니다.";
    }
    // Worded distinctly from the tabular judge tile's caption ("검증됨 (골든셋 대비 정밀도 0.8 이상)") on
    // purpose: the two legs share the same 0.8 gate, so a reader — and a test scanning the whole page — must be
    // able to tell which leg a verification line came from. Deliberately does NOT embed the tabular fragment.
    return this.facetJudgePresentable
      ? "패싯 심판 검증 완료 — 골든셋 정밀도 0.8 이상"
      : "패싯 심판 미검증 — 골든셋 정밀도 0.8 미만";
  }

  // ================================================================ ⑤ Facet 검증 — 실행 큐 (제안 대기 · 심판 검증 대기)

  get pendingFacetProposals() {
    return this.snapshot?.pendingFacetProposals ?? 0;
  }

  get hasPendingFacetProposals() {
    return this.pendingFacetProposals > 0;
  }

  /** Positive phrasing when the queue is empty — an empty queue and an unmeasured one must not look alike. */
  get facetProposalsLine() {
    return this.hasPendingFacetProposals
      ? `${this.pendingFacetProposals}건의 패싯 정답 제안이 승인을 기다리고 있습니다.`
      : "지금 승인할 패싯 정답 제안이 없습니다.";
  }

  get facetProposalsCardClass() {
    return this.hasPendingFacetProposals
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  get facetProposalsButtonVariant() {
    return this.hasPendingFacetProposals ? "brand" : "brand-outline";
  }

  get facetJudgeRunsNeedingValidation() {
    return this.snapshot?.facetJudgeRunsNeedingValidation ?? 0;
  }

  get hasFacetJudgeRunsNeedingValidation() {
    return this.facetJudgeRunsNeedingValidation > 0;
  }

  get totalFacetJudgeRuns() {
    return this.snapshot?.totalFacetJudgeRuns ?? 0;
  }

  get hasNoFacetJudgeRuns() {
    return this.totalFacetJudgeRuns === 0;
  }

  get facetJudgeValidationLine() {
    if (this.hasNoFacetJudgeRuns) {
      return "아직 패싯 심판 실행이 없습니다 — 먼저 '패싯 심판 실행'을 눌러 측정하세요.";
    }
    return this.hasFacetJudgeRunsNeedingValidation
      ? `${this.facetJudgeRunsNeedingValidation}건의 패싯 심판 실행이 아직 골든셋으로 검증되지 않았습니다.`
      : `모든 패싯 심판 실행(${this.totalFacetJudgeRuns}건)이 검증을 마쳤습니다.`;
  }

  get facetJudgeRunsCardClass() {
    return this.hasFacetJudgeRunsNeedingValidation
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  get facetJudgeRunsButtonVariant() {
    return this.hasFacetJudgeRunsNeedingValidation ? "brand" : "brand-outline";
  }

  // ================================================================ ② 지표 대시보드 — 산술 정합성

  get hasInvariantRun() {
    return this.isMeasured(this.snapshot?.latestInvariantMean);
  }

  /** Reported as a PASS rate, but labelled as "contradictions found" in the template — the check is asymmetric. */
  get invariantPassLabel() {
    return this.formatPercent(this.snapshot?.latestInvariantMean);
  }

  get invariantCountsLabel() {
    const checked = this.snapshot?.latestInvariantChecked;
    const violated = this.snapshot?.latestInvariantViolated;
    if (!this.isMeasured(checked)) {
      return "";
    }
    return `검사 ${checked}건 중 위반 ${violated ?? 0}건`;
  }

  get invariantCiLabel() {
    return this.formatInterval(
      this.snapshot?.latestInvariantCiLower,
      this.snapshot?.latestInvariantCiUpper
    );
  }

  get hasInvariantCi() {
    return (
      this.isMeasured(this.snapshot?.latestInvariantCiLower) &&
      this.isMeasured(this.snapshot?.latestInvariantCiUpper)
    );
  }

  get invariantTrendSpec() {
    return this.trendSpec("산술 통과율", this.snapshot?.invariantTrend);
  }

  get hasInvariantTrend() {
    return this.hasTrend(this.snapshot?.invariantTrend);
  }

  /**
   * All-time detector precision — of the reviewed violations, the share confirmed real errors. "측정 안 됨"
   * (never 0%) until a human reviews a violation. This is the answer to "when the arithmetic checks fire,
   * how often are they right", distinct from the pass rate above (which is not accuracy).
   */
  get detectorPrecisionLabel() {
    const ci = this.formatInterval(
      this.snapshot?.detectorPrecisionCiLower,
      this.snapshot?.detectorPrecisionCiUpper
    );
    const point = this.formatPercent(this.snapshot?.detectorPrecision);
    return ci ? `${point} · ${ci}` : point;
  }

  /** The reviewed/unreviewed remainder, so a high precision on few reviews can't read as a corpus claim. */
  get detectorPrecisionCountsLabel() {
    const real = this.snapshot?.confirmedRealErrors ?? 0;
    const fp = this.snapshot?.reviewedFalsePositives ?? 0;
    const violations = this.snapshot?.unconfirmedViolations ?? 0;
    const reviewed = real + fp;
    const unreviewed = Math.max(violations - reviewed, 0);
    return `검토 완료 ${reviewed}건 (실제 오류 ${real} · 오탐 ${fp}) · 미검토 ${unreviewed}건`;
  }

  // ================================================================ ② 지표 대시보드 — 수치 검색 재현 (SOQL)

  /** Null (not 0%) when no SOQL figure-retrieval run exists — an unmeasured leg must not read as a measured zero. */
  get latestRetrievalRecallLabel() {
    return this.formatPercent(this.snapshot?.latestRetrievalRecallAt1);
  }

  get latestRetrievalRecall5Label() {
    return this.formatPercent(this.snapshot?.latestRetrievalRecallAt5);
  }

  get latestRetrievalRecall10Label() {
    return this.formatPercent(this.snapshot?.latestRetrievalRecallAt10);
  }

  get latestRetrievalMrrLabel() {
    return this.formatDecimal(this.snapshot?.latestRetrievalMrr);
  }

  get hasRetrievalRun() {
    return this.isMeasured(this.snapshot?.latestRetrievalRecallAt1);
  }

  get retrievalTrendSpec() {
    return this.trendSpec("Recall@1", this.snapshot?.retrievalTrend);
  }

  get hasRetrievalTrend() {
    return this.hasTrend(this.snapshot?.retrievalTrend);
  }

  // ================================================================ ② 지표 대시보드 — 문서 검색 재현 (하이브리드 인덱스)

  /** Null (not 0%) when no hybrid document-retrieval run exists yet — same measured-vs-unmeasured distinction. */
  get latestDocRetrievalRecallLabel() {
    return this.formatPercent(this.snapshot?.latestDocRetrievalRecallAt1);
  }

  get latestDocRetrievalRecall5Label() {
    return this.formatPercent(this.snapshot?.latestDocRetrievalRecallAt5);
  }

  get latestDocRetrievalRecall10Label() {
    return this.formatPercent(this.snapshot?.latestDocRetrievalRecallAt10);
  }

  get latestDocRetrievalMrrLabel() {
    return this.formatDecimal(this.snapshot?.latestDocRetrievalMrr);
  }

  get hasDocRetrievalRun() {
    return this.isMeasured(this.snapshot?.latestDocRetrievalRecallAt1);
  }

  /** The index the latest document-retrieval run measured, taken from its label (no dedicated field). */
  get latestDocRetrievalIndexLabel() {
    return this.snapshot?.latestDocRetrievalLabel || "";
  }

  get docRetrievalTrendSpec() {
    // Series is Recall@5, matching the controller trend (docRetrievalTrend now queries Recall_At_5__c). Recall@1
    // is near-always 0 on a near-duplicate corpus and drew a flat zero line that read as total search failure;
    // Recall@5 reflects real-use retrieval quality ("intended doc in the top 5").
    return this.trendSpec("Recall@5", this.snapshot?.docRetrievalTrend);
  }

  get hasDocRetrievalTrend() {
    return this.hasTrend(this.snapshot?.docRetrievalTrend);
  }

  // ================================================================ ② 지표 대시보드 — LLM 심판 검증

  get hasJudgeRun() {
    return this.isMeasured(this.snapshot?.latestJudgePrecision);
  }

  /** True only when the latest judge validation cleared the 0.8 gate — the controller computes it, not the LWC. */
  get judgePresentable() {
    return this.snapshot?.judgePresentable === true;
  }

  /**
   * The verification-state caption. This reports whether the judge cleared the golden-set gate as a statement
   * about the DATA's trustworthiness, not about whether it may be shown to a customer — the "고객 제시" framing
   * belonged to our internal review workflow, not on a customer-facing screen.
   */
  get judgeGateLabel() {
    if (!this.hasJudgeRun) {
      return "아직 심판을 골든셋으로 검증하지 않았습니다.";
    }
    return this.judgePresentable
      ? "검증됨 (골든셋 대비 정밀도 0.8 이상)"
      : "미검증 (골든셋 대비 정밀도 0.8 미만)";
  }

  get latestJudgePrecisionLabel() {
    return this.formatPercent(this.snapshot?.latestJudgePrecision);
  }

  get latestJudgeRecallLabel() {
    return this.formatPercent(this.snapshot?.latestJudgeRecall);
  }

  get latestJudgeKappaLabel() {
    return this.formatDecimal(this.snapshot?.latestJudgeKappa);
  }

  /**
   * Planted-error sensitivity (합성 민감도) — the only evidence about what the judge MISSES, so it rides beside
   * precision. Shows the count AND the rate (e.g. "합성 오류 15/16 탐지 · 합성 민감도 93.8%"), matching the
   * number the post-run toast/Power_Note surfaces — so the same figure is visible on the card without pressing
   * a button. "" when no synthetic errors were injected (then sensitivity is genuinely unmeasured, not 0%).
   */
  get judgeSyntheticLabel() {
    const caught = this.snapshot?.latestJudgeSyntheticCaught;
    const injected = this.snapshot?.latestJudgeSyntheticInjected;
    if (!this.isMeasured(injected) || injected === 0) {
      return "";
    }
    const rate = this.formatPercent((caught ?? 0) / injected);
    return `합성 오류 ${caught ?? 0}/${injected} 탐지 · 합성 민감도 ${rate}`;
  }

  /** Whether planted-error sensitivity was measured (synthetic errors were injected), gating its explainer. */
  get hasJudgeSynthetic() {
    const injected = this.snapshot?.latestJudgeSyntheticInjected;
    return this.isMeasured(injected) && injected > 0;
  }

  /** The synthetic-sensitivity rate alone (e.g. "93.8%"), used in the unmeasured-precision explainer note. */
  get latestJudgeSyntheticRateLabel() {
    const caught = this.snapshot?.latestJudgeSyntheticCaught;
    const injected = this.snapshot?.latestJudgeSyntheticInjected;
    if (!this.isMeasured(injected) || injected === 0) {
      return "측정 안 됨";
    }
    return this.formatPercent((caught ?? 0) / injected);
  }

  /**
   * Whether to show the "precision 0% + recall unmeasured is NOT a zero score" explainer. This is exactly the
   * state this org is in: a judge run recorded a precision of 0 but its recall never computed, which is the
   * signature of a run whose verdicts were never paired to golden-confirmed rows (nothing to compare against),
   * not a judge that scored zero. Gated on a measured 0 precision AND an unmeasured recall so a genuine, fully
   * measured low score does not get explained away.
   */
  get showJudgeUnmeasuredNote() {
    return (
      this.snapshot?.latestJudgePrecision === 0 &&
      !this.isMeasured(this.snapshot?.latestJudgeRecall)
    );
  }

  get judgeTrendSpec() {
    return this.trendSpec("심판 정밀도", this.snapshot?.judgeTrend);
  }

  get hasJudgeTrend() {
    return this.hasTrend(this.snapshot?.judgeTrend);
  }

  // ================================================================ ② 지표 대시보드 — RAGAS Faithfulness

  /**
   * A faithfulness run exists whenever a denominator was measured. Keyed on the DENOMINATOR, not the score,
   * because the server withholds the score until the run's judge precision is validated — but the run, and its
   * "미검증" state, must still render (a measured-but-unvalidated run is NOT "not measured yet").
   */
  get hasFaithfulnessRun() {
    return this.isMeasured(this.snapshot?.latestFaithfulnessDenominator);
  }

  /** True only when the run's judge precision cleared the golden-set gate over a sufficient sample. */
  get faithfulnessPresentable() {
    return !!this.snapshot?.faithfulnessPresentable;
  }

  /**
   * The score is shown ONLY when presentable; otherwise "미검증", never a bare percentage. The server already
   * nulls latestFaithfulnessScore when not presentable, so formatPercent would say "측정 안 됨" — but the honest
   * label here is "미검증 (심판 검증 전)", because it WAS measured, just not yet validated for quoting.
   */
  get latestFaithfulnessLabel() {
    return this.faithfulnessPresentable
      ? this.formatPercent(this.snapshot?.latestFaithfulnessScore)
      : "미검증 (심판 검증 전)";
  }

  /** The denominator is exposed on purpose — 100%-of-3 and 100%-of-1000 are different claims. Always shown. */
  get faithfulnessFractionLabel() {
    const grounded = this.snapshot?.latestFaithfulnessGrounded;
    const denom = this.snapshot?.latestFaithfulnessDenominator;
    if (!this.isMeasured(denom)) {
      return "";
    }
    return `근거 있는 진술 ${grounded ?? 0} / 전체 ${denom}`;
  }

  /**
   * Faithfulness is capped by judge recall, so it is only meaningful read alongside the judge's recall. When the
   * run is validated, the recall ceiling is stated with its value; before that, the score is withheld entirely.
   */
  get faithfulnessCaveatLabel() {
    if (!this.hasFaithfulnessRun) {
      return "";
    }
    if (!this.faithfulnessPresentable) {
      return "심판 미검증 — 이 실행의 판정 LLM이 골든셋으로 검증되지 않아 Faithfulness 점수는 고객에게 제시할 수 없습니다(분모만 표시).";
    }
    const recall = this.snapshot?.latestFaithfulnessJudgeRecall;
    const recallLabel = this.isMeasured(recall)
      ? this.formatPercent(recall)
      : "측정 안 됨";
    return `심판 검증 완료 — Faithfulness의 상한은 심판 재현율(${recallLabel})이며 반드시 함께 제시하세요.`;
  }

  get faithfulnessTrendSpec() {
    return this.trendSpec("Faithfulness", this.snapshot?.faithfulnessTrend);
  }

  get hasFaithfulnessTrend() {
    return this.hasTrend(this.snapshot?.faithfulnessTrend);
  }

  // ================================================================ ② 지표 대시보드 — 커버리지 배너

  get hasCoverage() {
    return !!this.snapshot?.coverageFormats;
  }

  get coverageFormats() {
    return this.snapshot?.coverageFormats || "";
  }

  get coverageRoutes() {
    return this.snapshot?.coverageRoutes || "";
  }

  get coverageDocumentTypes() {
    return this.snapshot?.coverageDocumentTypes || "";
  }

  get coverageNote() {
    return this.snapshot?.coverageNote || "";
  }

  get coverageDocumentCountLabel() {
    const count = this.snapshot?.coverageDocumentCount;
    return this.isMeasured(count) ? `${count}건` : "";
  }

  // ================================================================ ② 정답셋 (승인 대기)

  get pendingProposals() {
    return this.snapshot?.pendingProposals ?? 0;
  }

  get hasPendingProposals() {
    return this.pendingProposals > 0;
  }

  /** Positive phrasing when the queue is empty — an empty queue and an unmeasured one must not look alike. */
  get pendingProposalsLine() {
    return this.hasPendingProposals
      ? `${this.pendingProposals}건이 승인을 기다리고 있습니다.`
      : "지금 승인할 제안이 없습니다.";
  }

  get pendingProposalsCardClass() {
    return this.hasPendingProposals
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  /** brand once there is real work waiting, so the button that matters is the one drawing the eye. */
  get pendingProposalsButtonVariant() {
    return this.hasPendingProposals ? "brand" : "brand-outline";
  }

  // ================================================================ ③ 판정 (분류 대기) + 산술 검사 (위반)

  get needsTriage() {
    return this.snapshot?.needsTriage ?? 0;
  }

  get hasNeedsTriage() {
    return this.needsTriage > 0;
  }

  get needsTriageLine() {
    return this.hasNeedsTriage
      ? `${this.needsTriage}건이 사람의 분류를 기다리고 있습니다.`
      : "지금 분류할 판정이 없습니다.";
  }

  get unconfirmedViolations() {
    return this.snapshot?.unconfirmedViolations ?? 0;
  }

  get hasUnconfirmedViolations() {
    return this.unconfirmedViolations > 0;
  }

  get violationsLine() {
    return this.hasUnconfirmedViolations
      ? `${this.unconfirmedViolations}건의 산술 모순이 확인됐습니다.`
      : "지금까지 확인된 산술 모순이 없습니다.";
  }

  /**
   * The per-run invariant breakdown for the card list: one line per Invariant run, each decorated with a
   * human-readable summary. Listing runs separately is what keeps several independent executions from being
   * read as one lumped all-time total (running the check repeatedly stacks row-sets, so the all-time count
   * overstates a single run).
   *
   * The violation count is labelled "미확정 후보" (unconfirmed candidate): a per-run 위반 is a RAW contradiction
   * the detector flagged, NOT a confirmed extraction error — some are the detector's own false positives until
   * a human sets Human_Judgment__c=Real_Error. The dashboard's all-time "확정 오류" tile counts only confirmed
   * ones; this per-run line must not be misread as that. Wording this honestly is why the count swings run to
   * run (it is recomputed over the current rows each time), which is expected, not a bug.
   *
   * @returns {Array} the decorated run summaries (newest-first), or [] before the wire resolves
   */
  get invariantRuns() {
    const runs = this.snapshot?.invariantRuns ?? [];
    return runs.map((r) => ({
      runId: r.runId,
      runLabel: r.runLabel,
      runDate: r.runDate,
      hasViolation: (r.violated ?? 0) > 0,
      summary: `모순 후보 ${r.violated ?? 0}건(미확정) / 검사 ${r.checked ?? 0}건 · 통과율 ${this.formatPercent(r.passRate)}`
    }));
  }

  /** Whether any Invariant run has been recorded, so the card lists per-run results rather than an empty note. */
  get hasInvariantRuns() {
    return (this.snapshot?.invariantRuns?.length ?? 0) > 0;
  }

  get triageCardClass() {
    return this.hasNeedsTriage || this.hasUnconfirmedViolations
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  get needsTriageButtonVariant() {
    return this.hasNeedsTriage ? "brand" : "brand-outline";
  }

  get violationsButtonVariant() {
    return this.hasUnconfirmedViolations ? "brand" : "brand-outline";
  }

  // ================================================================ ③ 평가 실행 (심판 검증 대기)

  get judgeRunsNeedingValidation() {
    return this.snapshot?.judgeRunsNeedingValidation ?? 0;
  }

  get hasJudgeRunsNeedingValidation() {
    return this.judgeRunsNeedingValidation > 0;
  }

  // Total judge runs, so "no run yet" is told apart from "all validated" — both otherwise make the
  // needs-validation count 0 and the old wording claimed "검증을 마쳤습니다" over an empty set (vacuous truth).
  get totalJudgeRuns() {
    return this.snapshot?.totalJudgeRuns ?? 0;
  }

  get hasNoJudgeRuns() {
    return this.totalJudgeRuns === 0;
  }

  get judgeValidationLine() {
    if (this.hasNoJudgeRuns) {
      return "아직 심판 실행이 없습니다 — 먼저 '심판 실행'을 눌러 측정하세요.";
    }
    return this.hasJudgeRunsNeedingValidation
      ? `${this.judgeRunsNeedingValidation}건의 심판 실행이 아직 골든셋으로 검증되지 않았습니다.`
      : `모든 심판 실행(${this.totalJudgeRuns}건)이 검증을 마쳤습니다.`;
  }

  get runsCardClass() {
    // A neutral (shade) box when there is nothing to act on OR nothing has run; warning only when work waits.
    return this.hasJudgeRunsNeedingValidation
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  get judgeRunsButtonVariant() {
    return this.hasJudgeRunsNeedingValidation ? "brand" : "brand-outline";
  }

  // ================================================================ ③ 답변 품질 (RAGAS, 검증 대기)

  get answerRunsNeedingValidation() {
    return this.snapshot?.answerRunsNeedingValidation ?? 0;
  }

  get hasAnswerRunsNeedingValidation() {
    return this.answerRunsNeedingValidation > 0;
  }

  get totalAnswerRuns() {
    return this.snapshot?.totalAnswerRuns ?? 0;
  }

  get hasNoAnswerRuns() {
    return this.totalAnswerRuns === 0;
  }

  get answerValidationLine() {
    if (this.hasNoAnswerRuns) {
      return "아직 답변 품질 실행이 없습니다 — 먼저 '답변 심판 실행'을 눌러 측정하세요.";
    }
    return this.hasAnswerRunsNeedingValidation
      ? `${this.answerRunsNeedingValidation}건의 답변 품질 실행이 아직 사람 표본으로 검증되지 않았습니다.`
      : `모든 답변 품질 실행(${this.totalAnswerRuns}건)이 검증을 마쳤습니다.`;
  }

  get retrievalCardClass() {
    return this.hasAnswerRunsNeedingValidation
      ? "slds-box slds-box_x-small slds-theme_warning slds-m-bottom_medium"
      : "slds-box slds-box_x-small slds-theme_shade slds-m-bottom_medium";
  }

  get retrievalRunsButtonVariant() {
    return "brand-outline";
  }

  get answerRunsButtonVariant() {
    return this.hasAnswerRunsNeedingValidation ? "brand" : "brand-outline";
  }

  // ================================================================ ③ 평가 실행 (run buttons)

  /** True while any leg is running — disables every run button so two launches can never overlap. */
  get isRunning() {
    return this.runningLeg !== "";
  }

  /** True when the callout gate is off, so the three callout-spending legs cannot run in this org. */
  get calloutGateOff() {
    return this.snapshot?.evalEnabled === false;
  }

  /** A callout button is disabled while any run is in flight OR when the eval gate is off. */
  get calloutRunDisabled() {
    return this.isRunning || this.calloutGateOff;
  }

  /** The gate note shown beside the callout buttons when the eval centre is off. */
  get calloutGateNote() {
    return this.calloutGateOff
      ? "평가 센터가 꺼져 있어 콜아웃 실행(심판·검색 재현·정답셋 제안)은 비활성 상태입니다."
      : "";
  }

  /** The disclosure chevron for the pipeline flow — down when expanded, right when collapsed. */
  get flowToggleIcon() {
    return this.flowExpanded ? "utility:chevrondown" : "utility:chevronright";
  }

  /** Assistive-text for the flow toggle, so the control announces its action. */
  get flowToggleAlt() {
    return this.flowExpanded ? "동작 순서 접기" : "동작 순서 펼치기";
  }

  /** Expands/collapses the 5-step pipeline flow diagram. */
  toggleFlow() {
    this.flowExpanded = !this.flowExpanded;
  }

  // ================================================================ 좌측 세로 네비 (leg 선택)

  /**
   * The left-nav GROUPED by verification target: one nav section per group ("① 추출 데이터 품질 …"), each with
   * its leg items, from the shared leg map (c/miEvalLegs). Grouping is what tells a first-time viewer whether a
   * leg checks the extracted DATA, the SEARCH engine, the AI ANSWER, or the AI JUDGE — before they even click.
   * No count badges — the nav is for navigation, and per-leg queue counts live inside each leg block.
   *
   * @returns {Array<object>} Nav groups ({ key, label, items: [{ id, label, icon, selected }] })
   */
  get navGroups() {
    return legGroups(this.selectedLeg);
  }

  /**
   * The current leg's three-line "무엇을 · 어떻게 · 왜" banner data, shown atop every non-intro leg block so a
   * newcomer knows what layer the leg verifies, how the number is derived, and why it matters. Sourced from the
   * shared leg map, so the wording lives in exactly one place.
   *
   * @returns {object} { target, how, why } for the selected leg
   */
  get selectedLegFrame() {
    return LEG(this.selectedLeg);
  }

  get selectedLegTarget() {
    return this.selectedLegFrame.target;
  }

  get selectedLegHow() {
    return this.selectedLegFrame.how;
  }

  get selectedLegWhy() {
    return this.selectedLegFrame.why;
  }

  get hasLegWhy() {
    return !!this.selectedLegFrame.why;
  }

  get isIntro() {
    return this.selectedLeg === "intro";
  }

  get isPrepare() {
    return this.selectedLeg === "prepare";
  }

  get isNumeric() {
    return this.selectedLeg === "numeric";
  }

  /** The search-quality leg (수치 조회 + 문서 검색) — split out of the old combined retrieval leg. */
  get isSearch() {
    return this.selectedLeg === "search";
  }

  /** The AI-answer-quality leg (RAGAS + answer bake-off) — the other half of the old combined retrieval leg. */
  get isAnswer() {
    return this.selectedLeg === "answer";
  }

  get isTrust() {
    return this.selectedLeg === "trust";
  }

  get isFacet() {
    return this.selectedLeg === "facet";
  }

  /** True for every leg except intro — gates the shared "무엇을·어떻게·왜" summary banner. */
  get showLegBanner() {
    return this.selectedLeg !== "intro";
  }

  /**
   * Selects a leg from the left vertical-nav.
   *
   * @param {Event} event The lightning-vertical-navigation select event; detail.name is the leg id
   */
  handleLegSelect(event) {
    this.selectedLeg = event.detail.name;
  }

  // ================================================================ 소개 — 인라인 방법론 (모달 대체)

  /**
   * The full methodology, rendered inline in the intro leg as its OWN always-open card (not a collapsible
   * section and no longer a separate modal). A first-time viewer should not have to hunt for or expand the
   * "무엇을·왜 이렇게 재는지" reference — it is the point of the intro leg.
   */
  get methodologySections() {
    return renderSections("overview");
  }

  handleRunGoldenScoring() {
    this.launchSync("golden", runGoldenScoring, "골든 채점");
  }

  handleRunInvariantCheck() {
    // Async, but zero-callout — so no cost-confirm dialog (unlike launchCallout) and no immediate refresh
    // (unlike launchSync); the batch is still running when the call returns.
    this.launchAsync("invariant", runInvariantCheck, "산술 정합성 검사");
  }

  handleRunJudgeValidation() {
    this.launchSync("judgeValidation", runJudgeValidation, "심판 검증");
  }

  handleRunJudgeAudit() {
    this.launchCallout(
      "judgeAudit",
      runJudgeAudit,
      "LLM 심판 실행",
      "심판은 페이지 범위마다 멀티모달 콜아웃을 1회씩 순차로 소비합니다 — 이 org 에서 가장 비싼 실행입니다. 실행할까요?"
    );
  }

  handleRunRetrievalProbe() {
    this.launchCallout(
      "retrievalProbe",
      runRetrievalProbe,
      "수치 검색 재현 측정",
      "수치 검색 재현은 자동 생성한 질문으로 조회 경로를 시험하며 콜아웃을 소비합니다. 실행할까요?"
    );
  }

  handleRunDocumentRetrievalProbe() {
    this.launchCallout(
      "docRetrievalProbe",
      runDocumentRetrievalProbe,
      "문서 검색 재현 측정",
      "문서 검색 재현은 상위 문서마다 하이브리드 인덱스 검색 콜아웃을 소비합니다. 실행할까요?"
    );
  }

  handleRunGoldenProposal() {
    this.launchCallout(
      "goldenProposal",
      runGoldenProposal,
      "정답셋 제안",
      "정답셋 제안은 페이지마다 멀티모달 콜아웃을 1회씩 소비합니다(결과는 승인 전까지 정답이 아닙니다). 실행할까요?"
    );
  }

  // ============================================================ ⑤ Facet 검증 — 실행 버튼

  handleRunFacetGoldenScoring() {
    // Zero-callout, synchronous — scores extracted facet sets against MI_Facet_Golden__c; refreshes on success.
    this.launchSync("facetGolden", runFacetGoldenScoring, "패싯 골든 채점");
  }

  handleRunFacetJudge() {
    this.launchCallout(
      "facetJudge",
      runFacetJudge,
      "패싯 LLM 심판 실행",
      "패싯 심판은 정답셋이 있는 문서마다 멀티모달 콜아웃을 1회씩 소비합니다. 실행할까요?"
    );
  }

  handleRunFacetJudgeValidation() {
    // Zero-callout — scores the latest facet-judge run against the facet golden set; refreshes on success.
    this.launchSync(
      "facetJudgeValidation",
      runFacetJudgeValidation,
      "패싯 심판 검증"
    );
  }

  handleRunFacetGoldenProposal() {
    this.launchCallout(
      "facetGoldenProposal",
      runFacetGoldenProposal,
      "패싯 정답 제안",
      "패싯 정답 제안은 정답셋이 없는 문서 하나에 멀티모달 콜아웃을 1회 소비합니다(결과는 승인 전까지 정답이 아닙니다). 실행할까요?"
    );
  }

  // ============================================================ ⑤ Answer-quality bake-off (generator compare)

  // The configured answer generators (for the multi-select) and the recent bake-offs (for the "open" list).
  wiredGeneratorsResult;
  answerGenerators = [];
  wiredBakeoffsResult;
  recentBakeoffs = [];
  // The generator keys the user ticked for the next bake-off.
  selectedGeneratorKeys = [];

  @wire(getGenerators)
  wiredGenerators(result) {
    this.wiredGeneratorsResult = result;
    if (result.data) {
      this.answerGenerators = result.data;
    }
  }

  @wire(getRecentBakeoffs, { maxGroups: 5 })
  wiredRecentBakeoffs(result) {
    this.wiredBakeoffsResult = result;
    if (result.data) {
      this.recentBakeoffs = result.data;
    }
  }

  /** @returns {boolean} whether any answer generator is configured */
  get hasGenerators() {
    return this.answerGenerators && this.answerGenerators.length > 0;
  }

  /** @returns {Array} the generator options shaped for lightning-checkbox-group */
  get generatorOptions() {
    return (this.answerGenerators || []).map((g) => ({
      label: `${g.label} (${g.generatorType})`,
      value: g.key
    }));
  }

  /** @returns {boolean} whether there are recent bake-offs to open */
  get hasRecentBakeoffs() {
    return this.recentBakeoffs && this.recentBakeoffs.length > 0;
  }

  /** @returns {Array} recent bake-offs decorated with a short label for the list */
  get decoratedBakeoffs() {
    return (this.recentBakeoffs || []).map((b) => ({
      groupId: b.groupId,
      shortId: b.groupId ? b.groupId.substring(0, 8) : "",
      summary: `답변 방식 ${b.generatorCount}개 · 질문 ${b.questionCount}개`
    }));
  }

  handleGeneratorSelection(event) {
    this.selectedGeneratorKeys = event.detail.value;
  }

  handleRunAnswerJudge() {
    this.launchCallout(
      "answerJudge",
      () => runAnswerJudge({ reportId: null }),
      "답변 품질 판정",
      "답변 품질 판정은 완료된 보고서 섹션마다 텍스트 콜아웃을 1회씩 소비합니다. 실행할까요?"
    );
  }

  handleRunAnswerBakeoff() {
    const keys = this.selectedGeneratorKeys || [];
    this.launchCallout(
      "answerBakeoff",
      () => runAnswerBakeoff({ reportId: null, generatorKeys: keys }),
      "답변 품질 비교 평가",
      "이 비교 평가는 (완료 섹션 × 선택한 답변 생성 방식)마다 생성·채점·순위 콜아웃을 소비합니다 — 가장 비싼 실행입니다. 아무것도 선택하지 않으면 설정된 모든 방식을 비교합니다. 실행할까요?"
    );
  }

  handleOpenBakeoff(event) {
    const groupId = event.currentTarget.dataset.group;
    if (!groupId) {
      return;
    }
    // Show the comparison inline on this page (the LWC is embedded below the launcher).
    this.openBakeoffGroupId = groupId;
  }

  // The bake-off group currently shown in the embedded comparison component (null = none open).
  openBakeoffGroupId;

  /** @returns {boolean} whether a bake-off comparison is open */
  get hasOpenBakeoff() {
    return !!this.openBakeoffGroupId;
  }

  /**
   * Runs a zero-callout leg: launches it, toasts the result message, and refreshes the dashboard so the figures
   * the run just changed show without a manual reload.
   *
   * @param {string} leg The leg key, tracked in runningLeg to disable the buttons
   * @param {Function} apexFn The imperative Apex method to call
   * @param {string} title The leg's Korean name, used in the toast title
   */
  async launchSync(leg, apexFn, title) {
    if (this.isRunning) {
      return;
    }
    this.runningLeg = leg;
    try {
      const result = await apexFn();
      this.toastResult(title, result);
      if (result?.launched) {
        // Refresh both the dashboard figures and the forward-looking prediction the run just moved.
        await Promise.all([
          refreshApex(this.wiredResult),
          refreshApex(this.wiredPredictionResult)
        ]);
      }
    } catch (error) {
      this.toastError(title, error);
    } finally {
      this.runningLeg = "";
    }
  }

  /**
   * Runs a callout-spending leg: confirms the cost first, then launches asynchronously. The dashboard is NOT
   * refreshed here because the batch is still running when the call returns — the toast tells the user to
   * refresh once it finishes.
   *
   * @param {string} leg The leg key, tracked in runningLeg to disable the buttons
   * @param {Function} apexFn The imperative Apex method to call
   * @param {string} title The leg's Korean name, used in the confirm and toast
   * @param {string} confirmMessage The cost warning shown in the confirmation dialog
   */
  async launchCallout(leg, apexFn, title, confirmMessage) {
    if (this.isRunning || this.calloutGateOff) {
      return;
    }
    const proceed = await LightningConfirm.open({
      label: `${title} 실행 확인`,
      message: confirmMessage,
      theme: "warning"
    });
    if (!proceed) {
      return;
    }
    this.runningLeg = leg;
    try {
      const result = await apexFn();
      this.toastResult(title, result);
    } catch (error) {
      this.toastError(title, error);
    } finally {
      this.runningLeg = "";
    }
  }

  /**
   * Runs an async but ZERO-callout leg (the arithmetic invariant batch): no cost-confirm dialog — it spends
   * nothing — but also no immediate refresh, because the batch is still running when the call returns. The
   * toast tells the user to refresh once it finishes, exactly like the callout legs.
   *
   * @param {string} leg The leg key, tracked in runningLeg to disable the buttons
   * @param {Function} apexFn The imperative Apex method to call
   * @param {string} title The leg's Korean name, used in the toast title
   */
  async launchAsync(leg, apexFn, title) {
    if (this.isRunning) {
      return;
    }
    this.runningLeg = leg;
    try {
      const result = await apexFn();
      this.toastResult(title, result);
    } catch (error) {
      this.toastError(title, error);
    } finally {
      this.runningLeg = "";
    }
  }

  /**
   * Toasts a LaunchResult: success when a run started, warning when the gate blocked it, info when nothing was
   * eligible.
   *
   * @param {string} title The leg's Korean name
   * @param {object} result The LaunchResult from the controller
   */
  toastResult(title, result) {
    let variant = "info";
    if (result?.gateBlocked) {
      variant = "warning";
    } else if (result?.launched) {
      variant = "success";
    }
    this.dispatchEvent(
      new ShowToastEvent({
        title,
        message: result?.message || "",
        variant
      })
    );
  }

  /**
   * Toasts a caught error, surfacing only the server message (never a stack trace).
   *
   * @param {string} title The leg's Korean name
   * @param {object} error The caught error
   */
  toastError(title, error) {
    this.dispatchEvent(
      new ShowToastEvent({
        title: `${title} 실패`,
        message:
          error?.body?.message || error?.message || "실행하지 못했습니다.",
        variant: "error"
      })
    );
  }

  // ================================================================ 포맷 / 파생 헬퍼

  /**
   * Whether a numeric value was actually measured (present), as opposed to null/undefined — the distinction
   * every metric tile turns on, since a measured 0 and an unmeasured metric mean opposite things.
   *
   * @param {number} value The stored value
   * @returns {boolean} True when the value is present
   */
  isMeasured(value) {
    return value !== null && value !== undefined;
  }

  /**
   * A stored rate as a percentage string, or an explicit "측정 안 됨" — never a bare 0%, which would assert a
   * failure nobody observed.
   *
   * @param {number} rate The stored rate (0..1), possibly null/undefined
   * @returns {string} The display string
   */
  formatPercent(rate) {
    if (!this.isMeasured(rate)) {
      return "측정 안 됨";
    }
    return `${(rate * 100).toFixed(1)}%`;
  }

  /**
   * A stored ratio-like number to three decimals (MRR, kappa), or "측정 안 됨".
   *
   * @param {number} value The stored value, possibly null/undefined
   * @returns {string} The display string
   */
  formatDecimal(value) {
    if (!this.isMeasured(value)) {
      return "측정 안 됨";
    }
    return value.toFixed(3);
  }

  /**
   * A credible-interval range as a percentage bracket, or "" when either bound is unmeasured (the caller hides
   * the interval line entirely rather than showing a half-open range).
   *
   * @param {number} lower The lower bound (0..1)
   * @param {number} upper The upper bound (0..1)
   * @returns {string} The display string
   */
  formatInterval(lower, upper) {
    if (!this.isMeasured(lower) || !this.isMeasured(upper)) {
      return "";
    }
    // "신용구간(credible interval)": the bound is a Bayesian Beta-posterior credible interval, not a
    // frequentist confidence interval. The 94% mass matches the Apex MI_BetaPosterior default (0.94).
    return `94% 신용구간 [${(lower * 100).toFixed(1)}% – ${(upper * 100).toFixed(1)}%]`;
  }

  /**
   * Whether a leg has enough run history to draw a meaningful trend line (at least two measured points). A
   * single point is not a trend, so the tile shows a "run 부족" note instead of a misleading flat line.
   *
   * @param {Array} trend The leg's TrendPoint list from the snapshot
   * @returns {boolean} True when there are two or more points
   */
  hasTrend(trend) {
    return Array.isArray(trend) && trend.length >= 2;
  }

  /**
   * Builds a c/miReportChartConfig line-chart spec from a leg's TrendPoint list, so the shared chart builder
   * (the same one the report viewer uses) renders the sparkline. Returns null when there is not enough
   * history, in which case the template renders the "run 부족" note instead of the chart.
   *
   * @param {string} seriesName The metric's name, shown as the series label
   * @param {Array} trend The leg's TrendPoint list ({ pointLabel, value })
   * @returns {object|null} A chart spec, or null when there are fewer than two points
   */
  trendSpec(seriesName, trend) {
    if (!this.hasTrend(trend)) {
      return null;
    }
    return {
      type: "line",
      title: "",
      labels: trend.map((p) => p.pointLabel),
      series: [{ name: seriesName, values: trend.map((p) => p.value) }]
    };
  }

  // ================================================================ 이동 버튼

  handleOpenDocuments() {
    this.navigateToObjectHome("Market_Insight_Document__c");
  }

  handleOpenPendingProposals() {
    this.navigateToListView(
      "MI_Tabular_Golden_Row__c",
      "Pending_LLM_Proposals"
    );
  }

  handleOpenNeedsTriage() {
    this.navigateToListView("MI_Tabular_Eval_Verdict__c", "Needs_Human_Triage");
  }

  handleOpenViolations() {
    this.navigateToListView("MI_Tabular_Eval_Invariant__c", "Violations");
  }

  /**
   * Opens one Invariant run's record, from a per-run line's "실행 열기" button — so a reviewer can see exactly
   * which figures that single run flagged, rather than the pooled list of every run's violations.
   *
   * @param {Event} event The click event; its currentTarget carries data-run-id (the run record Id)
   */
  handleOpenInvariantRun(event) {
    const runId = event.currentTarget.dataset.runId;
    if (!runId) {
      return;
    }
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: runId,
        objectApiName: "MI_Tabular_Eval_Run__c",
        actionName: "view"
      }
    });
  }

  handleOpenGoldenScoring() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Golden_Scoring");
  }

  handleOpenJudgeRuns() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Judge_Runs");
  }

  // Document (hybrid-index) retrieval runs — Run_Type=Retrieval_Probe.
  handleOpenRetrievalRuns() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Retrieval_Runs");
  }

  // Numeric (SOQL figure-lookup) retrieval runs — Run_Type=Probe. A dedicated list so the 수치 card no longer
  // links to the document-retrieval list (the two are different search paths over different populations).
  handleOpenNumericProbeRuns() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Numeric_Probe_Runs");
  }

  handleOpenAnswerEvalRuns() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Answer_Eval_Runs");
  }

  /** Opens the facet golden set — the Pending_LLM_Proposals view when proposals await, else the full set. */
  handleOpenFacetGolden() {
    this.navigateToListView(
      "MI_Facet_Golden__c",
      this.hasPendingFacetProposals ? "Pending_LLM_Proposals" : "All"
    );
  }

  handleOpenFacetRuns() {
    this.navigateToListView("MI_Tabular_Eval_Run__c", "Facet_Runs");
  }

  /**
   * Jumps to an object's default (All) list view.
   *
   * @param {string} objectApiName The object to open
   */
  navigateToObjectHome(objectApiName) {
    this[NavigationMixin.Navigate]({
      type: "standard__objectPage",
      attributes: {
        objectApiName,
        actionName: "list"
      },
      state: {
        filterName: "All"
      }
    });
  }

  /**
   * Jumps directly to a named, pre-filtered list view — this is what lets a card's button land the user on
   * exactly the queue the card's live count describes, not a generic object landing page.
   *
   * @param {string} objectApiName The object the list view belongs to
   * @param {string} listViewApiName The list view's developer name
   */
  navigateToListView(objectApiName, listViewApiName) {
    this[NavigationMixin.Navigate]({
      type: "standard__objectPage",
      attributes: {
        objectApiName,
        actionName: "list"
      },
      state: {
        filterName: listViewApiName
      }
    });
  }
}
