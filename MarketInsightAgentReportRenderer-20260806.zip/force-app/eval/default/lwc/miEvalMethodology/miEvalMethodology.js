/**
 * The evaluation methodology as DATA, plus a render helper. Previously this lived in the
 * `miEvalMethodologyModal` LightningModal that the home page opened on a button click; the modal was removed
 * because a separate overlay only lengthened the path to content that belongs on the page itself. The copy is
 * unchanged — it now renders INLINE (a collapsible section in the intro tab shows the full overview, and each
 * leg block shows its own relevant sections), so this module holds the sections and a helper that maps a list
 * of section keys to render-ready blocks.
 *
 * WHY DATA, NOT MARKUP. Keeping each section's copy here (rather than hand-written per consumer) lets the
 * intro's full overview and a leg block's per-leg slice share the same words without duplication — the
 * template just renders whichever slice `renderSections(keys)` returns.
 *
 * Import as `c/miEvalMethodology`: `import { renderSections, VIEWS } from "c/miEvalMethodology";`.
 * Rich strings use <strong>/<code>/<em> and render through lightning-formatted-rich-text. Every <strong> tag
 * carries its surrounding spaces here (JS string whitespace is preserved verbatim), which is exactly why the
 * copy was kept as strings rather than inlined into the template, where newline-adjacent tags glue words.
 */

// The methodology, one entry per item. Each block is { kind, ... }: 'para'/'callout'/'note' carry `html`,
// 'list'/'steps' carry `items` (rich strings), 'grade' carries `title` + `html`.
const SECTIONS = [
  {
    key: "overview",
    title: "한눈에: 무엇을, 왜 재나요",
    blocks: [
      {
        kind: "para",
        html: "이 앱은 문서에서 자동으로 뽑아낸 <strong>숫자(매출·점유율 같은 표 안의 정량 수치)</strong>가 두 가지 기준을 만족하는지 확인합니다."
      },
      {
        kind: "list",
        items: [
          "<strong>정확한가</strong> — 뽑아낸 숫자가 원본 문서의 숫자와 같은가.",
          "<strong>빠짐없이 뽑았는가</strong> — 원본에 있는 숫자를 놓치지 않았는가."
        ]
      },
      {
        kind: "para",
        html: '"AI가 뽑았으니 믿는다"가 아니라, <strong>사람이 검수한 정답과 대조해서 실제로 맞는지 수치로 증명</strong>하는 것이 이 앱의 목적입니다. 그래서 성격이 다른 여러 방법을 겹쳐 씁니다 — 하나가 못 보는 오류를 다른 하나가 잡도록.'
      },
      {
        kind: "steps",
        items: [
          "<strong>문서 업로드</strong> — 검증할 원본 문서를 등록합니다.",
          "<strong>숫자 추출</strong> — 표 안의 수치를 자동으로 읽어 저장합니다(<code>Market_Insight_Tabular__c</code>).",
          "<strong>평가 실행</strong> — 아래 여러 방법으로 그 숫자를 검증합니다.",
          "<strong>골든셋 대조 채점</strong> — 사람이 검수한 정답을 기준으로 점수를 매깁니다.",
          "<strong>사람의 확인</strong> — 애매한 판정을 사람이 분류하고, AI 정답 후보를 승인합니다."
        ]
      }
    ]
  },
  {
    key: "golden",
    title: "골든셋 — 모든 점수의 기준점 (정의상 참)",
    blocks: [
      {
        kind: "para",
        html: "사람이 원본 문서를 직접 펼쳐 한 줄 한 줄 검수해 만든 정답입니다. 사람이 확인한 값이므로 <strong>정의상 옳다</strong>고 봅니다. 다른 모든 점수는 결국 이 골든셋과 비교해서 나오므로, 골든셋이 이 평가 전체의 <strong>기준점(anchor)</strong>입니다."
      },
      {
        kind: "note",
        html: '골든셋을 만드는 데는 문서 한 건당 1~2시간이 듭니다. 그래서 전부가 아니라 <strong>사람이 실제로 검수한 페이지</strong>에 한해 점수를 내고, 그 범위를 항상 함께 표시합니다(아래 "측정 범위").'
      }
    ]
  },
  {
    key: "invariant",
    title: "산술 정합성 검사 — 숫자끼리 아귀가 맞는지",
    blocks: [
      {
        kind: "para",
        html: "AI를 부르지 않고, 저장된 숫자들 사이의 <strong>계산이 맞아떨어지는지</strong>만 확인하는 검사입니다. 예를 들면:"
      },
      {
        kind: "list",
        items: [
          "<strong>합계</strong> — 부문별 매출을 더하면 전체 매출과 같은가.",
          "<strong>분기 합</strong> — 1~4분기를 더하면 연간 값과 같은가.",
          "<strong>전년 대비(YoY)</strong> — 올해·작년 값으로 다시 계산한 증가율이 표에 적힌 증가율과 같은가.",
          '<strong>단위 배율</strong> — 같은 값이 "백만" 단위와 "억" 단위에서 앞뒤가 맞는가.'
        ]
      },
      {
        kind: "callout",
        html: '<strong>계산이 안 맞으면</strong> → 그 숫자 중 적어도 하나는 <strong>확실히 틀렸습니다.</strong> (부품을 더한 값이 합계와 다르면 어딘가는 반드시 잘못된 것이니까요.)<br /><br /><strong>계산이 맞아도</strong> → "다 옳다"는 뜻은 <strong>아닙니다.</strong> 무관한 두 숫자가 우연히 맞을 수도 있고, 아무도 대조하지 않는 외톨이 숫자는 이 검사만으로는 검증되지 않기 때문입니다.'
      },
      {
        kind: "para",
        html: '그래서 이 검사 결과는 "정확도 몇 %"가 아니라 <strong>"모순이 몇 건 발견됐다"</strong>로 읽어야 합니다. 통과율이 높다는 건 "지금까지 눈에 띈 모순은 없다"는 뜻이지, "모두 정답"이라는 보증이 아닙니다. 진짜 정확도는 골든셋으로만 나옵니다.'
      }
    ]
  },
  {
    key: "judge",
    title: "LLM 심판 — 그리고 왜 바로 믿지 않는가",
    blocks: [
      {
        kind: "para",
        html: '사람이 검수하지 못한 페이지까지 넓히려면 결국 AI(LLM)에게 채점을 맡겨야 합니다. 문제는, AI의 채점 결과는 <strong>진짜 측정값처럼 보이지만 사실은 "의견"</strong>이라는 점입니다 — 얼마나 자주 틀리는지 알기 전까지는요.'
      },
      {
        kind: "para",
        html: "그래서 이 앱은 <strong>심판을 바로 쓰지 않고 먼저 시험을 칩니다.</strong> 사람이 만든 골든셋(정답이 확실한 문제지)으로 AI 심판을 채점하는 겁니다. 여기서 두 가지를 봅니다:"
      },
      {
        kind: "list",
        items: [
          '<strong>정밀도</strong> — AI가 "틀렸다"고 지적한 것들 중 실제로 골든셋이 틀렸다고 확인해 주는 비율. 낮으면 AI가 <strong>멀쩡한 숫자를 자꾸 오답 처리</strong>해 사람을 헛수고하게 만듭니다.',
          "<strong>합성 오류 탐지(민감도)</strong> — 일부러 심어 둔 가짜 오류를 AI가 몇 개나 잡는가. AI가 <strong>침묵할 때(지적 안 할 때) 그게 의미 있는지</strong>를 이걸로만 알 수 있습니다."
        ]
      },
      {
        kind: "callout",
        html: '<strong>0.8 게이트:</strong> 골든셋 대비 정밀도가 <strong>0.8(80%) 이상</strong>으로 검증되기 전까지, AI 심판이 낸 숫자는 <strong>"미검증"</strong>으로 표시하고 단독 근거로 쓰지 않습니다. 시험을 통과한 심판만 정식으로 인용합니다.'
      },
      {
        kind: "note",
        html: "kappa(사람-AI 일치도)도 함께 기록하지만 <strong>보조용</strong>입니다 — 사람과 AI가 <em>똑같이 틀리면</em> 일치도는 오히려 높게 나오므로 정밀도를 대신할 수 없습니다."
      }
    ]
  },
  {
    key: "verdict",
    title: "판정(Verdict) — 그리고 실행(Run)과의 관계",
    blocks: [
      {
        kind: "para",
        html: "<strong>판정</strong>은 심판이 숫자 하나를 볼 때마다 남기는 결과입니다. 한 판정 레코드에는 AI 심판의 의견·골든셋 정답·사람의 최종 판단이 <strong>나란히</strong> 담겨, 심판 자체가 얼마나 믿을 만한지를 재는 근거가 됩니다."
      },
      {
        kind: "callout",
        html: '<strong>실행(Run)과 판정(Verdict)의 관계:</strong> "평가 실행"(<code>MI_Tabular_Eval_Run__c</code>) 한 건이 <strong>부모</strong>이고, 그 실행이 숫자마다 남긴 <strong>판정</strong>(<code>MI_Tabular_Eval_Verdict__c</code>)이 <strong>자식</strong>입니다(1 : N, master-detail). 즉 판정은 반드시 어떤 실행 하나에 속하며, 실행을 지우면 그 판정들도 함께 사라집니다. 실행에는 집계 수치(정밀도·재현율 등)가, 판정에는 개별 숫자 하나에 대한 판단이 담깁니다.'
      },
      {
        kind: "para",
        html: 'AI가 "일치"로 보지 않은 애매한 판정은 <strong>사람이 직접 분류</strong>합니다(전용 화면 없이 목록에서 바로 인라인 편집). 이 분류가 다시 심판 검증의 재료가 됩니다. 판정은 문서로의 링크도 따로 가져, 문서별 정확도 카드가 "이 문서의 최신 실행" 판정을 찾을 수 있습니다.'
      }
    ]
  },
  {
    key: "retrieval",
    title: "검색 재현 — 질문이 올바른 수치를 찾아오는가",
    blocks: [
      {
        kind: "para",
        html: '앞의 항목들이 "뽑아낸 숫자가 정확한가"였다면, 이 검사는 <strong>사용자의 자연어 질문이 그 숫자를 제대로 찾아오는가</strong>를 봅니다. 사용자가 "작년 3분기 매출 얼마야?"라고 물었을 때 시스템이 저장된 정답 행을 실제로 집어오는지를 재는 것입니다.'
      },
      {
        kind: "callout",
        html: "여기서 시험하는 것은 <strong>정형 수치 조회 경로(SOQL 기반)</strong>입니다 — 에이전트가 정확한 숫자를 답할 때 쓰는 바로 그 조회 방식입니다. 문서를 통째로 찾아오는 의미 검색(하이브리드 인덱스)과는 다른 경로이니 혼동하지 마세요."
      },
      {
        kind: "para",
        html: "<strong>① 입력 — 질문 자동 생성.</strong> 이미 저장된 실제 수치 행(Actual 값)을 골라, 그 행을 정답으로 삼는 질문을 자동으로 만듭니다. 정답이 처음부터 정해져 있어(<strong>known-item</strong>) 채점이 편향되지 않습니다. 한 행에서 다섯 가지 방식의 질문을 만듭니다:"
      },
      {
        kind: "list",
        items: [
          "<strong>Structured</strong> — 저장된 용어 그대로(엔터티+지표+기간). 대조군.",
          "<strong>Natural</strong> — 사람이 쓰는 자연스러운 한국어 문장.",
          "<strong>Synonym</strong> — 지표 이름을 동의어로 바꿔서(예: 매출 ↔ 매출액).",
          '<strong>Relative_Period</strong> — 기간을 상대 표현으로(예: "2024-Q3" 대신 "작년 3분기").',
          "<strong>Adjacent_Negative</strong> — 딱 한 분기만 물어, 이웃 분기가 새어 들어오는지 확인."
        ]
      },
      {
        kind: "para",
        html: '여기에 <strong>Negative(빈 결과) 질문</strong>도 섞습니다. 실제 엔터티·지표에 "1995-Q1"처럼 존재할 수 없는 기간을 붙인 것으로, 미리 SOQL로 "정말 0건"임을 확인한 뒤 씁니다. 이 질문은 <strong>아무것도 반환하지 않아야 정답</strong>입니다(없는 걸 지어내면 안 되니까).'
      },
      {
        kind: "para",
        html: "<strong>② 과정 — 최대 3번 재질의.</strong> 질문마다, 실제 사용자가 하듯 <strong>최대 3번까지</strong> 각도를 바꿔가며 조회합니다(1번째 그대로 → 2번째 한글 라벨↔영문 키 교체 → 3번째 기간을 연도로 넓히거나 엔터티 제거). 정답 행이 나오면 그 시점에 멈춥니다. 이는 실제 에이전트의 3회 재시도 동작을 그대로 흉내 낸 것입니다."
      },
      {
        kind: "para",
        html: '<strong>③ 결과 — 지표.</strong> 긍정 질문과 부정 질문은 따로 집계합니다(부정을 섞으면 "아무것도 안 답하기"가 점수를 올려버리므로):'
      },
      {
        kind: "list",
        items: [
          "<strong>Recall@1</strong> — <em>첫 시도</em>에 바로 정답 행이 1등으로 나온 비율(재질의로 겨우 찾은 건 여기선 실패로 셈).",
          "<strong>Recall@5 / @10</strong> — 어느 시도에서든 정답이 상위 5·10건 안에 든 비율.",
          "<strong>3회 재현율</strong> — 3번까지 써서 결국 찾은 비율. 실제 사용자 경험에 가장 가까운 값이라 Recall@1과 나란히 봅니다.",
          "<strong>MRR</strong> — 정답이 평균 몇 번째로 나왔는지(1등이면 1, 2등이면 0.5…).",
          "<strong>부정 질문 통과율</strong> — 빈 결과여야 할 질문에 실제로 아무것도 안 답한 비율(환각·과다매칭 저항력).",
          "표본이 적을 때를 대비해 94% 신뢰구간도 함께 냅니다."
        ]
      }
    ]
  },
  {
    key: "docretrieval",
    title: "문서 검색 재현 — 하이브리드 인덱스가 맞는 문서를 찾아오는가",
    blocks: [
      {
        kind: "para",
        html: '앞의 <strong>수치 검색 재현</strong>이 "저장된 숫자 한 개를 SOQL로 정확히 집어오는가"였다면, 이 검사는 다른 경로를 봅니다 — 사용자의 질문으로 <strong>하이브리드(의미+키워드) 검색 인덱스</strong>를 돌렸을 때, 의도한 <strong>문서</strong>가 결과에 들어오는가입니다. 숫자 조회가 아니라 <strong>문서 단위 검색</strong>의 성능입니다.'
      },
      {
        kind: "para",
        html: '<strong>① 입력.</strong> 문서마다 그 문서의 요약·주제(facet)에서 "이 문서를 가리키는 질문"을 자동으로 만듭니다(자연어·동의어·본문 인용 등). 여기에도 존재하지 않는 주제를 물어 <strong>아무 문서도 나오면 안 되는</strong> 부정 질문을 섞습니다.'
      },
      {
        kind: "para",
        html: "<strong>② 과정.</strong> 각 질문으로 실제 그라운딩 검색(<code>hybrid_search()</code>)을 호출하고, 돌아온 <strong>문서 목록</strong>에 정답 문서가 몇 번째로 들어왔는지 확인합니다. 여러 인덱스를 나란히 비교(A/B)할 수도 있습니다."
      },
      {
        kind: "para",
        html: '<strong>③ 결과.</strong> 지표는 수치 검색 재현과 같은 형태입니다 — Recall@1/5/10, MRR, 부정 질문 통과율, 94% 신뢰구간. 다만 "맞았다"의 기준이 <strong>수치 행</strong>이 아니라 <strong>문서</strong>라는 점이 다릅니다.'
      },
      {
        kind: "note",
        html: "두 검색 재현은 같은 실행 객체·같은 지표 필드를 쓰고 <code>Run_Type__c</code>로만 구분됩니다(수치=<strong>Probe</strong>, 문서=<strong>Retrieval_Probe</strong>). 그래서 대시보드도 별도 타일·별도 실행 버튼으로 나눠 두었습니다."
      }
    ]
  },
  {
    key: "ragas",
    title: "답변 품질 (RAGAS Faithfulness) — 생성된 답변이 근거에 충실한가",
    blocks: [
      {
        kind: "para",
        html: '검색 재현이 "올바른 숫자를 찾아오는가"였다면, 이 검사는 그렇게 찾은 근거로 <strong>실제 생성된 답변이 지어내지 않고 근거에 충실한가</strong>를 봅니다. RAGAS의 <strong>Faithfulness(근거성)</strong> 개념을 씁니다.'
      },
      {
        kind: "para",
        html: "<strong>① 입력.</strong> 지금은 완료된 <strong>보고서 섹션</strong>을 대상으로 합니다. 섹션마다 세 가지를 묶습니다 — 질문(섹션 제목·주제), 답변(생성된 본문), 근거(그 본문을 만들 때 실제로 찾아온 자료). 셋이 모두 있는 섹션만 채점합니다. (에이전트 대화 Q&A를 직접 채점하는 것은 다음 단계로 예정돼 있습니다.)"
      },
      {
        kind: "para",
        html: "<strong>② 과정.</strong> 섹션 하나당 AI를 한 번 호출해, 답변을 <strong>낱개의 사실 주장으로 쪼갠 뒤</strong> 주장마다 근거에 비춰 판정합니다 — <strong>Grounded</strong>(근거 있음) / <strong>Ungrounded</strong>(근거 없음) / <strong>Unverifiable</strong>(확인 불가). 답변 전체에 대한 관련성(질문에 답했는가) 판정도 따로 냅니다."
      },
      {
        kind: "callout",
        html: 'AI가 자기 말을 스스로 못 믿게 하는 장치가 있습니다 — <strong>"근거 없음"이라 지적하면서 원문 인용을 못 대면</strong>, 그 지적은 <strong>Unverifiable로 강등</strong>됩니다. 근거 없는 비난이 점수를 깎지 못하게 하는 것입니다.'
      },
      {
        kind: "para",
        html: '<strong>③ 결과 — Faithfulness 점수.</strong> <strong>근거 있는 주장 ÷ (근거 있는 주장 + 근거 없는 주장)</strong>입니다. 핵심은 <strong>Unverifiable(확인 불가) 주장은 분자·분모 양쪽에서 모두 뺀다</strong>는 점 — 확인 못 한 것으로 점수를 올리지도 내리지도 않습니다. 그래서 분모(판정 가능한 전체 주장 수)를 항상 함께 보여줍니다. "3개 중 3개(100%)"와 "1000개 중 1000개(100%)"는 같은 100%라도 신뢰도가 전혀 다르니까요. 분모가 0이면 0%가 아니라 "측정 안 됨"으로 남깁니다.'
      },
      {
        kind: "callout",
        html: '이 판정도 AI가 하므로, 답변 심판이 사람 표본으로 검증(정밀도 0.8 이상)되기 전엔 단독으로 제시하지 않습니다. 특히 Faithfulness 점수의 <strong>신뢰 상한은 심판의 재현율</strong>입니다 — 심판이 놓친 "근거 없는 주장"은 겉보기엔 근거 있는 주장과 구분되지 않아, 점수가 심판 자신의 재현율보다 더 정확할 수는 없기 때문입니다.'
      }
    ]
  },
  {
    key: "run",
    title: '"평가 실행"이란 무엇인가',
    blocks: [
      {
        kind: "para",
        html: '위 방법들을 <strong>한 번 돌린 결과 묶음</strong>이 "평가 실행" 레코드(<code>MI_Tabular_Eval_Run__c</code>) 한 건입니다. 어떤 방법을 돌렸는지는 <code>Run_Type__c</code> 값으로 구분합니다:'
      },
      {
        kind: "list",
        items: [
          "<strong>Golden</strong> (골든 채점) — 추출 숫자를 사람 정답(골든셋)과 대조해 정밀도·재현율·F1을 냅니다. 가장 믿을 수 있는 정확도. AI 호출 없음.",
          "<strong>Invariant</strong> (산술 정합성 검사) — 저장된 숫자끼리 계산이 맞는지 따져 모순을 찾습니다. AI 호출 없음.",
          "<strong>Judge</strong> (LLM 심판) — 사람이 못 본 페이지까지 AI가 채점해 커버리지를 넓힙니다. AI 호출 소비.",
          "<strong>Judge_Validation</strong> (심판 검증) — 그 AI 심판이 얼마나 정확한지 골든셋으로 되채점합니다(0.8 게이트). AI 호출 없음.",
          '<strong>Probe</strong> (검색 재현) — 자연어 질문이 저장된 수치를 SOQL로 제대로 찾아오는지(Recall·MRR)를 잽니다. "검색 재현 실행" 버튼이 만드는 실행. AI 호출 소비.',
          "<strong>Retrieval_Probe</strong> (문서 검색 재현) — 위와 별개로, 하이브리드(의미) 인덱스가 원하는 문서를 가져오는지를 잽니다.",
          "<strong>Answer_Judge</strong> (답변 품질) — 생성된 답변이 근거에 충실한지(RAGAS Faithfulness)를 AI로 판정합니다. AI 호출 소비.",
          "<strong>Answer_Judge_Validation</strong> (답변 심판 검증) — 그 답변 심판을 사람 표본으로 검증합니다.",
          "<strong>Golden_Proposal</strong> (정답셋 제안) — 정답셋이 없는 문서에서 AI가 정답 후보를 제안합니다(승인 전까지 정답 아님). AI 호출 소비.",
          "<strong>Replicate</strong> — 같은 문서를 여러 번 추출해 결과가 재현되는지 확인하는 내부 진단용. 대시보드에는 나오지 않습니다."
        ]
      },
      {
        kind: "callout",
        html: "한 번의 실행(Run)은 숫자마다 하나씩 <strong>판정(Verdict)</strong>을 자식으로 낳습니다(1 : N). 대시보드 타일 수치는 각 종류의 <strong>가장 최근 실행</strong>에서 온 값이고, 실행을 다시 하면 새 레코드가 쌓여 타일이 최신 값으로 갱신됩니다."
      },
      {
        kind: "para",
        html: "콜아웃(AI 호출)이 없는 <strong>골든 채점·산술 검사·심판 검증</strong>은 눌러서 즉시 돌릴 수 있고, AI를 부르는 <strong>LLM 심판·검색 재현·정답셋 제안</strong>은 비용이 들어 실행 전에 한 번 더 확인을 거칩니다."
      }
    ]
  },
  {
    key: "facet",
    title: "패싯 데이터 검증 — 자동 생성한 문서 속성이 정확한가",
    blocks: [
      {
        kind: "para",
        html: "문서를 업로드하면 시스템이 그 문서의 <strong>회사·산업·지역·기준일</strong> 같은 속성(패싯)을 자동으로 뽑아 검색·필터에 씁니다. 이 검사는 그 자동 생성 패싯이 <strong>사람이 확인한 정답 집합</strong>과 맞는지를 봅니다."
      },
      {
        kind: "para",
        html: "채점 방식은 수치 골든셋과 같습니다 — 사람 정답(<code>MI_Facet_Golden__c</code>)과 대조해 <strong>정밀도·재현율·F1</strong>을 내고, 정답이 없는 <strong>요약(Abstract)</strong>은 LLM 심판의 <strong>Faithfulness</strong>로만 평가합니다. 심판 수치는 여기서도 골든셋 검증(정밀도 0.8 이상) 전까지 참고용입니다."
      }
    ]
  },
  {
    key: "scope",
    title: "숫자를 읽을 때 함께 보는 것",
    blocks: [
      {
        kind: "list",
        items: [
          '<strong>측정 범위(커버리지)</strong> — 모든 점수는 "어떤 형식·어떤 문서·몇 건"을 대상으로 쟀는지와 함께 표시됩니다. 범위 밖(예: 차트·이미지 속 숫자)은 "측정 안 됨"으로 명시합니다.',
          "<strong>신뢰구간</strong> — 표본이 적으면 정확도가 높아도 값이 흔들릴 수 있어, 값 옆에 있음직한 범위(94% 신뢰구간)를 함께 보여줍니다.",
          '<strong>측정 안 됨 ≠ 0%</strong> — 아직 한 번도 재지 않은 항목은 "측정 안 됨"으로 표시합니다. "0점"(재봤더니 0점)과는 전혀 다른 뜻입니다.'
        ]
      }
    ]
  }
];

// The section keys shown, in order, per leg — so a leg block's inline help is self-contained and relevant.
// `overview` is the full methodology in order (the intro tab's inline help).
const VIEWS = {
  overview: SECTIONS.map((s) => s.key),
  prepare: ["golden", "run"],
  numeric: ["golden", "invariant", "scope"],
  // The old combined `retrieval` view was split, matching the leg split (search engine vs. generated answer).
  search: ["retrieval", "docretrieval"],
  answer: ["ragas"],
  // Kept for any caller still passing the old key, so it degrades to the search+answer union rather than the
  // full overview fallback.
  retrieval: ["retrieval", "docretrieval", "ragas"],
  trust: ["judge", "verdict"],
  facet: ["facet"]
};

/**
 * One raw content block normalized into a render-ready block with kind-flags and keyed list items (LWC
 * for:each cannot call a method per item, so the flags are precomputed).
 *
 * @param {object} block The raw block ({ kind, html | items | title })
 * @param {number} index The block's position, used to mint a stable key
 * @returns {object} The render-ready block
 */
function renderBlock(block, index) {
  return {
    key: `${block.kind}-${index}`,
    isPara: block.kind === "para",
    isList: block.kind === "list",
    isSteps: block.kind === "steps",
    isCallout: block.kind === "callout",
    isNote: block.kind === "note",
    isGrade: block.kind === "grade",
    html: block.html,
    title: block.title,
    items: (block.items || []).map((html, i) => ({
      key: `${index}-${i}`,
      html
    }))
  };
}

/**
 * The render-ready sections for a view key (or an explicit list of section keys). An unknown key falls back
 * to the full overview rather than an empty result.
 *
 * @param {string|Array<string>} view A VIEWS key (e.g. "numeric") or an array of section keys
 * @returns {Array<object>} The sections to render, in order, each with keyed render-ready blocks
 */
function renderSections(view) {
  const keys = Array.isArray(view) ? view : VIEWS[view] || VIEWS.overview;
  return keys
    .map((key) => SECTIONS.find((s) => s.key === key))
    .filter(Boolean)
    .map((section) => ({
      key: section.key,
      title: section.title,
      blocks: section.blocks.map((block, i) => renderBlock(block, i))
    }));
}

export { SECTIONS, VIEWS, renderSections };
