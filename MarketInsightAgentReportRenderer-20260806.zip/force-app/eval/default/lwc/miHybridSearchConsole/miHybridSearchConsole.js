import { LightningElement, track } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import search from "@salesforce/apex/MI_HybridSearchController.search";

/**
 * The Hybrid Search console on the Market Insight Quality app. A reviewer types a query and sees exactly what
 * the agent's grounding search returns from the live index — the same MI_HybridGroundingSearchAction the report
 * pipeline and the Coworker ground on. This is a diagnostic tool: the retrieval and faithfulness numbers on the
 * Home dashboard are measurements OF this index, and this console lets a reviewer watch a real query come back.
 *
 * It runs the query against EVERY registered search index (each an MI_Eval_Search_Index__mdt record) at once
 * and lays the results out in COLUMNS, one per index, so a reviewer can compare them directly — does the new
 * index retrieve the intended document where the old one misses it? Adding or removing an index is a CMDT edit;
 * the console picks it up with no code change.
 *
 * The controller returns each index's grounding as MARKDOWN (per-file headings + excerpts), not structured
 * rows, because the action discards per-hit scores. This component parses that Markdown into file cards per
 * column; if a column's summary has no file heading, its raw Markdown is shown so nothing is hidden.
 *
 * The call is imperative (not @wire): the controller is a non-cacheable live Data Cloud callout, so the search
 * runs on button click with a spinner, never on cache.
 */
export default class MiHybridSearchConsole extends NavigationMixin(
  LightningElement
) {
  query = "";
  boostCompanies = "";
  boostIndustry = "";
  boostGeography = "";

  isLoading = false;
  hasSearched = false;
  showAdvanced = false;
  wasTruncated = false;

  @track columns = [];

  get advancedToggleLabel() {
    return this.showAdvanced ? "고급 옵션 숨기기" : "고급 옵션 (facet 부스트)";
  }

  get isSearchDisabled() {
    return this.isLoading || !this.query || !this.query.trim();
  }

  get hasColumns() {
    return this.columns.length > 0;
  }

  /** SLDS column-width class so N index columns share the row evenly (2→1/2, 3→1/3, otherwise 1/4). */
  get columnSizeClass() {
    const count = this.columns.length;
    let size = "slds-size_1-of-1";
    if (count === 2) {
      size = "slds-medium-size_1-of-2";
    } else if (count === 3) {
      size = "slds-medium-size_1-of-3";
    } else if (count >= 4) {
      size = "slds-medium-size_1-of-4";
    }
    return `slds-col slds-size_1-of-1 ${size} slds-p-around_x-small`;
  }

  handleQueryChange(event) {
    this.query = event.target.value;
  }

  handleCompaniesChange(event) {
    this.boostCompanies = event.target.value;
  }

  handleIndustryChange(event) {
    this.boostIndustry = event.target.value;
  }

  handleGeographyChange(event) {
    this.boostGeography = event.target.value;
  }

  toggleAdvanced() {
    this.showAdvanced = !this.showAdvanced;
  }

  /** Enter runs the search; Shift+Enter still inserts a newline (multi-line = multi-pass RRF). */
  handleKeyup(event) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      this.handleSearch();
    }
  }

  /**
   * Runs one search across every registered index and maps each index's outcome into a display column. The
   * controller is a live callout, so this shows a spinner, resets prior results, and always clears isLoading in
   * finally.
   */
  async handleSearch() {
    if (this.isSearchDisabled) {
      return;
    }
    this.isLoading = true;
    this.resetResults();
    try {
      const response = await search({
        query: this.query,
        boostCompanies: this.boostCompanies,
        boostIndustry: this.boostIndustry,
        boostGeography: this.boostGeography
      });
      this.hasSearched = true;
      this.wasTruncated = response.wasTruncated === true;
      this.columns = (response.results || []).map((result, index) =>
        this.toColumn(result, index)
      );
    } catch (error) {
      const message =
        error?.body?.message || error?.message || "검색을 실행하지 못했습니다.";
      this.dispatchEvent(
        new ShowToastEvent({
          title: "검색 오류",
          message,
          variant: "error"
        })
      );
    } finally {
      this.isLoading = false;
    }
  }

  resetResults() {
    this.columns = [];
    this.wasTruncated = false;
  }

  /**
   * Turns one index's controller result into a view-model column: parsed file groups (or a raw-summary
   * fallback), a header label, counts, and its own success/error state. All display flags are precomputed here
   * so the template stays declarative (no per-column getters, which LWC cannot express over a list).
   *
   * @param {object} result One IndexSearchResult from the controller
   * @param {number} index The result's position (used for a stable key)
   * @returns {object} The column view-model
   */
  toColumn(result, index) {
    const summary = result.summary || "";
    const fileGroups = this.parseFileGroups(summary);
    const hasResults = fileGroups.length > 0;
    const hasRawSummary = !!summary.trim();
    return {
      key: `col-${index}-${result.indexKey || "default"}`,
      indexLabel: result.indexLabel,
      isActive: result.isActive === true,
      countLabel: `문서 ${result.sourceCount || 0}건 · 발췌 ${
        result.excerptCount || 0
      }건`,
      isSuccess: result.isSuccess === true,
      errorMessage: result.errorMessage || "검색이 결과를 반환하지 못했습니다.",
      fileGroups,
      hasResults,
      rawSummary: summary,
      // The action emits a Korean no-results summary (no "### File:" heading) — show it verbatim. This also
      // covers rare format drift. Only truly-empty text with no heading falls through to the empty note.
      showRawFallback:
        result.isSuccess === true && !hasResults && hasRawSummary,
      isEmptyResult: result.isSuccess === true && !hasResults && !hasRawSummary
    };
  }

  /**
   * Parses one index's grounding Markdown into per-file groups. The action emits, per file:
   *   ### File: <fileName>
   *   RecordId: <id>
   *   Type: <docType>      (optional)
   *   Page: <n>            (optional)
   *   - <excerpt>
   *   - <excerpt>
   * A line that is not a recognized header and not a "- " bullet is ignored, so minor format drift degrades
   * gracefully. Returns [] when no file heading is found (the caller then shows the raw-Markdown fallback).
   *
   * @param {string} summary The grounding Markdown
   * @returns {Array} The parsed file groups
   */
  parseFileGroups(summary) {
    if (!summary) {
      return [];
    }
    const groups = [];
    let current = null;
    const lines = summary.split("\n");
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith("### File:")) {
        if (current) {
          groups.push(current);
        }
        current = {
          key: `file-${groups.length}`,
          fileName: trimmed.replace("### File:", "").trim(),
          recordId: "",
          docType: "",
          page: "",
          excerpts: []
        };
      } else if (!current) {
        // Text before the first file heading (rare) is skipped.
        continue;
      } else if (trimmed.startsWith("RecordId:")) {
        current.recordId = trimmed.replace("RecordId:", "").trim();
      } else if (trimmed.startsWith("Type:")) {
        current.docType = trimmed.replace("Type:", "").trim();
      } else if (trimmed.startsWith("Page:")) {
        current.page = trimmed.replace("Page:", "").trim();
      } else if (trimmed.startsWith("- ")) {
        current.excerpts.push({
          key: `${current.key}-ex-${current.excerpts.length}`,
          text: trimmed.substring(2).trim()
        });
      }
    }
    if (current) {
      groups.push(current);
    }
    return groups;
  }

  /**
   * Opens the source document's record page for the clicked file card. The recordId comes straight from the
   * grounding (the action embeds it), so no extra lookup is needed.
   *
   * @param {Event} event The click event; the card's data-id carries the recordId
   */
  handleOpenRecord(event) {
    const recordId = event.currentTarget.dataset.id;
    if (!recordId) {
      return;
    }
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId,
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    });
  }
}
