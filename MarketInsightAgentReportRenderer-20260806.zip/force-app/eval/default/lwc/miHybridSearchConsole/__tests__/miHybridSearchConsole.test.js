import { createElement } from "lwc";
import MiHybridSearchConsole from "c/miHybridSearchConsole";
import search from "@salesforce/apex/MI_HybridSearchController.search";

// search() is called IMPERATIVELY (the controller is a non-cacheable live callout), so it is mocked with the
// imperative { default: jest.fn() } shape — NOT a wire adapter — and each test resolves/rejects it directly.
jest.mock(
  "@salesforce/apex/MI_HybridSearchController.search",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

// NavigationMixin's [Navigate]() runs on the component's internal instance (inaccessible from the host
// element), so replacing the whole module with a version whose [Navigate] forwards to a jest.fn is the only
// way to observe the call — the same approach miQualityAppHome's test uses.
jest.mock("lightning/navigation", () => {
  const Navigate = Symbol("Navigate");
  const GenerateUrl = Symbol("GenerateUrl");
  const navigateMock = jest.fn();
  const NavigationMixin = (Base) =>
    class extends Base {
      [Navigate](...args) {
        navigateMock(...args);
      }
      [GenerateUrl]() {
        return Promise.resolve("https://example.com");
      }
    };
  NavigationMixin.Navigate = Navigate;
  NavigationMixin.GenerateUrl = GenerateUrl;
  NavigationMixin.__navigateMock = navigateMock;
  return { NavigationMixin };
});

const { NavigationMixin } = require("lightning/navigation");

// A grounding summary in the exact shape MI_HybridGroundingSearchAction emits.
function groundingFor(fileName, recordId) {
  return [
    `### File: ${fileName}`,
    `RecordId: ${recordId}`,
    "Type: Market Report",
    "Page: 12",
    "- DRAM 가격이 분기별로 상승하고 있다.",
    "- 메모리 수급이 타이트하다."
  ].join("\n");
}

// A two-index response: an active OLD column with a hit, and a FILTERABLE column that failed.
const TWO_INDEX_RESPONSE = {
  wasTruncated: false,
  results: [
    {
      indexKey: "OLD",
      indexLabel: "OLD index",
      isActive: true,
      summary: groundingFor("sony.pdf", "aC9000000000001AAA"),
      citations: "FILE: sony.pdf => ...",
      sourceCount: 1,
      excerptCount: 2,
      isSuccess: true,
      errorMessage: null
    },
    {
      indexKey: "FILTERABLE",
      indexLabel: "FILTERABLE index",
      isActive: false,
      summary: "",
      citations: "",
      sourceCount: 0,
      excerptCount: 0,
      isSuccess: false,
      errorMessage: "Data Cloud rejected the query"
    }
  ]
};

function createComponent() {
  const element = createElement("c-mi-hybrid-search-console", {
    is: MiHybridSearchConsole
  });
  document.body.appendChild(element);
  return element;
}

async function flush() {
  // Two microtask turns: one for the awaited search() promise, one for the resulting re-render.
  await Promise.resolve();
  await Promise.resolve();
}

// Types into the query textarea. Setting .value on the element and then dispatching `change` on it makes the
// component's handler see event.target.value, since event.target IS this element.
function typeQuery(element, value) {
  const textarea = element.shadowRoot.querySelector("lightning-textarea");
  textarea.value = value;
  textarea.dispatchEvent(new CustomEvent("change"));
}

function clickSearch(element) {
  const button = Array.from(
    element.shadowRoot.querySelectorAll("lightning-button")
  ).find((b) => b.label === "검색");
  button.click();
}

// Runs a full search: type the query, wait for the button to enable, click, and let the promise + render flush.
async function runSearch(element, query) {
  typeQuery(element, query);
  await Promise.resolve();
  clickSearch(element);
  await flush();
}

describe("c-mi-hybrid-search-console", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("explains it runs every registered index at once", () => {
    const element = createComponent();
    const text = element.shadowRoot.textContent;
    expect(text).toContain("MI_HybridGroundingSearchAction");
    expect(text).toContain("등록된 모든 검색 인덱스");
    expect(text).toContain("MI_Eval_Search_Index__mdt");
  });

  it("disables the search button until a query is entered", () => {
    const element = createComponent();
    const button = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((b) => b.label === "검색");
    expect(button.disabled).toBe(true);
  });

  it("renders one result column per index, active first", async () => {
    search.mockResolvedValue(TWO_INDEX_RESPONSE);
    const element = createComponent();

    await runSearch(element, "DRAM 가격 추이");

    expect(search).toHaveBeenCalled();
    const columns = element.shadowRoot.querySelectorAll("article.index-column");
    expect(columns.length).toBe(2);
    const text = element.shadowRoot.textContent;
    // Column headers are the CMDT labels, and the active index is badged.
    expect(text).toContain("OLD index");
    expect(text).toContain("FILTERABLE index");
    expect(text).toContain("활성");
    // The successful column shows its parsed hit + counts.
    expect(text).toContain("sony.pdf");
    expect(text).toContain("문서 1건 · 발췌 2건");
  });

  it("shows a per-column error without sinking the other columns", async () => {
    search.mockResolvedValue(TWO_INDEX_RESPONSE);
    const element = createComponent();
    await runSearch(element, "DRAM");

    const text = element.shadowRoot.textContent;
    // The failed FILTERABLE column shows its error, while the OLD column still shows its hit.
    expect(text).toContain("Data Cloud rejected the query");
    expect(text).toContain("sony.pdf");
  });

  it("navigates to the document record when a file card link is clicked", async () => {
    search.mockResolvedValue(TWO_INDEX_RESPONSE);
    const element = createComponent();
    await runSearch(element, "DRAM");

    const link = element.shadowRoot.querySelector("article.index-column a");
    link.click();
    await Promise.resolve();

    const calls = NavigationMixin.__navigateMock.mock.calls;
    expect(calls.length).toBeGreaterThan(0);
    expect(calls[calls.length - 1][0]).toEqual({
      type: "standard__recordPage",
      attributes: {
        recordId: "aC9000000000001AAA",
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    });
  });

  it("falls back to the raw grounding text when a column has no file heading", async () => {
    search.mockResolvedValue({
      wasTruncated: false,
      results: [
        {
          indexKey: "OLD",
          indexLabel: "OLD index",
          isActive: true,
          summary: "관련 문서를 찾지 못했습니다.",
          citations: "",
          sourceCount: 0,
          excerptCount: 0,
          isSuccess: true,
          errorMessage: null
        }
      ]
    });
    const element = createComponent();
    await runSearch(element, "무관한 쿼리");

    // No "### File:" heading → no file cards, but the raw grounding text is shown verbatim.
    expect(
      element.shadowRoot.querySelectorAll(".raw-summary").length
    ).toBeGreaterThan(0);
    expect(element.shadowRoot.textContent).toContain(
      "관련 문서를 찾지 못했습니다."
    );
  });

  it("warns when the registered indexes exceeded the display cap", async () => {
    search.mockResolvedValue({
      wasTruncated: true,
      results: TWO_INDEX_RESPONSE.results
    });
    const element = createComponent();
    await runSearch(element, "DRAM");

    expect(element.shadowRoot.textContent).toContain(
      "표시 한도를 초과해 일부만 실행"
    );
  });

  it("surfaces a thrown controller error as a toast, not a crash", async () => {
    search.mockRejectedValue({
      body: { message: "검색을 실행하지 못했습니다: 권한 없음" }
    });
    const element = createComponent();
    await runSearch(element, "DRAM");

    // No columns rendered; the component survived the rejection (the toast path). No file cards appear.
    const columns = element.shadowRoot.querySelectorAll("article.index-column");
    expect(columns.length).toBe(0);
  });

  it("reveals the advanced boost options when the toggle is clicked", async () => {
    const element = createComponent();
    const toggle = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((b) => b.label && b.label.includes("고급 옵션"));
    toggle.click();
    await Promise.resolve();

    // Three facet-boost inputs appear; the single-index picker no longer exists.
    expect(element.shadowRoot.querySelectorAll("lightning-input").length).toBe(
      3
    );
    expect(element.shadowRoot.querySelector("lightning-combobox")).toBeNull();
  });
});
