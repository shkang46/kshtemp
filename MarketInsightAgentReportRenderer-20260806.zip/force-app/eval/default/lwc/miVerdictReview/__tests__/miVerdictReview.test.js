import { createElement } from "lwc";
import MiVerdictReview from "c/miVerdictReview";
import getDetail from "@salesforce/apex/MI_VerdictReviewController.getDetail";
import setHumanVerdict from "@salesforce/apex/MI_VerdictReviewController.setHumanVerdict";

// getDetail is a WIRED Apex method → needs a wire-adapter stub (emit/error).
jest.mock(
  "@salesforce/apex/MI_VerdictReviewController.getDetail",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// setHumanVerdict is called IMPERATIVELY → a plain jest.fn resolving undefined.
jest.mock(
  "@salesforce/apex/MI_VerdictReviewController.setHumanVerdict",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

// refreshApex is called after a successful save; a no-op mock resolving is enough.
jest.mock(
  "@salesforce/apex",
  () => ({ refreshApex: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

// The component extends NavigationMixin and calls [GenerateUrl] to link the source document.
jest.mock("lightning/navigation", () => {
  const GenerateUrl = Symbol("GenerateUrl");
  const NavigationMixin = (Base) =>
    class extends Base {
      [GenerateUrl](config) {
        return Promise.resolve(`/r/${config.attributes.recordId}/view`);
      }
    };
  NavigationMixin.GenerateUrl = GenerateUrl;
  return { NavigationMixin };
});

const RECORD_ID = "a4J000000000001AAA";

const TABULAR_VOCAB = [
  { value: "Match", label: "일치 (표기 차이 포함)" },
  { value: "Value_Mismatch", label: "값 불일치" },
  { value: "Period_Mismatch", label: "기간 불일치" },
  { value: "Unit_Mismatch", label: "단위 불일치" },
  { value: "Entity_Mismatch", label: "대상 불일치" },
  { value: "Not_In_Source", label: "원문에 없음" },
  { value: "Unverifiable", label: "판정 불가 (근거 부족)" }
];

const GROUNDING_VOCAB = [
  { value: "Grounded", label: "근거 있음 (Grounded)" },
  { value: "Ungrounded", label: "근거 없음 (Ungrounded)" },
  { value: "Unverifiable", label: "판정 불가 (근거 부족)" }
];

const TABULAR_DETAIL = {
  found: true,
  recordId: RECORD_ID,
  name: "VER-0001",
  runType: "Judge",
  runId: "a4I000000000001",
  runName: "Judge run",
  verdict: "Value_Mismatch",
  humanVerdict: null,
  goldenVerdict: null,
  hasGolden: false,
  isMissedFigure: false,
  isSynthetic: false,
  syntheticMutation: null,
  tabularRowKey: "row-1",
  sourceValue: "150.0",
  sourceSnippet: "Sales were 150.0 billion yen.",
  sourcePage: "10",
  judgeNote: "Stored 152.5 but source reads 150.0.",
  storedEntity: "Total",
  storedMetric: "sales",
  storedPeriod: "FY2025",
  storedValue: "152.5",
  storedUnit: "Billion yen",
  storedConfidence: "0.9",
  documentId: "a0X000000000001",
  fileName: "facts.pdf",
  allowedVerdicts: TABULAR_VOCAB
};

function createComponent() {
  const element = createElement("c-mi-verdict-review", {
    is: MiVerdictReview
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(detail) {
  getDetail.emit(detail);
  await Promise.resolve();
}

async function flush() {
  await Promise.resolve();
  await Promise.resolve();
}

describe("c-mi-verdict-review", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders the three verdicts and the source evidence", async () => {
    const element = createComponent();
    await emit(TABULAR_DETAIL);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("LLM 심판");
    expect(text).toContain("사람 판정");
    expect(text).toContain("골든셋 정답");
    // The judge verdict label renders.
    expect(text).toContain("값 불일치");
    // The source snippet is rendered through lightning-formatted-rich-text (auto-mocked, so its value does
    // not land in textContent) — assert on the element's value attribute instead.
    const snippet = element.shadowRoot.querySelector(
      "lightning-formatted-rich-text"
    );
    expect(snippet.value).toBe("Sales were 150.0 billion yen.");
    // No golden on this row → the "golden run only" note.
    expect(text).toContain("골든 문서 행에만 채워집니다");
  });

  it("offers the tabular vocabulary for a tabular run", async () => {
    const element = createComponent();
    await emit(TABULAR_DETAIL);

    const radioGroup = element.shadowRoot.querySelector(
      "lightning-radio-group"
    );
    expect(radioGroup).not.toBeNull();
    expect(radioGroup.options.map((o) => o.value)).toEqual([
      "Match",
      "Value_Mismatch",
      "Period_Mismatch",
      "Unit_Mismatch",
      "Entity_Mismatch",
      "Not_In_Source",
      "Unverifiable"
    ]);
  });

  it("offers the grounding vocabulary for an answer run", async () => {
    const element = createComponent();
    await emit({
      ...TABULAR_DETAIL,
      runType: "Answer_Judge",
      verdict: "Ungrounded",
      allowedVerdicts: GROUNDING_VOCAB
    });

    const radioGroup = element.shadowRoot.querySelector(
      "lightning-radio-group"
    );
    expect(radioGroup.options.map((o) => o.value)).toEqual([
      "Grounded",
      "Ungrounded",
      "Unverifiable"
    ]);
  });

  it("saves the picked human verdict and calls the controller", async () => {
    setHumanVerdict.mockResolvedValue(undefined);
    const element = createComponent();
    await emit(TABULAR_DETAIL);

    // Pick a verdict, then click save.
    const radioGroup = element.shadowRoot.querySelector(
      "lightning-radio-group"
    );
    radioGroup.dispatchEvent(
      new CustomEvent("change", { detail: { value: "Value_Mismatch" } })
    );
    await Promise.resolve();

    const saveButton = element.shadowRoot.querySelector(
      "lightning-button[data-id='save-verdict']"
    );
    expect(saveButton.disabled).toBe(false);
    saveButton.click();
    await flush();

    expect(setHumanVerdict).toHaveBeenCalledWith({
      verdictId: RECORD_ID,
      humanVerdict: "Value_Mismatch"
    });
  });

  it("disables save until a value different from the stored one is picked", async () => {
    const element = createComponent();
    // The row already has a human verdict; re-picking the same value must not enable save.
    await emit({ ...TABULAR_DETAIL, humanVerdict: "Value_Mismatch" });

    const saveButton = element.shadowRoot.querySelector(
      "lightning-button[data-id='save-verdict']"
    );
    expect(saveButton.disabled).toBe(true);
  });

  it("replaces the classification section with a notice for a synthetic row", async () => {
    const element = createComponent();
    await emit({
      ...TABULAR_DETAIL,
      isSynthetic: true,
      syntheticMutation: "digit change"
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("합성 주입 행");
    // No verdict picker for a synthetic row.
    expect(
      element.shadowRoot.querySelector("lightning-radio-group")
    ).toBeNull();
  });

  it("links the source document when a url resolves", async () => {
    const element = createComponent();
    await emit(TABULAR_DETAIL);
    await flush();

    const link = element.shadowRoot.querySelector("a");
    expect(link).not.toBeNull();
    expect(link.href).toContain(`/r/${TABULAR_DETAIL.documentId}/view`);
  });
});
