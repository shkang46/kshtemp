import { LightningElement, api, track, wire } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getDetail from "@salesforce/apex/MI_VerdictReviewController.getDetail";
import setHumanVerdict from "@salesforce/apex/MI_VerdictReviewController.setHumanVerdict";

/**
 * The detailed view of one MI_Tabular_Eval_Verdict__c record, shown on its record page. A verdict is a
 * snapshot judgment of a single extracted figure (or an omission claim): it holds three verdicts side by
 * side — the LLM judge's (Verdict__c), a person's (Human_Verdict__c) and the golden-set truth
 * (Golden_Verdict__c) — plus the stored coordinates and the verbatim source quote frozen at judgment time.
 *
 * This screen makes the record legible (three verdicts, snapshot, evidence, a jump to the source document)
 * and lets a reviewer record the ONE human decision the object exists for: classifying the flagged figure by
 * setting Human_Verdict__c. The vocabulary is supplied by the server per the parent run's Run_Type__c, so a
 * tabular run offers Match/Value_Mismatch/… and an answer run offers Grounded/Ungrounded/…. Golden_Verdict__c
 * is shown read-only — this screen never writes truth (that belongs to the golden-row capture flow). Synthetic
 * rows carry no real judgment, so the classification section is replaced by a notice for them.
 */

// Korean display labels for a verdict value, covering both the tabular figure-comparison vocabulary and the
// answer/facet grounding vocabulary. Used to render the machine and golden verdicts (the human verdict picks
// its label from the server-supplied option list).
const VERDICT_LABELS = {
  Match: "일치",
  Value_Mismatch: "값 불일치",
  Period_Mismatch: "기간 불일치",
  Unit_Mismatch: "단위 불일치",
  Entity_Mismatch: "대상 불일치",
  Not_In_Source: "원문에 없음",
  Unverifiable: "판정 불가",
  Grounded: "근거 있음",
  Ungrounded: "근거 없음"
};

export default class MiVerdictReview extends NavigationMixin(LightningElement) {
  @api recordId;

  detail;
  loadError;
  documentUrl;
  isSaving = false;

  // The reviewer's current pick, mirrored into a private field so the @api-driven wire value is never
  // mutated. Seeded from the stored Human_Verdict__c on each load.
  @track selectedVerdict = "";

  // The entire wire result is retained (not just .data) so refreshApex can re-fetch it after the save button
  // runs — refreshApex needs the provisioned wire object, and .data alone will not refresh.
  _wired;

  @wire(getDetail, { verdictId: "$recordId" })
  wiredDetail(result) {
    this._wired = result;
    const { data, error } = result;
    if (data) {
      this.detail = data;
      this.loadError = undefined;
      this.selectedVerdict = data.humanVerdict || "";
      this.resolveDocumentUrl();
    } else if (error) {
      this.detail = undefined;
      this.loadError = error?.body?.message || "판정을 불러오지 못했습니다.";
    }
  }

  /**
   * Resolves the source document's record-page URL so the reviewer can open the original and settle the
   * flagged figure. A failure to generate leaves the file name as plain text.
   */
  resolveDocumentUrl() {
    if (!this.detail?.documentId) {
      return;
    }
    this[NavigationMixin.GenerateUrl]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.detail.documentId,
        objectApiName: "Market_Insight_Document__c",
        actionName: "view"
      }
    })
      .then((url) => {
        this.documentUrl = url;
      })
      .catch(() => {
        // Leave documentUrl undefined; the template shows the file name as plain text.
      });
  }

  get hasDetail() {
    return this.detail != null && this.detail.found === true;
  }

  get hasDocumentUrl() {
    return !!this.documentUrl;
  }

  // ---- The three verdicts, decorated for display ----

  get judgeVerdictLabel() {
    return this.labelFor(this.detail?.verdict);
  }

  get humanVerdictLabel() {
    return this.detail?.humanVerdict
      ? this.labelFor(this.detail.humanVerdict)
      : "미분류";
  }

  get goldenVerdictLabel() {
    return this.labelFor(this.detail?.goldenVerdict);
  }

  get hasHumanVerdict() {
    return !!this.detail?.humanVerdict;
  }

  get hasGolden() {
    return this.detail?.hasGolden === true;
  }

  /**
   * A Korean label for a stored verdict value, falling back to the raw value so an unmapped value is still
   * visible rather than blank.
   *
   * @param {string} value The stored verdict value
   * @returns {string} The display label
   */
  labelFor(value) {
    if (!value) {
      return "—";
    }
    return VERDICT_LABELS[value] || value;
  }

  // ---- Flags ----

  get isSynthetic() {
    return this.detail?.isSynthetic === true;
  }

  get isMissedFigure() {
    return this.detail?.isMissedFigure === true;
  }

  get syntheticMutation() {
    return this.detail?.syntheticMutation;
  }

  // ---- Human-verdict picklist ----

  // The server-supplied vocabulary for this run type, shaped for lightning-radio-group and marked with the
  // current selection for a stable-key render.
  get verdictOptions() {
    return (this.detail?.allowedVerdicts || []).map((option) => ({
      label: option.label,
      value: option.value
    }));
  }

  get canSave() {
    // Enabled once a value is picked AND it differs from what is already stored — re-saving the same value is
    // a no-op the reviewer should not have to think about.
    return (
      !this.isSaving &&
      !this.isSynthetic &&
      this.selectedVerdict !== (this.detail?.humanVerdict || "")
    );
  }

  get saveDisabled() {
    return !this.canSave;
  }

  handleVerdictChange(event) {
    this.selectedVerdict = event.detail.value;
  }

  /**
   * Records the reviewer's human verdict on this record. The server re-checks the value against the run
   * type's vocabulary; on success the row leaves the triage queue and the wire is refreshed so the stored
   * value shown updates in place.
   */
  async handleSaveHumanVerdict() {
    this.isSaving = true;
    try {
      await setHumanVerdict({
        verdictId: this.recordId,
        humanVerdict: this.selectedVerdict
      });
      this.toast(
        "판정 저장",
        "사람 판정을 기록했습니다. 이 레코드는 분류 대기 큐에서 빠집니다.",
        "success"
      );
      await refreshApex(this._wired);
    } catch (error) {
      this.toast("저장하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isSaving = false;
    }
  }

  /**
   * Clears the human verdict, returning the record to the triage queue.
   */
  async handleClearHumanVerdict() {
    this.isSaving = true;
    try {
      await setHumanVerdict({ verdictId: this.recordId, humanVerdict: "" });
      this.selectedVerdict = "";
      this.toast(
        "판정 취소",
        "사람 판정을 지웠습니다. 이 레코드는 다시 분류 대기 큐로 돌아갑니다.",
        "success"
      );
      await refreshApex(this._wired);
    } catch (error) {
      this.toast("취소하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isSaving = false;
    }
  }

  /**
   * The message from an Apex error, falling back to something actionable rather than "undefined".
   *
   * @param {object} error The rejected Apex error
   * @returns {string} A displayable message
   */
  messageOf(error) {
    return (
      error?.body?.message ||
      error?.message ||
      "알 수 없는 오류가 발생했습니다."
    );
  }

  /**
   * Shows a toast.
   *
   * @param {string} title The toast title
   * @param {string} message The body
   * @param {string} variant success | warning | error | info
   */
  toast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }
}
