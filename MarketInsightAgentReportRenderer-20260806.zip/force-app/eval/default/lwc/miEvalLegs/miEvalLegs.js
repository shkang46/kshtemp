/**
 * The single source of truth for the Market Insight Quality app's evaluation "legs" (concerns) AND how they
 * group by VERIFICATION TARGET — the layer of the pipeline each leg actually judges.
 *
 * The app used to number its sections with hardcoded digit badges that clashed three ways (intro's 5-step
 * pipeline, a per-leg concern number reused on a leg's metric half and its run half, and the Apex "STAGE N"
 * spine), so the same digit meant different things on different rows. Numbers were the wrong tool: a leg is a
 * NAMED concern, not an ordinal step. This module replaces every section-number badge with a stable leg id +
 * Korean label + icon.
 *
 * It ALSO answers the question a first-time viewer keeps asking — "이 점수는 데이터 검증이야, 검색 검증이야,
 * 아니면 AI 답변 검증이야?" — by grouping the legs into four verification targets, surfaced as the left nav's
 * section headings and each leg block's banner:
 *   ① 추출 데이터 품질  — 문서에서 뽑아낸 데이터 자체가 맞는가 (numeric 수치, facet 패싯)
 *   ② 검색 품질        — 질문이 올바른 자료를 찾아오는가 (search: 수치 조회 + 문서 검색)
 *   ③ AI 답변 품질     — 에이전트가 생성한 답변이 근거에 충실한가 (answer: RAGAS + 답변 비교 평가)
 *   ④ AI 판정 신뢰성   — 채점을 맡은 AI 심판 자체를 믿어도 되는가 (trust)
 * Each leg carries { target(무엇을), how(어떻게), why(왜) } so the banner can state, in plain Korean, what layer
 * the leg verifies, how the number is derived, and why it matters — the three things a newcomer needs before a
 * percentage means anything.
 *
 * The old single `retrieval` leg mixed the search engine and the generated answer — two different verification
 * targets — so it is split here into `search` and `answer`.
 *
 * `intro` and `prepare` are nav items that are not measuring legs (intro = how-it-works + the 5-step PROCESS
 * pipeline; prepare = document + golden-set setup), so their banner explains their role rather than a metric.
 *
 * Import as `c/miEvalLegs`: `import { LEGS, LEG, legList, legGroups } from "c/miEvalLegs";`.
 */

/**
 * Every leg keyed by its stable id. Each entry:
 *  - id: the stable key used for nav selection (`selectedLeg`) and `lwc:if` switching
 *  - label: the Korean nav/section label
 *  - icon: an SLDS utility icon name for the nav item
 *  - target: 무엇을 검증하나 — which pipeline layer this leg judges (data / search / answer / judge)
 *  - how: 어떻게 재나 — one line on how the number is derived
 *  - why: 왜 중요한가 — one line on the consequence if this layer is wrong
 */
const LEGS = {
  intro: {
    id: "intro",
    label: "소개",
    icon: "utility:info",
    target:
      "이 앱이 무엇을 · 어떻게 · 왜 검증하는지 전체 그림을 봅니다 (측정 단계 아님).",
    how: "동작 순서(5단계 파이프라인)와 근거를 세 등급으로 나누어 보는 이유, 평가 방법론 전체를 설명합니다.",
    why: ""
  },
  prepare: {
    id: "prepare",
    label: "준비 · 입력",
    icon: "utility:upload",
    target: "검증에 쓸 문서와 정답셋을 갖추는 단계입니다 (아직 측정 아님).",
    how: "문서를 등록하고, 채점 기준이 되는 사람 검수 정답을 입력하거나 LLM 제안을 승인합니다.",
    why: "정답셋이 있어야 그 뒤 모든 채점의 기준점이 생깁니다."
  },
  numeric: {
    id: "numeric",
    label: "정량 수치 품질",
    icon: "utility:number_input",
    target:
      "문서에서 뽑아낸 숫자 데이터 자체입니다 — AI 답변이 아니라 표에서 추출해 저장한 수치.",
    how: "사람이 검수한 정답(골든셋)과 1:1로 대조해 정밀도·재현율을 내고, 저장된 숫자끼리 계산이 맞는지(산술 정합성)도 따집니다.",
    why: "보고서·검색·답변의 모든 숫자가 여기서 출발하므로, 추출이 틀리면 그 위 단계도 함께 틀립니다."
  },
  facet: {
    id: "facet",
    label: "패싯 데이터 검증",
    icon: "utility:tags",
    target:
      "업로드 시 자동 생성한 문서 속성 데이터입니다 — 회사·산업·지역·기준일 같은 패싯 값.",
    how: "사람이 확인한 패싯 정답 집합과 대조해 정밀도·재현율을 내고, 정답이 없는 요약은 LLM 심판의 Faithfulness로 봅니다.",
    why: "패싯은 검색·필터의 열쇠라, 틀리면 맞는 문서가 검색에서 아예 누락됩니다."
  },
  search: {
    id: "search",
    label: "검색 재현 품질",
    icon: "utility:search",
    target:
      "질문이 올바른 자료를 찾아오는 검색 엔진입니다 — 추출·생성이 아니라 '조회' 단계.",
    how: "정답이 정해진 질문(known-item)을 자동 생성해, 수치는 SOQL 정형 조회로·문서는 하이브리드 인덱스로 찾아 정답이 상위에 오는지(Recall·MRR)를 잽니다.",
    why: "에이전트가 옳은 답을 하려면 먼저 옳은 근거를 찾아와야 합니다 — 검색이 못 찾으면 답변은 지어내게 됩니다."
  },
  answer: {
    id: "answer",
    label: "AI 답변 품질",
    icon: "utility:chat",
    target:
      "에이전트가 생성한 답변 그 자체입니다 — 찾아온 근거에 충실한지, AI가 지어내지 않았는지.",
    how: "생성된 답변을 낱개 주장으로 쪼개 근거와 대조하고(RAGAS Faithfulness), 여러 답변 생성 방식의 답변을 같은 질문으로 돌려 나란히 비교합니다.",
    why: "검색이 맞아도 모델이 근거에 없는 말을 지어낼 수 있어, 답변 단계는 따로 검증해야 합니다."
  },
  trust: {
    id: "trust",
    label: "AI 판정 신뢰성",
    icon: "utility:like",
    target:
      "채점을 맡은 AI 심판 자체를 믿어도 되는지입니다 — 데이터가 아니라 심판의 정확도를 검증.",
    how: "AI 심판의 판정을 사람 정답(골든셋)과 대조해 정밀도를 내고(0.8 게이트), 일부러 심어 둔 가짜 오류를 몇 개나 잡는지(민감도)까지 봅니다.",
    why: "사람이 못 본 페이지의 커버리지 확장은 AI 심판에 기대는데, 심판이 부정확하면 그 위의 모든 수치가 흔들립니다."
  }
};

/**
 * The verification-target groups, in nav order. Each group's `label` is the target it verifies (surfaced as a
 * left-nav section heading), and `legIds` are the legs under it. This is what tells a newcomer whether a leg
 * checks the extracted DATA, the SEARCH engine, the AI ANSWER, or the AI JUDGE.
 */
const LEG_GROUPS = [
  { key: "start", label: "시작", legIds: ["intro", "prepare"] },
  {
    key: "data",
    label: "① 추출 데이터 품질 — 뽑아낸 데이터 검증",
    legIds: ["numeric", "facet"]
  },
  {
    key: "searchq",
    label: "② 검색 품질 — 검색 엔진 검증",
    legIds: ["search"]
  },
  {
    key: "answerq",
    label: "③ AI 답변 품질 — 생성 답변 검증",
    legIds: ["answer"]
  },
  {
    key: "judgeq",
    label: "④ AI 판정 신뢰성 — AI 심판 검증",
    legIds: ["trust"]
  }
];

/** The flat nav/render order of the legs, derived from the groups so the two never drift. */
const LEG_ORDER = LEG_GROUPS.reduce(
  (ids, group) => ids.concat(group.legIds),
  []
);

/**
 * Looks up one leg by id, falling back to `intro` for an unknown id so a caller never gets undefined.
 *
 * @param {string} id The leg id
 * @returns {object} The leg descriptor
 */
function LEG(id) {
  return LEGS[id] || LEGS.intro;
}

/**
 * The legs as an ordered flat array (intro first, then the eval concerns in workflow order).
 *
 * @returns {Array<object>} The leg descriptors in nav order
 */
function legList() {
  return LEG_ORDER.map((id) => LEGS[id]);
}

/**
 * The nav grouped by verification target: one entry per group, each carrying its resolved leg descriptors.
 * The left vertical-nav renders one `<section>` per group so the target headings ("① 추출 데이터 품질 …")
 * are visible, answering "이 leg 은 무엇을 검증하나" before the user even clicks.
 *
 * @param {string} selectedId The currently selected leg id, so each item can carry a `selected` flag
 * @returns {Array<object>} Groups ({ key, label, items: [{ id, label, icon, selected }] })
 */
function legGroups(selectedId) {
  return LEG_GROUPS.map((group) => ({
    key: group.key,
    label: group.label,
    items: group.legIds.map((id) => ({
      id: LEGS[id].id,
      label: LEGS[id].label,
      icon: LEGS[id].icon,
      selected: id === selectedId
    }))
  }));
}

export { LEGS, LEG_GROUPS, LEG_ORDER, LEG, legList, legGroups };
