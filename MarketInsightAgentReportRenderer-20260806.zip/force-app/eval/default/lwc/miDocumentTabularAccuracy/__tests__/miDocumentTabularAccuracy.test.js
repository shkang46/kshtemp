import { createElement } from "lwc";
import MiDocumentTabularAccuracy from "c/miDocumentTabularAccuracy";
import getSummary from "@salesforce/apex/MI_DocumentAccuracyController.getSummary";

// A WIRED Apex method needs a wire-adapter stub, which is NOT the same mock as an imperative one. The
// `{ default: jest.fn() }` pattern the other tests in this repo use gives a callable function with no emit()
// or error(), so a wired method mocked that way can never be fed data. createApexTestWireAdapter supplies both.
jest.mock(
  "@salesforce/apex/MI_DocumentAccuracyController.getSummary",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

const RECORD_ID = "a36Ie000000LgLkIAK";

const BASE_SUMMARY = {
  fileName: "quarterly-supplement.pdf",
  extractionStatus: "Complete",
  storedRowCount: 1713,
  extractionNote: null,
  goldenRowCount: 1375,
  hasRun: true,
  runId: "a4J000000000001",
  runLabel: "run",
  runDate: "2026-07-27T00:00:00.000Z",
  precisionPercent: 92.7,
  recallPercent: 48.1,
  recallLowerPercent: 43.8,
  recallUpperPercent: 48.9,
  truePositive: 637,
  falsePositive: 50,
  falseNegative: 688,
  unverifiable: 653,
  unitErrors: 36,
  valueErrors: 14,
  pagesReviewedComplete: 8,
  pagesReviewedPartial: 3,
  pagesNoFigures: 0,
  pages: []
};

function page(overrides) {
  return {
    page: "5",
    goldenFigures: 0,
    matched: 0,
    missed: 0,
    unitMismatch: 0,
    valueMismatch: 0,
    unverifiable: 0,
    matchRatePercent: null,
    reviewStatus: null,
    reviewedFigures: 0,
    verdict: "not_reviewed",
    ...overrides
  };
}

function createComponent() {
  const element = createElement("c-mi-document-tabular-accuracy", {
    is: MiDocumentTabularAccuracy
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(summary) {
  getSummary.emit(summary);
  await Promise.resolve();
}

describe("c-mi-document-tabular-accuracy", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("states the reviewed range alongside the headline figures", async () => {
    const element = createComponent();
    await emit(BASE_SUMMARY);

    const text = element.shadowRoot.textContent;
    // A percentage read without its scope is read as document-wide, which it is not. The scope must be present
    // on the same screen, not a click away.
    expect(text).toContain("검수 범위");
    expect(text).toContain("전수 8페이지");
    expect(text).toContain("일부 3페이지");
    expect(text).toContain("92.7%");
    expect(text).toContain("48.1%");
  });

  it("shows the credible interval with recall so a small reference set cannot read as precise", async () => {
    const element = createComponent();
    await emit(BASE_SUMMARY);

    expect(element.shadowRoot.textContent).toContain("43.8% – 48.9%");
  });

  it("warns that recall is a lower bound when any page was reviewed only partially", async () => {
    const element = createComponent();
    await emit(BASE_SUMMARY);

    expect(element.shadowRoot.textContent).toContain("하한으로 읽어야");
  });

  it("says nothing was measured instead of rendering 0% when no run exists", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      hasRun: false,
      precisionPercent: null,
      recallPercent: null,
      recallLowerPercent: null,
      recallUpperPercent: null
    });

    const text = element.shadowRoot.textContent;
    // THE CENTRAL DISTINCTION. Rendering 0% for an unscored document reports a failure nobody observed.
    expect(text).toContain("아직 채점하지 않았습니다");
    expect(text).not.toContain("0%");
  });

  it("prints a dash, never 0%, for a page that was never reviewed", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pages: [page({ page: "3", verdict: "not_reviewed" })]
    });

    const rowText = element.shadowRoot.querySelector("tbody").textContent;
    expect(rowText).toContain("미검수");
    expect(rowText).toContain("—");
    expect(rowText).not.toContain("0%");
  });

  it("labels a figure-less page as correct rather than as a failure", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pages: [
        page({ page: "20", verdict: "no_figures", reviewStatus: "No_Figures" })
      ]
    });

    // A prose table legitimately holds no numbers; extracting nothing there is the right outcome.
    expect(element.shadowRoot.querySelector("tbody").textContent).toContain(
      "수치 없음 (정상)"
    );
  });

  it("calls out a total mismatch as its own state, not merely a low score", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pages: [
        page({
          page: "10",
          goldenFigures: 136,
          matched: 0,
          missed: 136,
          matchRatePercent: 0,
          reviewStatus: "Partial",
          verdict: "no_match"
        })
      ]
    });

    // In practice this has meant a systematic coordinate or notation mismatch rather than 136 independent
    // extraction errors, and the two need different fixes — so it gets its own label.
    expect(element.shadowRoot.querySelector("tbody").textContent).toContain(
      "전량 불일치"
    );
  });

  it("flags rows stored on a page a reviewer found figure-less", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pages: [
        page({
          page: "20",
          unverifiable: 4,
          reviewStatus: "No_Figures",
          verdict: "unexpected_rows"
        })
      ]
    });

    expect(element.shadowRoot.querySelector("tbody").textContent).toContain(
      "불필요한 행"
    );
  });

  it("does not echo the partial-extraction note the extraction card above already owns", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      extractionNote: "[일부 미추출] 페이지 9 의 표 응답이 잘렸습니다."
    });

    // The "[일부 미추출]" note is rendered in full by miDocumentTabularReindex on the same record page; repeating
    // the same wall of text here just clutters the quality card, so it is suppressed.
    expect(element.shadowRoot.textContent).not.toContain("일부 미추출");
  });

  it("still surfaces a no-table note even though the document reads Complete", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      extractionNote: "[표 없음] 이 문서에서 정량 표를 찾지 못했습니다."
    });

    // A "[표 없음]" note is short and is NOT duplicated verbatim by the extraction card's guidance, so the
    // quality card keeps showing it — only the verbose partial note is suppressed.
    const text = element.shadowRoot.textContent;
    expect(text).toContain("Complete");
    expect(text).toContain("표 없음");
  });

  it("warns when no review scope is recorded at all", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pagesReviewedComplete: 0,
      pagesReviewedPartial: 0,
      pagesNoFigures: 0
    });

    // Without a recorded scope the numbers still mean something, but only for the pages that happen to have
    // reference figures — the card has to say so rather than imply document-wide coverage.
    expect(element.shadowRoot.textContent).toContain(
      "문서 전체를 대표하지 않습니다"
    );
  });

  it("reports the failure reason instead of rendering an empty card", async () => {
    const element = createComponent();
    // The adapter's error(body) WRAPS its argument as error.body, so the message goes in directly — passing
    // { body: { message } } here would nest it to error.body.body.message and the component would fall back to
    // its generic text, which is what an earlier version of this test wrongly asserted was fine.
    getSummary.error({ message: "FLS 오류" });
    await Promise.resolve();

    // The reason must reach the screen: a generic "could not read" leaves an admin with nothing to act on, and
    // the most likely cause here is a missing field permission, which is fixable only if it is named.
    expect(element.shadowRoot.textContent).toContain("FLS 오류");
  });

  const JUDGE_FIELDS = {
    hasJudgeRun: true,
    judgeRunId: "a4J000000000002",
    judgeRunDate: "2026-07-27T01:00:00.000Z",
    judgeTemplate: "Market_Document_Tabular_Eval_Prompt",
    judgePresentable: true,
    judgeCaveat: null,
    judgePrecisionPercent: 91.0,
    judgeRecallPercent: 64.0,
    judgeKappa: 0.78,
    syntheticInjected: 8,
    syntheticCaught: 6,
    faithfulnessPercent: 88.0,
    faithfulnessGrounded: 44,
    faithfulnessDenominator: 50
  };

  it("shows no judge section at all until the judge has run", async () => {
    const element = createComponent();
    await emit(BASE_SUMMARY);

    // Absence is rendered as absence. An empty judge panel with dashes in it would read as "the judge found
    // nothing", which is a claim rather than a gap.
    expect(element.shadowRoot.textContent).not.toContain("LLM 심판");
  });

  it("reports the judge leg separately from the golden figures", async () => {
    const element = createComponent();
    await emit({ ...BASE_SUMMARY, ...JUDGE_FIELDS });

    const text = element.shadowRoot.textContent;
    // Both legs are on screen at once, and the golden precision is still the headline. Blending them into a
    // single accuracy number would give the judge's opinion the standing of the measurement.
    expect(text).toContain("92.7%");
    expect(text).toContain("LLM 심판");
    expect(text).toContain("91%");
  });

  it("renders Faithfulness with its denominator, never as a bare ratio", async () => {
    const element = createComponent();
    await emit({ ...BASE_SUMMARY, ...JUDGE_FIELDS });

    // A ratio without its denominator hides how few rows it rests on — the same reason recall carries a credible
    // interval. 88% over 50 rows and 88% over 2 rows must not look identical.
    const text = element.shadowRoot.textContent;
    expect(text).toContain("88%");
    expect(text).toContain("44/50");
  });

  it("leads with the caveat when the judge has never been validated", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      ...JUDGE_FIELDS,
      judgePresentable: false,
      judgePrecisionPercent: null,
      judgeCaveat: "심판이 골든셋으로 검증되지 않았습니다 — 제시할 수 없습니다."
    });

    const text = element.shadowRoot.textContent;
    // The judge's output looks like a measurement whether or not it has been checked, so the permission to use it
    // has to be visible next to the numbers.
    expect(text).toContain("제시할 수 없습니다");
    expect(text).toContain("측정 안 됨");
  });

  it("says so when Faithfulness had no adjudicable rows, rather than showing zero", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      ...JUDGE_FIELDS,
      faithfulnessPercent: null,
      faithfulnessGrounded: 0,
      faithfulnessDenominator: 0
    });

    // 0% would assert that the judge grounded none of its findings. In fact it produced none to ground, which is
    // a different statement.
    expect(element.shadowRoot.textContent).toContain(
      "판정 가능한 행이 없었습니다"
    );
  });

  it("states that judge sensitivity is unmeasured when nothing was planted", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      ...JUDGE_FIELDS,
      syntheticInjected: 0,
      syntheticCaught: 0
    });

    // Without planted errors, precision tells us the judge is right when it speaks but nothing about what it
    // misses — so its silence cannot be used as evidence.
    expect(element.shadowRoot.textContent).toContain(
      "놓치는 결함은 측정되지 않았습니다"
    );
  });

  it("states which formats were covered and which were not", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      coveredFormats: "pdf",
      coveredRoutes: "PDF",
      coveredDocumentTypes: "증권사보고서",
      coverageNote:
        "이 실행에서 측정되지 않은 형식: [docx, xlsx] — 차트·이미지 OCR 유래 수치는 범위 밖입니다."
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("측정 대상");
    // The gap matters more than the coverage: a reader fills unstated range with an assumption.
    expect(text).toContain("측정되지 않은 형식");
  });

  it("counts period and entity mismatches per page instead of dropping them", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      pages: [
        page({
          page: "12",
          goldenFigures: 10,
          matched: 5,
          periodMismatch: 2,
          entityMismatch: 1,
          otherVerdicts: 1,
          matchRatePercent: 50,
          verdict: "partial"
        })
      ]
    });

    // Period mis-attribution is this pipeline's most common real defect. It used to fall through the per-page
    // if/else chain into no counter at all, so a page's parts stopped adding up to its whole.
    const text = element.shadowRoot.textContent;
    expect(text).toContain("기간 2");
    expect(text).toContain("대상 1");
    expect(text).toContain("기타 1");
  });

  it("renders the per-document retrieval leg alongside accuracy when a probe ran", async () => {
    const element = createComponent();
    await emit({
      ...BASE_SUMMARY,
      hasFigureProbe: true,
      figureProbeTotal: 4,
      figureProbeHits: 3,
      figureProbeHitRatePercent: 75.0,
      hasDocProbe: true,
      docProbeTotal: 5,
      docProbeHits: 2,
      docProbeHitRatePercent: 40.0
    });

    const text = element.shadowRoot.textContent;
    expect(text).toContain("검색 재현 (이 문서)");
    expect(text).toContain("3/4 적중 (75%)");
    expect(text).toContain("2/5 적중 (40%)");
    // The retrieval block must state that answer quality is measured per-report, not per-document.
    expect(text).toContain("보고서 단위");
  });

  it("omits the retrieval block when no probe ran for the document", async () => {
    const element = createComponent();
    await emit(BASE_SUMMARY); // no hasFigureProbe / hasDocProbe

    expect(element.shadowRoot.textContent).not.toContain("검색 재현 (이 문서)");
  });
});
