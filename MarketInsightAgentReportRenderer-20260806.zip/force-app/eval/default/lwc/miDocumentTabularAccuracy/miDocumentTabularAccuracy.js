import { LightningElement, api, wire } from "lwc";
import getSummary from "@salesforce/apex/MI_DocumentAccuracyController.getSummary";

// Prefix the extraction service writes onto Tabular_Error__c for a partial extraction. This card sits on the
// same record page as miDocumentTabularReindex, which owns that note and renders it in full — so repeating the
// verbose "[일부 미추출]" block here is pure duplication. Keep in sync with the reindex card's PARTIAL_PREFIX and
// MI_TabularExtractionService.WARNING_PREFIX.
const PARTIAL_PREFIX = "[일부 미추출]";

/**
 * Shows how accurate and how complete this document's extracted figures are, and — just as prominently — over
 * what range that was measured.
 *
 * The range matters as much as the number. A recall figure quoted alone invites the reader to assume the whole
 * document was checked, when in practice a golden set covers the pages a human had time to verify. So the card
 * always states the reviewed scope next to the headline, and every per-page row carries its own state rather
 * than only a percentage.
 *
 * WHAT THE STATES MEAN, and why they are not one scale:
 *   not_reviewed          — nobody checked this page. Carries no rate at all; 0% here would assert a failure
 *                           that was never observed.
 *   no_figures            — checked, and the page holds no figures. Extracting nothing is CORRECT.
 *   unexpected_rows       — checked as figure-less, yet rows were stored. A real defect.
 *   no_match              — has reference figures, none matched. In practice a systematic coordinate/notation
 *                           mismatch rather than many independent errors, so it is called out separately.
 *   weak / partial / good — a genuine match rate.
 */
/**
 * Display decoration per page state. Deliberately NOT a red/green gradient: three of these states are not
 * quality judgments, and colouring them like a score would misread a pass as a failure.
 */
const DECORATIONS = {
  good: {
    label: "양호",
    icon: "utility:success",
    variant: "success",
    rowClass: "slds-hint-parent"
  },
  partial: {
    label: "부분 일치",
    icon: "utility:warning",
    variant: "warning",
    rowClass: "slds-hint-parent"
  },
  weak: {
    label: "미흡",
    icon: "utility:warning",
    variant: "error",
    rowClass: "slds-hint-parent"
  },
  no_match: {
    label: "전량 불일치",
    icon: "utility:error",
    variant: "error",
    rowClass: "slds-hint-parent slds-text-color_error"
  },
  no_figures: {
    label: "수치 없음 (정상)",
    icon: "utility:info",
    variant: "",
    rowClass: "slds-hint-parent"
  },
  unexpected_rows: {
    label: "불필요한 행",
    icon: "utility:error",
    variant: "error",
    rowClass: "slds-hint-parent slds-text-color_error"
  },
  reviewed_no_reference: {
    label: "정답 미입력",
    icon: "utility:info",
    variant: "",
    rowClass: "slds-hint-parent"
  },
  not_reviewed: {
    label: "미검수",
    icon: "utility:dash",
    variant: "",
    rowClass: "slds-hint-parent slds-text-color_weak"
  }
};

/**
 * A short description of a page's problems, or a dash when it has none.
 *
 * @param {object} row The page row
 * @returns {string} The label
 */
function issueLabel(row) {
  const parts = [];
  if (row.unitMismatch) {
    parts.push(`단위 ${row.unitMismatch}`);
  }
  if (row.valueMismatch) {
    parts.push(`값 ${row.valueMismatch}`);
  }
  // Period and entity mis-attribution are the most common real defects this pipeline produces, so they get their
  // own labels rather than being folded into a generic count.
  if (row.periodMismatch) {
    parts.push(`기간 ${row.periodMismatch}`);
  }
  if (row.entityMismatch) {
    parts.push(`대상 ${row.entityMismatch}`);
  }
  if (row.unverifiable) {
    parts.push(`확인불가 ${row.unverifiable}`);
  }
  // Shown rather than dropped: a verdict this card has no named counter for still happened, and hiding it would
  // make the page's parts silently fail to add up to its whole.
  if (row.otherVerdicts) {
    parts.push(`기타 ${row.otherVerdicts}`);
  }
  return parts.length ? parts.join(" · ") : "—";
}

export default class MiDocumentTabularAccuracy extends LightningElement {
  @api recordId;

  summary;
  loadError;

  @wire(getSummary, { documentId: "$recordId" })
  wiredSummary({ data, error }) {
    if (data) {
      this.summary = data;
      this.loadError = undefined;
    } else if (error) {
      this.loadError =
        error?.body?.message ||
        error?.message ||
        "품질 요약을 읽지 못했습니다.";
      this.summary = undefined;
    }
  }

  get hasSummary() {
    return !!this.summary;
  }

  /** True once a scoring run exists. Until then no percentage may be shown. */
  get hasRun() {
    return !!this.summary && this.summary.hasRun === true;
  }

  /** The card title, naming the document so a screenshot is self-describing. */
  get cardTitle() {
    return this.summary?.fileName
      ? `추출 품질 — ${this.summary.fileName}`
      : "추출 품질";
  }

  /** Extraction state line: rows stored and the pipeline's own status. */
  get extractionLine() {
    if (!this.summary) {
      return null;
    }
    return `${this.summary.storedRowCount ?? 0}행 저장 · 추출 상태 ${
      this.summary.extractionStatus || "미실행"
    } · 정답 ${this.summary.goldenRowCount ?? 0}건`;
  }

  /**
   * The completeness note the extraction left behind, if any.
   *
   * These notes ride on a COMPLETE document, so the panel shows them whenever one exists rather than only on
   * an error status. The one exception is the "[일부 미추출]" partial-extraction note: the extraction card
   * above (miDocumentTabularReindex) owns it and renders it in full, so echoing it here just clutters the
   * quality card with the same wall of text. A "[표 없음]" note and a genuine error still show through.
   */
  get extractionNote() {
    const note = this.summary?.extractionNote || null;
    if (note && note.startsWith(PARTIAL_PREFIX)) {
      return null;
    }
    return note;
  }

  get hasExtractionNote() {
    return !!this.extractionNote;
  }

  /** Recall with its credible interval, so a small reference set cannot read as a precise figure. */
  get recallLine() {
    if (!this.hasRun || this.summary.recallPercent === null) {
      return null;
    }
    const bounds =
      this.summary.recallLowerPercent !== null &&
      this.summary.recallUpperPercent !== null
        ? ` [${this.summary.recallLowerPercent}% – ${this.summary.recallUpperPercent}%]`
        : "";
    return `${this.summary.recallPercent}%${bounds}`;
  }

  get precisionLine() {
    if (!this.hasRun || this.summary.precisionPercent === null) {
      return null;
    }
    return `${this.summary.precisionPercent}%`;
  }

  /** The counts behind the two rates, so a reader can see the sample size rather than trust a percentage. */
  get countsLine() {
    if (!this.hasRun) {
      return null;
    }
    return `일치 ${this.summary.truePositive} · 누락 ${this.summary.falseNegative} · 불일치 ${this.summary.falsePositive} (단위 ${this.summary.unitErrors} / 값 ${this.summary.valueErrors}) · 확인불가 ${this.summary.unverifiable}`;
  }

  /**
   * The reviewed range, stated next to the headline.
   *
   * Without this the two percentages read as document-wide. With it they read as what they are: a measurement
   * over the pages a human verified.
   */
  get scopeLine() {
    if (!this.summary) {
      return null;
    }
    const complete = this.summary.pagesReviewedComplete ?? 0;
    const partial = this.summary.pagesReviewedPartial ?? 0;
    const noFigures = this.summary.pagesNoFigures ?? 0;
    if (complete + partial + noFigures === 0) {
      return "검수 범위 기록이 없습니다 — 아래 수치는 정답 행이 있는 페이지에 한한 결과이며, 문서 전체를 대표하지 않습니다.";
    }
    return `검수 범위: 전수 ${complete}페이지 · 일부 ${partial}페이지 · 수치 없음 ${noFigures}페이지`;
  }

  /** Whether any page was reviewed only partially, which makes the recall a lower bound. */
  get hasPartialScope() {
    return (this.summary?.pagesReviewedPartial ?? 0) > 0;
  }

  /** Per-page rows decorated for display, since the template cannot compute a label from a state. */
  get pageRows() {
    if (!this.summary?.pages) {
      return [];
    }
    return this.summary.pages.map((row) => {
      const decoration = DECORATIONS[row.verdict] || DECORATIONS.not_reviewed;
      return {
        key: row.page,
        page: row.page,
        goldenFigures: row.goldenFigures || 0,
        matched: row.matched || 0,
        missed: row.missed || 0,
        // A rate of null must print as an em dash, never as 0 — that distinction is the whole point.
        rateLabel:
          row.matchRatePercent === null || row.matchRatePercent === undefined
            ? "—"
            : `${row.matchRatePercent}%`,
        issues: issueLabel(row),
        stateLabel: decoration.label,
        iconName: decoration.icon,
        iconVariant: decoration.variant,
        rowClass: decoration.rowClass
      };
    });
  }

  get hasPageRows() {
    return this.pageRows.length > 0;
  }

  /**
   * What this measurement covered — formats, extraction routes, document sources.
   *
   * Shown because accuracy is not one number: the four extraction routes fail in different ways, so a figure
   * measured on one PDF says nothing about a docx.
   */
  get coverageLine() {
    if (!this.summary) {
      return null;
    }
    const parts = [];
    if (this.summary.coveredFormats) {
      parts.push(`형식 ${this.summary.coveredFormats}`);
    }
    if (this.summary.coveredRoutes) {
      parts.push(`경로 ${this.summary.coveredRoutes}`);
    }
    if (this.summary.coveredDocumentTypes) {
      parts.push(`출처 ${this.summary.coveredDocumentTypes}`);
    }
    return parts.length ? parts.join(" · ") : null;
  }

  get hasCoverageLine() {
    return !!this.coverageLine;
  }

  /** What the run did NOT cover. The half a reader would otherwise fill in with an assumption. */
  get coverageNote() {
    return this.summary?.coverageNote || null;
  }

  get hasCoverageNote() {
    return !!this.coverageNote;
  }

  /** True once the LLM judge has audited this document. */
  get hasJudgeRun() {
    return !!this.summary && this.summary.hasJudgeRun === true;
  }

  /** Whether either retrieval leg (figure lookup or document retrieval) touched this document. */
  get hasRetrieval() {
    return (
      !!this.summary &&
      (this.summary.hasFigureProbe === true ||
        this.summary.hasDocProbe === true)
    );
  }

  get hasFigureProbe() {
    return !!this.summary && this.summary.hasFigureProbe === true;
  }

  get hasDocProbe() {
    return !!this.summary && this.summary.hasDocProbe === true;
  }

  /** "N/M 적중 (P%)" for the SOQL figure-lookup probe; measured-or-"측정 안 됨", never a bare 0%. */
  get figureProbeLine() {
    if (!this.hasFigureProbe) {
      return null;
    }
    const rate = this.summary.figureProbeHitRatePercent;
    if (rate === null || rate === undefined) {
      return "측정 안 됨 (프로브 없음)";
    }
    return `${this.summary.figureProbeHits}/${this.summary.figureProbeTotal} 적중 (${rate}%)`;
  }

  /** "N/M 적중 (P%)" for the hybrid document-retrieval probe. */
  get docProbeLine() {
    if (!this.hasDocProbe) {
      return null;
    }
    const rate = this.summary.docProbeHitRatePercent;
    if (rate === null || rate === undefined) {
      return "측정 안 됨 (프로브 없음)";
    }
    return `${this.summary.docProbeHits}/${this.summary.docProbeTotal} 적중 (${rate}%)`;
  }

  /**
   * Whether the judge's figures may be quoted.
   *
   * The whole risk of an LLM judge is that its output LOOKS like a measurement, so this flag decides whether the
   * numbers below are presented as findings or as provisional readings.
   */
  get isJudgePresentable() {
    return this.hasJudgeRun && this.summary.judgePresentable === true;
  }

  /** Why the judge's figures cannot be quoted, when they cannot. */
  get judgeCaveat() {
    return this.hasJudgeRun ? this.summary.judgeCaveat : null;
  }

  get hasJudgeCaveat() {
    return !!this.judgeCaveat;
  }

  /**
   * The judge's own accuracy, measured against the golden set.
   *
   * This is the figure that licenses everything else the judge says, so it leads the judge section rather than
   * sitting at the bottom as a footnote.
   */
  get judgeCredibilityLine() {
    if (!this.hasJudgeRun) {
      return null;
    }
    const precision =
      this.summary.judgePrecisionPercent === null ||
      this.summary.judgePrecisionPercent === undefined
        ? "측정 안 됨"
        : `${this.summary.judgePrecisionPercent}%`;
    const recall =
      this.summary.judgeRecallPercent === null ||
      this.summary.judgeRecallPercent === undefined
        ? "측정 안 됨"
        : `${this.summary.judgeRecallPercent}%`;
    return `골든셋 대비 심판 정밀도 ${precision} · 재현율 ${recall}`;
  }

  /**
   * RAGAS Faithfulness, always rendered with its denominator.
   *
   * A ratio without its denominator hides how few rows it rests on, which is the same reason the recall figure
   * carries a credible interval.
   */
  get faithfulnessLine() {
    if (!this.hasJudgeRun) {
      return null;
    }
    if (
      this.summary.faithfulnessPercent === null ||
      this.summary.faithfulnessPercent === undefined
    ) {
      return "측정 안 됨 (판정 가능한 행이 없었습니다)";
    }
    return `${this.summary.faithfulnessPercent}% (${this.summary.faithfulnessGrounded}/${this.summary.faithfulnessDenominator}행 원문 인용 확인)`;
  }

  /**
   * The planted-error detection rate — the only evidence about what the judge MISSES.
   *
   * Precision says whether the judge is right when it speaks; without this, its silence means nothing.
   */
  get syntheticLine() {
    if (!this.hasJudgeRun || !this.summary.syntheticInjected) {
      return "합성 오류를 주입하지 않아 심판이 놓치는 결함은 측정되지 않았습니다.";
    }
    return `합성 오류 검출 ${this.summary.syntheticCaught}/${this.summary.syntheticInjected}건`;
  }
}
