import { LightningElement, api, track, wire } from "lwc";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getBakeoff from "@salesforce/apex/MI_AnswerBakeoffController.getBakeoff";
import setHumanWinner from "@salesforce/apex/MI_AnswerBakeoffController.setHumanWinner";

/**
 * Side-by-side ANSWER-QUALITY BAKE-OFF comparison. For one bake-off group it shows each question as a block, and
 * within it every generator's answer as a column carrying its objective faithfulness/relevancy score and the
 * LLM's RECOMMENDED pairwise rank. A person reads the answers side by side and clicks "이 답변을 최종 선택" on
 * the one they judge best — the ONLY write, and a human-only one (the LLM never sets the final winner).
 *
 * HONESTY. The score/rank are shown as a RECOMMENDATION until the answer judge is validated against a human
 * sample: while judgePresentable is false the card carries the same "미검증 — 고객 제시 불가" caveat the rest of
 * the Quality app uses, so an unvalidated judge's numbers are never read as a customer-ready verdict.
 */
export default class MiAnswerBakeoff extends LightningElement {
  _groupId;
  wiredView;
  @track view;
  loadError;
  saving = false;

  /**
   * The bake-off group to render. Settable from a parent (the Home page) or bound on a record/app page.
   * @type {string}
   */
  @api
  get groupId() {
    return this._groupId;
  }
  set groupId(value) {
    this._groupId = value;
  }

  @wire(getBakeoff, { groupId: "$_groupId" })
  wiredBakeoff(result) {
    this.wiredView = result;
    if (result.data) {
      this.view = result.data;
      this.loadError = undefined;
    } else if (result.error) {
      this.loadError = this.readError(result.error);
    }
  }

  /** @returns {boolean} whether a group id has been provided */
  get hasGroup() {
    return !!this._groupId;
  }

  /** @returns {boolean} whether the loaded view has any questions to compare */
  get hasQuestions() {
    return !!(this.view && this.view.questions && this.view.questions.length);
  }

  /** @returns {boolean} whether the judge figures may be quoted (false → show the caveat) */
  get judgePresentable() {
    return !!(this.view && this.view.judgePresentable);
  }

  /** @returns {boolean} whether to show the "unvalidated judge" caveat banner */
  get showUnvalidatedCaveat() {
    return this.hasQuestions && !this.judgePresentable;
  }

  /**
   * The questions, each decorated with per-candidate display helpers (badge text, winner styling) so the
   * template stays declarative.
   * @returns {Array} the decorated question groups
   */
  get decoratedQuestions() {
    if (!this.hasQuestions) {
      return [];
    }
    return this.view.questions.map((q) => ({
      questionKey: q.questionKey,
      question: q.question,
      candidates: (q.candidates || []).map((c) => this.decorateCandidate(c))
    }));
  }

  decorateCandidate(candidate) {
    const faithful =
      candidate.faithfulnessScore === null ||
      candidate.faithfulnessScore === undefined
        ? "측정 안 됨"
        : `${(candidate.faithfulnessScore * 100).toFixed(1)}%`;
    const rank =
      candidate.pairwiseRank === null || candidate.pairwiseRank === undefined
        ? null
        : candidate.pairwiseRank;
    return {
      candidateId: candidate.candidateId,
      generatorKey: candidate.generatorKey,
      generatorLabel: candidate.generatorLabel,
      answer: candidate.answer,
      relevancy: candidate.relevancy,
      pairwiseNote: candidate.pairwiseNote,
      humanWinner: candidate.humanWinner,
      faithfulnessLabel: faithful,
      rankLabel: rank === null ? "추천 순위 없음" : `추천 순위 ${rank}`,
      // A chosen winner gets an emphasized card; others a plain one.
      cardClass: candidate.humanWinner
        ? "slds-box slds-box_x-small winner-card"
        : "slds-box slds-box_x-small candidate-card",
      winnerButtonLabel: candidate.humanWinner
        ? "✓ 최종 선택됨"
        : "이 답변을 최종 선택",
      winnerButtonVariant: candidate.humanWinner ? "success" : "neutral"
    };
  }

  /**
   * Records the human's final-winner choice for a question, then refreshes so the emphasis moves.
   * @param {CustomEvent} event the click event carrying the candidate id in dataset
   */
  async handleChooseWinner(event) {
    const candidateId = event.currentTarget.dataset.id;
    if (!candidateId || this.saving) {
      return;
    }
    this.saving = true;
    try {
      await setHumanWinner({ candidateId });
      await refreshApex(this.wiredView);
      this.dispatchEvent(
        new ShowToastEvent({
          title: "최종 승자 지정",
          message: "이 질문의 최종 승자를 저장했습니다.",
          variant: "success"
        })
      );
    } catch (error) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "저장 실패",
          message: this.readError(error),
          variant: "error"
        })
      );
    } finally {
      this.saving = false;
    }
  }

  readError(error) {
    return (
      (error && error.body && error.body.message) || "알 수 없는 오류입니다."
    );
  }
}
