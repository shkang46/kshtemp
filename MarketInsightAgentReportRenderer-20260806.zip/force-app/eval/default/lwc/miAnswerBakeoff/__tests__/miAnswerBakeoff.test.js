import { createElement } from "lwc";
import MiAnswerBakeoff from "c/miAnswerBakeoff";
import getBakeoff from "@salesforce/apex/MI_AnswerBakeoffController.getBakeoff";
import setHumanWinner from "@salesforce/apex/MI_AnswerBakeoffController.setHumanWinner";

// getBakeoff is a WIRED Apex method → needs a wire-adapter stub (emit/error).
jest.mock(
  "@salesforce/apex/MI_AnswerBakeoffController.getBakeoff",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// setHumanWinner is imperative → a plain jest.fn returning a resolved promise.
jest.mock(
  "@salesforce/apex/MI_AnswerBakeoffController.setHumanWinner",
  () => ({ default: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

const VIEW = {
  groupId: "g1",
  judgePresentable: false,
  questions: [
    {
      questionKey: "Q1",
      question: "삼성 반도체 매출은?",
      candidates: [
        {
          candidateId: "a0C1",
          generatorKey: "AGENT_A",
          generatorLabel: "Agent A",
          answer: "79조원입니다.",
          faithfulnessScore: 0.9,
          relevancy: "Relevant",
          pairwiseRank: 1,
          pairwiseNote: "충실",
          humanWinner: false
        },
        {
          candidateId: "a0C2",
          generatorKey: "TEMPLATE_B",
          generatorLabel: "Template B",
          answer: "큽니다.",
          faithfulnessScore: null,
          relevancy: "Irrelevant",
          pairwiseRank: 2,
          pairwiseNote: "모호",
          humanWinner: false
        }
      ]
    }
  ]
};

function createComponent(groupId = "g1") {
  const element = createElement("c-mi-answer-bakeoff", { is: MiAnswerBakeoff });
  element.groupId = groupId;
  document.body.appendChild(element);
  return element;
}

afterEach(() => {
  while (document.body.firstChild) {
    document.body.removeChild(document.body.firstChild);
  }
  jest.clearAllMocks();
});

describe("c-mi-answer-bakeoff", () => {
  it("renders one card per generator candidate", async () => {
    const element = createComponent();
    getBakeoff.emit(VIEW);
    await Promise.resolve();

    const buttons = element.shadowRoot.querySelectorAll("lightning-button");
    // One "final winner" button per candidate → 2.
    expect(buttons.length).toBe(2);
    const richText = element.shadowRoot.querySelectorAll(
      "lightning-formatted-rich-text"
    );
    expect(richText.length).toBe(2);
  });

  it("shows the unvalidated-judge caveat when judgePresentable is false", async () => {
    const element = createComponent();
    getBakeoff.emit(VIEW);
    await Promise.resolve();

    const body = element.shadowRoot.textContent;
    expect(body).toContain("심판 미검증");
  });

  it("shows 측정 안 됨 for a null faithfulness score, not 0%", async () => {
    const element = createComponent();
    getBakeoff.emit(VIEW);
    await Promise.resolve();

    const badges = Array.from(
      element.shadowRoot.querySelectorAll("lightning-badge")
    ).map((b) => b.label);
    expect(badges).toContain("측정 안 됨");
    expect(badges).not.toContain("0.0%");
  });

  it("calls setHumanWinner with the chosen candidate id on click", async () => {
    const element = createComponent();
    getBakeoff.emit(VIEW);
    await Promise.resolve();

    const button = element.shadowRoot.querySelector(
      'lightning-button[data-id="a0C2"]'
    );
    button.click();
    await Promise.resolve();

    expect(setHumanWinner).toHaveBeenCalledWith({ candidateId: "a0C2" });
  });

  it("prompts to pick a bake-off when no group is provided", async () => {
    // Build the element WITHOUT setting groupId (createComponent's default param would otherwise set "g1").
    const element = createElement("c-mi-answer-bakeoff", {
      is: MiAnswerBakeoff
    });
    document.body.appendChild(element);
    await Promise.resolve();
    expect(element.shadowRoot.textContent).toContain("비교할 평가를 선택");
  });
});
