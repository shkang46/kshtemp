import { LightningElement, api, track, wire } from "lwc";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import getContext from "@salesforce/apex/MI_FacetGoldenCaptureController.getContext";
import confirmProposal from "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal";
import saveHumanValue from "@salesforce/apex/MI_FacetGoldenCaptureController.saveHumanValue";
import deleteValue from "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue";

/**
 * Captures a ground-truth FACET value for a document — the facet twin of miGoldenRowCapture. It shows the
 * document's auto-extracted facets (company/industry/geography/as-of-date) beside the human-confirmed golden
 * values, and lets a reviewer either confirm/reject an LLM proposal or enter a value from scratch.
 *
 * WHY THIS EXISTS. The facet judge is validated against these golden values (MI_FacetEvalJudgeValidator). If a
 * model could confirm its own proposals the evaluation would be circular, so promotion to LLM_Confirmed and
 * manual Human entry are the only ways a value becomes reference — both go through a person here. The backend
 * (MI_FacetGoldenCaptureController) was already built and permissioned; this is the missing front-end.
 */
export default class MiFacetGoldenCapture extends LightningElement {
  /** Set by the document record page. */
  @api recordId;

  @track context;
  loadError;
  @track isSaving = false;

  // The draft a reviewer is entering. Mirrored into a private object so no @api prop is ever mutated.
  @track draft = {
    facetField: "Facet_Companies_Mentioned__c",
    valueText: "",
    sourceSnippet: ""
  };

  // The whole wire result is retained so a write can refreshApex it to re-pull the golden/extracted lists.
  _wired;

  facetFieldOptions = [
    { label: "회사 (Companies)", value: "Facet_Companies_Mentioned__c" },
    { label: "산업 (Industry)", value: "Facet_Industry__c" },
    { label: "지역 (Geography)", value: "Facet_Geography__c" },
    { label: "기준일 (As-of Date)", value: "Facet_As_Of_Date__c" }
  ];

  @wire(getContext, { documentId: "$recordId" })
  wiredContext(result) {
    this._wired = result;
    const { data, error } = result;
    if (data) {
      this.context = data;
      this.loadError = undefined;
    } else if (error) {
      this.context = undefined;
      this.loadError =
        error?.body?.message || "패싯 정답 현황을 불러오지 못했습니다.";
    }
  }

  get hasContext() {
    return !!this.context;
  }

  /** The recorded golden values, decorated for display (a friendly facet label + whether it is a proposal). */
  get goldenValues() {
    const labels = {
      Facet_Companies_Mentioned__c: "회사",
      Facet_Industry__c: "산업",
      Facet_Geography__c: "지역",
      Facet_As_Of_Date__c: "기준일"
    };
    return (this.context?.goldenValues || []).map((v) => ({
      ...v,
      facetLabel: labels[v.facetField] || v.facetField,
      isProposal: v.provenance === "LLM_Proposed",
      provenanceLabel: this.provenanceLabel(v.provenance)
    }));
  }

  get hasGoldenValues() {
    return this.goldenValues.length > 0;
  }

  /** The document's auto-extracted facets, for side-by-side review while entering the golden truth. */
  get extractedFacets() {
    const labels = {
      Facet_Companies_Mentioned__c: "회사",
      Facet_Industry__c: "산업",
      Facet_Geography__c: "지역",
      Facet_As_Of_Date__c: "기준일"
    };
    return (this.context?.extractedFacets || []).map((f) => ({
      facetField: f.facetField,
      facetLabel: labels[f.facetField] || f.facetField,
      valueText: (f.values || []).join(", ") || "(없음)"
    }));
  }

  get hasExtractedFacets() {
    return this.extractedFacets.length > 0;
  }

  /**
   * A Korean label for a provenance value.
   *
   * @param {string} provenance The stored Provenance__c
   * @returns {string} The display label
   */
  provenanceLabel(provenance) {
    return (
      {
        Human: "사람 입력",
        LLM_Proposed: "LLM 제안 (승인 대기)",
        LLM_Confirmed: "LLM 제안 → 승인됨"
      }[provenance] || provenance
    );
  }

  handleFacetFieldChange(event) {
    this.draft = { ...this.draft, facetField: event.detail.value };
  }

  handleValueChange(event) {
    this.draft = { ...this.draft, valueText: event.detail.value };
  }

  handleSnippetChange(event) {
    this.draft = { ...this.draft, sourceSnippet: event.detail.value };
  }

  get isSaveDisabled() {
    return this.isSaving || !this.draft.valueText;
  }

  /**
   * Saves the reviewer's hand-entered facet value as a Human golden value, then refreshes.
   */
  async handleSave() {
    this.isSaving = true;
    try {
      const newId = await saveHumanValue({
        documentId: this.recordId,
        facetField: this.draft.facetField,
        valueText: this.draft.valueText,
        sourceSnippet: this.draft.sourceSnippet
      });
      if (newId) {
        this.toast("정답 저장", "패싯 정답 값을 기록했습니다.", "success");
        this.draft = { ...this.draft, valueText: "", sourceSnippet: "" };
        await refreshApex(this._wired);
      } else {
        this.toast(
          "중복 값",
          "같은 패싯에 이미 있는 값이라 저장하지 않았습니다.",
          "info"
        );
      }
    } catch (error) {
      this.toast("저장하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isSaving = false;
    }
  }

  /**
   * Promotes the clicked LLM proposal to a confirmed reference value.
   *
   * @param {Event} event The click event; currentTarget carries data-id (the golden value Id)
   */
  async handleConfirm(event) {
    const goldenId = event.currentTarget.dataset.id;
    this.isSaving = true;
    try {
      await confirmProposal({ goldenId });
      this.toast("승인 완료", "LLM 제안을 정답으로 확정했습니다.", "success");
      await refreshApex(this._wired);
    } catch (error) {
      this.toast("승인하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isSaving = false;
    }
  }

  /**
   * Deletes the clicked golden value (e.g. rejecting a proposal).
   *
   * @param {Event} event The click event; currentTarget carries data-id (the golden value Id)
   */
  async handleDelete(event) {
    const goldenId = event.currentTarget.dataset.id;
    this.isSaving = true;
    try {
      await deleteValue({ goldenId });
      this.toast("삭제", "패싯 정답 값을 삭제했습니다.", "success");
      await refreshApex(this._wired);
    } catch (error) {
      this.toast("삭제하지 못했습니다", this.messageOf(error), "error");
    } finally {
      this.isSaving = false;
    }
  }

  /**
   * The message from an Apex error, falling back to something actionable.
   *
   * @param {object} error The rejected Apex error
   * @returns {string} A displayable message
   */
  messageOf(error) {
    return (
      error?.body?.message ||
      error?.message ||
      "알 수 없는 오류가 발생했습니다."
    );
  }

  /**
   * Shows a toast.
   *
   * @param {string} title The toast title
   * @param {string} message The body
   * @param {string} variant success | warning | error | info
   */
  toast(title, message, variant) {
    this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
  }
}
