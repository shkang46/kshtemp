import { createElement } from "lwc";
import MiFacetGoldenCapture from "c/miFacetGoldenCapture";
import getContext from "@salesforce/apex/MI_FacetGoldenCaptureController.getContext";
import confirmProposal from "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal";
import saveHumanValue from "@salesforce/apex/MI_FacetGoldenCaptureController.saveHumanValue";
import deleteValue from "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue";

// getContext is WIRED → wire-adapter stub (emit/error).
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.getContext",
  () => {
    const {
      createApexTestWireAdapter
    } = require("@salesforce/wire-service-jest-util");
    return { default: createApexTestWireAdapter(jest.fn()) };
  },
  { virtual: true }
);

// The three writes are IMPERATIVE → plain jest.fn.
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.confirmProposal",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.saveHumanValue",
  () => ({ default: jest.fn() }),
  { virtual: true }
);
jest.mock(
  "@salesforce/apex/MI_FacetGoldenCaptureController.deleteValue",
  () => ({ default: jest.fn() }),
  { virtual: true }
);

jest.mock(
  "@salesforce/apex",
  () => ({ refreshApex: jest.fn(() => Promise.resolve()) }),
  { virtual: true }
);

const RECORD_ID = "a0X000000000001AAA";

const CONTEXT = {
  goldenValues: [
    {
      id: "a1G000000000001",
      facetField: "Facet_Industry__c",
      valueText: "Semiconductors",
      provenance: "LLM_Proposed",
      sourceSnippet: "the semiconductor market…",
      note: null
    },
    {
      id: "a1G000000000002",
      facetField: "Facet_Companies_Mentioned__c",
      valueText: "Samsung",
      provenance: "Human",
      sourceSnippet: null,
      note: null
    }
  ],
  extractedFacets: [
    { facetField: "Facet_Companies_Mentioned__c", values: ["Samsung", "SK"] },
    { facetField: "Facet_Industry__c", values: ["Semiconductors"] },
    { facetField: "Facet_Geography__c", values: ["Korea"] },
    { facetField: "Facet_As_Of_Date__c", values: ["2024-Q3"] }
  ]
};

function createComponent() {
  const element = createElement("c-mi-facet-golden-capture", {
    is: MiFacetGoldenCapture
  });
  element.recordId = RECORD_ID;
  document.body.appendChild(element);
  return element;
}

async function emit(data) {
  getContext.emit(data);
  await Promise.resolve();
}

async function flush() {
  for (let i = 0; i < 4; i++) {
    // eslint-disable-next-line no-await-in-loop
    await Promise.resolve();
  }
}

describe("c-mi-facet-golden-capture", () => {
  afterEach(() => {
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    jest.clearAllMocks();
  });

  it("renders the extracted facets and recorded golden values", async () => {
    const element = createComponent();
    await emit(CONTEXT);

    const text = element.shadowRoot.textContent;
    expect(text).toContain("자동 추출된 패싯");
    expect(text).toContain("Semiconductors");
    expect(text).toContain("Samsung");
    // The proposal is labelled as awaiting approval; the human value as human-entered.
    expect(text).toContain("LLM 제안 (승인 대기)");
    expect(text).toContain("사람 입력");
  });

  it("shows a 승인 button only for LLM proposals", async () => {
    const element = createComponent();
    await emit(CONTEXT);

    const confirmButtons = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).filter((b) => b.label === "승인");
    // Only the one LLM_Proposed row gets a 승인 button.
    expect(confirmButtons.length).toBe(1);
  });

  it("confirms a proposal and refreshes", async () => {
    confirmProposal.mockResolvedValue(undefined);
    const element = createComponent();
    await emit(CONTEXT);

    const confirmButton = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((b) => b.label === "승인");
    confirmButton.click();
    await flush();

    expect(confirmProposal).toHaveBeenCalledWith({
      goldenId: "a1G000000000001"
    });
  });

  it("saves a hand-entered value when one is typed", async () => {
    saveHumanValue.mockResolvedValue("a1G000000000009");
    const element = createComponent();
    await emit(CONTEXT);

    // Type a value, then click save.
    const valueInput = Array.from(
      element.shadowRoot.querySelectorAll("lightning-input")
    ).find((i) => i.label === "정답 값");
    valueInput.dispatchEvent(
      new CustomEvent("change", { detail: { value: "TSMC" } })
    );
    await Promise.resolve();

    const saveButton = element.shadowRoot.querySelector(
      "lightning-button[data-id='save-facet']"
    );
    expect(saveButton.disabled).toBe(false);
    saveButton.click();
    await flush();

    expect(saveHumanValue).toHaveBeenCalledWith({
      documentId: RECORD_ID,
      facetField: "Facet_Companies_Mentioned__c",
      valueText: "TSMC",
      sourceSnippet: ""
    });
  });

  it("disables save until a value is entered", async () => {
    const element = createComponent();
    await emit(CONTEXT);

    const saveButton = element.shadowRoot.querySelector(
      "lightning-button[data-id='save-facet']"
    );
    expect(saveButton.disabled).toBe(true);
  });

  it("deletes a golden value when its 삭제 button is clicked", async () => {
    deleteValue.mockResolvedValue(undefined);
    const element = createComponent();
    await emit(CONTEXT);

    // The human-entered row (no 승인 button) still has a 삭제 button; click the first one.
    const deleteButton = Array.from(
      element.shadowRoot.querySelectorAll("lightning-button")
    ).find((b) => b.label === "삭제");
    deleteButton.click();
    await flush();

    expect(deleteValue).toHaveBeenCalledTimes(1);
    expect(deleteValue.mock.calls[0][0].goldenId).toBeDefined();
  });

  it("shows the empty state when no golden values exist", async () => {
    const element = createComponent();
    await emit({ goldenValues: [], extractedFacets: CONTEXT.extractedFacets });

    expect(element.shadowRoot.textContent).toContain(
      "아직 이 문서에 기록된 패싯 정답 값이 없습니다"
    );
  });
});
