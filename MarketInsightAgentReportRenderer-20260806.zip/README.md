# Market Insight Agent — Report Renderer

**시장 자료를 올려두면, 근거 있는 보고서를 써 주고 정확한 수치를 답해 주는 Salesforce 패키지입니다.**

Korean-first Agentforce 직원(Employee) 에이전트 `Market_Insight_Agent_v2`, 그리고 이를 뒷받침하는 문서 인텔리전스
파이프라인으로 구성됩니다. 크게 두 가지를 합니다 — ① 사용자가 **목차를 승인한 뒤** 여러 섹션짜리
시장 보고서를 실제 문서 발췌에 근거해 생성하고, ② 업로드된 문서의 **표에서 수치를 뽑아 조회 가능한 팩트
테이블로** 정규화해 정확한 숫자를 SOQL로 답합니다.

특정 산업에 국한되지 않습니다. 연결된 자료가 다루는 무엇이든(시장 동향, 경쟁사 전략, 신규 기술) 이해를
돕는 것이 목적이며, 자료가 있는지는 라우터가 아니라 근거 검색이 판단합니다. 모든 생성물은 **실제 문서
발췌에만 근거**합니다 — 없는 내용을 지어내지 않는 것이 이 저장소의 첫 번째 원칙입니다.

> 사용자 응답과 보고서 본문은 자연스러운 **한국어**, 검색 패싯 **값**은 **영어**로 씁니다(Coworker의 검색
> 인덱스가 영어에 최적화돼 있습니다).

---

## 1. 무엇을 할 수 있는가

| 누가                   | 무엇을 하려 할 때                             | 이 패키지가 제공하는 것                                                  |
| ---------------------- | --------------------------------------------- | ------------------------------------------------------------------------ |
| **리서치 담당**        | 여러 섹션짜리 시장 보고서를 초안까지 빠르게   | 목차 승인 후 자동 생성 → 레코드 페이지에서 진행 확인 → **Word 내보내기** |
| **애널리스트**         | "소니 25Q3 매출액?" 같은 **정확한 숫자**      | 벡터 검색이 아닌 **SOQL 결정론적 조회** (`tabular_analyst`)              |
| **자료 관리자**        | 수백 개 문서를 검색 가능한 상태로 만들기      | 업로드 즉시 패싯 자동 생성 + 표 데이터 추출 (형식별 4경로)               |
| **품질 담당**          | 추출 정확도를 감이 아니라 수치로 증명         | 정답셋 채점 · 산술 정합성 · 검색 프로브 + 신용구간 (`eval` 트리)         |
| **보고서를 읽는 사람** | 이 숫자가 어느 문서 몇 페이지에서 왔는지 확인 | 섹션별 인용 + 원본 파일 페이지 미리보기 (`miInteractivePreview`)         |

**이 저장소가 하지 않는 것:** 단순 문서 검색 · 파일 목록 조회 · 잡담. 그 역할은 Agentforce **Coworker**(범용
"정문")로 이관됐고, 여기서는 `off_topic` 으로 정중히 돌려보냅니다. 이 저장소는 **도메인 특화 전문가** 쪽입니다.

---

## 2. Quick Start

### 2.1 사전 준비

| 항목         | 요구 사항                                                                                  |
| ------------ | ------------------------------------------------------------------------------------------ |
| org          | **Data Cloud** + **Einstein / Prompt Builder**(`EinsteinGPTPlatformAddOn`) 활성화          |
| 모델         | File 입력을 쓰는 템플릿은 **멀티모달 Claude 모델** 필요. **이 프로젝트는 Claude만 씁니다** |
| CLI          | Salesforce CLI (`sf`) v2                                                                   |
| Node         | LWC 단위 테스트 · lint 도구용                                                              |
| Metadata API | **67.0** (모든 `-meta.xml` 이 동일 버전이어야 배포됩니다)                                  |

### 2.2 배포 순서 — 순서가 중요합니다

**① 프롬프트 템플릿을 org에서 먼저 만듭니다.** Apex가 템플릿을 **API 이름으로** 참조하므로 org에 먼저
존재해야 합니다. 로컬에서 XML을 만들어 배포하면 `versionId` 가 어긋나 템플릿이 깨집니다.
작성법은 [docs/agent/prompt-templates-authoring-guide.md](docs/agent/prompt-templates-authoring-guide.md)(보고서)와
[docs/ingest/tabular-extract-prompt-authoring.md](docs/ingest/tabular-extract-prompt-authoring.md)(표 데이터 추출).
만든 뒤 `sf project retrieve start -m GenAiPromptTemplate:<name>` 로 가져옵니다.

**② 메타데이터를 배포합니다. 타입별 디렉터리를 나열하지 말고 트리를 넘기세요** — 나열하면 나머지 트리를
조용히 빼먹습니다.

```bash
sf project deploy start --source-dir force-app     # 도메인 트리 네 개 전부 (운영 + 테스트)
sf project deploy start --source-dir datakit       # Data Cloud datakit
```

datakit은 **소스 디렉터리로** 배포해야 하고(매니페스트가 불완전), 배포 후 Data Cloud에서 **kit을 활성화하고
데이터 스트림을 갱신**해야 검색 인덱스가 채워집니다 — 배포만으로는 채워지지 않습니다.
[docs/deployment/Hand-off.md](docs/deployment/Hand-off.md) §4.3.

**③ 권한을 부여합니다.** 기본 읽기를 전원에게, 역할별 애드온을 얹습니다.

```bash
sf org assign permset --name Market_Insight_User               # 기본(읽기) — 전원
sf org assign permset --name Market_Insight_Report_Creator     # 보고서 생성자 + Einstein Agent User
sf org assign permset --name Market_Insight_Document_Uploader  # 자료 업로드 담당
sf org assign permset --name Market_Insight_Quality_Analyst    # 추출 품질 평가 담당
```

에이전트 액션을 실행하는 **Einstein Agent User** 에게도 `Market_Insight_Report_Creator` 를 부여해야 라이브
실행이 됩니다. 권한이 없으면 v67 사용자 모드에서 `No such column 'X__c'` 로 실패하는데, 이는 오타가 아니라
FLS 누락입니다.

> ⚠️ **파일을 올리는 사람에게 `Query Non Vetoed Files` 를 절대 부여하지 마세요.** Data Cloud 파일 수집이
> 켜진 org에서 이 권한을 가진 사용자는 모든 업로드가 "0 of 1 file uploaded" 에서 멈춥니다. 파일은 실제로
> 생성되지만 **모든 조회 경로에서 숨겨져** 컴포넌트가 `ContentDocumentId` 를 못 받습니다. 이 권한은 Data
> Cloud **색인 통합 사용자** 전용입니다. 원인·30초 진단·해결:
> [docs/deployment/file-upload-vetoing-incident.md](docs/deployment/file-upload-vetoing-incident.md).

**④ 스케줄 작업을 설치합니다 — 배포로는 설치되지 않습니다.** `System.schedule` 은 런타임 호출이므로 클래스를
배포해도 스케줄은 생기지 않습니다. org당 한 번 실행하세요.

```bash
# 선택 — 이름/파일명이 빈 쓰레기 문서 레코드를 야간에 정리
sf apex run --file /dev/stdin <<< 'MI_DocumentCleanupSchedulable.scheduleDaily();'
```

pptx와 (업로드 시점에 렌디션이 준비되지 않은) 레거시 문서는 `Tabular_Status__c = 'Pending'` 으로 대기하며,
**이를 이어받는 스케줄은 없습니다** — 필요할 때 렌디션 백필 배치를 직접 실행하세요.

```bash
sf apex run --file /dev/stdin <<< 'MI_TabularRenditionBackfillBatch.start();'
```

자세한 내용은 [§5 스케줄 작업](#5-스케줄-작업-scheduled-apex).

**⑤ 에이전트를 검증하고 활성화합니다.**

```bash
sf agent validate authoring-bundle --api-name Market_Insight_Agent_v2
sf agent preview start --use-live-actions --authoring-bundle Market_Insight_Agent_v2
# 만족스러우면 publish + activate
```

publish/activate는 **Web UI**로 하는 편이 안전합니다 — CLI는 `bundle-meta.xml` 에 남은 `<target>` 락에 걸려
`CannotFindBundle` 로 실패할 수 있습니다(그 줄을 지우고 재배포하면 CLI도 됩니다).

---

## 3. 사용 시나리오

### 3.1 보고서 생성 — 목차를 승인한 뒤에 만듭니다

```
👤 "삼성 반도체 시장 보고서 작성해줘"

🤖 (자료를 조사한 뒤)
   ## 전략 개요
   … 실제 문서 발췌에 근거한 접근 방향 …
   ## 생성할 목차 (6개 섹션)
   1. 시장 규모와 성장률   2. 주요 경쟁 구도   …
   이 목차대로 보고서를 생성할까요?

👤 "네"

🤖 ✅ 보고서를 생성하기 시작했습니다
   제목: 삼성 반도체 시장 분석
   [📄 보고서 열기](…)
   생성될 목차: 1. 시장 규모와 성장률 …
```

링크를 열면 `miReportViewer` 가 섹션이 완성되는 대로 하나씩 채워 나갑니다. **새로고침** 버튼으로 진행을
확인하고, 실패한 섹션은 **재시도**하고, 차트를 인라인으로 보고, 완료 후 **Word(.docx)로 내보냅니다**.

목차를 고치고 싶으면 "네" 대신 수정 요청을 하면 됩니다. 승인하지 않으면 본문 생성은 시작되지 않습니다.

### 3.2 정확한 수치 질의 — 검색이 아니라 SOQL

```
👤 "소니 25Q3 매출액?"
🤖 2조 9,700억 엔 (Actual) — 출처: Sony_FY25Q3_Results.pdf p.4
```

의미 검색 인덱스는 청킹 과정에서 표를 깨뜨려 **비슷하지만 틀린 숫자**를 돌려줍니다. 그래서 이 질문은
`tabular_analyst` 서브에이전트가 `Market_Insight_Tabular__c` 팩트 테이블에 **SOQL**로 답합니다. 비교값은
`Value_Type__c`(YoY/QoQ)로 태깅돼 있어 조회하면 Actual만 정확히 나옵니다. 합계·순위·성장률 같은 집계도
검증된 GROUP BY로 처리합니다.

### 3.3 자료 업로드 — 올리면 알아서 처리됩니다

`Market_Insight_Document__c` 레코드에 파일을 붙이면 업로드 트리거가 두 가지를 시작합니다.

1. **패싯 메타데이터 생성** — 회사·산업·지역·기준일자·초록을 `Facet_*` 필드에 채우고 Data Cloud DMO로
   미러링해 Coworker의 `hybrid_search()` 가 부스팅에 쓸 수 있게 합니다.
2. **정량 표 데이터 추출** — 형식에 따라 네 갈래로 갈라져(§4.2) 표의 수치를 팩트 테이블로 정규화합니다.

레코드 페이지의 **REINDEX** 버튼으로 둘 중 어느 쪽이든 다시 실행할 수 있고, 진행/오류 상태가 카드에 표시됩니다.
**수백 개**를 한 번에 올릴 때는 `miBulkFileUpload` 대신(선택당 10개 플랫폼 제한) 네이티브 **Files**로 올린 뒤
`scripts/apex/backfill-uploaded-files.apex` 로 `MI_DocumentBackfillBatch` 를 돌리세요 — 이미 연결된 파일은
건너뛰므로 몇 번 돌려도 안전합니다.

---

## 4. 아키텍처

### 4.1 보고서 생성 — 승인 게이트 + 트랜잭션당 콜아웃 1회

동기 in-agent 목차(사람 승인) → 비동기 섹션 체인. `Database.Batchable` scope 1 이라 **트랜잭션당 LLM 콜아웃
1회**를 지키고, 그래서 보고서 길이와 무관하게 거버너 한도를 넘지 않습니다. (Queueable이 아니라 Batchable인
이유는 Dev/trial org의 5-depth 체인 한도를 피하기 위함입니다.)

```mermaid
%%{init: {"flowchart": {"nodeSpacing": 45, "rankSpacing": 50, "curve": "linear"}} }%%
flowchart TB
    user(["👤 보고서 요청"])

    subgraph agent["🤖 에이전트 · 동기 · 사람 승인"]
        research["🔍 자료 조사"]
        toc["📋 전략 + 4-10 섹션 목차"]
        approve{"승인?"}
    end

    subgraph batch["⚡ 비동기 배치 · SCOPE 1 · 트랜잭션당 콜아웃 1회"]
        draft["📝 섹션별 초안"]
        extract["📊 원본 표 추출"]
        verify["✅ 초안 검증"]
        final["📄 마무리 + AI 요약"]
    end

    view(["📊 miReportViewer"])

    user --> research
    research -->|"하이브리드 + 부스트, 최대 3회"| toc
    toc --> approve
    approve -->|"수정"| toc
    approve -->|"네 · create_report"| draft
    draft -->|"검증 OFF"| final
    draft -->|"표 플래그 섹션"| extract
    draft -->|"검증 ON"| verify
    extract -->|"원본 파일을 읽음"| verify
    verify --> final
    final -->|"완료 / 부분 / 오류"| view

    style user fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style research fill:#bae6fd,stroke:#0369a1,color:#1f2937
    style toc fill:#fbcfe8,stroke:#be185d,color:#1f2937
    style approve fill:#fde68a,stroke:#b45309,color:#1f2937
    style draft fill:#fbcfe8,stroke:#be185d,color:#1f2937
    style extract fill:#99f6e4,stroke:#0f766e,color:#1f2937
    style verify fill:#a7f3d0,stroke:#047857,color:#1f2937
    style final fill:#a7f3d0,stroke:#047857,color:#1f2937
    style view fill:#bae6fd,stroke:#0369a1,color:#1f2937
    style agent fill:#fdf2f8,stroke:#be185d,stroke-dasharray:5
    style batch fill:#f5f3ff,stroke:#6d28d9,stroke-dasharray:5
```

실패 경로는 일관되게 보수적입니다. 검증 응답이 비었거나 쓸 수 없으면 **초안을 유지**하고(덮어쓰지 않음),
섹션에서 오류가 나면 한국어 안내를 남기고 **체인을 깨끗이 멈춥니다**(재큐잉하지 않음).

**선택 기능 2개** — 둘 다 Custom Metadata 게이트입니다.

- **2-pass 검증** (`Report_Section_Verify_Enabled__c`, **org에서 현재 ON**) — 독립된 두 번째 LLM 호출이
  초안의 수치·연도·기업명을 **같은 근거**와 대조해 근거 없는 것을 보수적으로 걷어냅니다. 초안 작성과 검증이
  한 트랜잭션의 120초 콜아웃 예산을 나눠 쓰지 않도록 **별도 배치 단계**로 돌립니다.
- **정확한 표 추출** (`Report_Exact_Tables_Enabled__c`) — 청킹 인덱스가 깨뜨리는 표를 **원본 파일**에서 읽어
  옵니다. 목차 시점에 "이 섹션의 주제가 표"라고 플래그된 섹션만 대상이고, DRAFT와 VERIFY 사이에서
  (섹션 × 후보파일) 작업 단위로 하나씩 처리합니다. **검증이 함께 ON이어야 효과가 있습니다**(검증 패스가 그
  결과의 소비자입니다).

### 4.2 정량 표 데이터 추출 — 분류기 하나, 경로 네 개

형식 판정은 **딱 한 곳**(`MI_TabularExtractionService.classifyRoute()`)에 있습니다. 이 정책을 두 곳에 두면
반드시 어긋나기 때문입니다(실제로 매번 어긋났습니다). 네 경로 모두 같은 팩트 테이블로 수렴합니다.

```mermaid
%%{init: {"flowchart": {"nodeSpacing": 70, "rankSpacing": 60}} }%%
flowchart LR
    upload(["📎 파일 업로드"])
    route{"classifyRoute()"}

    subgraph pdfroute["📄 PDF · 3-PASS · File 입력"]
        locate["페이지 탐색"] --> range["범위별 추출"] --> pverify["원문 대조 검증"]
    end

    subgraph officeroute["📊 DOCX · XLSX · 파싱에 콜아웃 없음"]
        unzip["zipreader로 그리드 복원"] --> chunk["행 분할, 헤더 반복"] --> oextract["텍스트 추출"] --> overify["텍스트 검증"]
    end

    subgraph deferredroute["🖼️ PPTX · 백필 배치 수동 실행"]
        park["pending 대기"] --> pdfrend["pdf 렌디션 읽기"] --> rereg["pdf로 재등록"]
    end

    subgraph legacyroute["🗂️ DOC · XLS · PPT · 렌디션 미준비 시 수동 실행"]
        textrend["text/plain 렌디션"] --> lchunk["줄 경계로 분할"]
    end

    fact[("💾 Market_Insight_Tabular__c")]
    analyst["🤖 tabular_analyst"]

    upload --> route
    route -->|"pdf"| locate
    route -->|"docx / xlsx"| unzip
    route -->|"pptx"| park
    route -->|"doc / xls / ppt"| textrend
    route -->|"txt, 기타"| skip(["조용히 건너뜀"])
    rereg --> locate
    lchunk --> oextract
    pverify --> fact
    overify --> fact
    fact -->|"벡터 인덱스가 아니라 soql"| analyst

    style upload fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style route fill:#fde68a,stroke:#b45309,color:#1f2937
    style locate fill:#bae6fd,stroke:#0369a1,color:#1f2937
    style range fill:#bae6fd,stroke:#0369a1,color:#1f2937
    style pverify fill:#a7f3d0,stroke:#047857,color:#1f2937
    style unzip fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style chunk fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style oextract fill:#bae6fd,stroke:#0369a1,color:#1f2937
    style overify fill:#a7f3d0,stroke:#047857,color:#1f2937
    style park fill:#e2e8f0,stroke:#334155,color:#1f2937
    style pdfrend fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style rereg fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style textrend fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style lchunk fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style skip fill:#e2e8f0,stroke:#334155,color:#1f2937
    style fact fill:#fde68a,stroke:#b45309,color:#1f2937
    style analyst fill:#fbcfe8,stroke:#be185d,color:#1f2937
    style pdfroute fill:#f0f9ff,stroke:#0369a1,stroke-dasharray:5
    style officeroute fill:#ecfeff,stroke:#0e7490,stroke-dasharray:5
    style deferredroute fill:#f8fafc,stroke:#334155,stroke-dasharray:5
    style legacyroute fill:#f8fafc,stroke:#334155,stroke-dasharray:5
```

**경로를 나눈 것은 임의로 정한 것이 아닙니다.** 프롬프트 File 입력은 **pdf/png/jpeg만** 받으므로 Office 파일을 그렇게
넣으면 모델이 본문을 전혀 못 보고 0행을 반환합니다 — 그래서 Office는 File 경로를 아예 쓰지 않고 Apex가
`Compression.ZipReader` 로 직접 풀어 **텍스트**로 넘깁니다. pptx는 OOXML에서도 표를 복원할 수 없습니다(실제
덱은 표를 개별 텍스트 박스로 그립니다) — 그래서 플랫폼의 PDF 렌디션을 기다립니다. 레거시 OLE2 파일은 압축
포맷이 아니라 풀 수 없어 `text/plain` 렌디션을 씁니다.

**렌디션을 기다리는 문서는 `Pending` 으로 남고, 이를 자동으로 이어받는 것은 없습니다** — 렌디션 백필 배치를
직접 실행해야 진행됩니다(§5).

캡에 걸려 빠진 부분은 `Tabular_Error__c` 에 `[일부 미추출] …` 로 기록되고 **완료 후에도 보존**되므로, 부분
추출이 완전한 것처럼 읽히지 않습니다. **0행이 곧 오류는 아닙니다** — 표가 정말 없는 문서는
`[표 없음]` 과 함께 `Complete` 로 끝납니다. 각 판단의 org 검증 근거는 [CLAUDE.md](CLAUDE.md) Gotcha #5b–5f.

### 4.3 데이터 모델

| 오브젝트                           | 역할                                                                                                                                                                     |
| ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `Market_Insight_Report_Main__c`    | 보고서 1건 (마스터, 13필드). 제목·전략 개요·목차·상태·AI 요약, 롤업 `Total_Sections__c`/`Completed_Sections__c`, `Boost_*__c`                                            |
| `Market_Insight_Report_Section__c` | 섹션 1행 (디테일, 15필드, **ControlledByParent**). `Content__c`(구조화 JSON 블록), `Charts__c`, `Research_Findings__c`, `Extracted_Tables__c`, `Status__c`(`Draft` 포함) |
| `Market_Insight_Document__c`       | 업로드된 원본 문서 (15필드). `Facet_*` 검색 패싯 + `Extraction_*`/`Tabular_*` 상태 + `Tabular_Row_Count__c` 롤업                                                         |
| `Market_Insight_Tabular__c`        | **정규화된 수치 팩트 테이블** (20필드). metric × entity × period × value 1행, `Row_Key__c` 키, `Value_Type__c` 가 Actual과 YoY/QoQ를 분리                                |
| 평가 오브젝트 7개                  | `MI_Tabular_Golden_Row__c`(사람이 검증한 정답) + `MI_Tabular_Eval_Run/Probe/Replicate/Verdict/Invariant__c` + `MI_Tabular_Review_Scope__c`                               |
| Custom Metadata 1종                | `MI_Setting__mdt`(org 전역 MI 설정 싱글턴, 레코드 `Default`) — 기능 게이트 + Section/Summary/Verify 템플릿 라우팅 3필드                                                  |

**프롬프트 템플릿 13개** (Prompt Builder, flex) — 보고서 생성 4(Section, Summary, Verify, 미연결 Section-Inputs),
문서 수집 7(Facet, Table-Extract, PDF용 `Tabular_{Locate,Extract,Verify}`, Office용 `Tabular_Text_{Extract,Verify}`),
평가 2(Query-Mapping, Tabular-Eval). 검색 질의 작성과 목차 구성은 **에이전트가** 하므로 템플릿이 없습니다.

**에이전트 번들 1개** — `Market_Insight_Agent_v2`(subagent 다이얼렉트, v44 라이브). 서브에이전트 **9개**:
`subagent_selector`(라우터) · `report_generation`(조사·목차, Opus) · `report_approval`(승인 턴, 기본 모델) ·
`report_result`(결과 렌더, 기본 모델) · `tabular_analyst` · `extensive_search` · `report_followup` ·
`off_topic` · `ambiguous_question`. 결정 단계를 모델 비용별로 쪼개, 템플릿형 렌더에 Opus를 쓰지 않습니다.

**Data Cloud 그라운딩**(설정만, Apex 없음) — 업로드 파일 → 데이터 스트림 → `MI_Doc__dlm` DMO → 청킹·임베딩
검색 인덱스. 그라운딩 액션이 이 인덱스를 조회합니다. 패싯 **필터 가능한** 신규 인덱스가 함께 있고, 그것이
채워지면 `MI_HybridGroundingSearchAction` 의 한 줄(`activeIndex`)만 바꿔 전환합니다.
전체 파이프라인: [docs/deployment/Hand-off.md](docs/deployment/Hand-off.md) §4.

---

## 5. 스케줄 작업 (Scheduled Apex)

**배포는 스케줄을 만들지 않습니다.** `System.schedule` 은 런타임 호출이라 클래스를 배포해도 아무 일도
일어나지 않습니다. org당 한 번 설치해야 합니다.

| 클래스                          | 무엇을 돌리는가                                                                       | 주기                     | 설치 명령                                        | 필수인가                | 현재 org 상태                                  |
| ------------------------------- | ------------------------------------------------------------------------------------- | ------------------------ | ------------------------------------------------ | ----------------------- | ---------------------------------------------- |
| `MI_DocumentCleanupSchedulable` | `MI_DocumentCleanupBatch`(200건 단위) — 이름/파일명이 빈 쓰레기 문서 레코드 영구 삭제 | 매일 01:00 `0 0 1 * * ?` | `MI_DocumentCleanupSchedulable.scheduleDaily();` | 선택 — 데이터 위생 목적 | ⚠️ **미설치** — 정리가 한 번도 돌지 않았습니다 |

> "현재 org 상태" 는 `vscodeOrg` 의 `CronTrigger` 를 직접 조회한 결과입니다(2026-07-27 확인). **새 org에
> 배포할 때는 설치되지 않은 상태에서 시작**하므로, 위 명령을 실행해야 정리 작업이 돕니다.

**렌디션 백필은 손으로 돌립니다.** pptx는 업로드 시점에 추출이 **불가능**합니다(File 입력이 pptx를 안 받고,
OOXML에도 표가 없음). 유일한 경로가 플랫폼이 비동기로 만드는 PDF 렌디션이고, 업로드 시점에 렌디션이 아직
없는 레거시(`doc`/`xls`/`ppt`) 문서도 같은 상황입니다. 이 org는 렌디션을 빠르게 만들어 주므로 주기적으로
폴링할 필요가 없어 스케줄을 두지 않습니다. 대신 **분명히 알아 두어야 할 점**이 있습니다 — 대기 중인 문서는
`Tabular_Status__c = 'Pending'` 에 머물고 **누군가 배치를 돌릴 때까지 아무것도 이를 처리하지 않습니다.**

```bash
sf apex run --file /dev/stdin <<< 'MI_TabularRenditionBackfillBatch.start();'
```

재시도 횟수는 배치가 제한하므로(기본 12회), 렌디션이 끝내 안 오면 "PDF로 올려 주세요"라는 명확한 `Error` 로
끝납니다. 자동으로 진행되기를 원한다면 폴링을 되살리는 대신 **업로드 시점에 렌디션을 읽는** 쪽이 맞습니다.

**주의 3가지**

1. **cron은 `System.schedule` 을 호출한 사용자의 시간대로 해석됩니다** — org 시간대가 아닙니다. 정리
   작업의 "1 AM KST" 는 UTC+9 사용자가 스케줄했을 때만 KST 1시입니다. 미국 관리자가 돌리면 조용히 그 사람의
   1시가 됩니다.
2. **같은 이름의 작업이 이미 있으면 `System.schedule` 이 `AsyncException` 을 던집니다.**
   `MI_DocumentCleanupSchedulableTest` 는 `scheduleDaily()` 를 그대로 호출해 운영 `JOB_NAME` 을 등록하는데,
   이 스케줄이 아직 설치돼 있지 않아서 통과합니다. 설치하기 전에 테스트가 고유한 작업 이름을 쓰도록
   바꿔야(작업 이름을 받는 `@TestVisible` 오버로드) 합니다.
3. **무엇이 실제로 걸려 있는지 확인**하세요.

```bash
sf data query --query "SELECT CronJobDetail.Name, CronExpression, State, NextFireTime, TimesTriggered FROM CronTrigger"
```

---

## 6. 리소스 맵

| 기능                      | 핵심 컴포넌트                                                                                                                                                                                                                                                                                                           |
| ------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 보고서 생성               | `MI_CreateMarketReportAction`, `MI_ReportGenerationService`(템플릿 라우팅 + 게이트 판정), `MI_ReportGenerationBatch`(DRAFT/VERIFY), `MI_TableExtractionBatch`, `MI_ReportTrigger` + `MI_MarketReportTriggerHandler`, `MI_PresentReportOutlineAction`, `MI_GetReportContentAction`                                       |
| 뷰어 · 차트 · DOCX        | `MI_MarketReportController`; LWC `miReportViewer`, `miReportSectionCard`, `miReportChart`, `miReportChartConfig`, `miReportBlock`, `miReportInline`; 정적 리소스 `MI_ChartJs`, `MI_DocxJs`                                                                                                                              |
| 표 데이터 추출 (형식별)   | `MI_TabularExtractionService`(단일 분류기), PDF: `MI_TabularLocateBatch` → `MI_TabularRangeExtractionBatch` → `MI_TabularVerifyBatch`, Office: `MI_OfficeTableExtractor` → `MI_TabularOfficeExtractionBatch` → `MI_TabularOfficeVerifyBatch`, 렌디션: `MI_ContentRenditionGateway` + `MI_TabularRenditionBackfillBatch` |
| 표 조회 · 분석 (에이전트) | `MI_QueryTabularDataAction`(단일 수치), `MI_AnalyzeTabularDataAction`(검증된 집계/GROUP BY/top-N), `MI_ExtractTabularDataAction`(온디맨드), `MI_TabularTermMatcher`(퍼지 매칭); LWC `miDocumentTabularReindex`                                                                                                          |
| 업로드 · 패싯             | `MI_BulkFileUploadController` + LWC `miBulkFileUpload`, `MI_DocumentFacetGenerationService`/`-Batch`/`-Queueable`, `MI_MarketInsightDocumentController`, `MI_DocumentFileTrigger` + 핸들러, `MI_DocumentBackfillBatch`, `MI_DocumentCleanupBatch`; LWC `miDocumentFacetReindex`                                         |
| **스케줄 작업**           | `MI_DocumentCleanupSchedulable`(야간) — §5 참조. 렌디션 백필(`MI_TabularRenditionBackfillBatch`)은 스케줄 없이 **손으로 실행**합니다                                                                                                                                                                                    |
| 품질 평가                 | `MI_TabularEvalGoldenService`, `MI_TabularEvalInvariantService`, `MI_TabularEvalProbeService` + `-Batch`, `MI_TabularRowMatcher`, `MI_GoldenRowCaptureController`, `MI_BetaPosterior`, `MI_EvalStats`                                                                                                                   |
| 공유 — 그라운딩 검색      | `MI_HybridGroundingSearchAction` (하이브리드 + 패싯 부스트; 보고서 생성과 문서 탐색이 함께 씀)                                                                                                                                                                                                                          |
| 원본 표 추출              | `MI_ExtractDocumentTableAction` + 프롬프트 `Market_Document_Table_Extract_Prompt`                                                                                                                                                                                                                                       |
| 파일 미리보기             | `MI_InteractivePreviewController`; LWC `miInteractivePreview`                                                                                                                                                                                                                                                           |

외부 경계(LLM 호출, Data Cloud, 파일 읽기)는 모두 `@TestVisible` 주입 인터페이스 뒤에 있어 테스트가
**대역**(stub — 실제 호출 대신 끼워 넣는 가짜 구현)으로 대체합니다. 공용 테스트 데이터와 게이트웨이
대역은 `MI_TestReportDataFactory` 에 있습니다.

---

## 7. 프로젝트 구조

`force-app` 은 SFDX 패키지 디렉터리 **한 개**지만 그 안에서 **도메인별 네 트리**로 나뉘고, 각 트리는 다시
**`default/`(운영)** 와 **`tests/`(Apex 테스트)** 로 갈립니다. `sfdx-project.json` 은 여전히 `force-app` 과
`datakit` 만 선언합니다 — SDR이 패키지 디렉터리 아래를 재귀적으로 훑기 때문에 추가 설정이 필요 없습니다.

```mermaid
%%{init: {"flowchart": {"nodeSpacing": 50, "rankSpacing": 60, "curve": "linear"}} }%%
flowchart LR
    proj["📦 sfdx-project.json"]

    subgraph fa["📁 FORCE-APP · 패키지 디렉터리 한 개"]
        mainT["🔗 main · 공유"]
        reportT["📝 report-gen · 보고서 생성"]
        ingestT["📊 ingest · 업로드 · 패싯 · 표 데이터 추출"]
        evalT["🔬 eval · 추출 품질 평가"]
    end

    dk["💾 datakit · data cloud"]

    proj -->|"선언"| fa
    proj -->|"선언"| dk
    mainT -->|"운영 1 · 테스트 2"| m1["에이전트 번들, 하이브리드 검색, 테스트 팩토리, 게이트 CMDT, 권한 집합"]
    reportT -->|"운영 8 · 테스트 8 · lwc 6"| r1["생성 배치, 뷰어, 차트/DOCX, 보고서 오브젝트"]
    ingestT -->|"운영 27 · 테스트 24 · lwc 4"| i1["표 데이터 추출 4경로, 렌디션, 스케줄 1개, 표 분석 액션"]
    evalT -->|"운영 8 · 테스트 9 · lwc 1"| e1["정답셋 채점, 프로브, 통계, 정답셋 입력"]

    style proj fill:#e2e8f0,stroke:#334155,color:#1f2937
    style mainT fill:#c7d2fe,stroke:#4338ca,color:#1f2937
    style reportT fill:#fbcfe8,stroke:#be185d,color:#1f2937
    style ingestT fill:#a5f3fc,stroke:#0e7490,color:#1f2937
    style evalT fill:#fde68a,stroke:#b45309,color:#1f2937
    style dk fill:#a7f3d0,stroke:#047857,color:#1f2937
    style m1 fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style r1 fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style i1 fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style e1 fill:#ddd6fe,stroke:#6d28d9,color:#1f2937
    style fa fill:#f8fafc,stroke:#334155,stroke-dasharray:5
```

```
force-app/                          Apex 87개 (운영 44 · 테스트 43) · LWC 11개
├── main/                           # 🔗 공유 — 두 도메인 이상이 쓰는 것만
│   ├── default/
│   │   ├── aiAuthoringBundles/     #   Market_Insight_Agent_v2 (라이브, v44)
│   │   ├── classes/                #   MI_HybridGroundingSearchAction (보고서 + 문서 탐색 공용)
│   │   ├── objects/                #   MI_Setting__mdt (보고서 + 표 게이트 + 템플릿 라우팅)
│   │   ├── customMetadata/         #   게이트 레코드 Default
│   │   ├── permissionsets/         #   Market_Insight_User · Market_Insight_Report_Creator
│   │   └── aura/                   #   redirectGlobalAction (레거시 shim)
│   └── tests/classes/              #   MI_TestReportDataFactory (네 트리의 테스트 28개가 의존)
├── report-gen/                     # 📝 보고서 생성
│   ├── default/
│   │   ├── classes/                #   생성 엔진·배치·에이전트 액션·컨트롤러 (8)
│   │   ├── objects/                #   Report_Main · Report_Section · Prompt_Template_Variant__mdt
│   │   ├── lwc/                    #   miReportViewer, SectionCard, Chart(+Config), Block, Inline
│   │   ├── genAiPromptTemplates/   #   Section · Summary · Verify · Section-Inputs
│   │   ├── staticresources/        #   MI_ChartJs (Chart.js) · MI_DocxJs (docx.js)
│   │   ├── triggers/ flexipages/ tabs/ customMetadata/
│   └── tests/classes/              #   테스트 8개
├── ingest/                         # 📊 업로드 · 패싯 · 표 데이터 추출 · 렌디션 · 미리보기
│   ├── default/classes/            #   MI_Document* · MI_Tabular* · OfficeTableExtractor
│   │                               #   · ContentRenditionGateway · 스케줄 1개 · 표 분석 액션 (27)
│   ├── default/objects/            #   Market_Insight_Document__c · Market_Insight_Tabular__c
│   ├── default/lwc/                #   miBulkFileUpload · miDocument{Facet,Tabular}Reindex
│   │                               #   · miInteractivePreview
│   ├── default/genAiPromptTemplates/  # Facet · Table-Extract · Tabular×3 · Tabular-Text×2
│   └── tests/classes/              #   테스트 24개
├── eval/                           # 🔬 추출 · 검색 품질 평가
│   ├── default/classes/            #   MI_TabularEval* · RowMatcher · BetaPosterior · EvalStats
│   │                               #   · GoldenRowCaptureController (8)
│   ├── default/objects/            #   Golden_Row · Eval_Run/Probe/Replicate/Verdict/Invariant · Review_Scope
│   ├── default/lwc/                #   miGoldenRowCapture (정답셋 입력)
│   └── tests/classes/              #   테스트 9개
datakit/main/default/               # Data Cloud datakit: MI_Doc__dlm, 데이터 스트림, 필드 맵 (설정만)
docs/                               # 소스 분할을 그대로 미러링 — docs/README.md 가 색인
manifest/                           # package.xml (sf project generate manifest 로 재생성) + 파괴 배포 매니페스트
scripts/apex/                       # 익명 Apex 진입점: 백필, 평가 실행, 프로브
CLAUDE.md                           # 엔지니어링 가이드 · 규약 · 함정
```

**트리를 다룰 때 지킬 규칙 3개** (전체는 [CLAUDE.md](CLAUDE.md) Source tree layout):

1. **부분 배포는 트리를 넘깁니다.** `--source-dir force-app/<tree>/default` 는 운영만, `<tree>` 는 운영+테스트.
   **테스트를 고쳤으면 `default` 가 아니라 트리를 배포**하세요 — 아니면 org에 옛 테스트가 남아 다음 테스트
   실행이 거짓 통과를 보고합니다.
2. **테스트 판정 기준은 `@isTest` 애노테이션이지 파일 이름이 아닙니다.** `MI_TestReportDataFactory` 와
   `MI_TestEvalDataFactory` 는 `*Test` 로 끝나지 않는 `@isTest` 팩토리라 테스트 쪽에 있습니다.
3. **`main` 은 공유 전용입니다.** `sf project retrieve start` 는 **처음 가져오는** 컴포넌트를 항상
   `force-app/main/default/` 에 떨어뜨리므로, 받은 뒤 도메인 트리로 직접 옮기세요.

---

## 8. 테스트

폴더가 트리별로 갈렸지만 **테스트 실행 명령은 바뀌지 않습니다** — `--tests` 는 클래스 API 이름을 받고 경로를
받지 않습니다.

```bash
# 보고서 생성 (report-gen 트리 + 공유 그라운딩 테스트)
# --synchronous 는 한 클래스만 받으므로 다중 클래스 실행에서는 빼야 합니다.
sf apex run test \
  --tests MI_ReportGenerationServiceTest --tests MI_ReportGenerationBatchTest \
  --tests MI_TableExtractionBatchTest --tests MI_MarketReportTriggerHandlerTest \
  --tests MI_MarketReportControllerTest --tests MI_CreateMarketReportActionTest \
  --tests MI_GetReportContentActionTest --tests MI_PresentReportOutlineActionTest \
  --tests MI_HybridGroundingSearchActionTest \
  --code-coverage --result-format human --wait 10

# 문서 수집 (ingest 트리): 업로드 · 패싯 · 표 데이터 추출 · 렌디션 · 미리보기
sf apex run test \
  --tests MI_DocumentFacetGenerationServiceTest --tests MI_DocumentFacetGenerationBatchTest \
  --tests MI_DocumentFileTriggerHandlerTest --tests MI_MarketInsightDocumentControllerTest \
  --tests MI_BulkFileUploadControllerTest --tests MI_ExtractDocumentTableActionTest \
  --tests MI_TabularExtractionServiceTest --tests MI_TabularThreePassBatchTest \
  --tests MI_OfficeTableExtractorTest --tests MI_TabularOfficeExtractionBatchTest \
  --tests MI_ContentRenditionGatewayTest --tests MI_TabularRenditionBackfillBatchTest \
  --tests MI_DocumentCleanupSchedulableTest \
  --tests MI_QueryTabularDataActionTest --tests MI_AnalyzeTabularDataActionTest \
  --tests MI_TabularTermMatcherTest --tests MI_InteractivePreviewControllerTest \
  --code-coverage --result-format human --wait 10

# 품질 평가 (eval 트리)
sf apex run test \
  --tests MI_TabularEvalGoldenServiceTest --tests MI_TabularEvalInvariantServiceTest \
  --tests MI_TabularEvalProbeServiceTest --tests MI_TabularEvalProbeBatchTest \
  --tests MI_TabularRowMatcherTest --tests MI_EvalStatsTest --tests MI_BetaPosteriorTest \
  --code-coverage --result-format human --wait 10

# LWC 단위 테스트 · lint (Node)
npm run test:unit
npm run lint
```

**게이트 판단 시 주의**

- org에는 이 기능과 **무관한 기존 실패 테스트가 약 68개** 있습니다(B2B Commerce, SDO 데모 등).
  `RunLocalTests` 전체 통과를 게이트로 삼지 말고 **위 클래스를 이름으로 지정**해 검증하세요.
- **검증 게이트가 org에서 ON** 이므로, 1-pass 완료를 가정하는 테스트는
  `MI_ReportGenerationService.verifyPassOverride = false` 를 설정해야 합니다. 아니면 `Complete` 대신
  `Draft` 를 보게 됩니다.
- `MI_InteractivePreviewControllerTest` 는 **설계상 known-flaky** 입니다(테스트 컨텍스트에서 방금 삽입한
  `ContentVersion` 을 다시 조회하는 것이 불안정 — `IContentFileGateway` 가 존재하는 이유).
- husky pre-commit 훅이 staged 파일에 prettier + eslint + `sfdx-lwc-jest` 를 돌리므로 **LWC Jest를 초록으로
  유지**하세요.

---

## 9. 문서

**[docs/](docs/) 가 전체 문서 세트이고, 시작점은 색인인 [docs/README.md](docs/README.md)** 입니다. 폴더가
소스 트리를 미러링하며, 각 파일이 현행/설계 배경/폐기 중 무엇인지 표시돼 있습니다.

- **[docs/deployment/](docs/deployment/)** — 운영·인수인계.
  [Hand-off.md](docs/deployment/Hand-off.md) 가 마스터 유지보수 가이드(한국어): 자산 인벤토리, 권한 집합,
  에이전트 구조, Data Cloud 수집 파이프라인(§4), 패싯 생성(§4.4), 런북(§5).
  [deployment-guide.html](docs/deployment/deployment-guide.html) 은 신규 org 배포 시각 가이드(SLDS),
  [report-pipeline-explorer.html](docs/deployment/report-pipeline-explorer.html) 은 파이프라인 단계를 클릭해
  입력·출력·산출물을 보는 인터랙티브 판본.
  [file-upload-vetoing-incident.md](docs/deployment/file-upload-vetoing-incident.md) 는 "0 of 1 에서 멈춤"의
  해결된 근본 원인과 30초 진단·기각된 가설 표.
- **[docs/agent/](docs/agent/)** — 보고서 에이전트 코어:
  [프롬프트 템플릿 작성 가이드](docs/agent/prompt-templates-authoring-guide.md)(프롬프트 원문, 입력 설정,
  Apex 호출 계약)와 에이전트 출력 렌더링 노트.
- **[docs/ingest/](docs/ingest/)** — 업로드·패싯·표 데이터 추출:
  [표 데이터 추출 프롬프트 작성 가이드](docs/ingest/tabular-extract-prompt-authoring.md), 처리 상태 대시보드 로직,
  문서 정리, 대량 업로드 노트.
- **[docs/eval/](docs/eval/)** — 추출·검색 품질: [평가 허브](docs/eval/tabular-eval-center.md), 사전 준비
  런북, 정답셋 라벨링 판정 기록, 감사 프롬프트.
- **[docs/coworker/](docs/coworker/)** — Agentforce Coworker:
  [하이브리드 검색 가이드](docs/coworker/coworker-hybrid-search-prompt.md), Coworker와 직원 에이전트의 역할
  구분, 분리 설계 배경.
- [CLAUDE.md](CLAUDE.md) — 이 저장소에서 작업할 때의 규약·함정·파일 위치.
