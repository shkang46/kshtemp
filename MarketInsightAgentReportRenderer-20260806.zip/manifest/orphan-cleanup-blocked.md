# org-only orphan 정리 — 완료분과 차단 잔여물

`MI_` 접두어 리네임(커밋 `50e07bd`) 이후 repo에서는 지웠지만 org에서는 파괴적 삭제를 하지 않아
살아남은 컴포넌트를 정리한 기록. **2026-07-25 측정 기준.**

source-dir 배포는 가산적이라 소스에 없는 org 컴포넌트를 지우지 않는다. 그래서 옛 이름 자산이 남고,
그중 일부는 무해하지 않았다 — 아래 "왜 시급했나" 참조.

---

## 왜 시급했나 — 프로덕션 보고서 생성이 깨져 있었다

`Market_Insight_Report_Main__c`에 after-insert 트리거가 **2개** 걸려 있었다: repo의 정상
`MI_ReportTrigger`와 org 잔존물 `MarketReportTrigger`. 후자의 핸들러 체인은 이미 컴파일 불가였다
(`DocumentFacetGenerationService`가 앞선 `destructiveChanges-legacy-apex.xml` 패스에서 제거됨):

```
MarketReportTriggerHandler → ReportGenerationBatch → ReportGenerationService
  → ExtractDocumentTableAction : Variable does not exist: DocumentFacetGenerationService
```

두 트리거가 **같은 트랜잭션에서 발동**하므로 보고서 레코드 insert가 매번 실패했다. 즉
`MI_ReportTrigger`가 제 일을 못 했고, **에이전트의 보고서 생성이 org에서 동작하지 않았다** — 테스트만의
문제가 아니었다. 실측으로 `MI_MarketReportTriggerHandlerTest`와 `MI_DocumentFileTriggerHandlerTest`가
둘 다 위 체인으로 죽었고(후자는 무관한 검증을 위해 보고서 레코드를 만들었을 뿐), CLAUDE.md Gotcha #6이
"기존부터 실패"로 분류한 `MarketInsightSearchActionTest` / `ReportTextExtractorTest`도 실은 이
orphan들이었다.

---

## 완료 — 36개 삭제됨

`manifest/destructiveChanges-mi-orphans.xml`, dry-run과 실배포 모두 **36/36 성공, 오류 0**.
org 재조회로 확인(요약 메시지가 아니라 실제 상태로 — 롤백된 컴포넌트도 "deleted"로 보고되므로).

- **ApexTrigger 1** — `MarketReportTrigger` ★근본 원인
- **ApexClass 35** — `MarketReportTriggerHandler`, `ReportGenerationBatch`, `ReportGenerationService`,
  `TableExtractionBatch`, `TestMIReportDataFactory`, `MarketReportGenerator`,
  `MarketInsightDocumentController`, `InteractivePreviewController`, `BulkFileUploadController`,
  `DocumentBackfillBatch`, `DocumentFacetPollingSchedulable`, `MIDocComprehensiveSearchAction`
  - 각 `*Test` 및 주체가 남은 클래스들의 고아 `*Test` (`CreateMarketReportActionTest`,
    `ExtractDocumentTableActionTest`, `MIHybridGroundingSearchActionTest` 등)

**검증 결과** — `MI_MarketReportTriggerHandlerTest` 7/7, `MI_DocumentFileTriggerHandlerTest` 4/4 통과.
보존 대상 9개(`MI_InteractivePreviewController`, `MI_MarketReportTriggerHandler`,
`MI_ReportGenerationBatch/Service`, `MI_CreateMarketReportAction`, `MI_HybridGroundingSearchAction`,
`MI_TabularExtractionService`, `MI_OfficeTableExtractor` 등) 전부 org에 온존.

---

## 차단 잔여물 — 14 Apex + 6 CLT + 13 LWC + 2 GenAiFunction

**전부 무해하다**: 이들을 호출할 수 있었던 트리거가 사라졌으므로 실행 경로가 없다. 다만 남아 있는
이유는 각각 다르고, 해제 조건도 다르다. 세 개의 독립적 차단 원인이 있다.

### 원인 A — 비활성 planner 버전 (CLI로 해결 불가)

org에 `Market_Insight_Agent_v2` planner 버전이 **v35~v53까지 비활성 상태로 쌓여** 있고(라이브는 v54),
이들이 `GenAiFunctionDefinition` 행을 붙잡고 있다. 파괴적 배포로는 evict할 수 없다.

| 남은 것                                                                                                                                                                                                                                                                                                     | 붙잡는 것                                                                                   |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| `GenAiFunction: ExtractDocumentTableAction`, `MI_PresentReportResultAction`                                                                                                                                                                                                                                 | 비활성 planner 버전                                                                         |
| `LightningTypeBundle: MI_ReportOutline`, `MI_ReportResult`, `MI_ExtractedTable`                                                                                                                                                                                                                             | `present_report_outline_179Ie…`, `extract_document_table_179Ie…` 등 GenAiFunctionDefinition |
| `ApexClass: CreateMarketReportAction`, `MIHybridGroundingSearchAction`, `MIReportGroundingSearchAction`, `MIDocComprehensiveSearchAction_v2`, `MIDocExhaustiveSearchAction`, `MIFileComprehensiveResearchAction`, `MarketInsightSearchAction`, `ExtractDocumentTableAction`, `MI_PresentReportResultAction` | GenAiFunctionDefinition / Authoring Bundle Version Content Dependency                       |

**해제 조건**: 옛 planner 버전이 만료되거나 제거될 때. 그 후
`manifest/destructiveChanges-clt-genai.xml`를 그대로 실행하면 된다.

**CLT는 삼각 순환이라 반드시 한 패스로 지워야 한다.** 실측으로 중간 조합 2가지를 시도해 봤고 둘 다
실패했으니 재시도하지 말 것:

```
기반 CLT (MI_ReportResult 등)  ← 비활성 planner의 GenAiFunctionDefinition
*Card CLT                      ← 렌더러 LWC (c:miReportResultCard 등)
렌더러 LWC                     ← 기반 CLT (PT-MI_ReportResult 등)
MI_*Data Apex DTO              ← *Card CLT + Managed Content Type Link
```

- (a) `*Card` + DTO만 → 렌더러 LWC가 차단
- (b) `*Card` + DTO + LWC → 기반 CLT가 차단

### 원인 B — org 전용 Lightning 페이지 (수동 Setup 작업 필요)

LWC 13개는 **하나도** 지울 수 없다. 3개가 Lightning 페이지에 고정돼 있고, 나머지는 모듈 import로
그것들에 전이적으로 매달려 있다. 가장 깊은 leaf(`reportInline`)조차 막힌다.

```
miWorkspace          ← Lightning 페이지 "Market Insight Report" + LWC c:aoHome
createReport         ← Lightning 페이지 "App - Dashboard Magic"
miUploadProbe        ← Lightning 페이지 "Market Insight Uploader"
  marketReportViewer, miOutlineEditor      ← c:miWorkspace
    reportSectionCard, reportChartConfig   ← c:marketReportViewer
      reportBlock, reportChart             ← c:reportSectionCard
        reportInline                       ← c:reportBlock
```

`ApexClass: MarketReportController`가 남은 이유도 이것이다 —
`marketReportViewer`/`miWorkspace`가 참조한다.

**해제 조건**: Setup → Lightning App Builder에서 세 페이지를 열어 컴포넌트 인스턴스를 삭제·저장.
그 후 `manifest/destructiveChanges-legacy-lwc-rest.xml`를 위 순서대로 **여러 번** 실행(패스마다 한
단계씩 풀린다).

**CLAUDE.md Gotcha #11 보정** — 이제 절반만 맞다. **repo** flexipage는 `miWorkspace`를 참조하지 않지만
(`force-app/main/default/flexipages` 검색 0건), **org 전용** "Market Insight Report" 페이지가 여전히
embed하고 있다. dangling 참조가 repo에서 org로 옮겨간 셈.

### 원인 C — 활성 Flow

| 남은 것                          | 붙잡는 것                                                           |
| -------------------------------- | ------------------------------------------------------------------- |
| `ApexClass: ReportTextExtractor` | Flow `Market_Report_Document` 버전 1·2의 `Extract_Report_Text` 요소 |

**해제 조건**: Flow에서 해당 요소를 제거하거나 그 Flow 버전을 폐기.

### 원인 A/B 파생 — `Prompt_Variant__c` 필드 삭제 차단 (2026-07-30 CMDT 병합, 2026-07-31 재측정)

`MI_Report_Generation_Setting__mdt`/`MI_Prompt_Template_Variant__mdt` 두 CMDT를 `MI_Setting__mdt`
하나로 병합(+ 이름 변경)하면서 보고서의 `Prompt_Variant__c`(Text(40)) 라우팅 키를 소스에서 제거했다.
소스 삭제와 라이브 Apex 정리(리더 0건, 테스트 124/124, 에이전트 validate 통과)는 끝났고 **두 CMDT 타입은
`destructiveChanges-cmdt-merge.xml`로 실제 삭제됐다**(org 재조회 확인: `MI_Setting__mdt`만 잔존).
그러나 **`Prompt_Variant__c` 필드 자체는 아직 못 지운다** — dry-run에서 org 전용 orphan 2개가 붙잡고 있고,
그 orphan들의 pin을 2026-07-31에 재측정한 결과 이전 스냅샷이 **부정확**했다.

| 남은 것                                                        | 붙잡는 것                                                                                                                                                                              |
| -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `CustomField: Market_Insight_Report_Main__c.Prompt_Variant__c` | orphan `ApexClass CreateMarketReportAction`(Id `01pIe0000004tOqIAI`) + orphan `ApexClass MarketReportController`(Id `01pIe0000004tOsIAI`) — 둘 다 접두어 **없는** 옛 이름              |
| orphan `CreateMarketReportAction`                              | `create_market_report_*` **GenAiFunctionDefinition 24행** 전부가 이 클래스를 invoke (아래 ★ drift 참조)                                                                                |
| orphan `MarketReportController`                                | LWC `c:marketReportViewer` → `c:miWorkspace`, 그리고 `c:miWorkspace`는 다시 org 전용 AppPage `Market_Insight_Report` + (별도 경로) `c:aoHome`→AppPage `Market_Insight_Agent_Companion` |

**★ 재측정으로 드러난 라이브 drift (이 정리와 무관하게 그 자체로 프로덕션 이슈).** 2026-07-25 노트의
"비활성 planner v35–v53이 pin" 이론과 CLAUDE.md의 "라이브 v44"는 **둘 다 낡았다**. 실제로 라이브는
`Market_Insight_Agent_v2` **v54**이고, `create_market_report` 액션이 **활성 v54에서조차** 접두어 없는
orphan `CreateMarketReportAction`(`01pIe0000004tOqIAI`)을 invoke한다 — 올바른 `MI_CreateMarketReportAction`
(`01pIe0000005CXTIA2`)이 아니다. 소스(`Market_Insight_Agent_v2.agent:501`)는 이미
`apex://MI_CreateMarketReportAction`로 올바르므로 **소스 버그가 아니라 소스↔org publish drift**다.
게다가 별도의 **활성** 테스트 봇 `[Test] Market Insight Agent with Custom UI` v5도 같은 orphan을 invoke한다.
(`create_market_report_*` 24행 = `Market_Insight_Agent_v2` v34–43·49–54 16행 + Custom-UI v1–5 5행 +
이미 삭제된 `Market_Insight_Agent_3` v13–15 3행. `MetadataComponentDependency`는 이 Bot/Planner/Plugin/
Function 계층을 추적하지 못하므로 dry-run과 GenAiFunctionDefinition 직접 조회가 유일한 진실.)

**해제 조건 (순서대로):**

1. **`Market_Insight_Agent_v2` 재게시** — 소스는 이미 맞으니 재게시하면 활성 버전의 액션 타깃이
   `MI_CreateMarketReportAction`로 재해석돼 drift가 고쳐지고 활성-버전 pin이 사라진다. **단 CLI publish는
   막힌다**: 이 번들에는 255자를 넘는 `description:` 필드가 **34개** 있고 `sf agent publish`는 이 상한을
   강제하지만(`validate`는 안 함) v54는 **Web UI로 게시돼** 그 상한을 우회했다. 그러므로 재게시는
   **Web UI로** 해야 한다(CLI로 하려면 planner가 읽는 load-bearing description 34개를 ≤255자로 잘라야 하는데,
   순전히 CLI 제약 회피를 위해 라이브 에이전트 프롬프트를 훼손하는 셈이라 하지 않았다). Gotcha #15의
   `<target>` 락은 이 번들엔 **없다**(확인) — 막는 건 오직 255자 description.
2. **비활성 planner/테스트 봇** — 재게시 후에도 v34–43·49–53 등 비활성 버전 + Custom-UI 봇 + 삭제된
   `Market_Insight_Agent_3` 잔존 행이 여전히 orphan 클래스를 pin한다. 이 비활성 GenAiFunctionDefinition
   행들은 **파괴적 배포로 축출 불가**(원인 A와 동일, 실측). 만료/제거를 기다리는 수밖에 없다.
3. **원인 B 수동 작업** — App Builder에서 AppPage `Market_Insight_Report`의 `miWorkspace` 인스턴스 제거 +
   `Market_Insight_Agent_Companion`(→`aoHome`→`miWorkspace`) 정리. `aoHome`는 **별도 agentic-office 레포**
   소관일 수 있어 이 repo만으로는 못 끝낸다.
4. 위가 모두 풀려 두 orphan 클래스가 삭제되면 그때 `Prompt_Variant__c`를 파괴적 패스에 넣는다.
   그 전까지 org 필드는 **무해하게 남는다** — 라이브 리더가 없다(소스에서 이미 제거, 병합된 `MI_Setting__mdt`
   경로는 이 필드를 읽지 않음).

---

## 의도적 제외 — 건드리지 않은 것

- **`MI_InteractivePreviewController` / `MI_InteractivePreviewControllerTest` /
  `miInteractivePreview`** — **살아있는 기능**(CLAUDE.md "인터랙티브 파일 프리뷰")이고 git HEAD에
  존재한다. **병행 세션의 미커밋 워킹트리 삭제** 때문에 디스크에서만 사라져 orphan처럼 보였을 뿐이다.
  어떤 manifest에도 넣지 말 것. `InteractivePreviewController`(접두어 **없음**, 삭제됨)와 혼동 금지 —
  한 글자 차이로 살아있는 기능을 죽인다.
- **`SD_extractTable`** — 빈 3줄 스텁이고 `SD_` 접두어가 이 repo 관례와 무관해 소유가 불확실하다.
  추측으로 지우지 않고 남겼다.
- **B2B\* / SDO\* / KForge\* / FCA\* / XDO\* / Wave\* 등 706개** — 다른 팀·데모 자산. 범위 밖.

---

## 재현·검증 방법

```bash
# 1) org과 git HEAD를 대조해 org-only 클래스 산출 (디스크가 아니라 HEAD 기준 — 미커밋 삭제 함정 회피)
sf data query --use-tooling-api \
  -q "SELECT Name FROM ApexClass WHERE NamespacePrefix = null ORDER BY Name" --json \
  | jq -r '.result.records[].Name' | LC_ALL=C sort > /tmp/org.txt
git ls-files force-app/main/default/classes | rg '\.cls$' | xargs -n1 basename | sed 's/\.cls$//' \
  | LC_ALL=C sort -u > /tmp/head.txt
LC_ALL=C comm -23 /tmp/org.txt /tmp/head.txt

# 2) 삭제 가능 여부는 반드시 --dry-run 으로 먼저 확인 (차단 목록이 그대로 나온다)
sf project deploy start --manifest manifest/package-empty.xml \
  --post-destructive-changes manifest/<manifest>.xml --dry-run --json --wait 25

# 3) 트리거 상태 — Market_Insight_Report_Main__c 에 트리거가 하나뿐이어야 한다
sf data query --use-tooling-api \
  -q "SELECT Name, Status, TableEnumOrId FROM ApexTrigger WHERE NamespacePrefix = null" --json
```

**주의 2가지.**

1. **파괴적 배포는 all-or-nothing**이다. 하나가 막히면 나머지 삭제까지 조용히 롤백되면서 요약에는
   전부 "deleted"로 찍힌다. **org 재조회만이 진실**이다.
2. **`--dry-run`을 먼저 돌려 차단 목록을 확보하고, 막힌 것을 manifest에서 빼라.** 이 정리에서 50개 →
   36개로 줄여 성공시킨 방법이다.

## 폴백 — 지울 수 없으면 Inactive라도

- **ApexTrigger는 Inactive 가능** (org에 Inactive 트리거 5개 실존). `<status>Inactive</status>`로
  배포하거나 Setup → Apex Triggers에서 "Is Active" 해제. 발동이 멈추므로 실질적 무해화가 된다.
- **ApexClass는 Inactive 불가** — org 클래스 792개 전부 `Active`이고 metadata API가 다른 값을 거부한다.
  지울 수 없으면 남는다. 다만 호출 경로(트리거·에이전트 액션)가 끊기면 무해하다.

## 대체된 manifest

아래는 목록이 낡거나 부분만 실행된 이력 파일이다. 새로 정리할 때는
`destructiveChanges-mi-orphans.xml`를 기준으로 삼되, **반드시 org을 다시 측정**해서 목록을 만들 것.

`destructiveChanges-rename.xml`, `destructiveChanges-legacy-apex.xml`,
`destructiveChanges-orphan-report-trigger.xml`, `destructiveChanges-tabular-orphans.xml`,
`destructiveChanges.xml`, `destructiveChanges-legacy-lwc.xml`
