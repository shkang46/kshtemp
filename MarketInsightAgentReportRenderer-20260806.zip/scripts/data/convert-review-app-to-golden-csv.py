#!/usr/bin/env python3
"""Converts the golden-set review app's embedded data into a loadable MI_Tabular_Golden_Row__c CSV.

The review app (golden-set-review-app.html) carries a `table` field on every row that the flat CSV export
dropped. That field is what makes the golden set usable: without it, figures that two different tables report
on different bases collapse onto one coordinate and one of them is silently lost during scoring.

Run:
    python3 scripts/data/convert-review-app-to-golden-csv.py \
        golden-set-review-app.html a36Ie000000LgLkIAK

Writes two files next to the input:
  - golden-rows-loadable.csv   — rows whose coordinate is unique; ready for `sf data import bulk`
  - golden-rows-ambiguous.csv  — rows still sharing a coordinate, for a human to resolve

WHY AMBIGUOUS ROWS ARE HELD BACK RATHER THAN LOADED: a coordinate collision means the golden set claims two
different values for the same figure. Loading both would make one of them score as an error no matter what the
pipeline stored, so the recall/precision numbers would be wrong in a way no later check could detect.
"""

import csv
import json
import re
import sys
from collections import defaultdict

# Value types the extraction pipeline deliberately harvests. Comparison columns (YoY/QoQ) are intentionally
# NOT extracted — this project keeps only fact data — so a golden row carrying one would score as a permanent
# false negative and understate recall.
HARVESTED_VALUE_TYPES = {"actual", "estimate", "guidance", "consensus", "target"}

FIELDNAMES = [
    "Name",
    "Market_Insight_Document__c",
    "Entity__c",
    "Entity_Parent__c",
    "Entity_Label__c",
    "Metric_Key__c",
    "Metric_Label__c",
    "Period__c",
    "Year__c",
    "Value_Text__c",
    "Unit__c",
    "Value_Type__c",
    "Table_Name__c",
    "Column_Note__c",
    "Source_Page__c",
    "Note__c",
]


def extract_data(html_path):
    """Pulls the `const DATA = {...}` object out of the review app by brace matching."""
    with open(html_path, encoding="utf-8") as handle:
        source = handle.read()
    marker = "const DATA = "
    start = source.index(marker) + len(marker)
    depth = 0
    for index in range(start, len(source)):
        char = source[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return json.loads(source[start : index + 1])["rows"]
    raise ValueError("could not find the end of the DATA object")


def coordinate(row):
    """The identity a golden row is scored on. Must mirror MI_TabularRowMatcher.coordinateKey's inputs.

    The metric is truncated to 80 here because that is what actually lands in the field; computing the
    collision check on the untruncated text would miss two long labels that become identical once stored.

    The PARENT is part of the key, matching MI_TabularEvalGoldenService.parentCoordinateOf, which tries the
    parent-qualified coordinate before falling back to the base one. Two rows that differ ONLY by parent are
    therefore two distinct, both-scoreable figures rather than a collision — which is the real structure:
    Sony p.5 prints "Network Services" under G&NS (159,346) AND under ET&S (44,638), and the Music breakdown
    prints "Streaming" under both Digital and Publishing.

    Including it here without the scorer's fallback would have been wrong in the other direction (two sources
    disagreeing about whether a segment is a parent or a top-level row would stop matching), which is why the
    fallback exists on the Apex side and is not optional.
    """
    entity, metric, parent, _dropped = relabel(row)
    return (
        entity.strip().lower(),
        metric.strip()[:80].lower(),
        row["period"].strip().lower(),
        (row["value_type"] or "Actual").strip().lower(),
        row["table"].strip().lower(),
        (row.get("col_note") or "").strip().lower(),
        parent.strip().lower(),
    )


def year_of(period):
    """Best-effort 4-digit year from a period label, so the Year__c roll-up field is populated."""
    digits = ""
    for char in period:
        if char.isdigit():
            digits += char
        elif digits:
            break
    if len(digits) == 4:
        return digits
    if len(digits) == 2:
        return "20" + digits
    return ""


# ---------------------------------------------------------------------------------------------------
# RELABELLING RULES, per the Cowork PDF-review ruling (docs/eval/golden-set-labelling-rulings.md)
#
# The reviewer's draft put the SEGMENT NAME in the metric field on "by segment" tables, which leaves the
# metric carrying no information about WHAT the number measures. Verified consequence: 63 coordinates were
# shared across up to FIVE different tables at once — the same segment and quarter in Inventory, Goodwill,
# D&A, Long-lived assets and Sales all collapsed onto one key. So the golden set could not distinguish a
# segment's inventory from its goodwill, and could never match a correctly-labelled extracted row.
#
# The ruling: keep the extraction convention (entity = subject, metric = what is measured) and relabel the
# golden set to match. Deriving the measure from the table's PRINTED TITLE is normal table reading, not
# invention — "Inventory" really is printed in "Inventory by segment". The verbatim rule applies to
# value_text / period / unit, which are untouched here.
# ---------------------------------------------------------------------------------------------------

# Tables whose ROWS are segments: the measure comes from the title, and the row label is the entity.
SEGMENT_ROW_TABLES = {
    "Inventory by segment": "Inventory",
    "Goodwill by segment": "Goodwill",
    "Depreciation & amortization by segment 1": "Depreciation & amortization",
    "Long-lived assets 2 and right-of-use assets by segment": "Long-lived assets and right-of-use assets",
    "Sales to customers by product category (to external customers)": "Sales",
    "Sales to customers by geographic region 1 (to external customers)": "Sales",
    "Research and development expenses by segment 1": "Research and development expenses",
}

# ---------------------------------------------------------------------------------------------------
# HIERARCHY RECOVERY — aligns the golden set to the convention the extraction prompt now follows.
#
# The prompt was changed (Extract template v_8) so a hierarchical table's INDENTED row keeps its own label
# as the entity and names its segment in entity_parent, while metric_key holds only the measure. Verified
# live on Sony p.5: 45 rows, entity_parent populated on 29, metric_key = {"sales"} alone.
#
# The reviewer's draft used the opposite split (entity = segment, metric = the indented label), and that
# difference is NOT absorbable by the matcher: the coordinate sorts and concatenates the two subject fields,
# so golden "G&NS"+"Digital Software and Add-on Content" yields ...addoncontentgns while extraction yields
# gnsdigitalsoftwareandaddoncontent + "sales" — the measure token can never cancel out. One side has to be
# restated, and the extraction side reflects the source's own structure, so the golden set moves.
#
# The parent is recoverable because the draft's `rowid` preserves emission order: within a hierarchical
# table, a row whose entity == metric is the SEGMENT SUBTOTAL, and every following row carrying that same
# entity is one of its children. That is a mechanical re-read of the draft, not new judgment — the reviewer's
# 2nd consultation confirmed the reading ("`entity == metric` 인 행에만 … 하위 행은 자기 라벨을 보존").
#
# Tables here are HIERARCHICAL: a subtotal row followed by indented children.
HIERARCHICAL_TABLES = {
    "Sales to customers by product category (to external customers)": "Sales",
}

# Tables that are ONE segment's breakdown: every row is a child of the single segment named in the title, and
# no subtotal/child distinction exists in the entity column (the draft repeats the segment on every row).
# The measure is the title's, and the row label becomes the entity.
SINGLE_PARENT_BREAKDOWN_TABLES = {
    "Game & Network Services segment sales breakdown": ("G&NS", "Sales"),
}

# Row labels inside a SINGLE_PARENT_BREAKDOWN table that are NOT a child line: a segment-level total keeps the
# segment itself as the entity, exactly as a top-level row would.
BREAKDOWN_TOTAL_LABELS = {"segment total sales"}

# NESTED breakdowns: a table whose indentation is more than one level deep, so the same child label repeats
# under different sub-blocks and the segment alone cannot identify a row.
#
# Measured on the Music table: "Streaming" and "Other" each repeat (196,663 under Recorded Music's Digital
# block and 56,511 under Publishing for the same quarter; "Other" three times). Naming only the segment as the
# parent made 41 of its rows collide — two different, both-correct figures on one coordinate, which is exactly
# the failure the coordinate's provenance fields exist to prevent.
#
# The structure was CONFIRMED BY ARITHMETIC on the reviewer's own FY24 Q1 values, not inferred from
# indentation guesses:
#     Download 6,450 + Streaming 196,663                     = Digital 203,113          ← three levels deep
#     Physical 23,589 + Digital 203,113 + Other 72,578       ≈ Recorded Music 299,279   (off by 1: rounding)
#     Streaming 56,511 + Other 40,165                        = Publishing 96,676
#     Gaming 17,593 + Other 22,178                           = Visual Media & Platform 39,771
#     Recorded 299,279 + Publishing 96,676 + VM&P 39,771     = Segment Total 435,726
#
# So each row's parent is the nearest FOLLOWING summary line, which is how the source prints a Japanese
# financial breakdown (components first, their total underneath). The map records that explicitly per child
# rather than deriving it, because a derivation would silently mis-assign a row the moment a table's order
# differs — and a wrongly-assigned parent is a false coordinate, not a missing one.
#
# NOTE this reaches a limit of what the golden set can express today: the fact table has ONE parent field, so
# a third level ("Streaming" under "Digital" under "Recorded Music") records only its IMMEDIATE parent. That
# is enough to key the rows apart, which is what scoring needs.
#
# The sequence is POSITIONAL, not keyed by label, and that is the whole point: "Streaming" and "Other" occur
# in more than one block, so a label→parent dictionary would assign both occurrences the same parent and leave
# them colliding. Each tuple is one OCCURRENCE in the draft's rowid order.
NESTED_BREAKDOWN_MEASURE = {
    "Music Revenue breakdown (to external customers)": "Revenue",
}

# Block headers the draft abbreviated, mapped to the spelling the SOURCE prints (and the pipeline stores).
# Not cosmetic: the parent is the only thing separating this table's two "Streaming"/"Other" rows, and
# ENTITY_ALIASES folds "music" but has no rule turning "Publishing" into "Music Publishing" — so the two
# spellings stay distinct and 23 correct extractions scored as value errors until this was aligned.
NESTED_ENTITY_SPELLING = {
    "Publishing": "Music Publishing",
}

# STACKED-SECTION tables: ONE title covering two or more measurement blocks stacked vertically, so the SAME
# row label appears once per block with legitimately different values. The section name is the measure.
#
# Verified from the draft's rowid runs (each run is one label × its period columns, in source order):
#
#   "Additions to long-lived assets ... / Depreciation and amortization"  (rowid 468-579)
#       rowid 468  'Additions 2: PP&E'                    ← the section name is FUSED into the first label
#       rowid 478..523  the Additions block's 5 other lines
#       rowid 524  'Depreciation and amortization 3: PP&E' ← second section starts, same 6 lines repeat
#       rowid 534..579  the D&A block's 5 other lines
#     The split point is unambiguous because the harvester captured the section heading in the label of each
#     block's FIRST row. That is why these 72 rows were previously held back as unresolvable: without the
#     section in the metric, "PP&E / FY24" names two different figures (381,061 additions vs 250,484 D&A).
#
#   "Adjusted Income 2"  (rowid 1070-1147) — four 3-row blocks, each: <measure> Before Adjustment /
#     Non-recurring (profit) loss / Adjusted. CONFIRMED BY ARITHMETIC on FY24:
#         Income taxes            257.5 + 83.7 = 341.2   ✓
#         Net income attributable 1,067.4 - 83.7 = 983.7 ✓
#     So a bare "Adjusted" or "Non-recurring (profit) loss" row belongs to the block above it, and 46 rows
#     collided purely because that block name was missing.
#
# Each entry is (row label, section) in rowid order — POSITIONAL, like NESTED_BREAKDOWN_SEQUENCE, because the
# same label recurs across sections and a label→section dictionary cannot separate the occurrences.
# ---------------------------------------------------------------------------------------------------
# ENTITY REALIGNMENT — the draft's segment labels are SHIFTED on the p.9 reconciliation table.
#
# Found by scoring, not by inspection: 16 of the run's 39 value mismatches were all on this table, and every
# one of them paired a golden value with the value the pipeline stored for the NEXT segment. The cause is in
# the draft: the table's FIRST run (Operating income) carries a BLANK entity, so the harvester attached each
# following segment name to the block above it and every label landed one block late.
#
# PROVEN, not assumed. The source prints four rows per segment (OI / D&A / Non-recurring / Adjusted OIBDA)
# and Adjusted OIBDA = OI + D&A. Realigning the OI run so its Nth value belongs to the Nth segment satisfies
# that identity for ALL EIGHT segments (FY24 Q1):
#     G&NS         65.2 + 30.4  =  95.6  vs   95.7   (0.1 rounding)
#     Music        85.9 + 21.8  = 107.7  vs  107.7
#     Pictures     11.3 + 16.5  =  27.8  vs   27.8
#     ET&S         64.1 + 26.0  =  90.1  vs   90.1
#     I&SS         36.6 + 69.2  = 105.8  vs  105.8
#     All Other     1.3 +  1.3  =   2.6  vs    2.6
#     Corp. Elim. -15.3 +  3.5  = -11.8  vs  -11.8
#     Total       249.1 + 168.7 = 417.8  vs  417.9   (0.1 rounding)
# The Cowork ruling independently states "G&NS OI FY24 Q1 = 65.2", which is what the PIPELINE stored — so the
# extraction was right and the reference was wrong. Left unfixed, a correct extraction is scored as 16 value
# errors AND 16 omissions, which is the worst possible outcome for an evaluation: it manufactures defects.
#
# Mapping is POSITIONAL over the run's label sequence, mirroring NESTED_BREAKDOWN_SEQUENCE and
# STACKED_SECTION_SEQUENCE. Each entry is (run label, correct entity) in rowid order.
ENTITY_REALIGN_SEQUENCE = {
    "Reconciliation Table for Adjusted OIBDA 1 by segment": [
        # The blank-entity OI run actually belongs to G&NS; each later run shifts back by one segment.
        ("OI", "G&NS"),
        ("Depreciation and", "G&NS"),
        ("Non-recurring", "G&NS"),
        ("Adjusted OIBDA", "G&NS"),
        ("OI", "Music"),
        ("Depreciation and", "Music"),
        ("Adjusted OIBDA", "Music"),
        ("OI", "Pictures"),
        ("Depreciation and", "Pictures"),
        ("Adjusted OIBDA", "Pictures"),
        ("OI", "ET&S"),
        ("Depreciation and", "ET&S"),
        # The reviewer's draft split one label as "(profit) loss Adjusted OIBDA" — ruling ①: the numeric
        # value belongs to Adjusted OIBDA (Non-recurring is "-" here).
        ("(profit) loss Adjusted OIBDA", "ET&S"),
        ("OI", "I&SS"),
        ("Depreciation and", "I&SS"),
        ("Adjusted OIBDA", "I&SS"),
        ("OI", "All Other"),
        ("Depreciation and", "All Other"),
        ("Adjusted OIBDA", "All Other"),
        ("OI", "Corp. Elim."),
        ("Depreciation and", "Corp. Elim."),
        ("Non-recurring", "Corp. Elim."),
        ("Adjusted OIBDA", "Corp. Elim."),
        ("OI", "Total"),
        ("Depreciation and", "Total"),
        ("Non-recurring", "Total"),
        ("Adjusted OIBDA", "Total"),
    ],
}

# The measure slug for a stacked table's rows. When absent, the section name doubles as the measure (which is
# what the pipeline does: section "Additions" -> metric_key "additions").
STACKED_SECTION_MEASURE = {}

STACKED_SECTION_SEQUENCE = {
    "Additions to long-lived assets and right-of-use assets / Depreciation and amortization": [
        ("Additions 2: PP&E", "Additions"),
        ("Content assets excl. film costs and", "Additions"),
        (
            "broadcasting rights and Other intangible assets Right-of-use assets",
            "Additions",
        ),
        ("Subtotal (Capex)", "Additions"),
        ("Film costs and", "Additions"),
        ("broadcasting rights Total", "Additions"),
        ("Depreciation and amortization 3: PP&E", "Depreciation and amortization"),
        ("Content assets excl. film costs and", "Depreciation and amortization"),
        (
            "broadcasting rights and Other intangible assets Right-of-use assets",
            "Depreciation and amortization",
        ),
        ("Subtotal", "Depreciation and amortization"),
        ("Film costs and", "Depreciation and amortization"),
        ("broadcasting rights Total", "Depreciation and amortization"),
    ],
    "Adjusted Income 2": [
        ("Operating income Before Adjustment", "Operating income"),
        ("Non-recurring (profit) loss", "Operating income"),
        ("Adjusted", "Operating income"),
        ("Income before income taxes Before Adjustment", "Income before income taxes"),
        ("Non-recurring (profit) loss", "Income before income taxes"),
        ("Adjusted", "Income before income taxes"),
        ("Income taxes Before Adjustment", "Income taxes"),
        ("Non-recurring (profit) loss", "Income taxes"),
        ("Adjusted", "Income taxes"),
        (
            "Net income attributable to Sony Group Corporation's stockholders Before Adjustment",
            "Net income attributable to Sony Group Corporation's stockholders",
        ),
        (
            "Non-recurring (profit) loss",
            "Net income attributable to Sony Group Corporation's stockholders",
        ),
        (
            "Adjusted",
            "Net income attributable to Sony Group Corporation's stockholders",
        ),
    ],
}

NESTED_BREAKDOWN_SEQUENCE = {
    "Music Revenue breakdown (to external customers)": [
        # (row label, immediate parent) — in the order the source prints them
        ("Physical", "Recorded Music"),
        ("Digital", "Recorded Music"),
        ("Download", "Digital"),
        ("Streaming", "Digital"),
        ("Other", "Recorded Music"),
        ("Recorded Music", "Music"),
        # "Music Publishing" (not bare "Publishing") is what the SOURCE prints and what the pipeline stores.
        # The distinction matters because the parent is the ONLY thing separating this block's Streaming/Other
        # from the Recorded Music block's, and the two spellings do not fold together (ENTITY_ALIASES maps
        # "music" but nothing maps "publishing" -> "musicpublishing"). Left as bare "Publishing", 23 correct
        # extractions on this table scored as value errors.
        ("Streaming", "Music Publishing"),
        ("Other", "Music Publishing"),
        # The block's own subtotal row: its LABEL also needs the source's spelling, or the subtotal itself is
        # a false negative against the stored entity "Music Publishing" (see PUBLISHING_LABEL_FIX below).
        ("Publishing", "Music"),
        ("Gaming", "Visual Media & Platform"),
        ("Other", "Visual Media & Platform"),
        ("Visual Media & Platform", "Music"),
        ("Segment Total Sales", ""),
        ("(Yen) Average USD rates", ""),
    ],
}

# Tables whose ROWS are line items of the CONSOLIDATED entity: the row label is already the measure, and the
# blank entity has to be filled in. A blank field cannot be matched at all — the matcher has nothing to fold —
# which is why all 303 of these rows were false negatives.
CONSOLIDATED_ENTITY = "Sony Group Corporation"
CONSOLIDATED_ROW_TABLES = {
    "Adjusted Income 2",
    "Reconciliation Table for Adjusted EBITDA 1",
    "Non-Recurring Profit and Loss",
    "Research and development expenses",
    "Film costs and broadcasting rights included in content assets (balance)",
    "Additions to long-lived assets and right-of-use assets / Depreciation and amortization",
}

# The p.6 table stacks TWO measurement blocks under one title (Additions, then Depreciation & amortization),
# so the same asset line appears twice with the same coordinate. Prefixing the metric with its section is what
# separates them; without it the two blocks collide (86 collisions, 201 rows held back).
STACKED_SECTION_TABLE = (
    "Additions to long-lived assets and right-of-use assets / Depreciation and amortization"
)

# Row labels the reviewer's draft captured as multi-line fragments, mapped to the label actually printed.
# Every entry was confirmed against the source page by the Cowork review; none is a guess.
FRAGMENT_FIXES = {
    # p.6 — a four-line row label the harvester split in two, plus the NEXT row's label stuck to the tail.
    # Confirmed against the source: rows are PP&E / Content assets excl… / Right-of-use assets /
    # Subtotal (Capex) / Film costs and broadcasting rights / Total.
    "Content assets excl. film costs and": "Content assets excl. film costs and broadcasting rights and Other intangible assets",
    "broadcasting rights and Other intangible assets Right-of-use assets": "Right-of-use assets",
    "Film costs and": "Film costs and broadcasting rights",
    "broadcasting rights Total": "Total",
    # p.5 — ruling ④: the G&NS product lines are "Digital Software and Add-on Content" / "Network Services" /
    # "Hardware and Others", and the harvester cut the first label after "and" then glued its tail onto the
    # next row's head. Confirmed by the arithmetic the reviewer cited:
    # 432,752 + 159,346 + 252,190 = 844,288 (the G&NS subtotal).
    "Digital Software and": "Digital Software and Add-on Content",
    "Add-on Content Network Services": "Network Services",
    # p.9 — footnote superscript captured into the label, and two rows merged. The numeric value belongs to
    # Adjusted OIBDA; Non-recurring (profit) / loss is usually "-" (no value).
    "Depreciation and": "Depreciation and Amortization",
    "(profit) loss Adjusted OIBDA": "Adjusted OIBDA",
    # p.14 — the unit moved to the front of the label.
    "(Yen) Average USD rates": "Average USD rates",
    # p.10 — the harvester joined the TAIL of row 1 to the HEAD of row 2. The value 4.2 belongs to row 2,
    # which the extraction side already had right.
    "stockholders Net income attributable to": "Net income attributable to noncontrolling interests",
    # p.11 — long line items whose labels wrapped, so a fragment carries the previous row's tail. The bracketed
    # (segment・FY) tags are separated out by SEGMENT_TAGGED_ITEMS below.
    "previous years in Japan (FY25) Tax effect with regard to the": "Tax effect with regard to the above items",
    "income (before adjustment) Recording of impairment losses against a portion of Bungie, Inc.\u2019s intangible and": "Recording of impairment losses against a portion of Bungie, Inc.\u2019s intangible and other assets in connection with Destiny 2",
    "Other\u30fbFY25) Realization of unrealized gains on land transferred by Sony Group Corporation to Sony Life Insurance Co., Ltd. in past fiscal years, in": "Realization of unrealized gains on land transferred by Sony Group Corporation to Sony Life Insurance Co., Ltd. in past fiscal years, in connection with an execution of a partial spin-off of the Financial Services business",
    # NOTE the trap here: the fragment's leading "(FY24)" is the PREVIOUS row's tag. This item's real tag is
    # (FY25), so the (FY24) must not be carried over as this row's year.
    "(FY24) Decrease in tax expense from refunds of taxes paid in": "Decrease in tax expense from refunds of taxes paid in previous years in Japan",
}

# p.11 line items whose bracketed tag names a SEGMENT: the segment is the entity, not part of the metric.
# Everything else on that table is a consolidated aggregate.
SEGMENT_TAGGED_ITEMS = {
    "Recording of impairment losses against a portion of Bungie, Inc.\u2019s intangible and other assets in connection with Destiny 2": "G&NS",
    "Recording of expenses resulting from a correction in the amount of certain previously capitalized development costs": "G&NS",
    "Impairment loss related to sales of long-lived assets": "All Other",
    "Realization of unrealized gains on land transferred by Sony Group Corporation to Sony Life Insurance Co., Ltd. in past fiscal years, in connection with an execution of a partial spin-off of the Financial Services business": "All Other",
}

# Rows that are not figures at all: a unit/header line whose footnote superscript was captured as the value.
# Dropped rather than relabelled — keeping a non-figure in the reference would make a correct extraction look
# like an omission.
DROP_METRICS = {"(Billions of yen) FY24 FY25"}

# The p.12 unit-sales table has a three-line label, so the value row carried no label at all.
UNIT_SALES_TABLE = "PlayStation®5 hardware and software unit sales"
UNIT_SALES_BLANK_METRIC = "Full game software (PS4/PS5)"


def realigned_entities(rows):
    """Assigns each row its CORRECT entity where the draft's segment labels are shifted, keyed by rowid.

    Same positional mechanism as nested_parents/stacked_sections: the Nth label run in rowid order is the Nth
    entry of the recorded sequence. Returns {rowid: entity}.

    Raises on a run-count or label mismatch rather than falling back. A silently mis-shifted entity is the
    worst failure mode available here: it scores a CORRECT extraction as both a value error and an omission,
    manufacturing defects that do not exist (measured: 16 such pairs before this fix).
    """
    assigned = {}
    for table, sequence in ENTITY_REALIGN_SEQUENCE.items():
        table_rows = sorted(
            (row for row in rows if row["table"].strip() == table),
            key=lambda row: row["rowid"],
        )
        if not table_rows:
            continue
        runs = []
        for row in table_rows:
            label = row["metric"].strip()
            if not runs or runs[-1][0] != label:
                runs.append((label, [row]))
            else:
                runs[-1][1].append(row)
        if len(runs) != len(sequence):
            raise ValueError(
                f"{table}: found {len(runs)} label runs but the recorded sequence has {len(sequence)} — "
                f"the table's row order changed, so the entity alignment must be re-verified against the "
                f"source (check that Adjusted OIBDA = OI + D&A still holds per segment)."
            )
        for (run_label, run_rows), (expected_label, entity) in zip(runs, sequence):
            if run_label != expected_label:
                raise ValueError(
                    f"{table}: expected run '{expected_label}' but found '{run_label}' — "
                    f"re-verify the entity alignment against the source."
                )
            for row in run_rows:
                assigned[row["rowid"]] = entity
    return assigned


# Populated by main() before any relabel() call, so a shifted row can look up its corrected entity.
REALIGNED_ENTITY_BY_ROWID = {}


def stacked_sections(rows):
    """Assigns each stacked-section row its section name, keyed by the row's own id.

    Same positional mechanism as nested_parents: the Nth label run in rowid order is the Nth entry of the
    recorded sequence. Returns {rowid: section}.

    Raises on a run-count or label mismatch rather than falling back — a row silently attached to the wrong
    section would carry a real value under the wrong measure, which scores as BOTH a false positive and a
    false negative and is indistinguishable from an extraction defect.
    """
    assigned = {}
    for table, sequence in STACKED_SECTION_SEQUENCE.items():
        table_rows = sorted(
            (row for row in rows if row["table"].strip() == table),
            key=lambda row: row["rowid"],
        )
        if not table_rows:
            continue
        runs = []
        for row in table_rows:
            label = row["metric"].strip()
            if not runs or runs[-1][0] != label:
                runs.append((label, [row]))
            else:
                runs[-1][1].append(row)
        if len(runs) != len(sequence):
            raise ValueError(
                f"{table}: found {len(runs)} label runs but the recorded sequence has "
                f"{len(sequence)} — the table's row order changed, so the sections must be "
                f"re-verified against the source before scoring."
            )
        for (run_label, run_rows), (expected_label, section) in zip(runs, sequence):
            if run_label != expected_label:
                raise ValueError(
                    f"{table}: expected run '{expected_label}' but found '{run_label}' — "
                    f"re-verify the section split against the source."
                )
            for row in run_rows:
                assigned[row["rowid"]] = section
    return assigned


# Populated by main() before any relabel() call, so a stacked row can look up its positionally-derived section.
STACKED_SECTION_BY_ROWID = {}


def nested_parents(rows):
    """Assigns each nested-breakdown row its immediate parent, keyed by the row's own id.

    The draft's `rowid` runs give the block order (verified: rowid 1289-1401 form 14 consecutive same-label
    runs matching NESTED_BREAKDOWN_SEQUENCE one-for-one), so the Nth run is the Nth entry of the sequence.
    Returns {rowid: parent}.

    A run count that does not match the recorded sequence RAISES rather than falling back, because a silent
    mismatch would attach figures to the wrong parent — a false coordinate is worse than a missing one, and
    it would be invisible in the output.
    """
    assigned = {}
    for table, sequence in NESTED_BREAKDOWN_SEQUENCE.items():
        table_rows = sorted(
            (row for row in rows if row["table"].strip() == table),
            key=lambda row: row["rowid"],
        )
        runs = []
        for row in table_rows:
            label = row["metric"].strip()
            if not runs or runs[-1][0] != label:
                runs.append((label, [row]))
            else:
                runs[-1][1].append(row)
        if len(runs) != len(sequence):
            raise ValueError(
                f"{table}: found {len(runs)} label runs but the recorded sequence has "
                f"{len(sequence)} — the table's row order changed, so the parents must be re-verified "
                f"against the source before scoring."
            )
        for (run_label, run_rows), (expected_label, parent) in zip(runs, sequence):
            if run_label != expected_label:
                raise ValueError(
                    f"{table}: expected run '{expected_label}' but found '{run_label}' — "
                    f"re-verify the nesting against the source."
                )
            for row in run_rows:
                assigned[row["rowid"]] = parent
    return assigned


# Populated by main() before any relabel() call, so a nested row can look up its positionally-derived parent.
NESTED_PARENT_BY_ROWID = {}


def relabel(row):
    """Applies the reviewer-confirmed labelling rules, returning (entity, metric, parent, dropped).

    Returns dropped=True for rows the review identified as non-figures, so the caller can exclude them.
    """
    table = row["table"].strip()
    entity = row["entity"].strip()
    metric = row["metric"].strip()
    parent = ""

    if metric in DROP_METRICS:
        return entity, metric, parent, True

    # ENTITY REALIGNMENT FIRST — before any label rewriting, because the lookup is by ROWID and the corrected
    # entity is what every later rule must see (a shifted segment would otherwise propagate).
    if table in ENTITY_REALIGN_SEQUENCE:
        corrected = REALIGNED_ENTITY_BY_ROWID.get(row["rowid"])
        if corrected:
            entity = corrected

    # Multi-line label fragments first, so later rules see the real label.
    metric = FRAGMENT_FIXES.get(metric, metric)

    # Footnote reference markers are not part of a label. A trailing 1-2 digit number after a word is a
    # footnote superscript the harvester flattened into the text ("Amortization 2"), and leaving it in makes
    # the label fail to match the same row extracted without it.
    metric = re.sub(r"\s+\d{1,2}$", "", metric).strip()

    # p.11: a bracketed segment tag identifies the SUBJECT, so it belongs in entity rather than the metric.
    if metric in SEGMENT_TAGGED_ITEMS:
        entity = SEGMENT_TAGGED_ITEMS[metric]

    # A blank metric on the unit-sales table is the three-line-label case.
    if not metric and table == UNIT_SALES_TABLE:
        metric = UNIT_SALES_BLANK_METRIC

    # HIERARCHICAL tables: a subtotal row (entity == metric) keeps the segment as the entity and takes the
    # measure from the title; a CHILD row moves its own label into the entity and names the segment as parent.
    #
    # This is the alignment the extraction prompt now produces, verified live on p.5. The draft's opposite
    # split cannot be reconciled by the matcher (see HIERARCHICAL_TABLES for why), so the golden set restates
    # it here rather than the matcher being loosened until it merges genuinely different figures.
    if table in HIERARCHICAL_TABLES:
        measure = HIERARCHICAL_TABLES[table]
        if entity and entity.lower() == metric.lower():
            metric = measure  # the segment subtotal — a top-level row, so no parent
        elif entity:
            parent = entity  # the draft's entity is the SEGMENT this child sits under
            entity = metric  # the child's own label is its subject
            metric = measure

    # Nested breakdown: the parent was derived POSITIONALLY (see nested_parents), because the same child label
    # occurs in more than one block and a label lookup would give both occurrences the same parent.
    elif table in NESTED_BREAKDOWN_SEQUENCE:
        parent = NESTED_PARENT_BY_ROWID.get(row["rowid"], "")
        if metric:
            entity = metric
            metric = NESTED_BREAKDOWN_MEASURE[table]
        # The draft abbreviated one block header. The source (and the pipeline) print "Music Publishing", and
        # nothing folds the two spellings together, so the subtotal row would be a false negative without this.
        entity = NESTED_ENTITY_SPELLING.get(entity, entity)

    # One-segment breakdown tables: every row is a child of the segment named in the title, except an explicit
    # segment total, which stays top-level.
    elif table in SINGLE_PARENT_BREAKDOWN_TABLES:
        segment, measure = SINGLE_PARENT_BREAKDOWN_TABLES[table]
        if metric.lower() in BREAKDOWN_TOTAL_LABELS:
            entity = segment
            metric = measure
        elif metric:
            parent = segment
            entity = metric
            metric = measure

    # Segment-row tables (no hierarchy): the measure comes from the title — but ONLY for the rows where the
    # draft duplicated the subject into both fields (entity == metric), which is the signature of "this row
    # has no measure of its own".
    #
    # This must NOT be applied per-table wholesale. Verified: a hierarchical table's child rows carry a real
    # label in the metric field, and flattening every metric to the title's measure erased the product line
    # and collapsed four distinct figures onto one coordinate (measured: 160 rows became ambiguous). Those
    # tables are handled above instead; this branch is for the flat ones.
    elif table in SEGMENT_ROW_TABLES and entity and entity.lower() == metric.lower():
        metric = SEGMENT_ROW_TABLES[table]

    # STACKED SECTIONS: one title, two or more measurement blocks. The section name qualifies the metric, which
    # is what stops the repeated row labels from colliding (measured: 118 of the 182 held-back rows).
    #
    # Looked up by ROWID, so it is unaffected by the label rewriting above — that matters because FRAGMENT_FIXES
    # and the footnote strip both change `metric`, and a label-keyed lookup would silently miss after them.
    if table in STACKED_SECTION_SEQUENCE:
        section = STACKED_SECTION_BY_ROWID.get(row["rowid"], "")
        if section:
            # The section heading is FUSED into the first row of each block ("Additions 2: PP&E"), so strip it —
            # it becomes the parent below rather than part of the line-item label.
            if ":" in metric:
                metric = metric.split(":", 1)[1].strip() or metric
            # SECTION GOES IN THE PARENT, not glued onto the metric.
            #
            # Checked against what the pipeline actually stores for this table rather than decided on taste:
            #   entity="PP&E"  entity_parent="Additions"  metric_key="additions"  value=345,726
            # so the extraction already treats the section as the row's parent and the line item as its
            # subject — the same decomposition the p.5 hierarchy uses. An earlier version of this rule folded
            # the section into the metric ("Additions — PP&E"), which separated the blocks correctly but would
            # have matched NOTHING: the golden metric would carry a section token the extracted metric never
            # has, exactly the un-cancellable-token failure documented in
            # docs/agent/tabular-extract-prompt-label-alignment.md.
            parent = section
            entity = metric
            metric = STACKED_SECTION_MEASURE.get(table, section)

    # Consolidated line-item tables: fill the blank entity so the coordinate is matchable.
    if table in CONSOLIDATED_ROW_TABLES and not entity:
        entity = CONSOLIDATED_ENTITY

    # The stacked p.6 table needs a section prefix (Additions vs D&A) to stop the two blocks colliding, but
    # the draft never recorded which section a row came from. That is NOT reconstructable here, and guessing
    # would assign figures to the wrong measure — so those rows stay ambiguous and are reported separately for
    # the reviewer rather than silently resolved.

    return entity, metric, parent, False


def to_golden(row, document_id):
    """Maps one review-app row to the golden-object field names."""
    # The standard Name field is Text(80) and a longer value fails the insert. The period is the most
    # useful part for a human scanning a list view, so it is kept and the metric is trimmed instead of
    # truncating the whole string from the right.
    entity, metric, parent, _dropped = relabel(row)
    period = row["period"].strip()
    subject = f"{entity} {metric}".strip()
    budget = 80 - len(period) - 1
    if len(subject) > budget:
        subject = subject[: max(budget - 1, 0)] + "…"
    # Metric_Key__c is Text(80) on both objects, and some source row labels are far longer (a 90-char Sony
    # line item). The UNTRUNCATED text is preserved in Metric_Label__c (Text 255) so nothing is lost, and the
    # matcher folds punctuation/case away, so a consistently truncated key still matches — as long as the
    # extraction side truncates identically, which MI_TabularExtractionService does at the same 80 chars.
    metric_key = metric[:80]
    return {
        "Name": f"{subject} {period}".strip()[:80],
        "Market_Insight_Document__c": document_id,
        "Entity__c": entity[:255],
        "Entity_Parent__c": parent[:255],
        "Entity_Label__c": "",
        "Metric_Key__c": metric_key,
        "Metric_Label__c": (metric or row.get("row_label") or "")[:255],
        "Period__c": row["period"][:40],
        "Year__c": year_of(row["period"]),
        "Value_Text__c": row["value_text"][:255],
        "Unit__c": row["unit"][:40],
        "Value_Type__c": row["value_type"] or "Actual",
        "Table_Name__c": row["table"][:255],
        "Column_Note__c": (row.get("col_note") or "")[:80],
        "Source_Page__c": str(row["page"])[:40],
        "Note__c": row.get("flag") or "",
    }


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    html_path, document_id = sys.argv[1], sys.argv[2]
    rows = extract_data(html_path)

    # Derived once, before any relabel() call, because a nested row's parent depends on its POSITION among
    # its siblings rather than on anything the row itself carries.
    global NESTED_PARENT_BY_ROWID, STACKED_SECTION_BY_ROWID, REALIGNED_ENTITY_BY_ROWID
    NESTED_PARENT_BY_ROWID = nested_parents(rows)
    STACKED_SECTION_BY_ROWID = stacked_sections(rows)
    REALIGNED_ENTITY_BY_ROWID = realigned_entities(rows)

    kept, dropped_value_type, blank_required, dropped_nonfigure = [], [], [], []
    for row in rows:
        value_type = (row["value_type"] or "Actual").strip().lower()
        if value_type not in HARVESTED_VALUE_TYPES:
            dropped_value_type.append(row)
            continue
        # Entity may legitimately be blank (the table's subject is the document), but a figure with no metric
        # or no period cannot be keyed at all — the extraction pipeline discards such rows too, so a golden
        # row like this could never be matched.
        _entity, _metric, _parent, is_nonfigure = relabel(row)
        if is_nonfigure:
            # A unit/header line whose footnote superscript was captured as a value — not a figure at all.
            dropped_nonfigure.append(row)
            continue
        if not _metric.strip() or not row["period"].strip():
            blank_required.append(row)
            continue
        kept.append(row)

    grouped = defaultdict(list)
    for row in kept:
        grouped[coordinate(row)].append(row)

    loadable = [rows_[0] for rows_ in grouped.values() if len(rows_) == 1]
    ambiguous = [row for rows_ in grouped.values() if len(rows_) > 1 for row in rows_]

    base = html_path.rsplit("/", 1)[0] if "/" in html_path else "."
    loadable_path = f"{base}/golden-rows-loadable.csv"
    ambiguous_path = f"{base}/golden-rows-ambiguous.csv"

    with open(loadable_path, "w", newline="\n", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        for row in loadable:
            writer.writerow(to_golden(row, document_id))

    with open(ambiguous_path, "w", newline="\n", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES + ["_collision_group"])
        writer.writeheader()
        for group_index, (key, rows_) in enumerate(
            sorted(
                ((k, v) for k, v in grouped.items() if len(v) > 1),
                key=lambda pair: (pair[0][4], pair[0][1], pair[0][2]),
            )
        ):
            for row in rows_:
                record = to_golden(row, document_id)
                record["_collision_group"] = group_index + 1
                writer.writerow(record)

    print(f"review-app rows              : {len(rows)}")
    print(f"  dropped (YoY/QoQ etc.)     : {len(dropped_value_type)}")
    print(f"  dropped (no metric/period) : {len(blank_required)}")
    print(f"  dropped (non-figure rows)  : {len(dropped_nonfigure)}")
    print(f"  LOADABLE (unique coord)    : {len(loadable)}  -> {loadable_path}")
    print(
        f"  AMBIGUOUS (needs a human)  : {len(ambiguous)} in "
        f"{sum(1 for v in grouped.values() if len(v) > 1)} groups -> {ambiguous_path}"
    )
    by_table = defaultdict(int)
    for row in ambiguous:
        by_table[row["table"]] += 1
    if by_table:
        print("\nambiguous rows by table:")
        for table, count in sorted(by_table.items(), key=lambda pair: -pair[1]):
            print(f"  {count:5d}  {table[:70]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
