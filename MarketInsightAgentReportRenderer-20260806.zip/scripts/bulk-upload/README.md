# 대량 파일 업로드 (12k) 런북

`miBulkFileUpload` LWC는 선택당 10개 상한 때문에 수천 개 파일을 사람 손으로 올리기 어렵다. 이 디렉터리의
`upload_content_versions.py`는 **파일 등록 전 과정을 Python 한 번의 실행으로** 끝낸다 — 익명 Apex를 왔다 갔다
할 필요가 없다.

- **1단계 — 파일 바이트:** REST `POST /sobjects/ContentVersion`(multipart/form-data)를 파일당 한 번, httpx로
  병렬 호출. (Bulk API는 `ContentVersion.VersionData` 바이너리를 못 실으므로 REST가 유일한 경로다.)
- **2단계 — `Market_Insight_Document__c` 레코드:** Composite sObject Collections로 200건씩.
- **3단계 — `ContentDocumentLink`:** Composite sObject Collections로 200건씩(ShareType `V`).

링크 삽입이 `MI_DocumentFileTrigger`를 깨우므로 Facet 생성이(그리고 스위치가 켜져 있으면 표 추출이) 시작된다.

## 왜 이 구조인가

- **파일 바이트는 REST만 가능.** `ContentVersion.VersionData`(바이너리)는 Bulk API 1.0/2.0이 지원하지 않는다
  (`sf data import bulk`도 Bulk 2.0 래퍼라 불가). sf CLI에는 파일 업로드 명령이 없어 **인증**에만 쓴다
  (`sf org display --json`). 스크립트는 OAuth를 직접 다루지 않는다.
- **레코드·링크는 Collections로 200건씩.** 그래서 12k 파일에 대해 링크 삽입 DML은 ~60번이고, 트리거도 ~60번만
  발화한다 → ~60개의 scope-1 Facet 배치가 flex 큐 한도 안에서 소진된다.
- **Tabular는 CMDT 토글로 억제.** 표 추출은 PDF당 최대 ~120개 scope-1 배치로 팬아웃되어 부하가 크므로, 적재
  중에는 `MI_Setting.Default.Tabular_Extraction_Enabled__c = false`로 꺼 두고, 완료 후 켜서
  `MI_TabularBackfillBatch`로 나눠 캐치업한다.

## 멱등성 (중간에 멈춰도 안전)

- **바이트:** 별도 원장 없이 **org 자체가 기준**이다. `ContentVersion.Checksum`이 파일 MD5라, org에 이미
  있는 내용은 다시 올리지 않는다(로컬 상태 파일에 의존하지 않으므로 어디서 실행하든 동일하게 안전).
- **레코드·링크:** 만들기 전에 각 파일을 ContentDocumentId로 해석하고, **이미 `Market_Insight_Document__c`에
  연결된 ContentDocument는 건너뛴다**(`MI_DocumentBackfillBatch`가 쓰는 것과 같은 확실한 검사). 어느 지점에서
  멈췄든 다시 실행하면 중복 없이 이어서 완성한다.

## 사전 준비: Data Cloud 파일 veto 확인

업로드 사용자가 `Query Non Vetoed Files`(`PermissionsQueryNonVetoedFiles`) 권한을 가진 채 Data Cloud 파일
수집이 켜져 있으면, 업로드된 파일이 **생성은 되지만 그 사용자에게 안 보여** 연결할 수 없다. 스크립트가
프리플라이트로 자동 검사하고 걸리면 중단한다. 조치는 그 권한을 사람 업로더가 아닌 **Data Cloud 인덱싱 통합
사용자**에게만 부여하는 것. 상세: [docs/deployment/file-upload-vetoing-incident.md](../../docs/deployment/file-upload-vetoing-incident.md).

## 실행 순서

```bash
# 0) 대상 org 확인
sf config get target-org --json

# 1) Tabular 추출 OFF (관리자) — Default CMDT 레코드에서 Tabular_Extraction_Enabled__c 체크 해제
#    (Setup > Custom Metadata Types > Report Generation Setting > Manage Records > Default)

# 2) (선택) 무엇이 올라갈지 먼저 확인 — 변경 없음
uv run --project scripts/bulk-upload scripts/bulk-upload/upload_content_versions.py \
  --source-dir /path/to/files --document-type 외부보고서 --dry-run

# 3) 전 과정 실행: 바이트 업로드 → 레코드 → 링크. veto 프리플라이트가 먼저 돈다.
#    (한 번에 일부만 올리려면 --limit N 을 붙인다 — 아래 "나눠서 업로드" 참고)
uv run --project scripts/bulk-upload scripts/bulk-upload/upload_content_versions.py \
  --source-dir /path/to/files --document-type 외부보고서 --workers 8
#    - 중간에 멈췄으면 같은 명령을 다시 실행한다. org 기준(바이트=Checksum, 레코드=링크 존재 여부)으로
#      이미 처리된 것은 자동으로 건너뛰고 남은 것만 이어서 완성한다.

# 4) 적재 검증 — 신규 문서 수와 Facet 진행, 그리고 Tabular_Status__c 가 여전히 null(=표 추출 미실행)인지 확인
sf data query --query "SELECT COUNT(Id) total, COUNT(Tabular_Status__c) withTabular FROM Market_Insight_Document__c WHERE CreatedDate = TODAY"

# 5) Tabular 추출 ON — Default CMDT 레코드에서 Tabular_Extraction_Enabled__c 다시 체크
#    (향후 업로드용 복원. 캐치업 실행 자체에는 필수 아님 — MI_TabularBackfillBatch는 게이트를 우회한다.)

# 6) 표 추출 캐치업 — 페이싱해서 실행 (한 번에 전부 잡으면 5-동시배치/일일 비동기/LLM 한도를 압박)
#    MI_TabularBackfillBatch는 Tabular_Status__c = NULL 문서를 잡아 문서당 팬아웃한다. 경계 있는
#    서브셋(유형/CreatedDate 창)으로 나눠 여러 번 돌린다.
sf apex run --file /dev/stdin <<< 'Database.executeBatch(new MI_TabularBackfillBatch(), 1);'
```

> **참고 — 유형이 여러 개면?** 이 스크립트는 한 번에 하나의 `--document-type`을 찍는다. 유형별로 소스
> 디렉터리를 나눠 유형마다 한 번씩 실행하면 된다.

## 스크립트 옵션

| 옵션                    | 기본값            | 설명                                                                                                                 |
| ----------------------- | ----------------- | -------------------------------------------------------------------------------------------------------------------- |
| `--source-dir DIR`      | (필수)            | 재귀 스캔할 디렉터리. `pdf/xlsx/docx/pptx/txt`만 대상(그 외 skip).                                                   |
| `--limit N`             | (없음, 전체)      | 이번 실행에서 처리할 최대 파일 수(파일 이름 오름차순 앞에서부터 N개). 나눠 올릴 때 쓴다 — 아래 "나눠서 업로드" 참고. |
| `--document-type VALUE` | (없음)            | 모든 레코드의 `Document_Type__c`. 공시자료/외부보고서/증권사보고서/컨설팅보고서/내부보고서 중 하나 또는 생략.        |
| `--target-org ALIAS`    | 설정된 target-org | sf CLI org 별칭/사용자명.                                                                                            |
| `--workers N`           | 8                 | 바이트 업로드 최대 동시 요청 수. org API 한도에 맞춰 조정.                                                           |
| `--api-version V`       | 67.0              | Salesforce API 버전.                                                                                                 |
| `--timeout SEC`         | 120               | 요청당 타임아웃(초).                                                                                                 |
| `--skip-veto-check`     | off               | veto 프리플라이트 건너뜀(권장하지 않음).                                                                             |
| `--dry-run`             | off               | 무엇을 할지만 출력, 변경 없음.                                                                                       |

### 나눠서 업로드 (`--limit`)

폴더에 12,000개가 있어도 한 번에 일부만 올리고 싶을 때 쓴다. 정렬 기준은 **파일 이름 오름차순**이고, 앞에서부터
N개를 자른다. 이미 만들어 둔 **org 기준 멱등성**과 맞물려, `--limit`만 키우며 여러 번 실행하면 이어서 올라간다:

```bash
# 1차: 이름순 1~1000번째
uv run --project scripts/bulk-upload scripts/bulk-upload/upload_content_versions.py \
  --source-dir /path/to/files --document-type 외부보고서 --limit 1000

# 2차: 1~1000은 이미 org에 있어 자동 skip, 1001~2000만 신규 업로드
uv run --project scripts/bulk-upload scripts/bulk-upload/upload_content_versions.py \
  --source-dir /path/to/files --document-type 외부보고서 --limit 2000

# … 계속 늘리거나, 마지막엔 --limit 없이 남은 전체를 마무리
```

`--limit`은 해시 계산 전에 잘라내므로, 1000개만 올릴 때 나머지 파일을 해싱하느라 시간을 낭비하지 않는다.

## 실행 환경 (uv)

이 디렉터리는 [uv](https://docs.astral.sh/uv/) 프로젝트다(`pyproject.toml`). 의존성은 `httpx` 하나.

```bash
# 최초 1회: 의존성 설치(가상환경 자동 생성)
uv sync --project scripts/bulk-upload
# 이후에는 uv run이 알아서 환경을 맞춰 실행한다(위 실행 순서 참고).
```

## 대안: `MI_DocumentBackfillBatch` (Apex 백필)

이미 native Files로 파일만 올려 둔(orphan ContentDocument) 상태라면, 레코드+링크+Facet 생성을 Apex 배치로
할 수도 있다: `scripts/apex/backfill-uploaded-files.apex`. 이 경로는 트리거를 우회(`bypass=true`)하므로 Facet만
시작하고 표 추출은 시작하지 않는다. 이 Python 스크립트는 그 두 경로(바이트 업로드 + 레코드/링크)를 한 번에
처리하는 것이 차이다.
