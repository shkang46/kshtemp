#!/usr/bin/env python3
"""파일 ~12,000개를 Salesforce에 한 번에 등록한다 — 전 과정을 Python에서 처리(익명 Apex 왕복 불필요).

--source-dir 아래 각 파일을 miBulkFileUpload LWC와 동일한 형태로 만든다:
  1. ContentVersion(파일 바이트)  — REST `POST /sobjects/ContentVersion` multipart, httpx로 병렬.
  2. Market_Insight_Document__c   — REST Composite sObject Collections, 200건/요청.
  3. ContentDocumentLink          — REST Composite sObject Collections, 200건/요청(ShareType 'V').

왜 REST인가: Bulk API 2.0(과 그 래퍼 `sf data import bulk`)은 ContentVersion.VersionData(바이너리)를 못
싣는다. sf CLI는 인증에만 쓴다(`sf org display --json`).

멱등성(중간에 멈춰도 안전): 별도 원장 없이 org 자체가 기준이다.
  - 바이트: 파일 MD5가 ContentVersion.Checksum으로 이미 org에 있으면 다시 올리지 않는다.
  - 레코드/링크: ContentDocument가 이미 Market_Insight_Document__c에 연결돼 있으면 건너뛴다.
어느 지점에서 멈췄든 같은 명령을 다시 실행하면 org 상태를 보고 남은 것만 이어서 완성한다.

표(Tabular) 추출 부하: 링크 삽입이 MI_DocumentFileTrigger를 깨워 Facet 생성과(스위치가 켜져 있으면) 표
추출을 시작한다. 표 추출은 무겁게 팬아웃되므로, 대량 적재 전에는
MI_Setting.Default.Tabular_Extraction_Enabled__c 를 꺼 두고 적재 후
MI_TabularBackfillBatch로 따로 채운다. 자세한 절차는 scripts/bulk-upload/README.md.

사용법:
    uv run --project scripts/bulk-upload \
        scripts/bulk-upload/upload_content_versions.py --source-dir /path/to/files --document-type 외부보고서
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import mimetypes
import os
import re
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass

import httpx

# 업로드 대상 확장자. Apex의 MI_DocumentBackfillBatch.TARGET_EXTENSIONS와 동일하게 맞춰,
# 이 스크립트가 등록하는 파일과 사후 백필 배치가 처리하는 파일 집합이 어긋나지 않게 한다.
# 여기 없는 확장자는 조용히 건너뛴다.
TARGET_EXTENSIONS = {"pdf", "xlsx", "docx", "pptx", "txt"}

# Market_Insight_Document__c.Document_Type__c는 제한 선택 목록(restricted picklist)이다. 여기에 없는
# 값을 넣으면 org가 INSERT를 거부하므로, 실행 전에 --document-type 값을 이 집합으로 검증한다.
DOCUMENT_TYPE_VALUES = {"공시자료", "외부보고서", "증권사보고서", "컨설팅보고서", "내부보고서"}

# --- Data Cloud "파일 veto"란 무엇이고 왜 사전 점검하나 (이 파일만으로 이해되도록 자체 설명) ---
# 조직에 "Enable Files to be ingested into Data Cloud"가 켜져 있고, 파일을 올리는 사용자가
# `Query Non Vetoed Files`(PermissionsQueryNonVetoedFiles) 권한을 가지고 있으면, 업로드한 파일이
# 실제로는 생성되지만(ContentVersion/ContentDocument의 Id는 정상 반환됨) 그 사용자의 모든 조회
# 경로(SOQL·UI·심지어 시스템 모드 Apex)에서 "veto"되어 보이지 않는다. 이 권한은 veto를 만드는 게
# 아니라, veto된 파일을 그 보유자에게서 걸러내는 역할이다. 그 결과 스크립트가 방금 올린 파일을
# 체크섬으로 다시 조회하지 못해(0건) ContentDocumentId를 얻을 수 없고, 레코드에 연결할 수 없다.
# 즉 "업로드는 성공한 것처럼 보이는데 아무것도 연결되지 않는" 증상이 대량으로 발생한다.
# 대책: 이 권한을 사람 업로더가 아니라 전용 Data Cloud 인덱싱 통합 사용자에게만 부여한다.
# (심층 배경과 실제 사고 기록: docs/deployment/file-upload-vetoing-incident.md)
VETO_PERMISSION = "PermissionsQueryNonVetoedFiles"

# Market_Insight_Document__c.Name은 Text(80). LWC/백필과 동일하게 파일명을 80자로 잘라 넣는다.
NAME_MAX = 80
# Composite sObject Collections의 요청당 최대 건수이자, SOQL IN 목록을 나누는 크기(URL 길이 제한 회피).
CHUNK = 200
# 재시도할 HTTP 상태 코드(일시적 장애·레이트리밋).
RETRYABLE_STATUS = {429, 500, 502, 503, 504}
# 재시도할 Salesforce 오류 코드(응답 본문에 포함되면 일시적 상황으로 간주).
RETRYABLE_CODES = ("REQUEST_LIMIT_EXCEEDED", "SERVER_UNAVAILABLE", "UNABLE_TO_LOCK_ROW")
# 파일 하나의 바이트 업로드 최대 시도 횟수(지수 백오프).
MAX_RETRIES = 5


@dataclass
class Doc:
    """업로드 대상 파일 하나의 로컬 정보 + org 측 상태를 담는 작업 단위.

    필드:
        path — 파일의 절대 경로(로컬 디스크).
        md5  — 파일 내용의 MD5 16진 문자열. ContentVersion.Checksum과 같은 값이라, org에 같은 내용이
               이미 있는지(=업로드 생략) 판별하는 키로 쓴다.
        cdid — 이 파일에 대응하는 org의 ContentDocumentId. 처음엔 None이고, resolve_cdids()가 체크섬
               매칭으로 채운다. 값이 있으면 "바이트는 org에 있다"는 뜻이고, 레코드/링크 생성의 대상이 된다.

    프로퍼티:
        name — 경로에서 뽑은 파일명(확장자 포함). File_Name__c와 (80자로 자른) Name에 쓴다.
        ext  — 소문자 확장자(점 없음). 확장자 판별용(현재 직접 쓰지는 않지만 디버깅/확장에 유용).
    """

    path: str
    md5: str
    cdid: str | None = None

    @property
    def name(self) -> str:
        """파일명(확장자 포함)을 반환한다. 예: /a/b/report.pdf → 'report.pdf'."""
        return os.path.basename(self.path)

    @property
    def ext(self) -> str:
        """소문자 확장자(점 제외)를 반환한다. 확장자가 없으면 빈 문자열. 예: 'report.PDF' → 'pdf'."""
        return self.name.rsplit(".", 1)[-1].lower() if "." in self.name else ""


# --------------------------------------------------------------------------- 도우미


def _sf_json(cmd: list[str]) -> dict:
    """sf CLI 명령을 `--json`으로 실행하고 그 `result` 객체를 반환하는 내부 도우미.

    입력:
        cmd — 실행할 sf CLI 인자 리스트. 끝에 `--json`이 자동으로 붙는다.
              예: ["sf", "org", "auth", "show-sfdx-auth-url", "--target-org", "myorg"]
    처리:
        subprocess로 명령을 실행하고 표준출력의 JSON을 파싱해 최상위 `result` 키를 꺼낸다.
        CLI가 없거나(FileNotFoundError) 0이 아닌 코드로 끝나면(CalledProcessError) 사람이 읽을
        오류 메시지와 함께 즉시 종료한다.
    반환:
        CLI 응답의 `result` 딕셔너리(그 안의 필드는 명령마다 다르다).
    """
    try:
        out = subprocess.run(cmd + ["--json"], capture_output=True, text=True, check=True).stdout
    except FileNotFoundError:
        sys.exit("오류: PATH에서 `sf` CLI를 찾지 못했습니다. Salesforce CLI를 먼저 설치하세요.")
    except subprocess.CalledProcessError as exc:
        sys.exit(f"오류: `{' '.join(cmd)}` 실패:\n{exc.stderr or exc.stdout}")
    return json.loads(out).get("result", {})


def resolve_auth(target_org: str | None) -> tuple[str, str, str | None]:
    """org에 접속할 (instance_url, access_token, username)을 얻는다 — 토큰은 새로 발급받는다.

    왜 이렇게 하나:
        최신 sf CLI(2.14x+)는 `sf org display`의 accessToken을 마스킹(`[REDACTED ...]`)해서 그대로는
        REST 호출에 쓸 수 없다. 그래서 `sf org auth show-sfdx-auth-url`로 마스킹되지 않은 SFDX Auth
        URL(refresh token 포함)을 받아, 그 refresh token으로 OAuth refresh_token 그랜트를 직접 호출해
        **새 access token**을 발급받는다. 이 방식은 CLI 버전의 마스킹 동작과 무관하게 항상 동작한다.

    입력:
        target_org — sf CLI org 별칭이나 사용자명. None이면 CLI에 설정된 기본 target-org를 쓴다.
    처리:
        1) `sf org display`로 instanceUrl과 username을 읽는다(이 둘은 마스킹되지 않는다).
        2) `sf org auth show-sfdx-auth-url`로 `force://<clientId>:<secret>:<refreshToken>@<host>`
           형식의 Auth URL을 받아 파싱한다.
        3) 그 host의 `/services/oauth2/token`에 refresh_token 그랜트를 POST한다. CLI 기본 연결
           앱(clientId=PlatformCLI)은 공개 클라이언트라 client_secret은 비어 있으므로 아예 보내지
           않는다(빈 값으로 보내면 invalid_client로 거부된다).
    반환:
        (instance_url, access_token, username) 튜플.
        - instance_url: 이후 모든 REST 호출의 베이스 호스트(끝의 '/'는 제거).
        - access_token: refresh로 새로 받은, 실제로 유효한 Bearer 토큰.
        - username: 로그와 veto 사전 점검(권한 집합 조회)에 쓰는 접속 사용자명(없으면 None).
    """
    base = ["sf", "org", "display"] + (["--target-org", target_org] if target_org else [])
    info = _sf_json(base)
    instance_url = (info.get("instanceUrl") or "").rstrip("/")
    username = info.get("username")

    au_cmd = ["sf", "org", "auth", "show-sfdx-auth-url"] + (["--target-org", target_org] if target_org else [])
    auth_url = _sf_json(au_cmd).get("sfdxAuthUrl", "")
    match = re.match(r"force://([^:]+):([^:]*):([^@]+)@(.+)", auth_url)
    if not match:
        sys.exit("오류: SFDX Auth URL을 파싱하지 못했습니다. `sf org login` 상태를 확인하세요.")
    client_id, _client_secret, refresh_token, host = match.groups()
    token_host = host if host.startswith("http") else f"https://{host}"

    # 공개 클라이언트(PlatformCLI)이므로 client_secret은 생략한다.
    form = urllib.parse.urlencode(
        {"grant_type": "refresh_token", "client_id": client_id, "refresh_token": refresh_token}
    ).encode()
    try:
        with urllib.request.urlopen(
            urllib.request.Request(f"{token_host}/services/oauth2/token", data=form)
        ) as resp:
            token = json.load(resp)
    except urllib.error.HTTPError as exc:
        sys.exit(f"오류: 토큰 갱신 실패 ({exc.code}): {exc.read().decode()[:300]}")
    return (token.get("instance_url") or instance_url).rstrip("/"), token["access_token"], username


def md5_of(path: str) -> str:
    """파일 내용의 MD5 해시를 계산한다.

    입력:
        path — 로컬 파일의 경로.
    처리:
        메모리를 아끼려고 1MB씩 스트리밍하며 MD5를 갱신한다(큰 파일도 안전).
    반환:
        MD5 16진 문자열. Salesforce가 ContentVersion.Checksum에 저장하는 값과 동일해서,
        "이 내용이 org에 이미 있는가"를 판별하는 org 측 중복 제거 키로 그대로 쓸 수 있다.
    """
    digest = hashlib.md5()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def enumerate_files(source_dir: str) -> list[str]:
    """소스 디렉터리를 재귀 순회하며 업로드 대상 파일의 절대 경로를 파일 이름 오름차순으로 모은다.

    입력:
        source_dir — 스캔할 최상위 디렉터리 경로.
    처리:
        os.walk로 하위 폴더까지 모두 순회하고, 확장자가 TARGET_EXTENSIONS에 든 파일만 남긴다.
        정렬 기준은 **파일 이름(basename) 오름차순**이다(하위 폴더 경로가 순서를 흔들지 않도록). 같은
        이름이 여러 폴더에 있으면 전체 경로를 2차 기준으로 써서 실행마다 순서가 재현되게 한다. 이
        순서가 --limit로 "앞에서부터 N개"를 자를 때의 기준이 된다.
    반환:
        업로드 대상 파일의 절대 경로 리스트(파일 이름 오름차순). 대상이 없으면 빈 리스트.
    """
    found = [
        os.path.abspath(os.path.join(root, name))
        for root, _dirs, files in os.walk(source_dir)
        for name in files
        if (name.rsplit(".", 1)[-1].lower() if "." in name else "") in TARGET_EXTENSIONS
    ]
    found.sort(key=lambda p: (os.path.basename(p), p))
    return found


def chunked(items: list, size: int):
    """리스트를 size 크기의 연속된 조각으로 나눠 하나씩 내보내는 제너레이터.

    입력:
        items — 나눌 리스트. size — 조각 하나의 최대 길이.
    처리/반환:
        items[0:size], items[size:2*size], ... 를 차례로 yield한다. Composite Collections(200건)나
        SOQL IN 목록(URL 길이 제한)을 배치로 처리할 때 쓴다.
    """
    for i in range(0, len(items), size):
        yield items[i : i + size]


def soql_in(values) -> str:
    """문자열들을 SOQL `IN (...)` 절에 넣을 따옴표 목록으로 만든다.

    입력:
        values — 문자열 이터러블(예: 체크섬 목록, ContentDocumentId 목록).
    처리:
        각 값을 작은따옴표로 감싸고, 값 안의 작은따옴표는 백슬래시로 이스케이프해 SOQL 인젝션을 막는다.
    반환:
        "'a', 'b', 'c'" 형태의 문자열. 호출부에서 `... IN ({soql_in(...)})`로 끼워 넣는다.
    """
    return ", ".join("'" + v.replace("'", "\\'") + "'" for v in values)


def multipart(filename: str, data: bytes) -> tuple[bytes, str]:
    """ContentVersion 업로드용 multipart/form-data 본문을 만든다.

    입력:
        filename — 올릴 파일명(확장자 포함). Title과 PathOnClient에 함께 넣어, 이후 백필/조회가
                   기대하는 파일명 형태를 만든다. data — 파일의 원본 바이트.
    처리:
        Salesforce의 blob-insert 규약대로 두 개의 파트를 조립한다:
          (1) entity_content 파트 — {"Title", "PathOnClient"} JSON,
          (2) VersionData 파트 — 파일 바이너리(Content-Type은 확장자로 추정, 실패 시 octet-stream).
        경계 문자열(boundary)은 충돌을 피하려고 매번 UUID로 새로 만든다.
    반환:
        (본문 bytes, boundary 문자열) 튜플. 호출부는 boundary를 Content-Type 헤더에 넣어야 한다.
    """
    boundary = "----MIBulk" + uuid.uuid4().hex
    content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    entity = json.dumps({"Title": filename, "PathOnClient": filename})
    head = (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="entity_content";\r\n'
        "Content-Type: application/json\r\n\r\n"
        f"{entity}\r\n"
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="VersionData"; filename="{filename}"\r\n'
        f"Content-Type: {content_type}\r\n\r\n"
    ).encode("utf-8")
    return head + data + f"\r\n--{boundary}--\r\n".encode(), boundary


# --------------------------------------------------------------------------- REST 클라이언트


class Client:
    """인증된 org 연결 하나를 감싸는 얇은 async REST 클라이언트.

    Bearer 토큰은 생성 시 넘긴 httpx.AsyncClient의 기본 헤더에 이미 실려 있으므로, 각 메서드는
    URL과 본문만 신경 쓴다. instance/base는 REST 엔드포인트 URL을 조립하는 데 쓴다.
    """

    def __init__(self, http: httpx.AsyncClient, instance: str, api: str):
        """
        입력:
            http     — Authorization 헤더가 설정된 httpx.AsyncClient(연결 풀·타임아웃 포함).
            instance — org 인스턴스 URL(예: https://xxx.my.salesforce.com).
            api      — API 버전 문자열(예: '67.0').
        처리:
            이후 호출에 재사용할 REST 베이스 URL(`{instance}/services/data/v{api}`)을 미리 만든다.
        """
        self.http = http
        self.instance = instance
        self.base = f"{instance}/services/data/v{api}"

    async def query(self, soql: str) -> list[dict]:
        """SOQL 쿼리를 실행하고 모든 페이지를 이어붙여 레코드를 반환한다.

        입력:
            soql — 실행할 SOQL 문자열.
        처리:
            GET /query 로 첫 페이지를 받고, 응답에 nextRecordsUrl이 있으면 없어질 때까지 따라가며
            records를 누적한다. 200이 아니면 상태 코드와 본문을 담아 예외를 던진다.
        반환:
            레코드(dict) 리스트. 각 dict의 키는 SELECT한 필드명이다.
        """
        records: list[dict] = []
        url, params = f"{self.base}/query", {"q": soql}
        while url:
            resp = await self.http.get(url, params=params)
            if resp.status_code != 200:
                raise RuntimeError(f"SOQL 실패 ({resp.status_code}): {resp.text}")
            data = resp.json()
            records += data["records"]
            nxt = data.get("nextRecordsUrl")
            url, params = (f"{self.instance}{nxt}", None) if nxt else (None, None)
        return records

    async def upload(self, filename: str, data: bytes) -> httpx.Response:
        """파일 하나를 ContentVersion으로 올린다(링크 없는 orphan 상태).

        입력:
            filename — 파일명(확장자 포함). data — 파일 바이너리.
        처리:
            multipart() 본문을 만들어 POST /sobjects/ContentVersion 한다. FirstPublishLocationId를
            넣지 않으므로 어떤 레코드에도 자동 연결되지 않는다 → 이 단계에서는 파일 트리거가 뜨지 않는다.
        반환:
            httpx.Response 원본(상태 코드와 JSON을 호출부가 직접 해석한다). 성공 시 본문에 새
            ContentVersion의 "id"가 담긴다.
        """
        body, boundary = multipart(filename, data)
        return await self.http.post(
            f"{self.base}/sobjects/ContentVersion",
            headers={"Content-Type": f'multipart/form-data; boundary="{boundary}"'},
            content=body,
        )

    async def insert(self, records: list[dict]) -> list[dict]:
        """Composite sObject Collections로 여러 레코드를 한 번에 삽입한다.

        입력:
            records — 최대 200건의 레코드 dict 리스트. 각 dict는 {"attributes": {"type": ...}, 필드...}
                      형태여야 한다(여러 sObject 타입 혼합 가능).
        처리:
            allOrNone=false로 POST 한다 → 일부가 실패해도 나머지는 커밋되는 부분 성공 모드.
            HTTP 자체가 200/201이 아니면(요청 형식 오류 등) 예외를 던진다.
        반환:
            입력과 같은 순서의 결과 dict 리스트. 각 결과는 {"success": bool, "id": ..., "errors": [...]}.
            호출부는 순서로 입력 레코드와 결과를 짝지어 성공/실패를 가른다.
        """
        resp = await self.http.post(
            f"{self.base}/composite/sobjects", json={"allOrNone": False, "records": records}
        )
        if resp.status_code not in (200, 201):
            raise RuntimeError(f"Collections 삽입 실패 ({resp.status_code}): {resp.text}")
        return resp.json()

    async def delete(self, sobject: str, record_id: str) -> None:
        """레코드 하나를 삭제한다(veto 확인용 임시 파일 정리에만 사용).

        입력:
            sobject — 오브젝트 API 이름(예: 'ContentDocument'). record_id — 삭제할 레코드 Id.
        처리/반환:
            DELETE /sobjects/{sobject}/{id} 를 호출한다. best-effort라 결과는 따로 검사하지 않는다.
        """
        await self.http.delete(f"{self.base}/sobjects/{sobject}/{record_id}")


# --------------------------------------------------------------------------- 단계별 작업


async def veto_preflight(client: Client, username: str | None) -> None:
    """업로드 사용자가 Data Cloud 파일 veto에 걸릴지 미리 확인하고, 걸리면 즉시 중단한다.

    veto가 무엇인지: 파일 상단 VETO_PERMISSION 주석에 자세히 설명돼 있다. 요약하면, 업로드한 파일이
    생성은 되지만 업로더에게는 조회되지 않아 ContentDocumentId를 얻지 못하고 레코드에 연결할 수 없게
    되는 상황이다. 12,000개를 올린 뒤에야 발견하면 큰 낭비이므로, 시작 전에 두 가지로 검사한다.

    입력:
        client   — 인증된 REST 클라이언트. username — 접속 사용자명(None이면 권한 조회는 건너뛴다).
    처리:
        (a) 정적 점검 — 이 사용자에게 할당된 권한 집합 중 VETO_PERMISSION을 부여하는 것이 있는지 SOQL로
            확인한다. 있으면, 그 권한을 사람 업로더가 아닌 전용 인덱싱 사용자에게 옮기라는 안내와 함께 중단.
        (b) 동작 점검 — 아주 작은 파일 하나를 실제로 올리고, 2초 뒤 별도 요청으로 다시 조회한다. Id는
            돌아왔는데 재조회가 0건이면 veto가 실제로 걸린 것이므로 중단한다(사고 문서의 "30초 판별법").
            확인용 파일은 끝에 삭제한다.
    반환:
        없음. 통과하면 조용히 리턴하고, 걸리면 sys.exit로 프로세스를 끝낸다(이후 대량 업로드로 진행 안 함).
    """
    if username:  # (a) 할당된 권한 집합 중 veto 권한을 부여하는 것이 있는가?
        rows = await client.query(
            "SELECT PermissionSet.Name FROM PermissionSetAssignment "
            f"WHERE Assignee.Username = '{username.replace(chr(39), chr(92) + chr(39))}' "
            f"AND PermissionSet.{VETO_PERMISSION} = true"
        )
        if rows:
            names = ", ".join(r["PermissionSet"]["Name"] for r in rows)
            sys.exit(
                f"오류: 업로드 사용자가 {VETO_PERMISSION} 권한을 보유합니다(경로: {names}). "
                "이 권한은 사람 업로더가 아니라 전용 Data Cloud 인덱싱 통합 사용자에게만 부여한 뒤 다시 실행하세요. "
                "docs/deployment/file-upload-vetoing-incident.md 참고."
            )

    # (b) 동작 확인: 작은 파일을 올린 뒤 별도 요청으로 재조회. Id는 오는데 0건이면 veto(사고 문서의 30초 판별법).
    marker = f"mi-veto-probe-{uuid.uuid4().hex}.txt"
    resp = await client.upload(marker, b"veto-probe")
    if resp.status_code not in (200, 201) or not resp.json().get("id"):
        sys.exit(f"오류: veto 확인용 업로드 실패 ({resp.status_code}): {resp.text}")
    await asyncio.sleep(2)
    rows = await client.query(
        f"SELECT Id, ContentDocumentId FROM ContentVersion WHERE Id = '{resp.json()['id']}'"
    )
    if not rows:
        sys.exit(
            "오류: veto 확인 실패 — 파일이 생성됐지만 별도 요청에서 조회되지 않습니다(Data Cloud 파일 veto). "
            "docs/deployment/file-upload-vetoing-incident.md 대로 QueryNonVetoedFiles를 업로더에서 제거 후 재실행하세요."
        )
    if rows[0].get("ContentDocumentId"):
        await client.delete("ContentDocument", rows[0]["ContentDocumentId"])  # 확인용 파일 정리
    print("veto 확인 통과.")


async def resolve_cdids(client: Client, docs: list[Doc]) -> None:
    """각 파일의 org 측 ContentDocumentId(doc.cdid)를 체크섬 매칭으로 채운다(제자리 수정).

    입력:
        client — REST 클라이언트. docs — 대상 파일들(각 doc.md5는 이미 계산돼 있어야 한다).
    처리:
        같은 내용(같은 MD5)의 파일이 여러 개일 수 있으므로 먼저 md5 → [Doc] 로 묶는다. 그 md5 목록을
        200개씩 나눠 `ContentVersion.Checksum IN (...)` 로 조회하고, 돌아온 ContentDocumentId를 같은
        체크섬을 가진 모든 Doc에 채운다. org에 없는 파일의 cdid는 None으로 남는다(= 아직 업로드 필요).
    반환:
        없음. docs의 각 원소 cdid를 직접 갱신한다(부수효과 함수).
    """
    by_md5: dict[str, list[Doc]] = {}
    for doc in docs:
        by_md5.setdefault(doc.md5, []).append(doc)
    for batch in chunked(list(by_md5), CHUNK):
        rows = await client.query(
            "SELECT ContentDocumentId, Checksum FROM ContentVersion "
            f"WHERE IsLatest = true AND Checksum IN ({soql_in(batch)})"
        )
        for row in rows:
            for doc in by_md5.get(row["Checksum"], []):
                doc.cdid = row["ContentDocumentId"]


async def linked_cdids(client: Client, cdids: list[str]) -> set[str]:
    """주어진 ContentDocument 중 이미 Market_Insight_Document__c에 연결된 것들을 찾는다(멱등성 검사).

    입력:
        client — REST 클라이언트. cdids — 확인할 ContentDocumentId 리스트.
    처리:
        200개씩 나눠, LinkedEntityId가 Market_Insight_Document__c인 ContentDocumentLink를 조회한다.
        이미 문서에 연결된 파일은 레코드/링크를 다시 만들면 안 되므로(중복 방지) 이 목록을 걸러낸다.
    반환:
        이미 연결된 ContentDocumentId들의 집합. 호출부는 이 집합에 없는 것만 새로 등록한다.
    """
    linked: set[str] = set()
    for batch in chunked(cdids, CHUNK):
        rows = await client.query(
            "SELECT ContentDocumentId FROM ContentDocumentLink "
            f"WHERE ContentDocumentId IN ({soql_in(batch)}) "
            "AND LinkedEntityId IN (SELECT Id FROM Market_Insight_Document__c)"
        )
        linked.update(r["ContentDocumentId"] for r in rows)
    return linked


async def upload_bytes(client: Client, sem: asyncio.Semaphore, doc: Doc) -> str | None:
    """파일 하나의 바이트를 ContentVersion으로 올린다(동시성 제한 + 재시도).

    입력:
        client — REST 클라이언트.
        sem    — 동시 업로드 수를 제한하는 세마포어(전체 동시 요청 수를 --workers로 묶는다).
        doc    — 올릴 파일(doc.path에서 바이트를 읽고 doc.name으로 업로드한다).
    처리:
        세마포어를 잡은 채 파일을 읽어 client.upload()를 호출한다. 실패가 일시적(재시도 대상 상태
        코드/오류 코드, 또는 네트워크 예외로 status=0)이면 지수 백오프(2·4·8…초, 최대 30초)로 최대
        MAX_RETRIES번 재시도한다. 영구 실패(예: 4xx)나 마지막 시도 실패면 즉시 오류를 반환한다.
    반환:
        성공하면 None. 실패하면 "[상태코드] 응답본문" 형태의 오류 문자열(호출부가 로그로 출력한다).
    """
    async with sem:
        with open(doc.path, "rb") as handle:
            data = handle.read()
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = await client.upload(doc.name, data)
                if resp.status_code in (200, 201) and resp.json().get("id"):
                    return None
                status, text = resp.status_code, resp.text
            except (httpx.HTTPError, OSError) as exc:
                status, text = 0, str(exc)
            retryable = status in RETRYABLE_STATUS or status == 0 or any(c in text for c in RETRYABLE_CODES)
            if attempt == MAX_RETRIES or not retryable:
                return f"[{status}] {text}"
            await asyncio.sleep(min(2**attempt, 30))


async def create_records(client: Client, docs: list[Doc], doc_type: str | None) -> tuple[int, int]:
    """파일마다 Market_Insight_Document__c 레코드를 만들고 그 파일을 문서에 연결한다.

    입력:
        client   — REST 클라이언트.
        docs     — 등록 대상 파일들(각 doc.cdid가 채워져 있어야 링크를 걸 수 있다).
        doc_type — 모든 레코드에 넣을 Document_Type__c 값(제한 선택 목록). None이면 이 필드를 비운다.
    처리:
        200건씩 배치로 나눠 두 번의 Collections INSERT를 한다:
          1) Market_Insight_Document__c 레코드 — Name(파일명 80자 절단), File_Name__c(전체 파일명),
             (doc_type이 있으면) Document_Type__c. 이는 LWC 업로드 경로와 동일한 형태다.
          2) 문서 생성에 성공한 항목만 ContentDocumentLink(ShareType 'V')로 파일과 문서를 연결.
             링크 INSERT가 트리거를 깨워 Facet 생성(및 스위치가 켜져 있으면 표 추출)이 시작된다.
        문서 생성 실패, 링크 실패는 각각 실패로 집계한다.
    반환:
        (created, failed) 튜플.
        - created: 문서 생성 + 링크까지 성공한 파일 수.
        - failed:  문서 생성 실패 + 링크 실패의 합(어느 단계든 실패하면 그 파일은 미완성으로 본다).
    """
    created = failed = 0
    for batch in chunked(docs, CHUNK):
        records = [
            {
                "attributes": {"type": "Market_Insight_Document__c"},
                "Name": doc.name[:NAME_MAX],
                "File_Name__c": doc.name,
                **({"Document_Type__c": doc_type} if doc_type else {}),
            }
            for doc in batch
        ]
        links = []
        for doc, result in zip(batch, await client.insert(records)):
            if result.get("success"):
                links.append(
                    {
                        "attributes": {"type": "ContentDocumentLink"},
                        "ContentDocumentId": doc.cdid,
                        "LinkedEntityId": result["id"],
                        "ShareType": "V",
                    }
                )
            else:
                failed += 1
        for result in await client.insert(links) if links else []:
            created += 1 if result.get("success") else 0
            failed += 0 if result.get("success") else 1
    return created, failed


# --------------------------------------------------------------------------- 전체 흐름


async def run(args: argparse.Namespace) -> int:
    """전체 등록 흐름을 지휘하는 비동기 진입점(바이트 업로드 → 레코드 → 링크).

    입력:
        args — argparse로 파싱한 CLI 옵션(source_dir, limit, document_type, target_org, workers,
               api_version, timeout, skip_veto_check, dry_run).
    처리(순서대로):
        1) 옵션 검증 — document_type이 제한 목록에 맞는지, source_dir이 실제 디렉터리인지 확인.
        2) 파일 열거(이름 오름차순) → --limit이 있으면 앞에서부터 그 개수만 남김 → 각 파일 MD5 계산.
        3) 인증(resolve_auth) → httpx.AsyncClient 생성(연결 풀·타임아웃·동시성 한도 설정).
        4) veto 사전 점검(--skip-veto-check면 생략).
        5) 멱등성: resolve_cdids로 이미 org에 있는 파일을 가려 업로드 대상만 추린다.
           dry_run이면 여기서 예정 내역만 출력하고 종료.
        6) 바이트 업로드(세마포어로 동시성 제한, 실패는 집계·로그). 업로드 후 새 파일의 cdid를 다시 채운다.
        7) 해석된 파일 중 아직 문서에 연결 안 된 것만 골라 create_records로 레코드+링크 생성.
        8) 요약 출력(성공/실패 수)과 후속 안내(Facet 진행 확인, 표 추출 캐치업).
    반환:
        프로세스 종료 코드. 업로드나 레코드 생성에 실패가 하나라도 있으면 1, 모두 성공/생략이면 0.
    """
    if args.document_type and args.document_type not in DOCUMENT_TYPE_VALUES:
        sys.exit(f"오류: --document-type은 {', '.join(sorted(DOCUMENT_TYPE_VALUES))} 중 하나여야 합니다(또는 생략).")
    source_dir = os.path.abspath(args.source_dir)
    if not os.path.isdir(source_dir):
        sys.exit(f"오류: --source-dir이 디렉터리가 아닙니다: {source_dir}")

    paths = enumerate_files(source_dir)
    if not paths:
        print(f"업로드 대상({', '.join(sorted(TARGET_EXTENSIONS))})을 {source_dir} 아래에서 찾지 못했습니다.")
        return 0
    total_found = len(paths)
    # --limit: 파일 이름 오름차순으로 앞에서부터 N개만 이번 실행 대상으로 자른다. 나머지는 다음 실행에서
    # (역시 앞에서부터) 이어서 처리하면 되고, org 기준 멱등성 덕분에 이미 올린 것은 자동으로 건너뛴다.
    if args.limit is not None and args.limit >= 0:
        paths = paths[: args.limit]
    if len(paths) < total_found:
        print(f"{source_dir} 아래에서 {total_found}개 발견 → 이번 실행은 이름순 앞에서부터 {len(paths)}개만 처리합니다.")
    else:
        print(f"{source_dir} 아래에서 {len(paths)}개를 찾았습니다.")
    print("해시 계산 중...")
    docs = [Doc(p, md5_of(p)) for p in paths]

    instance, token, user = resolve_auth(args.target_org)
    limits = httpx.Limits(max_connections=args.workers, max_keepalive_connections=args.workers)
    async with httpx.AsyncClient(
        headers={"Authorization": f"Bearer {token}"}, timeout=args.timeout, limits=limits
    ) as http:
        client = Client(http, instance, args.api_version)
        print(f"{instance}에 {user or '(사용자 미상)'}(으)로 인증됨.")
        if not args.skip_veto_check:
            await veto_preflight(client, user)

        # org에 이미 있는 것은 업로드 생략(멱등성).
        await resolve_cdids(client, docs)
        to_upload = [d for d in docs if not d.cdid]
        if len(docs) - len(to_upload):
            print(f"이미 org에 있는 {len(docs) - len(to_upload)}개는 업로드를 건너뜁니다.")

        if args.dry_run:
            print(f"[dry-run] 바이트 {len(to_upload)}개를 올리고, 미연결 파일에 레코드+링크를 만들 예정. 변경 없음.")
            return 0

        upload_failed = 0
        if to_upload:
            sem = asyncio.Semaphore(args.workers)
            print(f"{len(to_upload)}개를 최대 {args.workers}개 동시 요청으로 업로드합니다...")
            tasks = {asyncio.create_task(upload_bytes(client, sem, d)): d for d in to_upload}
            for task in asyncio.as_completed(tasks):
                error = await task
                if error:
                    upload_failed += 1
                    print(f"  실패 {tasks[task].name}: {error}")
            print(f"바이트 업로드: 성공={len(to_upload) - upload_failed} 실패={upload_failed}")
            await resolve_cdids(client, to_upload)  # 방금 올린 것의 ContentDocumentId 채우기

        # 해석된 것 중, 아직 문서에 연결되지 않은 파일만 레코드+링크 생성.
        # already: 이미 문서에 연결된 ContentDocumentId(재실행 시 중복 생성 방지).
        # seen:    이번 실행에서 같은 ContentDocumentId를 두 번 등록하지 않도록 하는 중복 방지 집합
        #          (같은 내용의 파일이 여러 개면 체크섬이 같아 cdid도 같아진다).
        resolvable = [d for d in docs if d.cdid]
        already = await linked_cdids(client, [d.cdid for d in resolvable])
        seen: set[str] = set()
        to_register: list[Doc] = []
        for doc in resolvable:
            cdid = doc.cdid  # resolvable 필터로 여기서는 None이 아님(타입 좁히기 + 가독성).
            if cdid is None or cdid in already or cdid in seen:
                continue
            seen.add(cdid)
            to_register.append(doc)
        if len(resolvable) - len(to_register):
            print(f"이미 연결됐거나 내용이 중복인 {len(resolvable) - len(to_register)}개는 레코드 생성을 건너뜁니다.")

        created, record_failed = await create_records(client, to_register, args.document_type) if to_register else (0, 0)

    print(f"\n완료. 업로드성공={len(to_upload) - upload_failed} 문서연결={created} 업로드실패={upload_failed} 레코드실패={record_failed}")
    print("Facet 생성은 파일 트리거가 시작합니다(Extraction_Status__c 확인). 표 추출을 껐다면 적재 후 "
          "MI_TabularBackfillBatch로 채우세요(README 참고).")
    return 1 if (upload_failed or record_failed) else 0


def main() -> int:
    """CLI 인자를 정의·파싱하고 asyncio 이벤트 루프에서 run()을 실행하는 동기 진입점.

    입력:
        없음(sys.argv를 argparse가 읽는다).
    처리:
        옵션을 정의하고 파싱한 뒤 asyncio.run(run(args))로 비동기 흐름을 돌린다.
    반환:
        run()이 준 종료 코드(0=성공, 1=일부 실패). __main__에서 SystemExit로 그대로 넘긴다.
    """
    parser = argparse.ArgumentParser(
        description="파일을 Salesforce에 통째로 등록(바이트 + Market_Insight_Document__c + 링크)."
    )
    parser.add_argument("--source-dir", required=True, help="재귀 순회할 소스 디렉터리.")
    parser.add_argument("--limit", type=int, default=None,
                        help="이번 실행에서 처리할 최대 파일 수(파일 이름 오름차순 앞에서부터). "
                             "생략하면 전체. 예: --limit 1000 으로 1000개씩 나눠 실행(멱등성으로 이어서 진행).")
    parser.add_argument("--document-type", default=None,
                        help="모든 레코드의 Document_Type__c(공시자료/외부보고서/증권사보고서/컨설팅보고서/내부보고서). 생략 가능.")
    parser.add_argument("--target-org", default=None, help="sf CLI org 별칭/사용자명.")
    parser.add_argument("--workers", type=int, default=8, help="바이트 업로드 최대 동시 요청 수.")
    parser.add_argument("--api-version", default="67.0", help="Salesforce API 버전.")
    parser.add_argument("--timeout", type=float, default=120.0, help="요청당 타임아웃(초).")
    parser.add_argument("--skip-veto-check", action="store_true", help="파일 veto 사전 점검을 건너뛴다.")
    parser.add_argument("--dry-run", action="store_true", help="무엇을 할지만 출력하고 아무것도 바꾸지 않는다.")
    return asyncio.run(run(parser.parse_args()))


if __name__ == "__main__":
    raise SystemExit(main())
